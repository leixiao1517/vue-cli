<template>
    <div class="mask-tip" @click="hideTip()">
        <tips :content="content"></tips>
    </div>
</template>
<script>
    import tips from './tips.vue'
    export default {
        components: {
            tips
        },
        data() {
            return {
                content:"我知道了"
            }
        },
        methods: {
            hideTip:function(){
                $(".mask-tip").hide()
            }
        },
        mounted() {
            $(".mask-tip").height($(window).height())
            $(".mask-tip").width($(window).width())
        }
    }
</script>
