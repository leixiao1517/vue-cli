<template>
    <div>
        <div class="tip-desc">
            <div class="vux-popover-arrow" :class="position"></div>
            <div>
                <div class="popover-demo-content">
                    {{content}}
                </div>
            </div>
        </div>
    </div>
</template>
<script>
    export default {
        components: {

        },
        data() {
            return {}
        },
        props:['position','content'],
        methods: {
        },
        mounted() {
            setTimeout(function () {
                $(".tip-desc").fadeOut(500)
            },5000)
        }
    }
</script>
