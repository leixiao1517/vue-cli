<!--公共列表样式1 调用方式-->
<!--<comm-item url="/publishMeeting"-->
           <!--imgSrc="http://192.168.1.210:8088/static/img/noservice-inner.c58bce5.jpg"-->
           <!--type="doc"-->
           <!--info1="习近平会见俄罗斯总统"-->
           <!--info2="韩林"-->
           <!--info3="党建工作部"-->
           <!--info4="2018-12-01">-->
<!--</comm-item>-->

<template>
<div class="comm-item-1" @click="toUrl">
<!--<div class="c-img">-->
            <!--<img src="../../assets/images/breakGame/noservice-inner.jpg" alt="">-->
        <!--</div>-->
        <!--<div class="c-info">-->
            <!--<p class="o-webkit-line2">习近平会见俄罗斯总统</p>-->
            <!--<div class="author">-->
                <!--<div>韩林 [党建工作部]</div>-->
                <!--<div>2018-12-01</div>-->
            <!--</div>-->
        <!--</div>-->

        <div class="c-img">
            <img :class="fit" :src="_imgSrc" alt="">
        </div>
        <div class="c-info">
            <p class="o-webkit-line2">{{info1}}</p>
            <div class="author">
                <div>{{info2}} {{_info3}}</div>
                <div>{{info4}}</div>
            </div>
        </div>

        <slot></slot>
    </div>
</template>
<script>
    export default {
        components: {

        },
        data() {
            return {
                ppt: require('../../assets/images/common/resourceType/icon-resource-ppt.jpg'),
                pdf: require('../../assets/images/common/resourceType/icon-resource-pdf.jpg'),
                word: require('../../assets/images/common/resourceType/icon-resource-word.jpg'),
                other: require('../../assets/images/common/resourceType/icon-resource-other.jpg'),
                fit: "fit"
            }
        },
        props:['url','imgSrc','type','info1','info2','info3','info4'],//参数含义见头部例子
        methods: {
            toUrl(){
                if(this.url){
                    this.$router.push(this.url)
                }
            }
        },
        computed: {
            _imgSrc :function () {
                let imgSrc = this.imgSrc
                let type = this.type.toLowerCase()
                if(null == imgSrc || '' == imgSrc || imgSrc.indexOf("other") > 0){ //如果封面不存在
                    if(type=='ppt'||type=='pptx'){
                        return this.ppt
                    }else if(type=='pdf'){
                        return this.pdf
                    }else if(type=='doc'||type=='docx'){
                        return this.word
                    }else if(type=='mp4'||type=='jpg'||type=='jpeg'){//传的是链接
                        this.fit = ""
                        return imgSrc
                    }else{
                        return this.other
                    }
                } else {
                    this.fit = ""
                    return imgSrc
                }
            },
            _info3 :function () {
                let info3 = this.info3
                if(info3){
                    if(info3.length>7){
                        info3 = info3.substring(0,7) + '...'
                    }
                    return '['+info3+']'
                }else {
                    return ''
                }
            }
        },
        mounted() {

        }
    }
</script>

<style lang="less">
    .comm-item-1{
        display: flex;
        padding: 15px;
        background: white;
        border-bottom: 1px solid #ececec;
        .c-img{
            width: 30%;
            img{
                width: 100%;
                height: 74px;
            }
        }
        .c-info{
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            flex: 1;
            padding-left: 10px;
            p{
                font-size: 16px;
                color: #424242;
            }
            .author{
                display: flex;
                justify-content: space-between;
                font-size: 12px;
                color: #8c8c8c;
                div{

                }
            }
        }
        .fit{
            object-fit: fill;
        }
    }
</style>
