<!--起始页开始-->
<template>
    <section class="myRank">

        <div class="comm-head-logo">
            <div class="logo">
                <img src="../../assets/images/common/icon-logo.png" alt="">
            </div>
            <div class="back" @click="toIndex">
                回到首页
            </div>
        </div>

        <div class="rankItem">
            <tab bar-active-color="#c3373a" custom-bar-width="80px" :line-width="2">
                <tab-item selected @on-item-click="onItemClick(1)">个人排名</tab-item>
                <tab-item @on-item-click="onItemClick(2)">支部排名</tab-item>
            </tab>
        </div>

        <div class="topSeat">
        </div>

        <!-- 个人排名 -->
        <div class="topRank" id = "rank0">
            <div class="listRank" v-for="(value,index) in explicitRank">
                <b> {{ value.userName }}</b>
                <span v-if="index > 2">第{{ index+1 }}名</span>
                <h5>总学分&nbsp;:<span>&nbsp;{{ value.credits }}</span></h5>
            </div>
        </div>

        <!--支部排名 -->
        <div class="topRank" style="display: none" id = "rank1">
            <div class="listRank" v-for="(value,index) in partyList">
                <b class="o-ellipsis"> {{ value.partyName }}</b>
                <span v-if="index > 2">第{{ index+1 }}名</span>
                <h5>总学分&nbsp;:<span>&nbsp;{{ value.credits }}</span></h5>
            </div>
        </div>


        <div class="checkRank" id="rank00">
                <span v-if="mineRank.rank != undefined ">个人排名&nbsp;:&nbsp;<b>第 {{ mineRank.rank }} 名</b></span>
                <span v-else>个人排名&nbsp;:&nbsp;<b>暂无排名</b></span>
        </div>

        <div class="checkRank" style="display: none" id="rank11">
            <span >党委总学分&nbsp;:&nbsp;&nbsp;<b> {{ totalParty }}</b></span>
            <!--<span v-else>个人排名&nbsp;:&nbsp;<b>暂无排名</b></span>-->
        </div>



        <div class="no-data" v-if="explicitRank.length == 0"><p>没有排名数据</p></div>
        <div class="seat"></div>
    </section>

</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import { getRankByUid,getPartyRank} from '../../api/api'
    import { Tab, TabItem } from 'vux'

    export default {
        components: {
            Tab,
            TabItem
        },
        data() {
            return {
                    explicitRank:['userName','credits'],
                    mineRank:"",
                    partyList:['partyName','credits'],
                    totalParty:0

            }
        },
        methods: {
            onItemClick(type) {
                if(type == 1){
                    $("#rank0").show();
                    $("#rank00").show();
                    $("#rank1").hide();
                    $("#rank11").hide();
                }
                if(type == 2){
                    $("#rank0").hide();
                    $("#rank00").hide();
                    $("#rank1").show();
                    $("#rank11").show();
                }
            },
            toIndex: function () {
                this.$router.push('/index')
            }
        },
        mounted() {
            $(".centerBg,.checkRank").width($(window).width());
            $(".myRank").height($(window).height());
            let _self = this;
            getRankByUid({}).then(data=>{
                console.log('getRankByUid',data);
                _self.explicitRank = data.data.list;
                _self.mineRank = data.data;
                console.log("++++++"+self.mineRank)
            })

            getPartyRank({}).then(data=>{
                _self.partyList = data.data.list;
                console.log('++++++++++++++',_self.partyList);
                _self.totalParty =  data.data.totalParty
            })




        }
    }




</script>

<style lang="less">
    .myRank{

        .topSeat{
            height:0.2rem;
        }
        .topRank{
            /*background-color:white;*/
        }
        .listRank{
            height:1rem;
            border-bottom:1px solid #ebe7db;
            background-color:white;
            position:relative;
        }
        .listRank>b{
            float:left;
            line-height:1rem;
            font-size:12px;
            font-weight:normal;
            margin-left:0.63rem;
        }
        .listRank>img{
            height:0.5rem;
            width:0.675rem;
            float:left;
            position:absolute;
            left:3.2rem;
            top:0.25rem;
        }
        .listRank>h5{
            float:right;
            margin-right:0.01rem;
            line-height:1rem;
            font-size:14px;
            font-weight:normal;
            width:2.0rem;
            text-align:left;
        }
        .listRank>span{
            line-height:1rem;
            font-size:12px;
            margin-left:1.8rem;
            position:absolute;
            left:2.35rem;

        }
        .listRank>h5>span{
            color:#b2413d;
        }
        .centerBg{
            margin-top:0.2rem;
            height:1.3rem;
        }
        .checkRank{
            background:url("../../assets/images/credit/10.jpg") no-repeat;
            background-size:cover;
            position:fixed;
            bottom:0;
            height:1.6rem;
            border-top:1px solid #ebe7db;
            width:100%;
        }
        .seat{
            height:1.6rem;
            width:100%;
        }
        .checkRank>span{
            float:right;
            line-height:1rem;
            font-size:0.3rem;
            margin-top:0.3rem;
            margin-right:0.3rem;
        }
        .checkRank>span>b{
            color:#b2413d;
            font-size:0.35rem;
        }
        .listRank:first-child{
            background:url(../../assets/images/credit/1.png) no-repeat;
            background-size:0.675rem 0.5rem;
            background-position:4.1rem 0.25rem;
            background-color:white;
        }
        .listRank:first-child>span{
            display:none;
        }
        .listRank:nth-child(2){
            background:url(../../assets/images/credit/2.png) no-repeat;
            background-size:0.675rem 0.5rem;
            background-position:4.1rem 0.25rem;
            background-color:white;
        }
        .listRank:nth-child(2)>span{
            display:none;
        }
        .listRank:nth-child(3){
            background:url(../../assets/images/credit/3.png) no-repeat;
            background-size:0.675rem 0.5rem;
            background-position:4.1rem 0.25rem;
            background-color:white;
        }
        .listRank:nth-child(3)>span{
            display:none;
        }
        .listRank:nth-child(4){
            margin-top:0.2rem;
        }
        .seat{
            height:1.6rem;
        }
        .vux-tab .vux-tab-item.vux-tab-selected{
            color:#c3373a;
        }


    }
</style>
