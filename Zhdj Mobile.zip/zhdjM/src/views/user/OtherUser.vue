<template>
    <section class="other-user">
        <!-- 头部信息 -->
        <div class="head">
            <img class="head-back" src="../../assets/images/user/top_back.png">
            <div class="head-img">
                <img :src="userModel.headImg | imgPath">
            </div>
            <div class="user-info">
                <div>{{userModel.userName}}</div>
                <div>党内职务：{{userModel.roleName}}</div>
                <div>单位职务：{{userModel.uniter}}</div>
            </div>
            <div class="like">关注ta</div>
        </div>
        <!-- 概览信息 -->
        <div class="info">
            <div>参加{{userModel.meetCount}}个会议</div><div>发表{{userModel.articleCount}}篇文章</div><div>{{userModel.follow}}人关注</div>
        </div>

        <!-- 列表信息 -->
        <div class="list">
            <flexbox orient="vertical" v-for="(article ,index) in articles" :key="index">
                <flexbox-item><div class="flex-demo">{{article.title}}</div></flexbox-item>
                <flexbox-item><div class="mini-font mt10 flex-demo">人数：{{article.count}}</div></flexbox-item>
                <flexbox-item><div class="mini-font flex-demo">{{article.createTime | dateFormat}}</div></flexbox-item>
            </flexbox>
        </div>
        <!-- 悬浮筛选信息 -->
        <div class="filter">
            <flexbox orient="vertical" v-for="(filter ,index) in filters" :key="index">
                <flexbox-item><div class="flex-demo">{{filter}}</div></flexbox-item>
            </flexbox>
        </div>
    </section>
</template>

<script>
    import { Flexbox, FlexboxItem,} from 'vux'

    export default {
        components: {
            Flexbox,
            FlexboxItem,
        },
        data() {
            return {
                userModel: {
                    userName:'古月',
                    headImg:'http://shp.qpic.cn/bizmp/NTS9mLiabFPK8Y3leWESPZImYpiarwJz2KxMM9mvy8lhbDUrRUHkfbUQ/132',
                    roleName:'党员',
                    uniter:'主任',
                    meetCount:22,
                    articleCount:12,
                    follow:32,
                },
                articles: [{
                    title: '标题一标题一标题一标题一标题一',
                    createTime: new Date(),
                    count:1
                }, {
                    title: '标题二标题一标题一标题一标题一标题一',
                    createTime: new Date(),
                    count:123
                }],
                filters:['条件1','条件2','条件3','条件4']
            }
        },
        methods: {

        },
        mounted() {
            let _self = this

        }
    }

</script>

<style lang="less">
    .other-user {
        .head {
            position: relative;
            width: 100%;
            height: 150px;
            .head-back{
                width:100%;
                height: 100%;
            }
            .head-img {
                position: absolute;
                width: 80px;
                height: 80px;
                margin-top: -0.7rem;
                top: 50%;
                left: 1rem;
                img {
                    width: 100%;
                    height: 100%;
                    border-radius: 50%;
                    border: #e5e5e5 1px solid;
                }
            }
            .user-info{
                position: absolute;
                margin-top: -0.7rem;
                top: 50%;
                left: 3rem;
                color: #ffffff;
                div{
                    margin-top: 5px;
                }
            }
            .like{
                position: absolute;
                width: 80px;
                line-height: 30px;
                text-align: center;
                right: 10px;
                top:20px;
                border-radius: 5px;
                border: 1px solid #D0021B;
                background: #ffffff;
                color: #D0021B;
            }
        }
        .info{
            display: flex;
            div{
                flex: 1;
                line-height: 30px;
                text-align: center;
                background: #D0021B;
                border-right: 1px solid #C00018;
                color: #ffffff;
            }
        }
        .info > div:last-child{
            border-right: 0 ;
        }
        .list{
            padding-left: 10px;
            background: #ffffff;
            font-size: 16px;
            color: #000000;
            .vux-flexbox{
                border-bottom: solid 1px #F2F2F2;
                padding: 10px 0 10px 0;
            }
            .mini-font{
                font-size: 12px;
                color: #4A4A4A;
            }
        }
        .filter{
            position: fixed;
            width: 90px;
            line-height: 30px;
            right:10px;
            top:200px;
            border-top: solid 1px #F2F2F2;
            border-left: solid 1px #F2F2F2;
            border-right: solid 1px #F2F2F2;
            color: #9B9B9B;
            background: #ffffff;
            .vux-flexbox{
                text-align: center;
                border-bottom: solid 1px #F2F2F2;
            }
        }
    }
</style>
