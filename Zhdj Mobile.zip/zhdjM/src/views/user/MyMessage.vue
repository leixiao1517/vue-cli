<!--起始页开始-->
<template>
    <section class="myMessage">
        <div class="topMessage">
            <img src="../../assets/images/myMessage/2.png">
            <span>消息列表</span>
        </div>
        <ul class="tabMenu">
            <li class="tab1 active" @click="changeType($event,null)">全部消息</li>
            <li class="tab2" @click="changeType($event,1)">会议消息</li>
            <li class="tab3" @click="changeType($event,2)">任务消息</li>
        </ul>

        <div v-infinite-scroll="loadMessage" infinite-scroll-disabled="busy" infinite-scroll-distance="10">
            <div class="listMessage" v-for="(message, index) in messageList" :key="index" v-if="messageList.length > 0" @click="toUrl(message)">
                <div class="listType">
                    <span v-if="message.type == 1">会</span>
                    <span v-if="message.type == 2">任</span>
                </div>
                <div class="listContent">
                    <p><b>{{message.title}}</b><badge v-if="message.status == 1"></badge><span>{{message.createDate |dateFormat}}</span></p>
                    <div class="content o-ellipsis">{{message.content}}</div>
                </div>
            </div>
            <loading></loading>
            <div class="no-data" v-if="messageList.length == 0"><p>没有消息数据</p></div>
        </div>
    </section>
</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import { Tab,TabItem,Badge } from 'vux'
    import loading from '../../components/common/loading.vue'
    import {getMessageList,readMsg} from '../../api/api'


    export default {
        components: {
            Tab,
            TabItem,
            loading,
            Badge
        },

        data() {
            return {
                messageList:[],
                pageNo:1,
                size:15,
                totalPage:1,
                busy:false,
                type:Number,

            }
        },

        methods: {
            changeType:function(obj,type){
                $(obj.target).addClass("active").siblings().removeClass("active");
                this.type = type
                this.pageNo=1
                this.size=15
                this.totalPage=1
                this.busy=false
                this.messageList = []
                this.loadMessage()
            },
            toUrl:function(message){
                readMsg(message).then((response) => {
                    console.log(response)
                    if(response.success){
                        window.location.href = message.url
                    } else {
//                        this.$vux.toast.text(response.message, 'middle')
                    }
                }).catch((error) => {
                    console.log(error)
                })
            },
            //答题列表
            initMessageList:function () {
                let _self = this
                getMessageList({pageNo:_self.pageNo,size:_self.size, type:_self.type}).then((response) => {
                    console.log(response)
                    $(".load-more").hide();
                    if(response.success){
                        _self.messageList = _self.messageList.concat(response.data.rows);
                        _self.totalPage = response.data.pageCount;
                        _self.pageNo++;
                        _self.busy = false;
                    } else {
//                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }).catch((error) => {
                    console.log(error)
                })
            },
            loadMessage: function() {
                if(this.pageNo > this.totalPage || this.busy){
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show()
                this.initMessageList();
            },


        },
        mounted() {





        }
    }

</script>

<style lang="less">

    .myMessage{
        .topMessage{
            height:1rem;
            width:100%;
            color:#646464;
            span{
                color:#323232;
                display: inline-block;
                margin-top:0.3rem;
                margin-left:0.2rem;
            }
        }
        .topMessage>img{
            float:left;
            width:0.4rem;
            height:0.4rem;
            margin-top:0.3rem;
            margin-left:0.33rem;
        }
        .tabMenu{
            height:1rem;
            width:100%;
            background-color:#ffffff;
            display: flex;
            border-bottom:1px solid #c3373a;
        }
        .tabMenu>li{
            flex:1;
            line-height:1rem;
            text-align:center;
            font-size:0.3rem;
            color:#646464;

        }
        .tabMenu>li.active {
            background-color: #c3383a;
            color: white;
        }
        .listMessage{
            height:1.25rem;
            width:100%;
            background-color:#ffffff;
        }
        .listType{
            background:url(../../assets/images/myMessage/messageType.png) no-repeat;
            background-size:0.75rem 0.75rem;
            height:0.75rem;
            width:0.75rem;
            margin-top:0.25rem;
            margin-left:0.33rem;
            float:left;
            text-align:center;
        }
        .listType>span{
            color:#ffffff;
            line-height:0.75rem;
            height:0.75rem;
            width:0.75rem;
            font-size:0.33rem;
        }
        .listContent{
            position: relative;
            margin-top: 0.2rem;
            width: 5.5rem;
            height:.1rem;
            float: right;
            padding-right: 0.5rem;

            .vux-badge-dot {
                position: absolute;
                top: .11rem;
            }
        }
        .listContent>p>b{
            font-size:0.27rem;
        }
        .listContent>p>span{
            float:right;
            font-size:0.27rem;
            color:#c1c1c1;
        }
        .content{
            color:#c1c1c1;
            font-weight:normal;
            font-size:0.27rem;
        }
        .listMessage:not(:first-child){
            border-top:1px solid #ebe7db
        }

    }
</style>
