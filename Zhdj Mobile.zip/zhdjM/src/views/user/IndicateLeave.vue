<!--请假页开始-->
<template>
    <section class="indicateLeave">
        <div class="topSeat"></div>
        <div class="leaveBoxContent">
            <img src="../../assets/images/indicateLeave/leaveBoxContentIcon.png" />
            <div class="leaveTopText">
                <span>请选择请假理由</span>
            </div>
                <form class="leaveRadio">
                    <div><input type="radio" name="leaveType" value="1" id="illLeave" v-model="meetingLeaveModel.leaveType"><label for="illLeave" class="leaveText">&nbsp;事假</label></div>
                    <div><input type="radio" name="leaveType" value="2" id="thingLeave" v-model="meetingLeaveModel.leaveType"><label for="thingLeave" class="leaveText">&nbsp;病假</label></div>
                </form>
            <div class="leaveTextArea">
                <group>
                    <x-textarea v-model="meetingLeaveModel.reason" placeholder="请输入请假理由(20字以内)" :max="20"></x-textarea>
                </group>
            </div>
        </div>
        <img src="../../assets/images/indicateLeave/indicateLeaveBg.png" class="indicateLeaveBg"/>
        <div class="seat"></div>
        <button class="footBtn" @click="submitLeave()">提交</button>
    </section>
</template>

<script>
    import $ from 'jquery'
    import { XTextarea,Group } from 'vux'
    import {applyLeave} from '../../api/api'

    export default {
        components: {
            XTextarea,
            Group
        },
        data () {
            return {
                meetingLeaveModel:{meetId:'',uid:'',reason:'',leaveType:'',leaveStatus:''},//题目
            }
        },
        methods: {
            onChange (val) {
                console.log('change', val)
            },

            vertify () {
                let _self = this;
                console.log(_self.meetingLeaveModel.leaveType);
                if (_self.meetingLeaveModel.leaveType == false){
                    _self.$vux.toast.text('必须选择请假类型', 'middle')
                    return false;
                }
                if ('' == _self.meetingLeaveModel.reason || _self.meetingLeaveModel.reason > 20){
                    _self.$vux.toast.text('理由不能为空且长度限制20字', 'middle')
                    return false;
                }
                return true;
            },
            //提交请假申请
            submitLeave:function () {
                let _self = this;
                if(_self.vertify()){
                    applyLeave({meetingLeaveModel:_self.meetingLeaveModel}).then((response) => {
                        console.log(response)
                        _self.$vux.toast.text(response.message, 'middle')
                        if(response.success){
                            _self.$vux.toast.text("提交成功", 'middle');
                            this.$router.push("/meeting")
                        } else {
                        }
                    }).catch((error) => {
                        console.log(error)
                    })

                }
            },
        },
        mounted () {
            let height = $(window).height();
            $(".indicateLeave").css("minHeight",height - 50);
            $(".footBtn,.indicateLeaveBg").width($(window).width());
            this.meetingLeaveModel.meetId = this.$route.params.meetId;//传进来的会议id
        }
    }
</script>
<style lang="less">
    .indicateLeave{
        position:relative;
        .topSeat{
            height:0.2rem;
            width:100%;
        }
        .leaveBoxContent{
            height:5.3rem;
            width:100%;
            background-color:white;
        }
        .leaveBoxContent>img{
            height:1rem;
            width:1.3rem;
            float:left;
        }
        .leaveTopText>span{
            line-height:1.2rem;
            font-size:0.35rem;
            margin-left:-0.8rem;
            font-weight:bolder;
        }
        .leaveRadio{
            border-bottom:1px solid #edeaef;
            border-top:1px solid #edeaef;
            height:1.2rem;
        }
        .leaveRadio>div{
            width:50%;
            line-height:1.2rem;
            text-align:center;
            float:left;
            position:relative;
        }

        .leaveRadio>div>label{
            font-size:0.33rem;
            font-family:"微软雅黑";
        }
        .leaveTextArea{
            border:1px solid #edeaef;
            margin:0.3rem 0.8rem 0.3rem 0.8rem;
            border-radius:5px;
        }
        .weui-cell{
            padding:0.2rem;
            font-size:0.3rem;
        }
        .weui-cells:after{
            border:0;
        }
        .weui-cells:before{
            border:0;
        }
        .vux-no-group-title{
            margin:0;
        }
        .weui-cell:before{
            border:0;
        }
        .vux-datetime{
            border-top:1px solid #edeaef;
        }
        .leaveDateBox{
            margin-top:0.2rem;
            background-color:white;
            height:3.2rem;

        }
        .leaveDateText{
            height:1rem;
        }
        .leaveDateText>span{
            line-height:1rem;
            font-size:0.35rem;
            margin-left:0.5rem;
            font-weight:bolder;
        }
        .select-date{
            border-bottom:1px solid #edeaef
        }
        .footBtn {
            height: 50px;
            background-color: #c3373a;
            color: white;
            width: 100%;
            position:absolute;
            bottom: -50px;
            font-size:0.25rem;
        }
        .indicateLeaveBg{

            position:absolute;
            bottom:0;
        }
        .vux-datetime>div>p{
            margin-left:0.6rem;
        }
        .seat{
            height:1.2rem;
            width:100%;
            background-color:#ebe7db;
        }
    }
</style>
