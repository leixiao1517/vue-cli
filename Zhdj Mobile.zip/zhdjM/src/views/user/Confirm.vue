<!--起始页开始-->
<template>
    <div class="base">
        <div class="confirm-banner">
        </div>
        <div class="head"></div>

        <div class="welcome">某某某，你好！</div>
        <div class="confirm-login">
            确认本人登录
        </div>
    </div>

</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import {Selector, Group} from 'vux'
    import {getRoleList, getAbilityByRole} from '../../api/api'


    export default {
        components: {
            Selector,
            Group
        },
        data() {
            return {
                role: null,
                identifyList: [],
            }
        },
        methods: {
            onChange(val) {
//                console.log(val)
            },
            identifyLogin: function () {
                let _self = this;
                if (_self.role == "") {
                    _self.$vux.toast.text("请选择身份", 'middle')
                } else {
                    _self.$vux.loading.show({text: 'loading'})
                    getAbilityByRole({"role": _self.role}).then((response) => {
                            console.log(response);
                            _self.$vux.loading.hide()
                            if (response.success) {
                                this.$router.push('/index/' + _self.role);
                            }
                        }
                    )
                }
            }
        },
        mounted() {
            $(".index").height($(window).height());
            getRoleList({}).then((response) => {
                    console.log(response.data);
                    this.$vux.loading.hide()
                    if (response.success) {
                        this.identifyList = response.data
                        // this.identifyList.push("/index")
                    }
                }
            )
        }
    }

</script>

<style lang="less">
    .base {
        background: url(../../assets/images/user/base.jpg) no-repeat;
        background-size: cover;
        height: 10.5rem;
        width: 7.8rem;
    }

    .confirm-banner {
        background: url(../../assets/images/user/confirm-banner.png) center no-repeat;
        background-size: cover;
        height: 3.5rem;
        width: 7.8rem;
        position: absolute;
        bottom: 0;

    }

    .head {
        width: 2rem;
        height: 2rem;
        border: solid 1px;
        border-radius: 50%;
        position: absolute;
        bottom: 17%;
        left: 38%;
    }

    .confirm-login {
        width: 4.5rem;
        height: 0.7rem;
        position: absolute;
        bottom: 5%;
        left: 22%;
        border-radius: 10px;
        background-color: #ebe7db;
        line-height: 0.7rem;
        text-align: center;
        font-size: 16px;
        color: #A0242C;
    }

    .welcome {

        position: absolute;
        bottom: 11%;
        left: 35%;
        line-height: 0.7rem;
        text-align: center;
        font-size: 18px;
        color: #FEFEFE;
    }

</style>
