<!--起始页开始-->
<template>
    <div class="userInfo">
        <div class="bg">
            <div class="headImg">
                <img class="previewer-demo-img" :src="userModel.headImg | imgPath">
                <img v-if="userModel.sex == 0" class="sex" src="../../assets/images/user/fale.png" height="20" width="20"/>
                <img v-if="userModel.sex == 1" class="sex" src="../../assets/images/user/female.png" height="20" width="20"/>
            </div>
            <div class="userBox">
                <div>
                    <p class="position">{{userModel.userName}}&nbsp;|
                        <span v-if="who == 0" class="position">普通群众</span>
                        <span v-if="who == 1" class="position">共产党积极分子</span>
                        <span v-if="who == 2" class="position">共产党预备党员</span>
                        <span v-if="who == 3" class="position">共产党员</span>
                        <span v-if="who == 4" class="position">支部</span>
                        <span v-if="who == 5" class="position">党委</span>
                    </p>
                </div>
            </div>

        </div>

        <div class="info">

            <div class="bar clfix"><label class="left-desc">电话</label> <span
                class="right-desc">{{userModel.mobile}}</span></div>
            <div class="bar clfix"><label class="left-desc">所属单位</label> <span
                class="right-desc">{{userModel.unitName}}</span></div>
            <div class="bar clfix"><label class="left-desc">职业信息</label> <span class="right-desc">{{userModel.partyName}}</span>
            </div>
            <div v-if="identifyList.length > 1" class="bar clfix">
                <label class="left-desc">切换身份</label>
                <group class="right-desc sel">
                    <selector v-model="userModel.role" style="direction:rtl" :options="identifyList" @on-change="onChange"></selector>
                </group>
                <tips :content="tip1" :position="position" style="line-height: 20px" v-if="getUserInfo.firstIn == 1"></tips>
            </div>
        </div>

        <confirm class="changeR" v-model="show" @on-confirm="onConfirm" @on-cancel="onCancel">
            <p v-if="userModel.role == 0" class="switch">确定切换为普通群众</p>
            <p v-if="userModel.role == 1" class="switch">确定切换为共产党积极分子</p>
            <p v-if="userModel.role == 2" class="switch">确定切换为共产党预备党员</p>
            <p v-if="userModel.role == 3" class="switch">确定切换为共产党员</p>
            <p v-if="userModel.role == 4" class="switch">确定切换为支部</p>
            <p v-if="userModel.role == 5" class="switch">确定切换为党委</p>
        </confirm>

        <div class="bottomBg"></div>

        <!--<x-button v-if="role == 4" class="publish-exam" @click.native="publishExam"><p id="pe">申请入党</p></x-button>-->

    </div>


</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import {Selector, Group, Confirm} from 'vux'
    import {getUserInfo, getRoleList, changeRole} from '../../api/api'
    import tips from '../../components/common/tips.vue'
    export default {
        components: {
            Selector,
            Group,
            Confirm,
            tips
        },
        data() {
            return {
                identifyList: [],
                userModel: {},
                show: false,
                who: '',
                modi: false,
                countNumber: 0,
                tip1:"切换身份后，只能拥有对应权限功能",
                position:'vux-popover-arrow-up'
            }
        },
        methods: {
            onChange(val) {
                let _self = this;
                console.log("**********",this.countNumber)
                if (this.countNumber == 0) {
                    _self.show = false;
                }else{
                    _self.show = true;
                }
                this.countNumber++;
            },
            onCancel() {
                return;
            },
            onConfirm(msg) {
                let _self = this;
                this.modi = true;
                this.who = _self.userModel.role;
                console.log("发送前", this.userModel.role);
                changeRole({role: this.userModel.role, type: this.modi}).then((response) => {
                        if (response.success) {
                            // _self.userModel.role = response.data.role;
                            _self.$vux.toast.text('切换成功', 'middle')
                            // _self.userModel.role = _self.role;
                        }
                    }
                )
            },
        },
        mounted() {
            let _self = this
            getUserInfo({role:''}).then((response) => {
                if (response.success) {
                        _self.userModel = response.data;
                         this.who = _self.userModel.role;
                }else{
                    _self.$vux.toast.text(response.message);
                }
            }),

                getRoleList({}).then((response) => {
                    if (response.success) {
                        let roleArr = response.data;
                        for (let i = 0; i < roleArr.length; i++) {
                            let obj = {};
                            let value;
                            if (roleArr[i] == 0) {
                                value = '普通群众 '
                            }else if (roleArr[i] == 1) {
                                value = '共产党积极分子'
                            }else if (roleArr[i] == 2) {
                                value = '共产党预备党员'
                            }else if (roleArr[i] == 3) {
                                value = '共产党员'
                            }else if (roleArr[i] == 4) {
                                value = '支部'
                            }else if (roleArr[i] == 5) {
                                value = '党委'
                            }
                            obj.key = roleArr[i];
                            obj.value = value;
                            _self.identifyList.push(obj);
                            console.log("+++++++++++++",_self.identifyList.length);
                        }
                    }
                })
            $(".userInfo").height($(window).height())
            $(".bottomBg").width($(window).width())

        }
    }

</script>

<style lang="less">
    .userInfo {

        .bg {
            background: url(../../assets/images/user/top_back.png) center no-repeat;
            background-size: cover;
            width: 7.5rem;
            height: 3.2rem;
        }
        .headImg .previewer-demo-img {
            position: absolute;
            top: 0.46rem;
            left: 3.0rem;
            border-radius: 50%;
            width: 1.45rem;
            height: 1.45rem;
            border: #e5e5e5 1px solid;
        }
        .userBox {
            width: 80%;
            height: 0.5rem;
            font-size: 0.3rem;
            text-align: center;
            position: absolute;
            left: 10%;
            top: 2rem;
            text-overflow: ellipsis;
            overflow: hidden;
        }
        .position {
            color: #ffffff;
            line-height: 0.5rem
        }
        .info {
            background-color: #ffffff;
        }
        .bar {
            position: relative;
            height: 1rem;
            border-bottom: solid 0.1px;
            color: #EBE8DA;
            line-height: 1rem;
        }
        .left-desc {
            margin-left: 20px;
            color: #323232;
        }

        .right-desc {
            float: right;
            margin-right: 30px;
            color: #969696;

        }
        .weui-select {

            border: solid #ffffff;
            color: #969696 !important;
            font-weight: normal;
            font-size: 14px;
        }

        .weui-cells, .vux-no-group-title {
            margin-top: 0px !important;
        }

        .sel {
            margin-right: 2px;
        }

        .weui-dialog {
            max-width: none !important;
            width: 85% !important;
            height: 40%;
            background: url(../../assets/images/user/confirmChange.png) no-repeat;
            background-size: cover;

        }
        .weui-dialog__btn {
            border-radius: 5px;
            background-color: #c3373a;
            margin-top: 30%;
        }
        .weui-dialog__btn_default {
            color: #e5e5e5;
            width: 20% !important;
            height: 20%;
        }

        .weui-dialog__btn_primary {
            color: #e5e5e5;
        }

        .weui-dialog__ft {
            margin-left: .2rem;
            margin-right: .5rem;
        }
        .weui-dialog__ft a {
            margin-left: .3rem;
            font-size: 15px;
            height: .6rem;
            line-height: .6rem;
            position: relative;
            bottom: 15px;
        }

        .switch {
            text-align: center;
            margin-top: 20px;
            font-size: 18px;
            position: relative;
            top: 20px;
            font-family: 微软雅黑;

        }

        .sex {
            position: absolute;
            top: 1.55rem;
            left: 4.4rem;
        }
        .publish-exam {
            width: 100%;
            position: fixed;
            bottom: 0px;
            color: #fff;
            background: #c3373a;
            line-height: 40px;
            text-align: center;
        }
        .weui-cell_select .weui-select{
            padding-right:25px !important;
        }
        .bottomBg{
            background: url(../../assets/images/user/bottomBg.png) center;
            background-size: cover;
            height:75px;
            position:absolute;
            bottom:0;
        }

    }
</style>
