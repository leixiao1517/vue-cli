<!--起始页开始-->
<template>
    <div class="index">
        <div class="login">
            <div>
                <img class="partylogo largef" src="../../assets/images/user/party_logo.png"/>
            </div>
            <div>
                <img class="welcome" src="../../assets/images/user/welcomeLogo.png"/>
            </div>
            <div class="choose">初次登录请选择身份:</div>
            <group class="selGroup">
                <selector class="sel" placeholder="请选择身份" v-model="role" :options="identifyList"></selector>
            </group>
            <div class="confirm welcome" @click="identifyLogin">确定</div>
        </div>
    </div>
</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import {Selector, Group} from 'vux'
    import {getRoleList,getUserInfo} from '../../api/api'


    export default {
        components: {
            Selector,
            Group
        },
        data() {
            return {
                role: null,
                identifyList: [],
            }
        },
        methods: {
            onChange(val) {
//                console.log(val)
            },
            identifyLogin: function () {
                let _self = this;
                console.log("+++++++++++"+_self.role);
                if (_self.role == "" || _self.role == null) {
                    _self.$vux.toast.text("请选择身份", 'middle');
                    return;
                } else {
                    _self.$vux.loading.show({text: 'loading'})
                    getUserInfo({role: _self.role}).then((response) => {
                            console.log(response);
                            _self.$vux.loading.hide()
                            if (response.success) {
                                // sessionStorage.setItem('userInfo', 'zhdj');
                                this.$router.push('/index?role=' + _self.role);
                            }
                        }
                    )
                }
            }
        },
        mounted() {
            let _self = this;
            $(".index").height($(window).height());
            getRoleList({}).then((response) => {
                    console.log(response.data);
                    this.$vux.loading.hide()
                if (response.success) {
                    let roleArr = response.data;
                    for (let i = 0; i < roleArr.length; i++) {
                        let obj = {};
                        let value;
                        if (roleArr[i] == 0) {
                            value = '普通群众 '
                        }else if (roleArr[i] == 1) {
                            value = '共产党积极分子'
                        }else if (roleArr[i] == 2) {
                            value = '共产党预备党员'
                        }else if (roleArr[i] == 3) {
                            value = '共产党员'
                        }else if (roleArr[i] == 4) {
                            value = '支部'
                        }else if (roleArr[i] == 5) {
                            value = '党委'
                        }
                        obj.key = roleArr[i];
                        obj.value = value;
                        _self.identifyList.push(obj);
                    }
                }
                }
            )
        }
    }

</script>

<style lang="less">
    .index {
        background: url(../../assets/images/user/identify.jpg) no-repeat;
        background-size: cover;
        .weui-cells.vux-no-group-title {
            border-radius: 10px !important;
        }

        .partylogo {
            width: 2.8rem;
            height: 2.8rem;
            position: absolute;
            left: 40%;
            top: 20%;

        }

        .welcome {
            width: 80%;
            line-height: 40px;
            text-align: center;
            position: absolute;
            top: 35%;
            left: 10%;

        }
        .largef {
            font-size: 40px;
        }
        .choose {
            font-size: 18px;
            font-family: 微软雅黑;
            position: absolute;
            left: 30%;
            top: 45%;
        }

        .sel {
            border: solid 1px #C3373A;
            border-radius: 10px;
            color: #C3373A;

        }
        .selGroup {
            width: 60%;
            text-align: center;
            margin-left: auto;
            margin-right: auto;
            position: absolute;
            top: 50%;
            left: 22%;
            /*border-radius: 10px; */
            .weui-select {
                color: #C3373A !important;
            }

        }
        .confirm {
            width: 3rem;
            height: 40px;
            line-height: 40px;
            text-align: center;
            color: white;
            border-radius: 5px;
            position: absolute;
            top: 85%;
            left: 32%;
            background-color: #C3373A;
            font-size: 20px;

        }

        .weui-cells vux-no-group-title {
            border-radius: 10px !important;
        }
    }
</style>
