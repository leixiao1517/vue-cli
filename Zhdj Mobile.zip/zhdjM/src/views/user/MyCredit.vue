<!--起始页开始-->
<template >
    <section class="myCredit">
        <div class="creditTop">
            <img src="../../assets/images/credit/topBG.jpg" class="topBg"/>
            <img src="../../assets/images/credit/moreHelp.png" class="moreHelp" @click="helpCredit"/>
            <div class="userCredit">
                <p class="commonText">{{tScore}}</p>
                <p class="commonText">我的学分</p>
                <p class="lookAllCredit" @click="toUrl('myRank')">查看个人/党委排名</p>
            </div>
        </div>
        <div class="creditTab">
            <tab :line-width="1" custom-bar-width="2rem" default-color="#323232" bar-active-color="#c3373a" active-color="#c3373a">
                <tab-item selected style="font-size:0.3rem" @on-item-click="onItemClick(0)">必修学分</tab-item>
                <tab-item style="font-size:0.3rem" @on-item-click="onItemClick(1)">选修学分</tab-item>
            </tab>
        </div>
        <div class="credit">

            <div class="mustCredit" v-infinite-scroll="loadSelect" infinite-scroll-disabled="busy" infinite-scroll-distance="10" id="selectScroll" v-show="curTab == 0">
                <div class="creditList" v-for="value in sDataList">
                    <div class="listTitle">
                        <p class="title">{{ value.content }}</p>
                        <p class="dateTitle">{{ value.createDate|dateFormat('YMDhm')}}</p>
                    </div>
                    <b>+ {{ value.credits }}</b>
                </div>
                <div class="no-data" v-if="sDataList.length == 0"><p>没有必修学分数据</p></div>
                <img src="../../assets/images/credit/bottomBg.png" class="bottomBg1" id="bottomBg1"/>
                <div class="seatBg1" id="seatBg1"></div>
            </div>
            <div class="electiveCredit" v-infinite-scroll="loadSimple" infinite-scroll-disabled="busy" infinite-scroll-distance="10" id="simpleScroll" v-show="curTab == 1">
                <div class="creditList" v-for="value in qDataList">
                    <div class="listTitle">
                        <p class="title">{{ value.content }}</p>
                        <p class="dateTitle">{{ value.createDate|dateFormat('YMDhm')}}</p>
                    </div>
                    <b><span>已得分</span>&nbsp;+ {{ value.credits }}</b>
                </div>
                <div class="no-data" v-if="qDataList.length == 0"><p>没有选修学分数据</p></div>
                <img src="../../assets/images/credit/bottomBg.png" class="bottomBg2" id="bottomBg2"/>
                <div class="seatBg2" id="seatBg2"></div>
            </div>
        </div>
        <div class="helpWindow" @click="closeHelp">
            <div class="helpBox">
                <div class="helpText">
                    <div class="helpImg"><img src="../../assets/images/credit/helpIcon.png" /></div>
                    <div class="helpBorder1"></div>
                    <div class="helpBorder2"></div>
                    <div class="helpcontent">
                        <h3>个人：</h3>
                        <p>(1)个人学分排行榜成绩将作为年度优秀党员的评选参数之一;</p>
                        <p>(2)个人总学分排行榜前30名，年末将获得超级大奖一份.</p>
                    </div>
                    <div class="helpcontent">
                        <h3>支部：</h3>
                        <p>支部排行榜年度第十名将获得“智慧党建荣誉支部”称号;</p>
                        <p>支部内每位党员新年里各奖励选修学分10分.</p>
                    </div>
                    <div class="helpcontent">
                        <h3>党委：</h3>
                        <p>党委排行榜年度第一名将获得“智慧党建最佳党委”称号</p>
                        <p>党委内每位党员新年里各奖励选修学分10分</p>
                    </div>
                    <img src="../../assets/images/credit/helpBg.png" class="helpBg">
                </div>
                <img src="../../assets/images/credit/closeHelp.png" class="closeHelp" @click="closeHelp"/>
            </div>
        </div>
    </section>

</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import { Cell,Tab,TabItem } from 'vux'
    import { getCreditsByUid,getRankByUid } from '../../api/api'
    export default {
        components: {
            Cell,
            Tab,
            TabItem,
        },
        data() {
            return {
                getCreditsByUid:{},
                sDataList:[],
                creditsModel:{},
                sCurPage:1,
                sTotalPage:1,
                sBusy:false,
                qDataList:[],
                qCurPage:1,
                qTotalPage:1,
                qBusy:false,
                pub:false,
                type:1,
                userName:"",
                totalScore:0,
                credits:'',
                tScore:'',
                mid: 0,
                curTab:0,

            }
        },
        methods: {
            toUrl: function (enterUrl) {
                this.$router.push("/" + enterUrl)
            },
            helpCredit: function () {
                $(".helpWindow").css("display","block")
            },
            closeHelp:function(){
                $(".helpWindow").css("display","none")
            },
            loadSelect: function() {
                if(this.sCurPage > this.sTotalPage || this.sBusy){
                    this.sBusy = true;
                    return;
                }
                this.sBusy = true;
                $(".load-more").show();
                this.moreSelect();
            },
            loadSimple: function() {
                if(this.qCurPage > this.qTotalPage || this.qBusy){
                    this.qBusy = true;
                    return;
                }
                this.qBusy = true;
                $(".load-more").show();
                this.moreSimple();
            },
            moreSelect:function () {
                let _self = this;
                getCreditsByUid({curPage:_self.sCurPage,uId:_self.uId,type:1}).then((response) => {
                    _self.userName = response.data.creditsModel.userName;
                    _self.tScore = response.data.creditsModel.credits
                    if(response.success) {
                        _self.sDataList = _self.sDataList.concat(response.data.page.rows);
                        _self.sTotalPage = response.data.page.pageCount;
                        _self.sCurPage++;
                        _self.sBusy = false;
                        console.log("~~~~~",response.data.creditsModel)
                        if( $(".mustCredit").height() < $(window).height() - $(".topBg").height() - $(".creditTab").height() - 85 )
                        {
                            document.getElementById("bottomBg1").style.bottom="-85px";
                            document.getElementById("seatBg1").style.height="0px";
                        }
                        else if($(".mustCredit").height() >= $(window).height() - $(".topBg").height() - $(".creditTab").height() - 85)
                        {
                            document.getElementById("bottomBg1").style.bottom="0px";
                            document.getElementById("seatBg1").style.height="85px";
                        }



                    } else {
                        _self.userName = '暂无数据';
                        _self.tScore = '暂无数据';

                    }
                    // _self.busy = false;
                    $(".load-more").hide()
                }).catch((error) => {
                    $(".load-more").hide()
                    console.log(error)
                })
            },

            moreSimple:function () {
                let _self = this;
                console.log('curPage:', this.qCurPage)
                console.log('totalPage:', this.qTotalPage)
                console.log('busy:',this.qBusy);
                getCreditsByUid({curPage:_self.qCurPage,uId:_self.uId,type:2}).then((response) => {
                    if(response.success) {
                        console.log(response);
                        _self.qDataList = _self.qDataList.concat(response.data.page.rows);
                        _self.qTotalPage = response.data.page.pageCount;
                        _self.qCurPage++;
                        _self.qBusy = false;
                        if( $(".electiveCredit").height() < $(window).height() - $(".topBg").height() - $(".creditTab").height() - 85 )
                        {
                            document.getElementById("bottomBg2").style.bottom="-85px";
                            document.getElementById("seatBg2").style.height="0px";
                        }
                        else if($(".electiveCredit").height() >= $(window).height() - $(".topBg").height() - $(".creditTab").height() - 85)
                        {
                            document.getElementById("bottomBg2").style.bottom="0px"
                            document.getElementById("seatBg2").style.height="85px";
                        }
                    } else {
                        $(".no-business").show()
                    }
                    $(".load-more").hide()
                }).catch((error) => {
                    $(".load-more").hide()
                    console.log(error)
                })
            },
            onItemClick (index) {
                this.curTab = index;
            },
            },
        mounted() {
                $(".bottomBg1,.bottomBg2,.topBg,.helpImg,.helpBg").width($(window).width())
                $(".helpWindow").height($(window).height())
                $(".mustCredit").css("minHeight",$(window).height() - $(".topBg").height() - $(".creditTab").height() - 100)
                $(".electiveCredit").css("minHeight",$(window).height() - $(".topBg").height() - $(".creditTab").height() - 100)

            }
        }
</script>

<style lang="less">

    .myCredit{
            position:relative;

        .creditTop{
            position:relative;
        }
        .topBg {
            height: 3rem;
        }
        .moreHelp{
            position:absolute;
            top:0.2rem;
            right:0.2rem;
            width:0.5rem;
            height:0.5rem;
        }
        .userCredit{
            margin-top:-2.5rem;
            height:2.4rem;
            width:100%;
            position:absolute;
            z-index:80;
            text-align:center;

        }
        .userCredit > .commonText{
            font-size:0.35rem;
            color:#b2413d;
            margin-top:0.1rem;
        }
        .userCredit > .lookAllCredit{
            margin-top:0.15rem;
            font-size:0.3rem;
        }
        .creditTab{
            margin-top:0.2rem;
            width:100%;
        }
        .credit{
            margin-top:0.1rem;
            width:100%;
        }
        .bottomBg1{
            height:65px;
            position:absolute;
            bottom:0;
        }
        .bottomBg2{
            height:65px;
            position:absolute;
            bottom:0;
        }
        .creditList{
            height:1rem;
            background-color:#ffffff;
            border-bottom:1px solid #ebe7db;
        }
        .listTitle{
            height:0.9rem;
            margin-top:0.05rem;
            margin-left:0.33rem;
            width: 4.8rem;
            float:left;
        }
        .creditList>b{
            line-height:1rem;
            font-size:0.33rem;
            margin-right:0.33rem;
            float:right;
            color:#c3373a;
            font-weight:normal;
        }
        .creditList>b>span{
            color:#323232;
        }
        .title{
            font-size:0.33rem;
        }
        .dateTitle{
            font-size:0.27rem;
            color:#969696;
        }
        .electiveBox{
            float:right;
            margin-right:0.33rem;
        }
        .electiveBox>p{
            line-height:0.5rem;
            font-size:0.33rem;
            text-align:right;
        }
        .electiveBox>p>span{
            color:#c3373a;
        }
        .helpBox{
            position:absolute;
            bottom:0;
            z-index:200;
            height:10.2rem;
            background-color:#ffffff;
        }
        .closeHelp{
            position:absolute;
            top:0.33rem;
            right:0.5rem;
            height:0.5rem;
            width:0.5rem;
            z-index:100;
        }
        .helpText{
            height:1.2rem;
        }
        .helpText>div>img{
            width:0.7rem;
            height:0.7rem;
            display:block;
            margin:0.2rem auto;
            padding-top:0.2rem;
        }
        .helpBorder1{
            border-bottom:1px solid #c3373a;
            width:60%;
            height:1px;
            margin-left:5%;
        }
        .helpBorder2{
            border-bottom:1px solid #c3373a;
            width:60%;
            height:1px;
            margin-left:35%;
        }
        .helpcontent{
            width: 90%;
            margin:0.3rem auto;
        }
        .helpcontent>h3{
            font-size:0.33rem;
        }
        .helpcontent>p{
            font-size:0.3rem;
        }
        .helpWindow{
            display:none;
            width:100%;
            background:rgba(0,0,0,0.5);
            top:0;
            position:fixed;
            z-index:99;
        }
        .helpBg{
            height:1.2rem;
        }
        .seatBg1{
            height:0px;
        }
        .seatBg2{
            height:0px;
        }
    }
</style>
