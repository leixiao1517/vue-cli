<!--起始页开始-->
<template>
    <section class="checkLeave">
        <div class="topSeat"></div>
        <div class="checkTop">
            <div class="checkTopBox">
                <img :src="leave.headImg" class="headImg"/>
                <b class="userName">{{ leave.userName }} </b>
                <span class="leaveStatus">请假</span>
            </div>
        </div>
        <div class="checkContent">
            <img src="../../assets/images/checkLeave/contentIcon.png" class="iconImg">
            <img src="../../assets/images/checkLeave/success.png" class="checkStatus" v-if="leave.leaveStatus == 1">
            <img src="../../assets/images/checkLeave/fail.png" class="checkStatus" v-if="leave.leaveStatus == -1">
            <ul class="checkText">
                <li><span>所属公司：</span><b>{{leave.unitName}}</b></li>
                <li><span>当前职位：</span><b>{{leave.department}}</b></li>
                <li><span>请假类型：</span><b v-if="leave.leaveType == 1">事假</b><b v-if="leave.leaveType == 2">病假</b></li>
                <li><span>请假事由：</span><b>{{leave.reason}}</b></li>
            </ul>
        </div>
            <img src="../../assets/images/checkLeave/contentBg.png" alt="" class="contentBg">

        <div class="checkBtn" v-if="(leave.leaveStatus != 1 && leave.leaveStatus != -1) && (leave.curUser == leave.createUser)">
            <button class="checkFail" @click="leaveCheck(leave.leaveStatus = -1)">不通过</button>
            <button class="checkSuccess" @click="leaveCheck(leave.leaveStatus = 1)">通过</button>
        </div>
    </section>
</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import { leaveDetail,leaveCheck } from '../../api/api'


    export default {
        components: {
        },
        data () {
            return {
                uid:String,
                meetId:Number,
                leave:{},
            }
        },
        methods: {
            //初始化
            initLeave:function () {
                let _self = this;
                leaveDetail({uid:_self.uid,meetId:_self.meetId}).then((response) => {
                    console.log(response);
                    if(response.success){
                        //对leave赋值
                        _self.leave = response.data;
                        _self.leaveStatus = response.data.leaveStatus
                        _self.curUser = response.data.curUser
                        _self.createUser =response.data.createUser
                        if((this.leaveStatus != 1 && this.leaveStatus != -1) && (this.curUser == this.createUser)){
                            $(".contentBg").css("bottom",60);
                        }else{
                            $(".contentBg").css("bottom",0);
                        }
                    } else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }).catch((error) => {
                    console.log(error)
                })
            },
            //查看
            leaveCheck:function () {
                let _self = this;
                leaveCheck(_self.leave).then((response) => {
                    console.log(response)
                    _self.$vux.toast.text(response.message, 'middle')
                }).catch((error) => {
                    console.log(error)
                })
            },

    },
        mounted () {
            let height = $(window).height();
            $(".checkLeave").css("height",height)
            this.uid = this.$route.query.uid;
            this.meetId = this.$route.query.meetId;
            this.initLeave();
        }
    }


</script>

<style lang="less">
    .checkLeave{
        .topSeat{
            height:0.2rem;
            width:100%;
        }
        .checkTop{
            background-color:#ffffff;
            height:1.5rem;
            width:100%;
        }
        .checkContent{
            background-color:#ffffff;
            height:7.5rem;
            width:100%;
            margin-top:0.2rem;
            position:relative;
        }
        .checkBtn{
            height:1.2rem;
            width:100%;
            position:fixed;
            bottom:0;
        }
        .checkBtn>button{
            width:50%;
            height:60px;
            text-align:center;
            line-height:60px;
            float:left;
            font-size:16px;
        }
        .checkFail{
            color:#ffffff;
            background-color:#e9cda1;
        }
        .checkSuccess{
            color:#ffffff;
            background-color:#c3373a;
        }
        .contentBg{
            height:1.2rem;
            width:100%;
            position:absolute;
            bottom:0;
        }
        .seat{
            height:1.2rem;
            width:100%;
        }
        .iconImg{
            height:1.8rem;
            width:2.16rem;
        }
        .checkText{
            margin-top:-1rem;
            margin-left:1rem;
            font-size:0.33rem;
        }
        .checkText>li{
            margin-top:0.2rem;
            color:#969696
        }
        .checkText>li>b{
            font-weight:normal;
            color:#323232;
        }
        .checkTopBox{
            padding-top:0.15rem;
            margin-left:0.33rem;
            height:1.2rem;
        }
        .headImg{
            height:1.2rem;
            width:1.2rem;
            border-radius:50%;
            background-color:blue;
            float:left;
        }
        .userName{
            font-weight:normal;
            line-height:1.2rem;
            font-size:0.4rem;
            margin-left:0.33rem;
        }
        .leaveStatus{
            font-size:0.4rem;
            float:right;
            line-height:1.2rem;
            margin-right:0.66rem;
            color:#bf901c;
        }
        .checkStatus{
            position:absolute;
            height:1.2rem;
            width:1.2rem;
            right:0.5rem;
            top:0.4rem;
        }

    }
</style>
