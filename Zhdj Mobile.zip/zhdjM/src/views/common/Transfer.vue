<template>
    <div>页面跳转中...</div>
</template>

<script>
    import {setCookie, getCookie, delCookie} from '../../assets/js/common/cookieOper'
    import {mobileServer} from '../../config/config'

    export default {
        components: {

        },
        data () {
            return {

            }
        },
        mounted() {
            let query = this.$route.query;
            let loginState = query.loginState;

            if("SUCCESS" == loginState){ //如果是已登录状态
                sessionStorage.setItem('userInfo', 'zhdj');
                let oldUrl = getCookie('oldUrl');
                console.log(oldUrl)
                if(null != oldUrl && 'undefined' != oldUrl){ //跳转到登录前的页面
                    this.$router.push(oldUrl);
                } else { //如果第一个页面是选择登录方式页，则跳转到首页
                    this.$router.push('/index');
                }
                setCookie("oldUrl", 'undefined');
            } else { //非登录状态需要先登录
                //记录跳转过来时的页面，以便登录完成之后跳转回去
                setCookie("oldUrl", query.redirect);
                window.location.href = mobileServer + "login"
            }
        },
        methods: {

        }
    }
</script>

<style lang="less">

</style>
