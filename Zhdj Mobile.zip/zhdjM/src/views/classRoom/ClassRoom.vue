<template>
    <section  class="class-room">
        <section style="height: 44px">
            <search
                v-model="searchVal"
                position="absolute"
                auto-scroll-to-top
                top="0px"
                @on-focus="onFocus"
                @on-cancel="onCancel"
                @on-submit="onSubmit"
                ref="search"></search>
        </section>
        <section>
            <div>
                <div v-infinite-scroll="loadClassRoom" infinite-scroll-disabled="busy"
                     infinite-scroll-distance="10">
                    <template v-if="classRoomList.length>0">
                        <comm-item @click.native="toResourceDetail('/ResourceDetail',scrollIndex)"
                                   v-for="(classRoom,scrollIndex) in classRoomList" :key="scrollIndex"

                                   :imgSrc="classRoom.videoImg"
                                   :type="classRoom.zyType"
                                   :info1="classRoom.title"
                                   :info2="classRoom.userName"
                                   :info3="classRoom.partyName"
                                   :info4="classRoom.modifyDate | dateFormat('YMD')">
                            <input :id="'classRoom' + scrollIndex" type="hidden" :value="classRoom.docType"/>
                            <input :id="'vid' + scrollIndex" type="hidden" :value="classRoom.vid"/>
                        </comm-item>
                        <loading></loading>
                    </template>
                    <div class="no-data" v-if="classRoomList.length==0"><p>没有数据</p></div>
                </div>
            </div>

        </section>
    </section>
</template>

<script>
    import loading from '../../components/common/loading.vue'
    import{getResourceList} from '../../api/api'
    import {Search} from 'vux'
    import $ from 'jquery'
    import commItem from '../../components/common/commItem1.vue'
    export default {

        components: {
            loading,
            Search,
            commItem
        },
        data () {
            return {
                classRoomList: [],
                curPage: 1,
                pageSize: 6,
                totalPage: 1,
                busy: false,
                searchVal:''
            }
        },

        methods: {

            toResourceDetail(url, scrollIndex){
                let type = $("#classRoom" + scrollIndex).val();
                let vid = $("#vid" + scrollIndex).val();
                this.$router.push({path: url, query: {type: type, vid: vid}});
            },

            loadClassRoom: function () {
                if (this.curPage > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initClassRoomList();
            },

            initClassRoomList: function () {
                let _self = this;

                $(".load-more").hide();
                getResourceList({
                    menu: '云课堂',
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.classRoomList = _self.classRoomList.concat(response.data.list);
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            },

            onFocus() {

            },
            onCancel() {
                console.log('cancelsearch '+this.searchVal)
            },
            onSubmit() {
                this.$refs.search.setBlur()
                let _self = this;
                _self.curPage = 1;
                getResourceList({
                    searchKey: _self.searchVal,
                    menu: '云课堂',
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.classRoomList = response.data.list;
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false;
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            }
        }
    }
</script>

<style lang="less">

    .class-room {
        height: 11.4rem;

        .class-room-summary {
            height: 1rem;
            background-color: #FFFFFF;
            margin-bottom: 1px;
            .class-room-resource {
                display: inline-block;
                font-size: 14px;
                margin: 14px 20px;
            }

            .class-room-sort {
                display: inline-block;
                float: right;
                margin: 14px 20px;
            }
        }

        .class-room-list {
            height: 1.7rem;
            /*margin: 10px 10px 0px 10px;*/
            margin-bottom: 1px;
            padding-left: 20px;
            padding-right: 20px;
            background-color: #FFFFFF;

            .class-room-title {
                font-size: 14px;
                color: #323232;
                display: block;
                text-overflow: ellipsis;
                overflow: hidden;
                white-space: nowrap;
            }
            .class-room-type {
                color: #969696;
            }

            .class-room-list-content {
                margin: 0px 5px 5px 0px;
                font-size: 12px;
                color: #969696;
                .class-room-date {
                    float: right;
                }
                .class-room-userName {
                    padding-left: .6rem;
                }
            }
        }

        .class-room-footer {
            padding-bottom: 2px;
            img {
                width: 100%;
            }
        }

    }

    @import '../../assets/css/content.less';
</style>
