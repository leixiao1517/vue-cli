<!--会议详情开始-->
<template>
    <section class="meeting-detail">
        <div class="comm-head-logo">
            <div class="logo">
                <img src="../../assets/images/common/icon-logo.png" alt="">
            </div>
            <div class="back" @click="toIndex">
                回到首页
            </div>
        </div>

        <div class="detail-top">
            <div class="title">
                {{meeting.title}}
            </div>
            <div class="create-user">
                发起人:{{meeting.createUserName}}
                <!--<span>【{{roleDesc}}】</span>-->

                <div class="meeting-status" v-if="meeting.process == 1"><span>会议状态:</span><span class="before">未开始</span></div>
                <div class="meeting-status " v-if="meeting.process == 2"><span>会议状态:</span><span class="ing">进行中</span></div>
                <div class="meeting-status " v-if="meeting.process == 3"><span>会议状态:</span><span class="after">已结束</span></div>
                <div class="meeting-status before" v-if="null != meetingUser && null != meetingUser.seatNo">座位号:{{meetingUser.seatNo}}</div>
            </div>
            <div class="time">会议时间:{{meeting.startDate | dateFormat('HM')}} 至 {{meeting.endDate | dateFormat('HM')}}</div>
            <div class="address">会议地点:{{meeting.address}}</div>
        </div>

        <div class="meeting-content">
            <div class="meeting-content-img">
                <img src="../../assets/images/meeting/large-logo.png">
            </div>
            <img :src="meeting.cover" class="cover-img" v-if="meeting.cover != null && meeting.cover != ''">
            <div class="content" v-html="meeting.content"></div>
        </div>

        <!-- 发布会议人看到的页面 -->
        <div class="creator" v-if="isCreator">
            <!-- 会议生成座位前 可编辑 -->
            <div class="meeting-create" v-if="meeting.process == 1">
                <div class="create-title">
                    <img src="../../assets/images/meeting/small-logo.png"><span>·</span>会议数据
                </div>
                <div class="create-items">
                    <cell title="参与者详情" value="详情" :link="{path:'/partakeDetails/' + meeting.meetId}" ></cell>
                    <cell title="会议编辑" value="去编辑" :link="{path:'/publishMeeting?meetId=' + meeting.meetId}"
                          v-if="meeting.canEdit == 0 && meeting.editTimes < 3"></cell>
                </div>
            </div>
            <!-- 会议进行时考勤 -->
            <div class="meeting-create" v-if="meeting.process < 3">
                <div class="create-title">
                    <img src="../../assets/images/meeting/small-logo.png"><span>·</span>会议考勤
                </div>
                <div class="create-items">
                    <cell title="签到/抽查/签退" value="考勤" :link="{path:'/meetingAttendance/' + meeting.meetId}"></cell>
                    <tips :content="tip1" :position="position" v-if="firstIn == 1"></tips>
                </div>
            </div>

            <!-- 会议结束后展示数据统计 -->
            <div class="meeting-create" v-if="meeting.process == 3">
                <div class="create-title">
                    <img src="../../assets/images/meeting/small-logo.png"><span>·</span>会后事宜
                </div>
                <div class="create-items">
                    <cell title="查看纪要" value="查看" :link="{path:'/ResourceDetail?type=' + meeting.summaryType + '&vid=' + meeting.summaryId +
                        '&meetId=' + meeting.meetId}" is-link v-if="null != meeting.summaryId && 0 < meeting.summaryId"></cell>
                    <cell title="发布考试" value="发布" @click.native="publishExam()" is-link v-if="meeting.exam == 0"></cell>
                    <cell title="考试查看" value="查看" :link="{path:'/replyDetails/' + meeting.meetId}" v-if="meeting.exam == 1"></cell>
                    <cell title="会议数据" value="查看" :link="{path:'/countMeeting/' + meeting.meetId}" is-link></cell>
                    <tips :content="tip2" :position="position" v-if="firstIn == 1"></tips>
                </div>
            </div>
        </div>

        <!-- 纪要人看到的页面 -->
        <!--<div class="creator" v-if="!isCreator && isSummary && meeting.process == 3">-->
            <!--&lt;!&ndash; 会议结束后展示 &ndash;&gt;-->
            <!--<div class="meeting-create">-->
                <!--<div class="create-title">-->
                    <!--<img src="../../assets/images/meeting/small-logo.png"><span>·</span>会后事宜-->
                <!--</div>-->
                <!--<div class="create-items">-->
                    <!--<cell title="发布纪要" :value="this.action" @click.native="publishSummary()" is-link></cell>-->
                <!--</div>-->
            <!--</div>-->
        <!--</div>-->


        <!-- 普通用户看到的页面 -->
        <div class="creator" v-if="!isCreator && meeting.process == 3 && null != meeting.summaryId && 0 < meeting.summaryId">
            <!-- 会议结束后展示 -->
            <div class="meeting-create">
                <div class="create-title">
                    <img src="../../assets/images/meeting/small-logo.png"><span>·</span>会后事宜
                </div>
                <div class="create-items">
                    <cell title="查看纪要" value="查看" :link="{path:'/ResourceDetail?type=' + meeting.summaryType +
                        '&vid=' + meeting.summaryId + '&meetId=' + meeting.meetId}" is-link></cell>
                </div>
            </div>
        </div>

        <div class="attachment" v-if="titles.length > 0">
            <div class="create-title">
                <img src="../../assets/images/meeting/small-logo.png"><span>·</span>附件
            </div>
            <div class="create-items" v-for="title in titles">
                <cell :title="title.title" value="查看" :link="{path:'/ResourceDetail?type=' + title.type + '&vid=' + title.vid}" is-link></cell>
            </div>
        </div>

        <!-- 参加会议人看到的页面 -->
        <div class="joiner" v-if="!isCreator && null != meetingUser">
            <!-- 会前 如果在请假查看的显示一下 如果通过了 则不显示 -->
            <div class="meeting-joiner" v-show="meeting.process == 1 && meetingUser.leaveStatus != 1 && meetingUser.attend != 1" >
                <span v-if="meetingUser.leaveStatus == 2">请假申请中</span>
                <!-- 下面用于占位 -->
                <span v-if="meetingUser.leaveStatus != 2" :style="meetingUser.leaveStatus != 2?'visibility: hidden;':''">请假申请中</span>
                <x-button mini :class="meetingUser.leaveStatus == 2?'active':''" @click.native="applyLeave()">请假</x-button>
                <x-button mini :class="meetingUser.leaveStatus == 2?'active':''" @click.native="attendMeeting()">参加</x-button>
            </div>

            <!-- 会中 如果不是请假通过的都需要参加会议-->
            <div class="meeting-ing" v-show="meeting.process == 2 && meetingUser.leaveStatus != 1" >
                <div>
                    <div class="ing-img" :class="meetingUser.signIn == 1?'active':''"></div>
                    <p :class="meetingUser.signIn == 1?'active':''">已签到</p>
                </div>
                <div>
                    <div class="ing-img" :class="meetingUser.checkStatus == 1?'active':''"></div>
                    <p :class="meetingUser.checkStatus == 1?'active':''">已抽查</p>
                </div>
                <div>
                    <div class="ing-img" :class="meetingUser.signOut == 1?'active':''"></div>
                    <p :class="meetingUser.signOut == 1?'active':''">已签退</p>
                </div>
                <div class="sao-yi-sao" @click="callScanQrCode">
                    <img src="../../assets/images/meeting/saoyisao.png"/>
                    <span>扫一扫</span>
                </div>
            </div>

            <!-- 会后 请假查看通过的需要考试-->
            <div class="meeting-joiner" v-show="meeting.process == 3 &&
                (meetingUser.leaveStatus == 1 || meetingUser.leaveStatus == 2
                    || meetingUser.signIn == 0 || meetingUser.checkStatus == 0 || meetingUser.signOut == 0 ) && meetingUser.exam != 2">
                <x-button v-show="null != meeting.summaryId && 0 != meeting.summaryId" mini @click.native="toUrl('ResourceDetail?type=' + meeting.summaryType +
                    '&vid=' + meeting.summaryId + '&meetId=' + meeting.meetId)">补课</x-button>
                <x-button v-show="1 == meeting.exam" mini @click.native="toUrl('questionList/'+ meeting.meetId)">考试</x-button>
            </div>
        </div>
        <!--<div class="white-area" v-if="!isCreator"></div>-->
    </section>
</template>
<!--会议详情结束-->

<script>
    import $ from 'jquery'
    import { Group,XButton ,Cell} from 'vux'
    import { meetingDetail,getWXJsApiSignData,attendMeeting} from '../../api/api'
    import { wxScanQRCode,wxShare} from '../../assets/js/common/wxjsapi.js'
    import { imageRootPath,mobileClient} from '../../config/config'
    import tips from '../../components/common/tips.vue'

    export default {
        components: {
            Group,
            XButton,
            Cell,
            tips
        },
        data () {
            return {
                isCreator:false,//是否是发起人，true发起人 false参会人
                isSummary:false,//纪要人
                isPublished:false,//是否已经发布
                action:"去发布",
                roleDesc:'',
                tip1:'签到二维码就在这里',
                tip2:'请查看会议数据尽快发布考试',
                position:'vux-popover-arrow-up',
                //会议进程 1：会前 2：会中 3：会后
                meeting:{meetId:'',title:'',createUser:'',createUserName:'',startDate:'',endDate:'',address:'',process:Number,
                    canEdit:Number,exam:Number,attachment:'',types:'',titles:'',summaryId:Number,summaryType:Number},
                //leaveStatus:2,//0未请假,1请假通过,-1查看未通过,2:查看中
                meetingUser:{meetId:'',uid:'',attend:Number,signIn:Number,checkStatus:Number,signOut:Number,leaveStatus:Number},
                firstIn:'',
                titles:[]
            }
        },
        methods: {
            //初始化
            initDetail:function () {
                let _self = this;
                _self.meeting.meetId = _self.$route.params.meetId;
                /*接口请求*/
                meetingDetail({meetId:_self.meeting.meetId}).then((response) => {
                    console.log('~~~~~~~~~~~~~~~~~~~',response)
                    if(response.success){
                        _self.meeting = response.data.meeting;
                        _self.meetingUser = response.data.meetingUser;
                        _self.isCreator = response.data.isCreator;
                        _self.isSummary = response.data.isSummary;
                        _self.isPublished = response.data.isPublished;
                        _self.roleDesc = response.data.roleDesc
                        _self.firstIn = response.data.firstIn
                        if(null != _self.meeting.attachment){
                            let vidArr = _self.meeting.attachment.split(",").sort()
                            let typeArr = _self.meeting.types.split(",")
                            let titleArr = _self.meeting.titles.split(",")
                            for(let i = 0 ;i < vidArr.length; i++){
                                let title = {}
                                title.vid = vidArr[i]
                                title.type = typeArr[i]
                                title.title = titleArr[i]
                                _self.titles.push(title)
                            }
                        } else {
                            _self.titles = []
                        }
                        console.log(_self.titles)

                        if(_self.isPublished){
                            _self.action="修改";
                        }
                        if(!_self.isCreator && !_self.isSummary){
                            _self.action="查看";
                        }
                        if (_self.meeting.process == 2){
                            getWXJsApiSignData({}).then(function (rsp) {
                                if(rsp.success){
                                    console.log(rsp);
                                    let link = mobileClient + "#/meetingDetail/" + _self.meeting.meetId;
                                    let param = {
                                        title: _self.meeting.title, // 分享标题
                                        desc:"我发布了一次会议，还等什么？快来围观吧！",// 分享描述
                                        link: link ,
                                        imgUrl: imageRootPath + 'zhdj/resource/image/large-logo.png'// 分享图标
                                    };
                                    wxShare(rsp.data,param);
                                }
                            })
                        }
                    } else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }).catch((error) => {
                    console.log(error)
                })
            },
            //跳转
            toUrl:function(enterUrl){
                this.$router.push("/" + enterUrl)
            },
            //发布纪要
            publishSummary:function () {
                this.$router.push('/publishAbstract/' + this.meeting.meetId)
                if(this.isPublished ){
                    this.$router.push('/publishAbstract/' + this.meeting.meetId + '?model=modi');
                }
            },
            callScanQrCode:function () {
                let _self = this
                _self.$vux.loading.show({
                    text: 'Loading'
                })
                setTimeout(() => {
                    _self.$vux.loading.hide()
                }, 3000)
                wxScanQRCode(function (rsp) {
                    _self.$vux.loading.hide()
                    _self.$vux.loading.show({
                        text: '扫码成功'
                    })
                    console.log("scan result:",rsp)
                    setTimeout(() => {
                        window.location.href = rsp;
                    }, 1500)
                })
            },
            //查看纪要
            lookSummary:function () {
                this.$router.push('/meetingAbstract/' + this.meeting.meetId + '?model=look' )
            },
            //发布考题
            publishExam:function () {
                this.$router.push('/publishQuestion/' + this.meeting.meetId)
            },
            attendMeeting:function () {
                let _self = this
                /*接口请求*/
                if( _self.meetingUser.attend == 1){
                    _self.$vux.toast.text("你已经确认参加过此会议", 'middle')
                    return;
                }
                if(_self.meetingUser.leaveStatus == 2){
                    // _self.$vux.toast.text("你已经申请了请假，正在查看中", 'middle')
                    return;
                }
                //确认参加后，更新meetingUser.attend状态
                _self.meetingUser.attend = 1;
                attendMeeting(_self.meetingUser).then((response) => {
                    console.log(response)
                    _self.$vux.toast.text(response.message, 'middle')
                    if(response.success){
                        _self.$vux.toast.text("成功确认", 'middle')
                        setTimeout(() => {
                            location.reload()
                        }, 1000)
                    } else {
                        _self.$vux.toast.text("确认失败", 'middle')
                    }
                }).catch((error) => {
                    console.log(error)
                })
            },
            applyLeave:function () {
                if( this.meetingUser.attend == 1){
                    // this.$vux.toast.text("确认参加会议后，不可再请假", 'middle');
                    return;
                }else if(this.meetingUser.leaveStatus == 2){
                    // this.$vux.toast.text("请假正在查看中，不可再申请", 'middle');
                    return;
                }else{
                    this.$router.push('/indicateLeave/' + this.meeting.meetId);
                }
            },
            toIndex: function () {
                this.$router.push('/index')
            }
            },
        mounted () {
            this.initDetail()
            //适应小屏幕
            if ($(".detail-top").height() < 100){
                $(".detail-top").height(130)
                $(".meeting-joiner span").css("marginRight","1rem");
            }
//            let height = $(window).height() -  $(".detail-top").outerHeight() - $(".meeting-content").outerHeight() - 200
//            if (height > 0){
//                $(".white-area").css("height",height)
//            }

        }
    }

</script>

<style lang="less">
    @import "../../assets/css/meeting/meetingDetail";
</style>
