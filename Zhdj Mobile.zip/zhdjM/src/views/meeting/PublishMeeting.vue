
<template>
    <section class="publish-meeting">
        <!-- 发布会议页面 -->
        <section class="first-part" v-show="firstPart">
            <section class="topArea">
                <section class="meeting-info">
                    <x-input placeholder="请输入会议标题" v-model="meeting.title"></x-input>
                    <x-textarea :max="150" placeholder="请输入会议议题" v-model="meeting.topics" auto :height="100"></x-textarea>
                    <x-textarea :max="1000" placeholder="请输入会议内容" v-model="meeting.content" auto :height="300"></x-textarea>
                    <img class="meeting-img" src="../../assets/images/meeting/publish-meeting.png">
                </section>

                <section class="select-date">
                    <!--<datetime v-model="meeting.startDate" :format="format" title="开始时间" :min-year="minYear"></datetime>-->
                    <!--<datetime v-model="meeting.endDate" :format="format" title="结束时间" :min-year="minYear"></datetime>-->

                    <datetime v-model="meeting.startDate" :min-year=minYear :format="format"
                              @on-change="changeStartDate" title="开始时间"
                              year-row="{value}年" month-row="{value}月" day-row="{value}日" hour-row="{value}点"
                              minute-row="{value}分"></datetime>

                    <datetime v-model="meeting.endDate" :min-year=minYear :format="format"
                              title="结束时间"
                              year-row="{value}年" month-row="{value}月" day-row="{value}日" hour-row="{value}点"
                              minute-row="{value}分"></datetime>

                    <x-input placeholder="请输入会议地点" v-model="meeting.address"></x-input>
                </section>

                <section class="meeting-user">
                    <selector v-model="meeting.meetingType" title="会议类型" name="meetingType" :options="typeList" direction="rtl"></selector>
                    <cell title="选择纪要人" :value="summaryUser.userName" @click.native="showSecondPart" is-link :disabled="null != meeting.meetId ? true : false"></cell>
                    <cell title="选择参会人" :value="hadUserDesc" @click.native="showThirdPart" is-link :disabled="null != meeting.meetId ? true : false"></cell>
                </section>
            </section>

            <div class="adapt"></div>
            <x-button class="publish-meeting-btn" @click.native="publishMeeting()">确认发布</x-button>
        </section>

        <!-- 选择纪要人页面 -->
        <section class="second-part" v-show="secondPart">
            <search v-model="userName" @on-submit="onSubmit(1)" ref="search" placeholder="输入名字搜索"></search>

            <section class="select-from-all">
                <cell title="选择纪要人" value="去通信录选择" @click.native="showFivePart" is-link></cell>
            </section>

            <group title="历史会议纪要记录人" v-show="summaryUsers.length > 0">
                <checker v-model="summaryUser" type="radio" default-item-class="demo5-item" selected-item-class="demo5-item-selected">
                    <checker-item v-for="(user,index) in summaryUsers" :key="index" :value="user" >{{user.userName}}</checker-item>
                </checker>
            </group>

            <group title="搜索结果" v-show="searchUserList1.length > 0">
                <checker class="user-detail-check" v-model="summaryUser" type="radio" default-item-class="demo6-item" selected-item-class="demo5-item-selected">
                    <checker-item v-for="(user,index) in searchUserList1" :key="index" :value="user">{{user.userName}}</checker-item>
                </checker>
            </group>

            <div class="select-summary-user">
                <x-button  @click.native="hideSecondAndThirdPart()">返 回</x-button>
                <x-button  @click.native="selectSummaryUser()">选好了</x-button>
            </div>
        </section>

        <!-- 根据党组织结构选择纪要人页面 -->
        <section class="five-part" v-show="fivePart">
            <tab>
                <tab-item v-for="(item,index) in level1" :key="index" :selected="index===0" @on-item-click="onItemClick(item.pid)">{{ item.partyName }}</tab-item>
            </tab>

            <div class="left-content">
                <div class="left-item" v-for="(item,index) in level2" :key="index" @click="getUserByPartyName(index, item.partyName)"
                     :id="'party_' + index" :class="index == selectedIndex ?'active':''">
                    {{ item.partyName }}
                </div>
            </div>

            <div class="right-content">
                <checker class="user-detail-check" v-model="summaryUser" type="radio" default-item-class="demo5-item" selected-item-class="demo5-item-selected" v-if="pUser.length > 0">
                    <checker-item v-for="(item,index) in pUser" :key="index" :value="item">{{item.userName}}</checker-item>
                </checker>
                <div v-if="pUser.length == 0">
                    <div class="no-data" v-show="noData"><p>该党支部下没有用户数据</p></div>
                    <loading v-show="!noData"></loading>
                </div>
            </div>

            <div class="select-join-user">
                <x-button  @click.native="onlyShowSecondPart()">返 回</x-button>
                <x-button  @click.native="onlyShowSecondPart()">选好了</x-button>
            </div>
        </section>

        <!-- 选择参会人页面 -->
        <section class="third-part" v-show="thirdPart">
            <search v-model="userName" @on-submit="onSubmit(2)" ref="search" placeholder="输入名字搜索"></search>
            <section class="select-user-from-all clfix">
                <div class="user-detail fl clfix" @click="showJoinUsers">
                    <div>已选择<span id="selectNum">{{selectedUser.length}}</span>人</div>
                    <div>详情 ></div>
                </div>
                <div class="to-choose fr" @click="showForthPart">去选择</div>
            </section>

            <section class="regular-user">
                <div class="regular-user-head">
                    <img src="../../assets/images/meeting/small-logo.png"><span>·</span>固定人员
                </div>
                <div class="regular-users">
                    <checker v-model="selectedUser" type="checkbox" default-item-class="demo5-item" selected-item-class="demo5-item-selected">
                        <checker-item v-for="(user,index) in regularUsers" :key="index" :value="user">{{user.userName}}</checker-item>
                    </checker>
                </div>
            </section>

            <section class="history-user" v-show="historyUsers.length > 0">
                <div class="history-user-head">
                    <img src="../../assets/images/meeting/small-logo.png"><span>·</span>历史参会人员
                </div>
                <div class="history-users">
                    <checker v-model="selectedUser" type="checkbox" default-item-class="demo5-item" selected-item-class="demo5-item-selected">
                        <checker-item v-for="(user,index) in historyUsers" :key="index" :value="user">{{user.userName}}</checker-item>
                    </checker>
                </div>
            </section>

            <!-- 参会人详细页面 -->
            <section class="user-detail-back" v-show="detailShow">
                <div class="user-detail-show">
                    <img class="user-detail-close" src="../../assets/images/meeting/close.png" @click="detailShow = false">
                    <div class="user-details">
                        <div>
                            <img src="../../assets/images/meeting/large-logo.png">
                        </div>
                        参会人名单
                    </div>
                    <checker class="user-detail-check" v-model="selectedUser" type="checkbox" default-item-class="demo5-item" selected-item-class="demo5-item-selected">
                        <checker-item v-for="(user,index) in selectedUser" :key="index" :value="user">{{user.userName}}</checker-item>
                    </checker>
                    <img class="user-detail-foot" src="../../assets/images/meeting/detail-foot.png">
                </div>
            </section>

            <group title="搜索结果" v-show="searchUserList2.length > 0">
                <!--<checklist :options="searchUserList2" @on-change="selectedJoinUser"></checklist>-->
                <checker class="user-detail-check" v-model="selectedUser" type="checkbox" default-item-class="demo6-item" selected-item-class="demo5-item-selected">
                    <checker-item v-for="(user,index) in searchUserList2" :key="index" :value="user">{{user.userName}}</checker-item>
                </checker>
            </group>
            <div class="select-join-user">
                <x-button  @click.native="hideSecondAndThirdPart()">返 回</x-button>
                <x-button  @click.native="selectJoinUser()">选好了</x-button>
            </div>
        </section>

        <!-- 根据党组织结构选择参会人页面 -->
        <section class="forth-part" v-show="forthPart">
            <tab>
                <tab-item v-for="(item,index) in level1" :key="index" :selected="index===0" @on-item-click="onItemClick(item.pid)">{{ item.partyName }}</tab-item>
            </tab>

            <div class="left-content">
                <div class="left-item" v-for="(item,index) in level2" :key="index" @click="getUserByPartyName(index, item.partyName)"
                        :id="'party_' + index" :class="index == selectedIndex ?'active':''">
                    {{ item.partyName }}
                </div>
            </div>

            <div class="right-content">
                <checker class="user-detail-check" v-model="selectedUser" type="checkbox" default-item-class="demo5-item" selected-item-class="demo5-item-selected" v-if="pUser.length > 0">
                    <checker-item v-for="(item,index) in pUser" :key="index" :value="item">{{item.userName}}</checker-item>
                </checker>
                <div v-if="pUser.length == 0">
                    <div class="no-data" v-show="noData"><p>该党支部下没有用户数据</p></div>
                    <loading v-show="!noData"></loading>
                </div>
            </div>

            <div class="select-join-user">
                <x-button  @click.native="onlyShowThirdPart()">返 回</x-button>
                <x-button  @click.native="onlyShowThirdPart()">选好了</x-button>
            </div>
        </section>

        <confirm v-model="leaveShow" title="离开后数据将丢失" @on-confirm="powerLeave" @on-cancel="stayHere">
            <p style="text-align:center;">确定离开?</p>
        </confirm>

    </section>
</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import { Tab, TabItem,dateFormat,Confirm,Checker, CheckerItem,Group,Cell, XTextarea, XInput,Selector, Datetime,Search,XButton} from 'vux'
    import {getHistoryAndRegularUsers,publishMeeting,searchUser} from '../../api/api'
    import loading from '../../components/common/loading.vue'
    import { formatDate } from '../../utils/index'
    export default {
        components: {
            Confirm,
            Checker,
            CheckerItem,
            Group,
            Cell,
            XTextarea,
            XInput,
            Datetime,
            Search,
            Selector,
            XButton,
            Tab,
            TabItem,
            loading
        },
        data () {
            return {
                typeList:['支部党员大会','党支部委员会','党小组会','支部主题党日','组织生活会','民主评议','评选表彰','书记述职','党课','其他'],
                powerGo:false,
                leaveShow:false,//离开当前页提示 标记
                detailShow:false,//已选参会人信息展示 标记
                path:'',//记录即将前往页面
                firstPart:true,//第一部分，基本信息填写
                secondPart:false,//第二部分，选择纪要人
                thirdPart:false,//第三部分，选择参会人
                forthPart:false,//第四部分，根据党委、党支部选择参会人
                fivePart:false,//第四部分，根据党委、党支部选择纪要人
                minYear:2018,//最小可选年份
                format: 'YYYY-MM-DD HH:mm',//时间格式化
                meeting:{meetId:'',title:'',topics:'',content:'',startDate:'',endDate:'',address:'',meetingType:'',editTimes:1},//会议
                userName:'',//搜索关键字
                summaryUser:{},//选择的纪要人
                summaryUsers: [],//历史纪要人
                searchUserList1: [],//纪要人搜索结果集
                searchUserList2: [],//参会人搜索结果
                hadUserDesc:'已选0人',//已选人数描述
                selectedUser: [],//已选参会人
                regularUsers:[],//固定参会人员列表
                historyUsers:[],//历史参会人员列表
                level1: [],
                level2: [],
                pUser:[],
                selectedIndex:0,
                noData:false
            }
        },
        methods: {
            //初始化数据
            initPublish:function () {
                let _self = this;

                if (null != _self.$route.query.meetId && undefined != _self.$route.query.meetId){
                    _self.meeting.meetId = _self.$route.query.meetId
                }
                if ('' == _self.meeting.meetId){
                    _self.meeting.meetId = null
                }
                console.log(_self.meeting.meetId)
                /*接口请求*/
                getHistoryAndRegularUsers({meetId:_self.meeting.meetId}).then((response) => {
                    console.log(response)
                    if(response.success){
                        if(null != response.data.meeting){
                            _self.meeting = response.data.meeting;
                            _self.meeting.editTimes = _self.meeting.editTimes + 1
                            _self.summaryUser.uid =  _self.meeting.summaryUser
                            _self.summaryUser.userName = _self.meeting.summaryUserName
                            _self.hadUserDesc = '已选'+ response.data.selectedUser.length +'人'
                            _self.selectedUser = response.data.selectedUser
                        } else {
                            _self.meeting.meetId = null
                        }

                        _self.meeting.startDate = dateFormat(_self.meeting.startDate,_self.format);
                        _self.meeting.endDate = dateFormat(_self.meeting.endDate,_self.format);
                        _self.regularUsers = response.data.regularUsers;
                        _self.summaryUsers = response.data.summaryUsers;
                        _self.historyUsers = response.data.historyUsers;
                        _self.level1 = response.data.level1;
                        _self.level2 = response.data.level2;
                        _self.pUser = response.data.pUser;
                        if (_self.pUser.length == 0){
                            _self.noData = true
                        }
                    } else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }).catch((error) => {
                    console.log(error)
                })
            },
            //选择时间
            vertify () {
                let _self = this
                if (_self.meeting.editTimes > 3){
                    _self.$vux.toast.text('修改次数不能超过3次', 'middle')
                    return false;
                }
                if ('' == _self.meeting.title.trim() || _self.meeting.title.length > 30){
                    _self.$vux.toast.text('标题不能为空且长度限制30字', 'middle')
                    return false;
                }
                if ('' == _self.meeting.content.trim() || _self.meeting.content.length > 1000){
                    _self.$vux.toast.text('内容不能为空且长度限制1000字', 'middle')
                    return false;
                }
                if ('' == _self.meeting.startDate || '' == _self.meeting.endDate ){
                    _self.$vux.toast.text('起始和截止时间都不能为空', 'middle')
                    return false;
                }
                if (_self.meeting.startDate > _self.meeting.endDate){
                    _self.$vux.toast.text('起始时间不能大于截止时间', 'middle')
                    return false;
                }
                if (null == _self.meeting.address || _self.meeting.address.length > 20){
                    _self.$vux.toast.text('地点长度限制20字', 'middle')
                    return false;
                }
                console.log(_self.summaryUser)
                if ( null == _self.summaryUser.uid || _self.summaryUser.uid.length == 0){
                    _self.$vux.toast.text('请选择纪要人', 'middle')
                    return false;
                }
                if (_self.selectedUser.length == 0){
                    _self.$vux.toast.text('请选择参会人', 'middle')
                    return false;
                }
                return true;
            },
            //发布会议
            publishMeeting:function () {
                let _self = this
                if (_self.vertify()){
                    /*接口请求*/
                    publishMeeting({meeting:_self.meeting,summaryUser:_self.summaryUser,selectedUser:_self.selectedUser}).then((response) => {
                        console.log(response)
                        _self.$vux.toast.text(response.message, 'middle')
                        if(response.success){
                            _self.powerGo = true;
                            setTimeout(() => {
                                _self.$router.push('/meeting')
                            }, 1000)
                        } else {
                        }
                    }).catch((error) => {
                        console.log(error)
                    })
                }
            },
            //展示第二部分-选择纪要人
            showSecondPart:function () {
                if (null != this.meeting.meetId ){
                    this.$vux.toast.text('纪要人不支持再次编辑', 'middle')
                    return;
                }
                this.firstPart= false;
                this.secondPart= true;
                this.thirdPart= false;
                this.forthPart= false;
            },
            // 展示第三部分-选择参会人
            showThirdPart:function () {
                if (null != this.meeting.meetId ){
                    this.$vux.toast.text('参会人不支持再次编辑', 'middle')
                    return;
                }
                this.firstPart= false;
                this.secondPart= false;
                this.thirdPart= true;
                this.forthPart= false;
            },
            //隐藏第二、三部分-选择纪要人
            hideSecondAndThirdPart:function () {
                this.firstPart= true;
                this.secondPart= false;
                this.thirdPart= false;
                this.forthPart= false;
            },
            onlyShowThirdPart:function () {
                this.firstPart= false;
                this.secondPart= false;
                this.thirdPart= true;
                this.forthPart= false;
                this.fivePart= false;
            },
            onlyShowSecondPart:function () {
                this.firstPart= false;
                this.secondPart= true;
                this.thirdPart= false;
                this.forthPart= false;
                this.fivePart= false;
            },
            //搜索
            onSubmit (type) {
                let _self = this;
                /*接口请求*/
                searchUser({userName:_self.userName}).then((response) => {
                    console.log(response)
                    if(response.success){
                        if (type == 1){
                            _self.searchUserList1 = response.data;
                        } else {
                            _self.searchUserList2 = response.data;
                        }
                    } else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }).catch((error) => {
                    console.log(error)
                })
            },
            getUserByPartyName:function (index,partyName) {
                $("#party_" + index).addClass("active").siblings().removeClass("active")
                let _self = this;
                _self.selectedIndex = index
                _self.pUser = []
                _self.noData = false
                /*接口请求*/
                searchUser({partyName:partyName}).then((response) => {
                    console.log(response)
                    if(response.success){
                        _self.pUser = response.data;
                    } else {
                        _self.noData = true
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }).catch((error) => {
                    console.log(error)
                })
            },
            //确认离开
            powerLeave () {
                this.$router.replace(this.path)
            },
            //留下
            stayHere(){
                this.path = ''
            },
            showForthPart () {
                this.thirdPart= false;
                this.forthPart= true;
            },
            showFivePart () {
                this.secondPart= false;
                this.fivePart= true;
            },
            //显示参会详情
            showJoinUsers:function () {
                this.detailShow = true
                console.log('selectedUser:',this.selectedUser)
            },
            //纪要人选好了
            selectSummaryUser:function () {
                this.firstPart= true;
                this.secondPart= false;
                this.thirdPart= false;
                this.userName = ''
                $('html,body').animate({scrollTop: '1000px'}, 500);
            },
            //参会人选好了
            selectJoinUser:function () {
                this.firstPart= true;
                this.secondPart= false;
                this.thirdPart= false;
                console.log('selectedUser:', this.selectedUser)
                this.hadUserDesc = '已选' + this.selectedUser.length + '人'
                this.userName = ''
                $('html,body').animate({scrollTop: '1000px'}, 500);
            },
            onItemClick (pid) {
                console.log('pid', pid)
                if(8 != parseInt(pid)){
                    this.$vux.toast.text('其他党委尚未开放', 'middle')
                }
            },
            changeStartDate (startDate) {
                // console.log(startDate)
                // console.log(typeof startDate)
                // let date = new Date(startDate.replace(/-/,"/")).getTime() //

                let dateArr = startDate.split(" ");
                let yearMonthDayArr = dateArr[0].split('-');
                let hourMinuteArr = dateArr[1].split(':');

                let date = new Date(yearMonthDayArr[0], yearMonthDayArr[1]-1, yearMonthDayArr[2]);
                date.setHours(parseInt(hourMinuteArr[0]))
                date.setMinutes(parseInt(hourMinuteArr[1]))

                let datetime = date.getTime()

                // 两小时之后
                datetime += 2*3600*1000
                // 结束时间给个默认值
                this.meeting.endDate = formatDate(datetime,'Y-M-D h:m')
            }
        },
        mounted () {
            let height = $(window).height();
            $(".topArea").css("minHeight",height)//一开始就让按钮在底部
            $(".left-content").css("height",height - 84)//固定左右的高度
            $(".right-content").css("height",height - 45)//固定左右的高度

            $(window).resize(function() {
                let height = $(window).height();
                if(height > 270){
                    $(".meeting-button").show();
                } else {
                    $(".meeting-button").hide();
                }
            });

            this.initPublish()
        },
        // 在当前路由改变时调用
        beforeRouteLeave (to, from, next) {
            console.log('to=', to.path)
            if ('' == this.path && !this.powerGo){
                this.path = to.path;
                this.leaveShow = true
                next(false)
            } else {
                next()
            }
        },
    }


</script>

<style lang="less">
    @import "../../assets/css/meeting/publishMeeting";
</style>
