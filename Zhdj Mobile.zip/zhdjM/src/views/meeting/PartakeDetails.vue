<!--起始页开始-->
<template>
    <section class="partakeDetails">
        <div class="top">
            <img src="../../assets/images/countExam/topIcon.png" />
            <b>参与详情</b>
            <span class="meetingTime" v-if="startDifference > 0" style="color:#c3373a">距会议开始还有 {{moreTime}}</span>
            <span class="meetingTime" v-if="startDifference < 0" style="color:#c3373a"></span>
        </div>
        <div class="listBox" v-infinite-scroll="loadSelect" infinite-scroll-disabled="busy" infinite-scroll-distance="10">
            <div class="list" v-for="value in uDataList">
                <img :src="value.headImg">
                <b>{{value.userName}}</b>
                <span style="color:#c3373a;" v-if="value.leaveStatus == -1">请假未通过</span>
                <span style="color:#327caf;" v-else-if="value.leaveStatus == 1">请假通过</span>
                <span style="color:#b69337;" v-else-if="value.leaveStatus == 2">请假申请中</span>
                <h5 style="color:#327caf;" v-if="value.attend == 1">确认参加</h5>
                <h5 style="color:#c3373a;" v-else-if="value.absent == 1">缺席</h5>
                <h5 v-else-if="value.leaveStatus != 0" style="color:#b69337" @click="checkLeave(value.uid,value.meetId)">请假
                    <img src="../../assets/images/countExam/right.png"  class="moreInfoIcon"/>
                </h5>
                <h5 v-else-if="value.leaveStatus == 0 && value.attend == 0" style="color:#c3373a;">待参加</h5>
            </div>
            <!-- <img src="../../assets/images/countExam/contentBg.png" class="contentBg"/> -->
        </div>
        <div class="seat"></div>
        <tips :content="tip1" :position="position"></tips>
        <button class="bottomBtn" @click="generateSeat">生成座位</button>
        <confirm v-model="showTip" title="生成座位" @on-confirm="confirmSeat" @on-cancel="cancelSeat">
            <p style="text-align:center;">确定吗</p>
        </confirm>

    </section>
</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import {Confirm} from 'vux'
    import { getAtsMeetingStsByMid,generateSeat } from '../../api/api'
    import tips from '../../components/common/tips.vue'
    export default {
        components: {
            Confirm,
            tips
        },
        data () {
            return {
                showTip:false,
                getAtsMeetingStsByMid:{},
                uDataList:[],
                uCurPage:1,
                uTotalPage:1,
                uBusy:false,
                meetId:"",
                headImg:"",
                userName:"",
                leaveStatus:"",
                absent:"",
                uid:"",
                startDifference:"",
                endDifference:"",
                tip1:'请将所有人状态确认完毕后，生成座位表',
                position:'vux-popover-arrow-down'
            }
        },
        methods: {

            confirmSeat:function () {
                let _self = this;
                generateSeat({meetId:_self.meetId}).then((response) => {
                    console.log(response)
                    this.showTip = true;
                    if (response.success) {
                        this.$vux.loading.show({
                            text: 'Loading'
                        })
                        this.showTip = false;
                        setTimeout(() => {
                            this.$vux.loading.hide()
                        }, 1000)
                        _self.$vux.toast.text("生成成功", 'middle');
                        this.$router.push("/meetingDetail/" + this.question.meetId)
                    } else {
                    }
                }).catch((error) => {
                    console.log(error)
                })
            },
            cancelSeat:function () {
                return;
            },
            loadSelect:function() {
                if(this.uCurPage > this.uTotalPage || this.uBusy){
                    this.uBusy = true;
                    return;
                }
                this.uBusy = true;
                $(".load-more").show();
                this.moreSelect();
            },
            moreSelect:function () {
                let _self = this;
                getAtsMeetingStsByMid({curPage:_self.uCurPage,meetId:_self.meetId}).then((response) => {
                    _self.meetId = _self.$route.params.meetId;
                    console.log('getAtsMeetingStsByMid',response)
                    if(response.success) {
                        _self.uDataList = _self.uDataList.concat(response.data.rows);
                        _self.uTotalPage = response.data.pageCount;
                        _self.uCurPage++;
                        _self.uBusy = false;
                        _self.startTime = response.data.rows[0].startDate;
                        let ms = Date.parse(new Date());
                        _self.startDifference = _self.startTime - ms;
                        console.log(_self.startDifference);
                        //获取当前时间 并且转化为毫秒
                        //将时间差转化为day/hour/min
                        let days = parseInt(_self.startDifference / (1000 * 60 * 60 * 24));
                        let hours = parseInt((_self.startDifference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                        let minutes = parseInt((_self.startDifference % (1000 * 60 * 60)) / (1000 * 60));
                        let moreTime = days + " 天 " + hours + " 小时 " + minutes + " 分";
                        console.log(moreTime);
                        _self.moreTime = moreTime;
                    } else {
                        $(".no-business").show()
                    }
                    // _self.busy = false;
                    $(".load-more").hide()
                }).catch((error) => {
                    $(".load-more").hide()
                    console.log(error)
                })
            },
            generateSeat:function(){
                this.showTip = true;
            },

            checkLeave:function(uid,meetId){
                this.$router.push("/checkLeave?uid="+uid+"&meetId="+meetId);
            }
        },
        mounted () {
            let height = $(window).height();
            $(".partakeDetails").css("height",height);
            this.meetId = this.$route.params.meetId;
        }
    }


</script>

<style lang="less">

    .partakeDetails {
        .tip-desc{
            position:fixed !important;
            bottom: 55px;
        }
        .top{
            height:0.8rem;
            width:100%;
        }
        .top>img{
            height:0.4rem;
            width:0.4rem;
            margin-top:0.15rem;
            margin-left:0.3rem;
            float:left;
        }
        .top>b{
            height:0.8rem;
            line-height:0.8rem;
            font-weight:normal;
            margin-left:0.2rem;
            font-size:0.30rem;
        }
        .meetingTime{
            line-height:0.8rem;
            font-size:0.27rem;
            float:right;
            margin-right:0.5rem;
        }
        .list{
            width:100%;
            height:60px;
            border-top:1px solid #ebe7db;
            background-color:white;
            position:relative;
        }
        .list>img{
            width:50px;
            height:50px;
            border-radius: 50%;
            background-color:skyblue;
            margin-left:0.2rem;
        }
        .list>b{
            height:60px;
            line-height:60px;
            font-weight:normal;
            margin-left:0.2rem;
            font-size:15px;
        }
        .list>h5{
            height:60px;
            line-height:60px;
            font-weight:normal;
            font-size:15px;
            float:right;
            margin-right:0.5rem;
            color:#327caf;
        }
        .list>h4{
            height:60px;
            line-height:60px;
            font-weight:normal;
            font-size:0.30rem;
            float:right;
            margin-right:0.5rem;
            color:#c3373a;
        }
        .list>span{
            font-size:15px;
            line-height:60px;
            position:absolute;
            left:3.5rem;

        }
        // .contentBg{
        //     width:100%;
        //     height:65px;
        //     margin-top:25px;
        //     position:absolute;
        //     bottom:0;
        // }
        .bottomBtn{
            position:fixed;
            width:100%;
            height:50px;
            line-height:50px;
            color:white;
            background-color:#c3373a;
            font-size:16px;
            text-align:center;
            bottom:0;
        }
        .moreInfoIcon{
            height: 0.3rem;
            width: 0.15rem;
            position:absolute;
            right:0.2rem;
            top:0.45rem;
        }
        .listBox{
            position:relative;
        }
        .seat{
            // height:140px;
            height:50px;
            width:100%;
        }


    }
</style>
