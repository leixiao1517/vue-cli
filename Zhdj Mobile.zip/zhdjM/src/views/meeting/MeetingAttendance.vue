<!--会议详情开始-->
<template>
    <section class="meeting-user-detail">
        <!-- 考勤页面 -->
        <div class="user-detail">
            <div class="user-head">
                <span class="title"><img src="../../assets/images/meeting/small-logo.png"><span>·</span>考勤记录</span>
                <span class="sign-in">签到</span>
                <span class="check">抽查</span>
                <span class="sign-out">签退</span>
            </div>
            <div class="detail" v-infinite-scroll="loadUser" infinite-scroll-disabled="busy" infinite-scroll-distance="10">
                <div class="attendance" v-for="(user, index) in userList" :key="index" v-if="userList.length > 0">
                    <span class="userName"><img :src="user.headImg">&nbsp;{{user.userName}}</span>
                    <span :class=" user.signIn == 0?'v-hidden':''" class="sign-in-img" v-if=""><img src="../../assets/images/meeting/red.png"></span>
                    <span class="check-img" :class="user.checkStatus == 0?'v-hidden':''"><img src="../../assets/images/meeting/orange.png"></span>
                    <span class="sign-out-img" :class="user.signOut == 0?'v-hidden':''"><img src="../../assets/images/meeting/blue.png"></span>
                </div>
                <loading></loading>
            </div>
        </div>
        <div class="qrCode">
            <flexbox :gutter="0">
                <flexbox-item @click.native="showQrCode('SIGN_IN')"><div class="flex-demo">签到</div></flexbox-item>
                <flexbox-item @click.native="showQrCode('CHECK')"><div class="flex-demo">抽查</div></flexbox-item>
                <flexbox-item @click.native="showQrCode('SIGN_OUT')"><div class="flex-demo">签退</div></flexbox-item>
            </flexbox>
        </div>

        <div class="qrCodeDiv" style="display: none;" @click="hideQrCode">
            <div class="qrcontent">
                <p>签到/抽查/签退二维码</p>
                <qrcode :value="qrCodeUrl" type="img" :size=200></qrcode>
            </div>
        </div>
    </section>
</template>
<!--会议详情结束-->

<script>
    import $ from 'jquery'
    import { Qrcode,Flexbox,FlexboxItem } from 'vux'
    import { mobileServer } from '../../config/config'
    import { meetingUserList } from '../../api/api'
    import loading from '../../components/common/loading.vue'

    export default {
        components: {
            Qrcode,
            Flexbox,
            FlexboxItem,
            loading
        },
        data () {
            return {
                meetId:Number,
                userList:[],//leaveStatus:2,//0未请假,1请假通过,-1查看未通过,2:查看中
                curPage:1,
                totalPage:1,
                busy:false,
                qrCodeUrl:''
            }
        },
        methods: {
            //初始化
            initUserDetail:function () {
                let _self = this;
                _self.meetId = _self.$route.params.meetId;
                /*接口请求*/
                meetingUserList({curPage:this.curPage,meetId:_self.meetId}).then((response) => {
                    console.log(response)
                    $(".load-more").hide();
                    if(response.success){
                        this.userList = this.userList.concat(response.data.page.rows);
                        this.totalPage = response.data.page.pageCount;
                        this.curPage++;
                        this.busy = false;
                    } else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }).catch((error) => {
                    console.log(error)
                })
            },
            loadUser: function() {
                if(this.curPage > this.totalPage || this.busy){
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show()
                this.initUserDetail();
            },
            showQrCode:function (type) {
                this.qrCodeUrl = mobileServer + 'meeting/signCheck?type=' + type + '&meetId=' + this.meetId + '&objType=' + 5;
                console.log(this.qrCodeUrl)
                $(".qrCodeDiv").show();
            },
            hideQrCode:function () {
                $(".qrCodeDiv").hide();
            }
        },
        mounted () {

        }
    }


</script>

<style lang="less">
    @import '~vux/src/styles/1px.less';

    .flex-demo {
        line-height:40px;
        text-align: center;
        color: #f0bb68;
        background-color: #c3373a;
        border-radius: 4px;
        background-clip: padding-box;
        border-right:1px solid #c3373a;
    }
    .meeting-user-detail{
        .user-head{
            line-height: 40px;
            margin-left: .2rem;
            img{
                width:15px;
                height:15px;
                margin-top: -5px;
            }
            .check{
                color:#e4a439;
            }
            .sign-out{
                color:#0e6ab9;
            }
        }
        .qrCode{
            width:100%;
            height:40px;
            position: fixed;
            bottom: 0;
        }
        .detail{
            padding-bottom: 45px;
        }
        .attendance{
            line-height:40px;
            background-color:#ffffff;
            padding-left: .2rem;
            margin-top: 1px;
            img{
                width:14px;
                height:10px;
            }
        }
        .title,.userName{
            display: inline-block;
            width:2rem;
            text-align: left;
        }
        .userName{
            width:3.1rem;
        }
        .userName>img{
            height:30px;
            width:30px;
            border-radius:50%;
        }
        .sign-in{
            margin-left: 1.5rem;
            color:#a12730;
        }
        .check,.sign-out{
            margin-left: .5rem;
        }
        .user-name{
            margin-left: .2rem;
        }
        .sign-in-img{
            margin-left: 0.6rem;
        }
        .check-img,.sign-out-img{
            margin-left: .8rem;
        }
        .qrCodeDiv{
            position: fixed;
            left:0;
            top:0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,.5);
        }
        .qrCodeDiv>div>p{
            margin-bottom: 15px;
            text-align: center;
            color: #a12730;
            font-size: 16px;
        }
        .qrCodeDiv > div{
            width:200px;
            height:240px;
            left: 50%;
            position: absolute;
            top: 50%;
            margin-left: -150px;
            margin-top: -180px;
            padding: 30px 50px 50px 50px;
            background-color: white;
        }
    }
</style>
