    <!--起始页开始-->
<template>
    <section class="startMeeting">
        <div class="topSeat"></div>
        <div class="topBox">
            <x-input placeholder="搜索会议" :max="20" class="searchMeeting" v-model="title" @on-enter="searchMeeting"></x-input>
            <img src="../../assets/images/meetinglist/zoom.png" class="zoom"/>

            <button class="btnBox">
                <button @click="btnClick1" class="tab1" id="active" >我参加的</button>
                <button @click="btnClick2" class="tab2">我发布的</button>
            </button>
        </div>
        <div class="myJoin columnActive">
            <div class="column">
                <span>会议统计</span>
            </div>
            <div class="census" v-if = " getMeetingDataByUid.allNum == null || getMeetingDataByUid.realNum == null || getMeetingDataByUid.vacNum == null || getMeetingDataByUid.absNum == null">
                <div>
                    <p>0</p>
                    <p>应参加</p>
                </div>
                <div>
                    <p>0</p>
                    <p>实际参与</p>
                </div>
                <div>
                    <p>0</p>
                    <p>请假</p>
                </div>
                <div>
                    <p>0</p>
                    <p>缺席</p>
                </div>
            </div>
            <div class="census" v-if = " getMeetingDataByUid.allNum >= 0 || getMeetingDataByUid.realNum >=0 || getMeetingDataByUid.vacNum >= 0 || getMeetingDataByUid.absNum >= 0">
                <div>
                    <p>{{ getMeetingDataByUid.allNum }}</p>
                    <p>应参加</p>
                </div>
                <div>
                    <p>{{ getMeetingDataByUid.realNum }}</p>
                    <p>实际参与</p>
                </div>
                <div>
                    <p>{{ getMeetingDataByUid.vacNum }}</p>
                    <p>请假</p>
                </div>
                <div>
                    <p>{{ getMeetingDataByUid.absNum }}</p>
                    <p>缺席</p>
                </div>
            </div>
            <div class="column">
                <span>会议列表</span>
            </div>
            <div class="listBox1" v-infinite-scroll="loadSelect" infinite-scroll-disabled="busy" infinite-scroll-distance="10" id="selectScroll" >
                <div class="list" v-for="value in sDataList" @click="sDetail(value.meetId,value.uid,value.leaveStatus)" v-if="sDataList.length > 0">
                    <b class="o-ellipsis" style="width:5rem;font-size:0.25rem;display: inline-block;">{{ value.title }}</b>

                    <div>
                        <!-- process 1会议未开始2进行中3已结束 leaveStatus 0未请假 1请假通过 2审核中 -1拒绝  attend确认参加
                             signIn签到  checkStatus抽查 signOut签退 全部为1 表示全程参与会议
                             exam 参会人是否需要考试 0：不需要考试，1：未考；2：已考
                             meetExam 会议是否发布考试 0未 1已
                             -->
                        <span v-if="value.process == 1 && value.leaveStatus == 0 && value.attend == 0" style="color:#D0021B">待参加&nbsp;&nbsp;</span>
                        <span v-if="value.process == 1 && value.attend == 1" style="color:#D0021B">未开始&nbsp;&nbsp;</span>
                        <span v-else-if="(value.process == 1 || value.process == 2) && value.leaveStatus == 1" style="color:#b4b5b7;">请假通过&nbsp;&nbsp;</span>
                        <span v-else-if="value.process == 1 && value.leaveStatus == 2" style="color:#D0021B;">请假申请中&nbsp;&nbsp;</span>
                        <span v-else-if ="value.process == 1 && value.leaveStatus == -1" style="color:#b4b5b7;">请假未通过&nbsp;&nbsp;</span>
                        <span v-else-if="value.process == 2 && value.leaveStatus != 1" style="color:#D0021B;">进行中&nbsp;&nbsp;</span>

                        <!-- 会议结束后的状态-->
                        <span v-else-if="value.process == 3 && value.signIn == 1 && value.signOut == 1 && value.checkStatus == 1"style="color:#b4b5b7;">已结束&nbsp;&nbsp;</span>
                        <span v-else-if="value.process == 3 && value.meetExam == 1 && (value.signIn || 0 && value.signOut == 0 ||
                            value.checkStatus == 0) && value.exam != 2" style="color:#D0021B;">待考试&nbsp;&nbsp;</span>
                        <span v-else-if="value.process == 3 && value.meetExam == 0 && (value.signIn || 0 && value.signOut == 0 ||
                            value.checkStatus == 0) && value.exam != 2" style="color:#b4b5b7;">已结束&nbsp;&nbsp;</span>
                        <span v-else-if="value.process == 3 && value.meetExam == 0 && value.leaveStatus != 0" style="color:#b4b5b7;">已结束&nbsp;&nbsp;</span>
                        <span v-else-if="value.process == 3 && value.meetExam == 1 && value.leaveStatus != 0 && value.exam != 2" style="color:#D0021B;">待考试&nbsp;&nbsp;</span>
                        <span v-else-if="value.process == 3 && value.exam == 2" style="color:#b4b5b7;">已结束&nbsp;&nbsp;</span>
                        <img src="../../assets/images/meetinglist/left.png" />
                    </div>
                </div>
            </div>
            <div class="no-data" v-if="sDataList.length == 0"><p>没有会议数据</p></div>
        </div>
        <div class="meetingBegin ">
            <div class="column">
                <span>我发起的会议</span>
            </div>
            <div class="listBox2" v-infinite-scroll="loadSimple" infinite-scroll-disabled="busy" infinite-scroll-distance="10" id="simpleScroll" >
                <div class="list" v-for="value in qDataList" @click="qDetail(value.meetId)" v-if="qDataList.length > 0">
                    <b class="o-ellipsis" style="width:5.2rem;font-size:0.25rem;display: inline-block;">{{value.title}}</b>
                    <div>
                        <span v-if="compileDate(value.startDate,value.endDate) == 1" style="color:#D0021B">未开始&nbsp;&nbsp;</span>
                        <span v-else-if="compileDate(value.startDate,value.endDate) == 2" style="color:#D0021B;">进行中&nbsp;&nbsp;</span>
                        <span v-else-if="compileDate(value.startDate,value.endDate) == 3" style="color:#b4b5b7;">已结束&nbsp;&nbsp;</span>
                        <img src="../../assets/images/meetinglist/left.png" />
                    </div>
                </div>
            </div>
            <div class="tabContentBg" v-show="qDataList.length > 0">
                <img class="bottom-img" src="../../assets/images/meetinglist/launchBg.png" />
            </div>
            <div class="no-data" v-if="qDataList.length == 0"><p>没有会议数据</p></div>
        </div>
        <button v-show="personalState == 4  || personalState == 5 || personalState == 3" class="footBtn"  @click="publishMeeting()" >发起会议</button>
    </section>
</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import { XInput } from 'vux'
    import { getMeetingDataByUid,getPublishedByUid,searchMeeting } from '../../api/api'

    export default {
        components: {
            XInput
        },
        data() {
            return {
                title: '',
                isSplashTemp: "",
                uid: "",
                curTab: 0,
                sDataList: [],
                sCurPage: 1,
                sTotalPage: 1,
                sBusy: false,
                qDataList: [],
                qCurPage: 1,
                qTotalPage: 1,
                qBusy: false,
                meetingUserModel: "",
                getMeetingDataByUid: [],
                meetId: "",
                type: "",
                flag: 1,
                personalState: "",
                rows:"",
            }
        },
        methods: {
            btnClick1: function () {                                       //选项卡1 点击事件
                this.flag = 1;
                this.sBusy = false;
                $(".myJoin").addClass("columnActive");
                $(".meetingBegin").removeClass("columnActive");
                $(".tab1").attr("id", "active");
                $(".tab2").attr("id", "");
            },
            btnClick2: function () {//选项卡2 点击事件
                this.flag = 2;
                this.qBusy = false;
                $(".meetingBegin").addClass("columnActive");
                $(".myJoin").removeClass("columnActive");
                $(".tab2").attr("id", "active");
                $(".tab1").attr("id", "");
            },
            compileDate: function (startDate, endDate) {
                let beginTime = new Date(startDate);
                let endTime = new Date(endDate);
                let curTime = new Date().getTime();

                if (beginTime.getTime() - curTime > 0) {
                    return 1;//未开始
                } else {
                    if (endTime.getTime() - curTime >= 0) {
                        return 2; //正在进行中
                    } else {
                        return 3;//已经结束
                    }
                }
            },
            publishMeeting: function () {
                this.$router.push("/publishMeeting")
            },
            loadSelect: function () {
                if (this.sCurPage > this.sTotalPage || this.sBusy) {
                    this.sBusy = true;
                    return;
                }
                this.sBusy = true;
                $(".load-more").show();
                this.moreSelect();
            },
            loadSimple: function () {
                if (this.qCurPage > this.qTotalPage || this.qBusy) {
                    this.qBusy = true;
                    return;
                }
                this.qBusy = true;
                $(".load-more").show();
                this.moreSimple();
            },
            moreSelect: function () {
                let _self = this;
                getMeetingDataByUid({curPage: _self.sCurPage, uid: _self.uid, title: _self.title}).then((response) => {
                    console.log('getMeetingDataByUid', response)
                    if (response.success) {
                        if(response.data.page){
                            _self.sDataList = _self.sDataList.concat(response.data.page.rows);
                            _self.sTotalPage = response.data.page.pageCount;
                            _self.sCurPage++;
                            _self.sBusy = false;
                        }

                        _self.getMeetingDataByUid = response.data.meetingUserModel;
                        _self.personalState = response.data.role;
                        let height = $(window).height();
                        if(this.personalState == 1  || this.personalState == 2){
                            $(".listBox2").css("minHeight", height - $(".topSeat").height() - $(".topBox").height() - $(".column").height() - $(".tabContentBg").height())
                        }
                        else if(this.personalState == 3  || this.personalState == 4 || this.personalState == 5) {
                            $(".tabContentBg").css("marginBottom", 40)
                            $(".listBox2").css("minHeight", height - $(".topSeat").height() - $(".topBox").height() - $(".column").height() - $(".tabContentBg").height() - 40 )
                            $(".listBox1").css("paddingBottom", 40)
                        }
                    } else {
                        $(".no-business").show()
                    }
                    if(_self.sDataList.length == 0){
                        $(".listBox1").hide()
                    }
                    // _self.busy = false;
                    $(".load-more").hide()
                }).catch((error) => {
                    $(".load-more").hide()
                    console.log(error)
                })
            },
            moreSimple: function () {
                let _self = this;
                console.log('curPage:', this.qCurPage)
                console.log('totalPage:', this.qTotalPage)
                console.log('busy:', this.qBusy);
                getPublishedByUid({curPage: _self.qCurPage, uid: _self.uid, title: _self.title}).then((response) => {
                    console.log('response:', response);
                    if (response.success) {
                        _self.qDataList = _self.qDataList.concat(response.data.page.rows);
                        _self.qTotalPage = response.data.page.pageCount;
                        _self.qCurPage++;
                        _self.qBusy = false;
                    } else {
                        $(".listBox2").hide()
                        $(".no-business").show()
                    }
                    $(".load-more").hide()
                }).catch((error) => {
                    $(".load-more").hide()
                    console.log(error)
                })

            },
            sDetail(meetId, uid, leaveStatus) {
                this.$router.push('/meetingDetail/' + meetId);
            },
            qDetail(meetId) {
                this.$router.push('/meetingDetail/' + meetId);
            },
            searchMeeting: function () {
                if (this.flag == 1) {
                    this.sCurPage = 1
                    this.sTotalPage = 1
                    this.sBusy = false
                    this.sDataList = []
                    this.loadSelect()
                } else {
                    this.qCurPage = 1
                    this.qTotalPage = 1
                    this.qBusy = false
                    this.qDataList = []
                    this.loadSimple()
                }
            }
        },
        mounted() {
            this.uid = this.$route.params.uid;
            $(".tabContentBg").width($(window).width());

        }
    }
</script>

<style lang="less" scoped="scope">

    .startMeeting {
        .topSeat{
            height:0.2rem;
            width:100%;
            background-color:#ebe7db;
        }
        .topBox {
            background-color: #ebe7db;
            height: 1.85rem;
            position: relative;
        }
        .zoom {
            height: 0.3rem;
            width: 0.3rem;
            position: absolute;
            left: 0.45rem;
            top: 0.25rem;
        }
        .searchMeeting {
            border: 1px solid #ffffff;
            border-radius: 5px;
            height: 0.8rem;
            width: 6rem;
            margin-left: 0.3rem;
            font-size: 0.3rem;
            padding-left: 0.6rem;
            padding-top:0;
            padding-bottom:0;
            background-color:white;
        }
        .btnBox {
            margin-top: 0.2rem;
            display: flex;
            border: 1px solid #c3373a;
            width: 100%;
        }

        .btnBox>button{
            flex: 1;
            height: 0.8rem;
            text-align: center;
            line-height: 0.8rem;
            font-size: 0.3rem;
            background-color: #FFFFFF;
            color: #c3373a;
            border:0;
            border-radius:0;
        }

        #active {
            background-color: #c3373a;
            color: #ffffff;
        }
        .myJoin {
            display: none;
        }
        .meetingBegin {
            display: none;
        }
        .columnActive {
            display: block;
        }
        .column {
            height: 0.65rem;
        }
        .column > span {
            line-height: 0.65rem;
            margin-left: 0.3rem;
            font-size: 0.28rem;
            color: #52514e;
        }
        .census {
            background: url(../../assets/images/meetinglist/meetingIcon.png) no-repeat;
            background-size: 1.3rem 1rem;
            height: 1.95rem;
            display: flex;
            background-color:white;
        }
        .census > div {
            flex: 1;
            height: 1.6rem;
            margin: auto 0;
        }
        .census > div:not(:first-child) {
            border-left: 1px solid #ebe7dc;
        }
        .census > div > p {
            margin-top: 0.2rem;
            text-align: center;
            font-size: 0.3rem;
            color:#323232;
        }
        .listBox2{
            background-color:#ffffff;
            position:relative;
        }
        .listBox1{
            background-color:#ffffff;
        }

        .listBox1 .list {
            height: 1rem;
            border-bottom: 1px solid #ebe7db;
            position:relative;
        }
        .listBox2 .list {
            height: 1rem;
            border-bottom: 1px solid #ebe7db;
            position:relative;
        }
        .list b, span {
            height: 1rem;
            font-size: 0.3rem;
            line-height: 1rem;
            margin-left: 0.3rem;
            font-weight: normal;
        }
        .list>div{
            float: right;
        }
        .list >div> span {
            margin-right: 0.15rem;
        }
        .list >div> i {
            height:1rem;
            line-height:1rem;
            display:inline-block;
            font-style:normal;
            font-size:0.3rem;
            color: #b6b6b6;
        }
        .list >div> img {
            height: 0.3rem;
            width: 0.15rem;
            position:absolute;
            right:5px;
            top:0.36rem;
        }
        .tabContentBg{
            height:110px;
            background-color:#ffffff;
            position: relative;
        }
        .tabContentBg>img{
            width:100%;
            position: absolute;
            bottom: 0;
        }
        .footBtn{
            height: 40px;
            background-color: #c3373a;
            color: white;
            width: 100%;
            font-size:16px;
            position: fixed;
            bottom: 0;
        }
        .seat1{
            height: 1.7rem;
        }
        .seat2{
            width:100%;
        }
        .status-box{
            float:right;
        }
    }
</style>
