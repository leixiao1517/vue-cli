<!--起始页开始-->
<template>

    <section class="meetingAbstract">
        <div class="column">
            <span>{{ meetingSummaryModel.title }}</span>
        </div>
        <div class="AbstractContent">
            <div class="AbstractIcon">
                <img src="../../assets/images/publishAbstract/AbstractIcon.png" />
            </div>
            <div class="borderLeft"></div>
            <div class="borderRight"></div>
            <div class="abstractText">
                <p>{{ meetingSummaryModel.content }}</p>
            </div>
        </div>
        <button v-if="this.flag" class="footBtn" @click="submitAbstract()">确认修改</button>
    </section>

</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import { getSummary ,pubSummary,addLessonCredits} from '../../api/api'


    export default {
        components: {

        },
        data () {
            return {
                meetingSummaryModel:{meetId:'',title:'',content:'',uid:''},
                flag:true,
                stayConfirm:false

            }
        },
        methods: {

            vertify () {
                let _self = this;
                if ('' == _self.meetingSummaryModel.title || _self.meetingSummaryModel.title > 20){
                    _self.$vux.toast.text('会议标题不能为空且长度限制20字', 'middle')
                    return false;
                }
                if ('' == _self.meetingSummaryModel.content || _self.meetingSummaryModel.content > 200){
                    _self.$vux.toast.text('会议内容不能为空且长度限制200字', 'middle')
                    return false;
                }
                return true;
            },

            submitAbstract:function () {
                let _self = this;
                if(_self.vertify()){
                    pubSummary({meetingSummaryModel:_self.meetingSummaryModel,stayConfirm:this.stayConfirm}).then((response) => {
                        console.log(response)
                        _self.$vux.toast.text(response.message, 'middle')
                        if(response.success){
                            _self.$vux.toast.text("发布成功", 'middle');
                            this.$router.push("/meetingDetail/"+this.meetingSummaryModel.meetId)
                        } else {
                        }
                    }).catch((error) => {
                        console.log(error)
                    })

                }
            },
            //用户停留10秒即增加积分
            stayFoo:function () {
                let _self = this;
                setTimeout(function(){
                    _self.stay()
                },30000);
            },
            stay:function () {
                let _self = this
                _self.stayConfirm = true;
                addLessonCredits({objId:_self.meetingSummaryModel.meetId,objType:6,stayConfirm:_self.stayConfirm}).then((response) => {
                    console.log(response)
                    _self.$vux.toast.text(response.message, 'middle');
                }).catch((error) => {
                    console.log(error)
                })
            }

        },
        mounted () {
            $(".abstractBg").width($(window).width())
            let height = $(window).height();
            $(".publishAbstract").css("height",height)
            this.meetingSummaryModel.meetId = this.$route.params.meetId;
            // this.meetingLeaveModel.uid = this.$route.query.uid;
            // console.log("meetId***********", this.meetingSummaryModel.meetId);
            getSummary({meetId:this.meetingSummaryModel.meetId,stay:this.stay}).then((response) => {
                console.log(response)
                // this.$vux.toast.text(response.message, 'middle')
                if(response.success){
                    this.meetingSummaryModel.title = response.data.title;
                    this.meetingSummaryModel.content = response.data.content;
                    this.meetingSummaryModel.uid = response.data.uid;
                } else {
                }
            }).catch((error) => {
                console.log(error)
            })
            console.log("++++",this.$route.query.model)
             if(this.$route.query.model == 'look'){
                 this.flag = false
             }

             this.stayFoo();

        }
    }


</script>

<style lang="less">


    .meetingAbstract {

        background-color:#ffffff;

        .column {
            height: 0.8rem;
            background-color:#ffffff;
            border-bottom:1px solid #edeaef;
            text-overflow:ellipsis;
            overflow:hidden;
        }
        .column > span {
            line-height: 0.8rem;
            font-size: 0.35rem;
            color: #52514e;
            margin-left:0.2rem;
            font-weight:bolder;
        }
        .footBtn {
            height: 1rem;
            background-color: #c3373a;
            color: white;
            width: 100%;
            position: fixed;
            bottom: 0;
            font-size:0.3rem;
            border-radius:3px;
        }
        .AbstractContent{
            height:11rem;
            background-color:#ffffff;
        }
        .AbstractIcon{
            height:0.75rem;
            width:0.75rem;
            margin:0.2rem auto;

        }
        .AbstractIcon>img{
            height:0.75rem;
            width:0.75rem;
        }
        .borderLeft{
            height:1px;
            width:60%;
            margin-left:5%;
            border-top:1px solid #c3373a;
        }
        .borderRight{
            margin-top:0.025rem;
            height:1px;
            width:60%;
            margin-left:35%;
            border-top:1px solid #c3373a;
        }
        .abstractText{
            height:9.4rem;
            width:85%;
            margin:0.25rem auto;
            font-size:0.325rem;
            word-wrap:break-word;
        }
    }
</style>
