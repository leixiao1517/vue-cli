<!--起始页开始-->
<template>

    <section class="publishAbstract">
        <div class="topSeat"></div>
        <div class="publishAbstractBox">
            <div class="editAbstractTitle">
                <group>
                    <x-textarea v-model="meetingSummaryModel.title" placeholder="请输入会议标题(20字以内)" :max="20"></x-textarea>
                </group>
            </div>
            <div class="editAbstractContent">
                <group>
                    <x-textarea v-model="meetingSummaryModel.content" placeholder="请输入会议纪要(200字以内)" :max="200"></x-textarea>
                </group>
            </div>
            <div class="AbstractBgBox">
                <img src="../../assets/images/publishAbstract/AbstractBg.png" class="abstractBg" />
            </div>
        </div>
        <div class="seat"></div>
        <button class="footBtn" @click="submitAbstract()">提交</button>
    </section>

</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import { XTextarea,Group } from 'vux'
    import {pubSummary,getSummary} from '../../api/api'

    export default {
        components: {
            XTextarea,
            Group,

        },
        data () {
            return {
                meetingSummaryModel:{meetId:'',title:'',content:'',uid:''},
                flag:'',

            }
        },
        methods: {

            vertify () {
                let _self = this;
                if ('' == _self.meetingSummaryModel.title || _self.meetingSummaryModel.title > 20){
                    _self.$vux.toast.text('会议标题不能为空且长度限制20字', 'middle')
                    return false;
                }
                if ('' == _self.meetingSummaryModel.content || _self.meetingSummaryModel.content > 200){
                    _self.$vux.toast.text('会议内容不能为空且长度限制200字', 'middle')
                    return false;
                }
                return true;
            },


            submitAbstract:function () {
                let _self = this;
                if(_self.vertify()){
                    pubSummary({meetingSummaryModel:_self.meetingSummaryModel}).then((response) => {
                        console.log(_self.flag);
                        if(_self.flag){
                            this.$router.push('/meetingAbstract/' + this.meetingSummaryModel.meetId);
                            return;
                        }
                        console.log(response)
                        _self.$vux.toast.text(response.message, 'middle')
                        if(response.success){
                            _self.$vux.toast.text("发布成功", 'middle');
                            this.$router.push("/meetingDetail/"+this.meetingSummaryModel.meetId)
                        } else {
                        }
                    }).catch((error) => {
                        console.log(error)
                    })

                }
            }
        },
        mounted () {
            $(".abstractBg").width($(window).width())
            let height = $(window).height();
            $(".publishAbstract").css("height",height)
            this.meetingSummaryModel.meetId = this.$route.params.meetId;
            // this.meetingLeaveModel.uid = this.$route.query.uid;
            // console.log("meetId***********", this.meetingSummaryModel.meetId);
            getSummary({"meetId":this.meetingSummaryModel.meetId}).then((response) => {
                console.log(response)
                // this.$vux.toast.text(response.message, 'middle')
                if(response.success){
                    this.meetingSummaryModel.title = response.data.title;
                    this.meetingSummaryModel.content = response.data.content;
                    this.meetingSummaryModel.uid = response.data.uid;
                        } else {
                }
            }).catch((error) => {
                console.log(error)
            })
            if(this.$route.query.model == 'modi'){
                this.flag = true;
            }


        }
    }


</script>

<style lang="less">

    .publishAbstract {

        .topSeat{
            height:0.2rem;
            width:100%;
        }
        .editAbstractContent .vux-no-group-title{
            border-top:1px solid #ebe7db;
            margin-top:0;
        }
        .editAbstractContent .weui-textarea{
            height:7.5rem;
        }
        .weui-cell{
            padding:0.2rem;
            font-size:0.3rem;
        }
        .weui-cells:after{
            border:0;
        }
        .weui-cells:before{
            border:0;
        }
        .vux-no-group-title{
            margin:0;
        }
        .weui-cell:before{
            border:0;
        }
        .AbstractBgBox{
            background-color:white;
        }
        .footBtn {
            height: 1rem;
            background-color: #c3373a;
            color: white;
            width: 100%;
            position: fixed;
            bottom: 0;
            font-size:0.3rem;
            border-radius:3px;
        }
        .seat{
            height:1rem;
        }
    }


</style>
