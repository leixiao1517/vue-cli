<!--起始页开始-->
<template>

    <section class="countMeeting">

        <div class="comm-head-logo">
            <div class="logo">
                <img src="../../assets/images/common/icon-logo.png" alt="">
            </div>
            <div class="back" @click="toIndex">
                回到首页
            </div>
        </div>

        <div class="column">
            <img src="../../assets/images/countmeeting/thisMeetingIcon.png">
            <span>本次会议统计</span>
        </div>
        <div class="census">
            <div>
                <p class="nColor">{{meetUserModel.allNum}}</p>
                <p>应参加</p>
            </div>
            <div>
                <p class="nColor">{{meetUserModel.realNum}}</p>
                <p>实际参与</p>
            </div>
            <div>
                <p class="nColor">{{meetUserModel.vacNum}}</p>
                <p>请假</p>
            </div>
            <div>
                <p class="nColor">{{meetUserModel.absNum}}</p>
                <p>缺席</p>
            </div>
        </div>
        <div class="column border">
            <img src="../../assets/images/countmeeting/meetingrecode.png">
            <span>考勤记录</span>
        </div>
        <div class="tableTop">
            <div style="color:#969488">姓名</div>
            <div style="color:#9d424c">签到</div>
            <div style="color:#dfae46">抽查</div>
            <div style="color:#0d6eab">签退</div>
            <div style="color:#a33175">请假</div>
            <div style="color:#929294">缺席</div>
        </div>
        <div class="tablelist" v-infinite-scroll="loadSelect" infinite-scroll-disabled="busy" infinite-scroll-distance="10">
            <div class="tableContent" v-for="value in cDataList">
                <div><span> {{value.userName}} </span></div>
                <div>
                    <span v-if="value.signIn == 0"> </span>
                    <img src="../../assets/images/countmeeting/signInIcon.png" v-if="value.signIn == 1"/>
                </div>
                <div>
                    <span v-if="value.checkStatus == 0"> </span>
                    <img src="../../assets/images/countmeeting/checkIcon.png" v-if="value.checkStatus == 1"/>
                </div>
                <div>
                    <span v-if="value.signOut == 0"> </span>
                    <img src="../../assets/images/countmeeting/signOutIcon.png" v-if="value.signOut == 1"/>
                </div>
                <div>
                    <span v-if="value.leave == 0"> </span>
                    <img src="../../assets/images/countmeeting/leaveIcon.png" v-if="value.leaveStatus == 1"/>
                </div>
                <div>
                    <span v-if="value.leaveStatus == 1 || (value.signIn == 1 || value.signOut == 1 || value.checkStatus == 1)"></span>
                    <img src="../../assets/images/countmeeting/absentIcon.png" v-else-if="value.process == 3  && (value.signIn == 0 && value.signOut == 0 && value.checkStatus == 0)"/>
                </div>
            </div>
        </div>

    </section>

</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import { getMeetingStatistics,getAtsMeetingStsByMid } from '../../api/api'

    export default {
        components: {


        },
        data () {
            return {
                meetId:Number,
                getMeetingStatistics:[],
                getAtsMeetingStsByMid:[],
                meetUserModel:{},
                cDataList:[],
                cCurPage:1,
                cTotalPage:1,
                cBusy:false,
            }
        },
        methods: {
            loadSelect:function() {
                if(this.cCurPage > this.cTotalPage || this.cBusy){
                    this.cBusy = true;
                    return;
                }
                this.cBusy = true;
                $(".load-more").show();
                this.moreSelect();
            },
            moreSelect:function () {
                let _self = this;
                // console.log('tab:', this.tab)
                getAtsMeetingStsByMid({curPage:_self.cCurPage,meetId:_self.meetId}).then((response) => {
                    console.log(response);
                    if(response.success) {
                        _self.cDataList = _self.cDataList.concat(response.data.rows);
                        _self.cTotalPage = response.data.pageCount;
                        _self.cCurPage++;
                        _self.cBusy = false;
                    } else {
                        $(".no-business").show()
                    }
                    // _self.busy = false;
                    $(".load-more").hide()
                }).catch((error) => {
                    $(".load-more").hide()
                    console.log(error)
                })
            },
            toIndex: function () {
                this.$router.push('/index')
            }

        },
        mounted () {
            let _self = this;
            this.meetId = this.$route.params.meetId;
            getMeetingStatistics({meetId:_self.meetId}).then(data=>{
                console.log('getMeetingStatistics',data)
                if(data.data == null){
                    _self.$vux.toast.text(data.message, 'middle');
                    return;
                }
                _self.meetUserModel = data.data.meetUserModel;
            })

        }
    }


</script>

<style lang="less">


    .countMeeting {
        .column {
            height: 0.65rem;
            background-color: #ebe7db;
        }
        .column > img {
            height: 0.3rem;
            width: 0.3rem;
            margin-left: 0.3rem;
            margin-bottom:0.1rem;
        }
        .column > span {
            line-height: 0.65rem;
            font-size: 0.28rem;
            margin-left:0.1rem;

        }
        .census {
            background: url(../../assets/images/countmeeting/meetingIconBg.png) no-repeat;
            background-size: 1.3rem 1rem;
            height: 1.95rem;
            display: flex;
            background-color: white;
        }
        .census > div {
            flex: 1;
            height: 1.6rem;
            margin: auto 0;
        }
        .census > div:not(:first-child) {
            border-left: 1px solid #ebe7dc;
        }
        .census > div > p {
            margin-top: 0.2rem;
            text-align: center;
            font-size: 0.3rem;
        }
        .nColor{
            color: #a0242c;
        }
        .border{
            border-bottom:1px solid #ffffff;
        }
        .tableTop{
            height:0.8rem;
            display: flex;
        }
        .tableTop>div{
            float:left;
            font-size:0.3rem;
        }
        .tableTop>div:first-child{
            float:left;
            text-align:center;
            line-height:0.8rem;
            width:2rem;
        }
        .tableTop>div:not(:first-child){
            float:left;
            text-align:center;
            line-height:0.8rem;
            flex: 1;
        }
        .tableContent{
            height:1rem;
            display: flex;
            border-bottom:1px solid #ebe7dc;
        }
        .tableContent>div{
            float:left;
            background-color:#ffffff;
            font-size:0.3rem;
        }
        .tableContent>div:first-child{
            float:left;
            text-align:center;
            line-height:1rem;
            width:2rem;
            color:#969488;
        }
        .tableContent>div:not(:first-child){
            float:left;
            text-align:center;
            line-height:1rem;
            border-left:1px solid #ebe7db;
            flex: 1;
        }
        .tableContent>div>img{
            width:0.455rem;
            height:0.35rem;
        }
    }
</style>
