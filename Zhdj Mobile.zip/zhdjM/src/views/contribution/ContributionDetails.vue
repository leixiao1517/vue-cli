<template>
    <div class="contribution-details">
        <section>
            <div>
                <h3>{{contributionDetailsModel.contributionDetailsTitle}}</h3>
                <div class="contribution-details-title">
                    <p>{{contributionDetailsModel.contributionDetailsAuthor}}</p>
                </div>
            </div>
            <div>
                <article>
                    <div>推荐理由</div>
                    <div class="contribution-details-content">
                        <p v-html="contributionDetailsModel.contributionDetailsDescription"></p>
                    </div>
                </article>
            </div>
            <div>
                <article>
                    <div>内容简介</div>
                    <div class="contribution-details-content">
                        <p v-html="contributionDetailsModel.contributionDetailsDescription"></p>
                    </div>
                </article>
            </div>
        </section>
        <div class="contribution-details-download">
            <span class="attachText1">附件</span>
            <span class="attachText2">点击图标下载对应附件</span>
        </div>
        <img class="contribution-details-download-img" src="../../assets/images/book/test.png"/>
    </div>

</template>

<script>
    import{getContributionDetails} from '../../api/api'

    export default {

        data () {
            return {

                contributionDetailsModel: {
                    contributionDetailsTitle: '我是标题，我是标题，我是标题，我是标题，我是标题，我是标题，我是标题',
                    contributionDetailsAuthor: '投稿人:二狗子 xxxx党委 xxxxx支部',
                    contributionDetailsReason: '1914年，毛泽东进入湖南第一师范学习。据他的同班同学周世钊和蒋竹如回忆，该校每个周六打“牙祭”吃红烧肉，用湘潭酱油（老抽）加冰糖、料酒、大茴（八角）慢火煨成，肉用带皮的“五花三层”，八人一桌，足有四斤肉。从这时起，毛泽东就爱上了红烧肉这个菜。',
                    contributionDetailsDescription: '红烧肉可以大量补充能量，恢复体力，使人精力充沛。据历史记载，毛主席在指挥三大战役时，对警卫员李银桥说：“你只要隔三天给我吃一顿红烧肉，我就有精力打败敌人。”可见，主席对红烧肉的钟爱。',
                }
            }
        },

        methods: {},


        mounted(){
            let _self = this;

            this.contributionId = this.$route.params.contributionId;

            getContributionDetails({contributionId: _self.contributionId}).then(data => {

                if (data.data == null) {
                    _self.$vux.toast.text(data.message, 'middle');
                    return;
                }
                _self.contributionDetailsModel = data.data.contributionDetailsModel;
            })

        }
    }
</script>

<style lang="less">

    .contribution-details {
        background-color: #FFFFFF;
        h3 {
            width: 7rem;
            margin: 0 0.25rem;
            padding-top: 0.2rem;
        }

        .contribution-details-title {
            font-size: 0.1rem;
            margin-top: 0.5rem;
        }
        .contribution-details-title > p {
            margin-left: 0.25rem;
            padding-bottom: 0.5rem;
        }

        article {
            margin-top: 6px;
            background: white;
            div:first-child {
                width: 100px;
                line-height: 30px;
                color: #D0021B;
                text-align: left;
                margin-left: 0.25rem;
            }
            .contribution-details-content {
                margin: 0.05rem;
                p {
                    margin-bottom: 5px;
                    line-height: 26px;
                    font-size: 12px;
                    width: 7rem;
                    margin-left: 0.2rem;
                }
            }
        }

        .contribution-details-download {
            margin: 0.25rem 0.3rem;
            .attachText1 {
                color: #D0021B;
                /*font-size:8px;*/
                font-weight: bold;
            }
            .attachText2 {
                font-size: 1px;
            }
        }

        .contribution-details-download-img {
            width: 70px;
            height: 86px;
            margin-left: 2rem;
            margin-bottom: 1.8rem
        }
    }


</style>
