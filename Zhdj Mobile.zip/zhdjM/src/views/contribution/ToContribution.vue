<template>
    <div class="to-contribution">
        <group>
            <x-input title="主题:" v-model="contributionTheme" placeholder="请输入主题"></x-input>
        </group>

        <group>
            <x-textarea :max="400" v-model="contributionReason" placeholder="输入推荐理由"></x-textarea>
        </group>
        <box gap="180px 60px 10px 60px">
            <flexbox>
                <flexbox-item>
                    <x-button type="warn" @click.native="submitContribution()">发送</x-button>
                </flexbox-item>
            </flexbox>
        </box>
    </div>
</template>

<script>

    import{Group, XInput, XTextarea, Box, Flexbox, FlexboxItem, XButton} from 'vux'
    import{submitContributionLink} from '../../api/api'
    export default {

        components: {
            Group,
            XInput,
            XTextarea,
            Box,
            Flexbox,
            FlexboxItem,
            XButton,
        },

        data () {
            return {
                contributionTheme: '',
                contributionReason: '',
            }
        },

        methods: {
            submitContribution(){
                let _self = this;

                submitContributionLink({
                    contributionTheme: _self.contributionTheme, contributionReason: _self.contributionReason
                }).then(data => {

                    if (data.success) {

                        this.$vux.confirm.show({
                            title: '提交成功',
                            content: '',
                            confirmText: '',
                            showCancelButton: false,

                            onCancel(){

                            },

                            onConfirm(){

                            }

                        })

                    } else {
                        this.$vux.toast.text('提交失败');
                    }
                })

            }
        }
    }
</script>

<style lang="less">
    .to-contribution {

        .weui-cells {
            margin-top: 0px !important;
            font-size: 0.27rem;
        }

    }

</style>
