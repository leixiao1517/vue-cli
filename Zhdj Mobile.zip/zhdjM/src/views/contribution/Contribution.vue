<template>
    <div class="contribution">
        <tab :line-width=2 v-model="tabIndex" active-color='#D0021B'>
            <tab-item class="vux-center" :selected="contributionSelected === contributionItem"
                      v-for="(contributionItem, tabIndex) in contributionTitleList"
                      @click.native="contributionSelectedItem(tabIndex)"
                      :key="tabIndex">{{contributionItem}}
            </tab-item>
        </tab>
        <div v-infinite-scroll="loadContributions" infinite-scroll-disabled="busy" infinite-scroll-distance="10">

            <div class="contribution-scroller" v-for="(contribution,scrollIndex) in contributionsList"
                 :key="scrollIndex"
                 v-if="contributionsList.length > 0" @click="toContributionDetails">
                <img :src="contribution.contributionImg | imgPath"/>
                <div>
                    <h4>{{contribution.contributionTitle}}</h4>
                    <p class="contribution-content-author">
                        <span>投稿人:{{contribution.contributionAuthor}}</span><span>{{contribution.contributionPubilsh}}</span>
                    </p>
                    <p class="contribution-content">{{contribution.contributionDescription}}</p>

                </div>
            </div>
            <loading></loading>
        </div>

    </div>
</template>

<script>
    import{Tab, TabItem, Swiper, SwiperItem} from 'vux'
    import loading from '../../components/common/loading.vue'
    import{getContributionsDetail} from '../../api/api'

    const contributionTitleList = () => ['全部投稿', '我的投稿', 'XXX党委', 'XXX党委2', 'XXX党委22', 'XXX党委2222'];

    export default {
        components: {
            Tab,
            TabItem,
            Swiper,
            SwiperItem,
            loading
        },
        data () {
            return {
                contributionSelected: '我的投稿',
                contributionTitleList: contributionTitleList(),
                tabIndex: 0,
                scrollIndex: 0,
                contributionsList: [
                    {
                        contributionId: 1,
                        contributionImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                        contributionTitle: '红色起点',
                        contributionAuthor: '二狗子',
                        contributionPubilsh: '一家牛逼出版社',
                        contributionDescription: '哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈',
                    },
                    {
                        contributionId: 2,
                        contributionImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                        contributionTitle: '红色起点',
                        contributionAuthor: '二狗子',
                        contributionPubilsh: '一家牛逼出版社',
                        contributionDescription: '哈哈哈哈哈哈哈哈哈哈哈',
                    },
                    {
                        contributionId: 1,
                        contributionImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                        contributionTitle: '红色起点',
                        contributionAuthor: '二狗子',
                        contributionPubilsh: '一家牛逼出版社',
                        contributionDescription: '哈哈哈哈哈哈哈哈哈哈哈',
                    },
                    {
                        contributionId: 1,
                        contributionImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                        contributionTitle: '红色起点',
                        contributionAuthor: '二狗子',
                        contributionPubilsh: '一家牛逼出版社',
                        contributionDescription: '哈哈哈哈哈哈哈哈哈哈哈',
                    },
                    {
                        contributionId: 1,
                        contributionImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                        contributionTitle: '红色起点',
                        contributionAuthor: '二狗子',
                        contributionPubilsh: '一家牛逼出版社',
                        contributionDescription: '哈哈哈哈哈哈哈哈哈哈哈',
                    },
                    {
                        contributionId: 1,
                        contributionImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                        contributionTitle: '红色起点',
                        contributionAuthor: '二狗子',
                        contributionPubilsh: '一家牛逼出版社',
                        contributionDescription: '哈哈哈哈哈哈哈哈哈哈哈',
                    },

                ],
                busy: false,
                pageNo: 1,
                size: 15,
                totalPage: 1,

            }
        },
        methods: {

            toContributionDetails () {
                this.$router.push("/contributionDetails");
            },

            contributionSelectedItem(tabIndex){

            },

            initContributionsList: function () {
                let _self = this;
                getContributionsDetail({
                    curPage: _self.pageNo,
                    contributionId: _self.contributionId,
                    contribution: 'flag'
                }).then((response) => {
                    console.log(response);
                    $(".load-more").hide();
                    if (response.success) {
                        _self.contributionsList = _self.contributionsList.concat(response.data.page.rows);
                        _self.totalPage = response.data.page.pageCount;
                        _self.pageNo++;
                        _self.busy = false;
                    } else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }).catch((error) => {
                    $(".load-more").hide()
                })
            },

            loadContributions: function () {
                if (this.pageNo > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initContributionsList();
            },
        }
    }
</script>

<style lang="less">

    .contribution {
        background-color: #FFFFFF;
        .contribution-scroller {
            height: 2rem;
            margin: 8px 0px 14px 12px;
            img {
                float: left;
                width: 70px;
                height: 96px;
                margin-right: 5px;
            }
        }

        .contribution-content-author {
            margin: 8px 0px 10px 0px;
            font-size: 10px;

            span {
                margin-right: 8px;
            }
        }
        .contribution-content {
            font-size: 10px;
        }
    }

</style>
