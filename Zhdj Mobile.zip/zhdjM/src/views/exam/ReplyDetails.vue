<!--起始页开始-->
<template>
    <section class="replyDetails">
        <div class="comm-head-logo">
            <div class="logo">
                <img src="../../assets/images/common/icon-logo.png" alt="">
            </div>
            <div class="back" @click="toIndex">
                回到首页
            </div>
        </div>

        <div class="main-container">
            <div class="column">
                <span>参与统计</span>
            </div>
            <div class="topContent" @click="detailExam()">
                <img src="../../assets/images/countExam/contentIcon.png"/>
                <span>题目共{{allNum}}道</span>
                <div class="rightBox">
                    <!--<span>{{answeredNum}}人已答&nbsp;</span>-->
                    <!--<b>{{nonAnsweredNum}}人未答</b>-->
                    <img src="../../assets/images/countExam/right.png" class="right"/>
                </div>
            </div>
            <div class="column">
                <span>答题详情</span>
            </div>
            <div class="listContent">
                <ul class="tab">
                    <li><span id="tabActive" class="tab2" @click="btnClick2">选择题</span></li>
                    <li><span class="tab1"  @click="btnClick1">问答题</span></li>
                </ul>
                <div class="listTab2 listActive" v-infinite-scroll="loadQuestion" infinite-scroll-disabled="busy" infinite-scroll-distance="10">
                    <div class="list" v-for="(question, index) in questionList" :key="index" v-if="questionList.length > 0" @click="reviewList(question.qid)">
                        <span>{{question.title}}</span>
                        <img src="../../assets/images/countExam/right.png" class="right"/>
                    </div>
                    <div class="no-data" v-if="questionList.length == 0"><p>没有答题详情数据</p></div>
                    <loading></loading>
                </div>
                <div class="listTab1" v-infinite-scroll="loadQuestion" infinite-scroll-disabled="busy" infinite-scroll-distance="10">
                    <div class="list" v-for="(question, index) in questionList" :key="index" v-if="questionList.length > 0" @click="reviewList(question.qid)">
                        <span>{{question.title}}</span>
                        <img src="../../assets/images/countExam/right.png" class="right"/>
                    </div>
                    <div class="no-data" v-if="questionList.length == 0"><p>没有答题详情数据</p></div>
                    <loading></loading>
                </div>
            </div>
        </div>

        <div class="bottom-img">
            <img src="../../assets/images/countExam/contentBg.png" />
        </div>
    </section>
</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import {getAnswersGeneral} from '../../api/api'
    import loading from '../../components/common/loading.vue'

    export default {
        components: {
            loading
        },
        data () {
            return {
                meetId:Number,
                questionList:[],
                pageNo:1,
                size:15,
                totalPage:1,
                busy:false,
                type:1,
                allNum:0,
                answeredNum:0,
                nonAnsweredNum:0,
            }
        },
        methods: {
            btnClick1:function(){ //选项卡1 点击事件
                $(".listTab1").addClass("listActive");
                $(".listTab2").removeClass("listActive");
                $(".tab1").attr("id","tabActive");
                $(".tab2").attr("id","");
                this.type = 2
                this.pageNo=1
                this.size=15
                this.totalPage=1
                this.busy=false
                this.questionList = []
            },
            btnClick2:function(){ //选项卡2 点击事件
                $(".listTab2").addClass("listActive");
                $(".listTab1").removeClass("listActive");
                $(".tab2").attr("id","tabActive");
                $(".tab1").attr("id","");
                this.type = 1
                this.pageNo=1
                this.size=15
                this.totalPage=1
                this.busy=false
                this.questionList = []
            },
            //答题列表
            initQuestionList:function () {
                let _self = this
                getAnswersGeneral({curPage:_self.pageNo,meetId:_self.meetId,type:_self.type}).then((response) => {
                    $(".load-more").hide()
                    this.allNum = response.data.allQues
                    this.answeredNum = response.data.killQues
                    this.nonAnsweredNum = response.data.liveQues
                    if(response.success) {
                        _self.questionList = _self.questionList.concat(response.data.page.rows);
                        _self.totalPage = response.data.page.pageCount;
                        _self.pageNo++;
                        _self.busy = false;
                        _self.tQuestion = response.data.page.total
                    } else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }).catch((error) => {
                    $(".load-more").hide()
                })
            },
            loadQuestion:function () {
                if(this.pageNo > this.totalPage || this.busy){
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show()
                this.initQuestionList();
            },
            detailExam:function () {
                this.$router.push('/detailsExam/'+ this.meetId)
            },
            reviewList:function (qid) {
                this.$router.push('/questionReviewList/'+qid+'?meetId='+this.meetId);
            },
            toIndex: function () {
                this.$router.push('/index')
            }
        },
        mounted () {
            this.meetId = this.$route.params.meetId;
            let height = $(window).height();
            $(".main-container").css("minHeight", height - 70)

        }
    }



</script>

<style lang="less">
    .replyDetails{

        position:relative;

        .column {
            height: 0.8rem;
            background-color: #ebe7db;
        }
        .column > span {
            line-height: 0.8rem;
            margin-left: 0.51rem;
            font-size: 0.3rem;
            color: #52514e;
        }
        .topContent{
            background-color:white;
            height:1rem;
            width:100%;
        }
        .topContent>img{
            height:0.8rem;
            width:0.96rem;
            float:left;
        }
        .topContent>span{
            line-height:1rem;
            height:1rem;
            font-size:0.3rem;
            margin-left:-0.45rem;
        }
        .rightBox{
            float:right;
            height:1rem;
        }
        .rightBox>b{
            font-weight:normal;
            font-size:0.3rem;
            line-height:1rem;
            height:1rem;
            margin-right:0.3rem;
        }
        .right{
            float:right;
            width:0.2rem;
            height:0.32rem;
            margin-top:0.36rem;
            margin-right:0.3rem;
        }
        .rightBox>span{
            color:#3989c7;
        }
        .rightBox>b{
            color:#cd5d5e;
        }
        .listContent{
            width:100%;
            background-color:#ffffff;
        }
        .tab{
            height:0.8rem;
            width:100%;
            border-bottom:1px solid #ebe7db;
        }
        .tab>li{
            height:0.8rem;
            width:50%;
            float:left;
            text-align:center;
        }
        .tab>li>span{
            line-height:0.8rem;
            font-weight:normal;
            height:0.8rem;
            display:inline-block;
            font-size:0.3rem;
        }
        #tabActive{
            border-bottom:2px solid #cd5d5e;
            color:#cd5d5e;
        }
        .list{
            height:1rem;
            width:100%;
            border-bottom:1px solid #ebe7db;
            position:relative;
            background-color:#ffffff;
        }
        .list>span{
            display:inline-block;
            line-height:1rem;
            font-size:0.3rem;
            margin-left:0.51rem;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
            width:6.3rem;
        }
        .listTab1,.listTab2{
            display:none;
            background-color:#ebe7db;
            position:relative;
        }
        .listActive{
            display:block;
        }
        .list>b{
            color:#3989c7;
            margin-left:0.6rem;
            font-weight:normal;
            line-height:1rem;
            font-size:0.3rem;
            position: absolute;
            right:0.8rem;
        }
        .contentBg1{
            width:100%;
            height:60px;
            margin-top:25px;
            position:absolute;
            bottom:0px;
        }
        .contentBg2{
            width:100%;
            height:60px;
            margin-top:25px;
            position:absolute;
            bottom:0px;
        }
        .bottom-img{
            width: 100%;
            height: 60px;
            margin-top: 10px;
        }

        .bottom-img img{
            width: 100%;
            height: 100%;
        }
    }
</style>
