
<template>
    <section class="question-detail">
        <div class="comm-head-logo">
            <div class="logo">
                <img src="../../assets/images/common/icon-logo.png" alt="">
            </div>
            <div class="back" @click="toIndex">
                回到首页
            </div>
        </div>

        <!-- 选择题 -->
        <div v-if="question.type == 1">
            <checklist :title="question.title" :options="options" v-model="selected" :disabled="true"></checklist>
        </div>
        <!-- 问答题 -->
        <div class="wenda" v-if="question.type == 2">
            <div class="title">
                <img src="../../assets/images/meeting/small-logo.png">
                {{question.title}}
            </div>
            <div class="content">标准答案：{{question.answer}}</div>
        </div>
        <!-- 答题状态 -->
        <div class="title">答题详情</div>

        <div v-infinite-scroll="loadQuestion" infinite-scroll-disabled="busy" infinite-scroll-distance="10">
            <div class="question" v-for="(answer, index) in answerList" :key="index" v-if="answerList.length > 0">
                <div class="userName o-ellipsis">
                    <img :src="answer.headImg | imgPath" />
                    <span>{{answer.userName}}</span>
                </div>
                <img class="answer-img" src="../../assets/images/meeting/error.png" v-if="answer.result == 0"/>
                <img class="answer-img" src="../../assets/images/meeting/right.png" v-if="answer.result == 1"/>
                <div class="go-review"  v-if="answer.result == 2 && null != answer.answer" @click="goReview(answer.asid)">去判定></div>
                <div class="go-review"  v-if="answer.result == 2 && null == answer.answer">未作答</div>
            </div>
            <loading></loading>
        </div>
        <div class="no-data" v-if="answerList.length == 0"><p>还没人答题</p></div>
    </section>
</template>

<script>
    import $ from 'jquery'
    import {Group,Checklist} from 'vux'
    import {getQuestion,questionReview,saveAnswer} from '../../api/api'
    import loading from '../../components/common/loading.vue'

    export default {
        components: {
            Group,
            Checklist,
            loading
        },
        data () {
            return {
                meetId:Number,
                question:{},
                options:[],
                selected:[],
                answerList:[],
                pageNo:1,
                size:10,
                totalPage:1,
                busy:false,
            }
        },
        methods: {
            //答题
            initQuestion:function () {
                let _self = this
                getQuestion({qid:_self.question.qid,isAdmin:1}).then((response) => {
                    console.log(response)
                    if(response.success){
                        _self.question = response.data
                        _self.selected = _self.question.answer.split(",")

                        if (1 == _self.question.type){ //选择题
                            if (null != _self.question.option1){
                                let q = {};
                                q.key = 'A'
                                q.value = 'A.' + _self.question.option1
                                _self.options.push(q)
                            }
                            if (null != _self.question.option2){
                                let q = {};
                                q.key = 'B'
                                q.value = 'B.' + _self.question.option2
                                _self.options.push(q)
                            }
                            if (null != _self.question.option3){
                                let q = {};
                                q.key = 'C'
                                q.value = 'C.' + _self.question.option3
                                _self.options.push(q)
                            }
                            if (null != _self.question.option4 && _self.question.option4 != ''){
                                let q = {};
                                q.key = 'D'
                                q.value = 'D.' +_self.question.option4
                                _self.options.push(q)
                            }
                            if (null != _self.question.option5 && _self.question.option5 != ''){
                                let q = {};
                                q.key = 'E'
                                q.value = 'E.' +_self.question.option5
                                _self.options.push(q)
                            }
                            if (null != _self.question.option6 && _self.question.option6 != '') {
                                let q = {};
                                q.key = 'F'
                                q.value = 'F.' +_self.question.option6
                                _self.options.push(q)
                            }
                        } else {

                        }

                    } else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }).catch((error) => {
                    console.log(error)
                })
            },
            initAnswer:function () {
                let _self = this
                questionReview({pageNo:_self.pageNo,size:_self.size,qid:_self.question.qid,meetId:_self.meetId}).then((response) => {
                    console.log(response)

                    $(".load-more").hide();
                    if(response.success){
                        _self.answerList = _self.answerList.concat(response.data.rows);
                        _self.totalPage = response.data.pageCount;
                        _self.pageNo++;
                        _self.busy = false;
                    } else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                })
            },
            loadQuestion: function() {
                if(this.pageNo > this.totalPage || this.busy){
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show()
                this.initAnswer();
            },

            //保存答案
            save:function () {
                let _self = this
                saveAnswer(_self.answer).then((response) => {
                    console.log(response)
                    if (response.success) {
                        _self.nextOne = true
                        _self.nextQid = response.data
                    }
                })
            },
            //返回列表页
            returnQuestions:function () {
                this.$router.push("/questionList/" + this.question.meetId)
            },
            goReview:function (asid) {
                this.$router.push("/questionReview/" + asid)
            },
            toIndex: function () {
                this.$router.push('/index')
            }
        },
        mounted () {
            this.question.qid = this.$route.params.qid;
            this.meetId = this.$route.query.meetId;
            this.initQuestion();
        }
    }
</script>

<style lang="less">
    .question-detail{
        .title{
            min-height: .4rem;
            padding: .2rem;
            color:#79716f;
            img{
                width: 15px;
                height: 15px;
                margin-top: -6px;
            }
        }
        .wenda{
            .content{
                min-height: 40px;
                background: #ffffff;
                padding: .2rem .2rem .8rem .2rem;
            }
        }
        .question{
            width:100%;
            height: 50px;
            position: relative;
            background-color:#ffffff;
            margin-top:1px;
            .answer-img{
                position: absolute;
                top:18px;
                right: .2rem;
                width: 10px;
                height: 10px;
            }
            .userName{
                width:6rem;
                line-height:50px;
                font-size:12px;
                margin-left: .2rem;
                img{
                    width:30px;
                    height:30px;
                    border-radius: 50%;
                    margin-top: -5px;
                }
            }
        }
        .go-review{
            color: #c3373a;
            font-size: 13px;
            position: absolute;
            top: 18px;
            right: .2rem;
        }
    }

</style>
