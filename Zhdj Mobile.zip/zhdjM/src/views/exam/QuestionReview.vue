
<template>
    <section class="question-detail">
        <div class="comm-head-logo">
            <div class="logo">
                <img src="../../assets/images/common/icon-logo.png" alt="">
            </div>
            <div class="back" @click="toIndex">
                回到首页
            </div>
        </div>

        <!-- 问答题 -->
        <div class="wenda" >
            <div class="title">
                <img src="../../assets/images/meeting/small-logo.png">
                {{answer.qTitle}}
            </div>
            <div class="content">标准答案：{{answer.qAnswer}}</div>
        </div>

        <div class="wenda" >
            <div class="title">
                TA 的答案
            </div>
            <div class="content">{{answer.answer}}</div>
        </div>

        <div class="checkBtn" v-if="answer.result == 2">
            <button class="checkFail" @click="review(answer.result = 0)">不合格</button>
            <button class="checkSuccess" @click="review(answer.result = 1)">合格</button>
        </div>
    </section>
</template>

<script>
    import $ from 'jquery'
    import {getAnswerByAsid,reviewAnswer} from '../../api/api'

    export default {
        components: {
        },
        data () {
            return {
                answer:{}
            }
        },
        methods: {
            //答题
            initAnswer:function () {
                let _self = this
                getAnswerByAsid({asid:_self.answer.asid}).then((response) => {
                    console.log(response)
                    if(response.success){
                        _self.answer = response.data
                    } else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }).catch((error) => {
                    console.log(error)
                })
            },

            //保存答案
            review:function () {
                let _self = this
                reviewAnswer(_self.answer).then((response) => {
                    console.log(response)
                    if (response.success) {
                        this.$router.push("/questionReviewList/" + this.answer.qid + "?meetId=" + this.answer.meetId)
                    }
                })
            },
            toIndex: function () {
                this.$router.push('/index')
            }
        },
        mounted () {
            this.answer.asid = this.$route.params.asid;
            this.initAnswer();
        }
    }
</script>

<style lang="less">
    .question-detail{
        .title{
            min-height: .4rem;
            padding: .2rem;
            color:#79716f;
            img{
                width: 15px;
                height: 15px;
                margin-top: -6px;
            }
        }
        .wenda{
            .content{
                min-height: 40px;
                background: #ffffff;
                padding: .2rem .2rem .8rem .2rem;
            }
        }
        .question{
            width:100%;
            height: 50px;
            position: relative;
            background-color:#ffffff;
            margin-top:1px;
            .answer-img{
                position: absolute;
                top:18px;
                right: .2rem;
                width: 10px;
                height: 10px;
            }
            .userName{
                width:6rem;
                line-height:50px;
                font-size:12px;
                margin-left: .2rem;
            }
        }
        .go-review{
            color: #c3373a;
            font-size: 13px;
            position: absolute;
            top: 18px;
            right: .2rem;
        }
        .checkBtn{
            width:100%;
            position:fixed;
            bottom:0;
        }
        .checkBtn>button{
            width:50%;
            text-align:center;
            line-height:.8rem;
            float:left;
            font-size:0.3rem;
        }
        .checkFail{
            color:#ffffff;
            background-color:#e9cda1;
        }
        .checkSuccess{
            color:#ffffff;
            background-color:#c3373a;
        }
    }

</style>
