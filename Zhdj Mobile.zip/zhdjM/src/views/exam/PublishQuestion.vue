<template>
    <section class="publish-question">
        <div class="comm-head-logo">
            <div class="logo">
                <img src="../../assets/images/common/icon-logo.png" alt="">
            </div>
            <div class="back" @click="toIndex">
                回到首页
            </div>
        </div>

        <!-- 发布问答题页面 -->
        <section class="select-question" v-show="firstPart">
            <div class="question-title">
                <img src="../../assets/images/exam/danghui.png" height="20" width="20"/>
                <span>出题</span>
            </div>
            <div class="select-main">
                <div class="select-left" @click="publishSelect">
                    <img src="../../assets/images/exam/xuanzeti.png" height="17" width="17"/>
                    <span>出选择题</span>
                </div>
                <div class="select-right " @click="publishAsk">
                    <img src="../../assets/images/exam/wendati.png" height="18" width="20"/>
                    <span>出问答题</span>
                </div>
            </div>
        </section>

        <section class="question-tab">
            <tab :line-width="1" custom-bar-width="60px" default-color="#323232" bar-active-color="#c3373a"
                 active-color="#c3373a">
                <tab-item selected @on-item-click="onItemClick(1)">选择题</tab-item>
                <tab-item @on-item-click="onItemClick(2)">问答题</tab-item>
            </tab>
        </section>

        <section class="mb50" style="padding-bottom: 1rem;" v-infinite-scroll="loadData" infinite-scroll-disabled="busy"
                 infinite-scroll-distance="10" id="selectScroll">
            <div v-for="item in dataList">
                <group>
                    <cell class="question-title title-size" :title="item.title"  >
                        <img  class="modify" src="../../assets/images/exam/modify.png"
                             height="12" width="12" @click=toDetail(item.qid) />
                    </cell>
                </group>
            </div>
            <div class="no-data" v-if="dataList.length == 0"><p>没有出题的数据</p></div>
        </section>

        <x-button class="publish-exam" @click.native="publishExam"><p id="pe">发布补考</p></x-button>
        <x-button class="back_meeting" @click.native="back()">返回</x-button>
        <tips :content="tip1" :position="position"></tips>
        <confirm v-model="pub" title="发布后不可更改" @on-confirm="onConfirm" @on-cancel="onCancel">
            <p style="text-align:center;">确定吗?</p>
        </confirm>

    </section>
</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import {
        Confirm,
        Checker,
        CheckerItem,
        Group,
        Cell,
        XTextarea,
        XInput,
        Search,
        XButton,
        Tab,
        TabItem,
        Tabbar,
        TabbarItem
    } from 'vux'
    import {getAnswersGeneral, getSimpleQuestion, publishExam,getMeetingByMid} from '../../api/api'
    import tips from '../../components/common/tips.vue'

    export default {
        components: {
            Confirm,
            Checker,
            CheckerItem,
            Group,
            Cell,
            XTextarea,
            XInput,
            Search,
            XButton,
            Tab,
            TabItem,
            Tabbar,
            TabbarItem,
            tips
        },
        data() {
            return {
                firstPart: true,//第一部分，基本信息填写
                format: 'YYYY-MM-DD HH:mm',//时间格式化
                question: {qid: '', uid: '', title: '', answer: '', meetId: ''},//题目
                dataList: [],
                curPage: 1,
                totalPage: 1,
                busy: false,
                tab: 0,
                pub: false,
                mid: 0,
                type: 1,
                exam:0,
                tip1:'确认所有题目出完之后发布',
                position:'vux-popover-arrow-down'
            }
        },
        methods: {
            //修改题目
            toDetail(qid) {
                if (this.type == 1) {
                    this.$router.push('/modifyS/' + qid);
                } else {
                    this.$router.push('/modifyQ/' + qid);
                }

            },
            onCancel() {
                return;
            },
            onConfirm(msg) {
                let _self = this;
                publishExam({"meetId": _self.mid}).then((response) => {
                    this.$vux.toast.text(response.message, 'middle')
                    if (response.success) {
                        _self.$vux.toast.text("发布成功", 'middle');
                        this.$router.push("/meetingDetail/" + this.mid)
                    } else {

                    }
                }).catch((error) => {
                    console.log(error)
                })
                $('#pe').html("已发布")
                $('.publish-exam').css("background", "#d58f8a");
                $('.publish-exam').attr("disabled", true);

            },

            back:function () {
                this.$router.push("/meetingDetail/" + this.mid)
            },
            publishExam: function () {
                this.pub = true;
            },
            publishAsk: function () {
                console.info(this);
                let _self = this;
                _self.$router.push('/publishAsk/' + this.mid);
            },
            publishSelect: function () {
                console.info(this);
                let _self = this;
                _self.$router.push('/publishSelect/' + this.mid);
            },
            moreData: function () {
                let _self = this;
                getAnswersGeneral({curPage: _self.curPage, meetId: _self.mid, type: _self.type}).then((response) => { //取得选择题
                    if (response.success) {
                        _self.dataList = _self.dataList.concat(response.data.page.rows);
                        _self.totalPage = response.data.page.pageCount;
                        _self.curPage++;
                        _self.busy = false;
                    } else {

                    }
                    $(".load-more").hide()
                }).catch((error) => {
                    $(".load-more").hide()
                    console.log(error)
                })
            },
            vertify() {
                let _self = this
                if ('' == _self.question.title.trim() || _self.question.title.length > 20) {
                    _self.$vux.toast.text('标题不能为空且长度限制20字', 'middle')
                    return false;
                }
                if ('' == _self.question.answer.trim() || _self.question.answer.length > 200) {
                    _self.$vux.toast.text('内容不能为空且长度限制200字', 'middle')
                    return false;
                }
                return true;
            },
            //发布考题
            publishQuestion: function () {
                let _self = this
                if (_self.vertify()) {
                    publishQuestion({question: _self.question}).then((response) => {
                        _self.$vux.toast.text(response.message, 'middle')
                        if (response.success) {
                            _self.$vux.toast.text("提交成功", 'middle')
                        } else {
                        }
                    }).catch((error) => {
                        console.log(error)
                    })
                }
            },
            onItemClick(type) {
                this.$vux.loading.show({
                    text: 'Loading'
                })
                this.type = type;
                this.dataList = []
                this.curPage = 1
                this.totalPage = 1
                this.busy = false
                setTimeout(() => {
                    this.$vux.loading.hide()
                }, 1000)
            },
            loadData: function () {
                if (this.curPage > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.moreData();
            },
            toIndex: function () {
                this.$router.push('/index')
            }
        },
        mounted() {
            let height = $(window).height();
            $(".topArea").css("height", height)//一开始就让按钮在底部
            $(window).resize(function () {
                let height = $(window).height();
            });
            this.mid = this.$route.params.meetId;//传进来的会议id
            let _self = this;
            console.log(_self.mid);
        },
    }
</script>

<style lang="less">
    .publish-question {
        background: #ffffff;
        height: 14rem;
        .tip-desc{
            bottom: 45px;
            position:fixed;
        }
        .question-title {
            background: #ffffff;
            padding: 0px .3rem 0 .6rem;
            height: 0.8rem;
            line-height: 0.8rem;

        }
        .question-title img {
            margin-left: -15px;
            margin-top: 8px;
        }
        .question-title span {
            font-weight: bold;
            font-size: 18px;
            font-family: "微软雅黑";
            margin-top: 15px;
            margin-left: 5px;
            position: relative;
            top: 8px;
        }
        .select-main {
            height: 2.5rem;
            background-size: cover;
            background: #EBE7DB;
        }
        .select-left {
            display: inline-block;
            margin-top: 0.30rem;
            margin-left: 0.35rem;
            height: 1.8rem;
            width: 3.3rem;
            background: url(../../assets/images/exam/wendatikuang.png) center no-repeat;
            background-size: 3.3rem 1.8rem;
            text-align: center;
            line-height: 1.8rem;
            position: relative;
            left: 9px;

        }
        .select-left span {
            color: #c3373a;
            font-size: 14px;

        }
        .select-right {
            display: inline-block;
            margin-top: 0.2rem;
            height: 1.8rem;
            width: 3.3rem;
            background: url(../../assets/images/exam/xuanzetikuang.png) center no-repeat;
            background-size: 3.3rem 1.8rem;
            text-align: center;
            line-height: 1.8rem;

        }
        .select-right span {
            color: #c3373a;
            font-size: 14px;

        }
        .question-tab {
            height: 1rem;
        }
        .question-title {
            color: #323232;
            font-size: 15px;
            font-family: 微软雅黑;
            line-height: 0px;
        }
        .publish-exam {
            width: 50%;
            position: fixed;
            bottom: 0px;
            color: #fff;
            background: #c3373a;
            line-height: 40px;
        }
        .back_meeting{
            width: 50%;
            position: fixed;
            right: 0px;
            bottom: 0px;
            color: #fff;
            background: #c3373a;
            line-height: 40px;
            float: left;
        }
        .weui-btn {
            border-radius: 0;
            font-size: 14px;
        }
        .weui-cells {
            margin-top: 0 !important;
        }
        .publish-question .question-title {
            line-height: 20px !important;
        }
        .modify {
            margin-top: -5px !important;
        }
        .title-size {
            font-size: 14px;
        }
        .publish-question .title-size{
            white-space: nowrap;
        }
        .vux-cell-primary{
            overflow:hidden;
        }
        .vux-cell-primary>p{
            line-height:0.75rem;
        }
        .vux-label{
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            width:6.3rem;
            margin-top:0.15rem;
        }
    }
</style>
