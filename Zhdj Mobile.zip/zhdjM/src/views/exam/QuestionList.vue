
<template>
    <section class="question-list">
        <div class="comm-head-logo">
            <div class="logo">
                <img src="../../assets/images/common/icon-logo.png" alt="">
            </div>
            <div class="back" @click="toIndex">
                回到首页
            </div>
        </div>

        <div class="question-title">
            <img src="../../assets/images/meeting/small-logo.png"><span>·</span>题目列表
        </div>
        <div class="questions" v-infinite-scroll="loadQuestion" infinite-scroll-disabled="busy" infinite-scroll-distance="10">
            <div class="question" v-for="(question, index) in questionList" :key="index" v-if="questionList.length > 0" @click="detail(question)">
                <img class="left-top" src="../../assets/images/meeting/left-top.png"/>
                <div class="content o-ellipsis">
                    <span>【{{question.type == 1 ? '选择题':'问答题'}}】</span>
                    <span>{{question.title}}</span>
                </div>
                <img class="answer-img" src="../../assets/images/meeting/error.png" v-if="question.result == 0"/>
                <img class="answer-img" src="../../assets/images/meeting/right.png" v-else-if="question.result == 1"/>
                <img class="answer-img" src="../../assets/images/meeting/write.png" v-else="question.result == 2"/>
            </div>
            <loading></loading>
        </div>
        <div class="no-data" v-if="questionList.length == 0"><p>没有题目数据</p></div>
    </section>
</template>

<script>
    import $ from 'jquery'
    import {Tab,TabItem} from 'vux'
    import {getQuestionList} from '../../api/api'
    import loading from '../../components/common/loading.vue'


    export default {
        components: {
            Tab,
            TabItem,
            loading
        },
        data () {
            return {
                meetId:Number,
                questionList:[],
                pageNo:1,
                size:15,
                totalPage:1,
                busy:false,
            }
        },
        methods: {
            //答题列表
            initQuestionList:function () {
                let _self = this
                _self.meetId = _self.$route.params.meetId;
                getQuestionList({pageNo:_self.pageNo,size:_self.size, meetId:_self.meetId}).then((response) => {
                    console.log(response)
                    $(".load-more").hide();
                    if(response.success){
                        _self.questionList = _self.questionList.concat(response.data.rows);
                        _self.totalPage = response.data.pageCount;
                        _self.pageNo++;
                        _self.busy = false;
                    } else {
                         _self.$vux.toast.text(response.message, 'middle')
                    }
                }).catch((error) => {
                    console.log(error)
                })
            },
            loadQuestion: function() {
                if(this.pageNo > this.totalPage || this.busy){
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show()
                this.initQuestionList();
            },
            detail:function (question) {
//                sessionStorage.setItem("question",JSON.stringify(question))
                this.$router.push('/question/' + question.qid + '?meetId=' + this.meetId)
            },
            toIndex: function () {
                this.$router.push('/index')
            }
        },
        mounted () {

        },

    }

   </script>

<style lang="less">
    .question-list{
        .question-title{
            line-height: 40px;
            margin: 0 .25rem 0 .25rem;
            img{
                width:15px;
                height:15px;
                margin-top: -5px;
            }
        }
        .question{
            width:100%;
            height: 50px;
            position: relative;
            background-color:#ffffff;
            margin-top:1px;
            .left-top{
                position: absolute;
                top:0;
                width: 40px;
                height:30px;
            }
            .answer-img{
                position: absolute;
                top:18px;
                right: .4rem;
                width: 10px;
                height: 10px;
            }
            .content{
                width:6rem;
                line-height:50px;
                font-size:12px;
                margin-left: .2rem;
            }
        }
    }

</style>
