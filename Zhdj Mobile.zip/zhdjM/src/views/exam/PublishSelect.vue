<template>

    <section class="publishSelect">
        <div class="comm-head-logo">
            <div class="logo">
                <img src="../../assets/images/common/icon-logo.png" alt="">
            </div>
            <div class="back" @click="toIndex">
                回到首页
            </div>
        </div>

        <section class="publish-select">
            <!-- 发布问答题页面 -->
            <group>
                <x-textarea placeholder="输入标题(200字以内)" v-model="question.title" auto></x-textarea>
            </group>

            <ul class="opNum">

                <li>
                    <div class="option option1">
                        <x-input title="A" placeholder="输入选项(20字以内)" v-model="question.option1"></x-input>
                    </div>
                    <check-icon :value.sync="s1" class="fr" @click-native="setAnswer()">设为正确答案</check-icon>
                </li>


                <li>
                    <div class="option">
                        <x-input title="B" placeholder="输入选项(20字以内)" v-model="question.option2"></x-input>
                    </div>
                    <check-icon :value.sync="s2" class="fr">设为正确答案</check-icon>
                </li>

                <li>
                    <div class="option">
                        <x-input title="C" placeholder="输入选项(20字以内)" v-model="question.option3"></x-input>
                    </div>
                    <check-icon :value.sync="s3" class="fr">设为正确答案</check-icon>
                </li>


                <li v-if="status0">
                    <div class="option">
                        <x-input title="D" placeholder="输入选项(20字以内)" v-model="question.option4"></x-input>
                    </div>
                    <check-icon :value.sync="s4" class="fr">设为正确答案</check-icon>
                </li>


                <li v-if="status1">
                    <div>
                        <div class="option">
                            <x-input title="E" placeholder="输入选项(20字以内)" v-model="question.option5"></x-input>
                        </div>
                    </div>
                    <check-icon :value.sync="s5" class="fr">设为正确答案</check-icon>
                </li>


                <li v-if="status2">
                    <div>
                        <div class="option">
                            <x-input title="F" placeholder="输入选项(20字以内)" v-model="question.option6"></x-input>
                        </div>
                    </div>
                    <check-icon :value.sync="s6" class="fr">设为正确答案</check-icon>
                </li>

                <img @click="cancel()" class="cancel" src="../../assets/images/exam/cha.png" height="20" width="20"/>

            </ul>
        </section>


        <section class="publish-option">
            <div style="width: 200px;margin: auto;height: 0.7rem;">
                <img @click="addOption()" src="../../assets/images/exam/addselect.png" height="25" width="25"/>
                <span>新增选项</span>
            </div>
        </section>

        <section class="bottomBg">
            <img src="../../assets/images/exam/buttondanghui.png">
            <div class="seat"></div>
        </section>

        <x-button class="publish-meeting" @click.native="publishQuestion()">提交</x-button>

        <confirm v-model="show" confirm-text="出下一题" cancel-text="完成"
                 title="提交成功!"
                 @on-cancel="onDone"
                 @on-confirm="onNext"
                 >
            <!--<p style="text-align:center;">{{ $t('Are you sure?') }}</p>-->
        </confirm>



    </section>

</template>
<!--起始页结束-->
<script>

    import $ from 'jquery'
    import {
        Confirm,
        Checker,
        CheckerItem,
        Group,
        CheckIcon,
        Cell,
        XTextarea,
        XInput,
        Datetime,
        XButton,
        Icon
    } from 'vux'
    import {publishQuestion, getQuestionByQid} from '../../api/api'

    let count = 4;
    export default {
        components: {
            Confirm,
            Checker,
            CheckerItem,
            Group,
            Cell,
            XTextarea,
            XInput,
            XButton,
            Icon,
            CheckIcon,
        },
        data() {
            return {
                question: {
                    qid: '',
                    uid: '',
                    title: '',
                    answer: '',
                    meetId: '',
                    option1: "",
                    option2: "",
                    option3: "",
                    option4: "",
                    option5: "",
                    option6: "",
                    type: "1",
                },//题目
                status0: false,
                status1: false,
                status2: false,
                s1: false,
                s2: false,
                s3: false,
                s4: false,
                s5: false,
                s6: false,
                qid: '',
                editable: false,
                modify: false,
                show:false,
            }
        },
        methods: {
            vertify() {
                let _self = this
                if ('' == _self.question.title.trim() || _self.question.title.length > 200) {
                    _self.$vux.toast.text('标题不能为空且长度限制200字', 'middle')
                    return false;
                }
                if (!_self.s1 && !_self.s2 && !_self.s3 && !_self.s4 && !_self.s5 && !_self.s6) {
                    _self.$vux.toast.text('至少选择一个答案', 'middle')
                    return false;
                }
                return true;
            },



            onDone:function () {
                this.$router.push("/publishQuestion/" + this.question.meetId)
            },

            onNext:function () {
                window.location.reload();
            },

            //发布选择题
            publishQuestion: function () {
                let _self = this
                if (_self.vertify()) {
                    if (_self.s1) {
                        _self.question.answer += 'A,';
                        console.log()
                        if (_self.question.option1.trim() == '') {
                            _self.$vux.toast.text('选项A不能为空', 'middle');
                            return;
                        }
                    }
                    if (_self.s2) {
                        _self.question.answer += 'B,';
                        if (_self.question.option2.trim() == '') {
                            _self.$vux.toast.text('选项B不能为空', 'middle');
                            return;
                        }

                    }
                    if (_self.s3) {
                        _self.question.answer += 'C,';
                        if (_self.question.option3.trim() == '') {
                            _self.$vux.toast.text('选项C不能为空', 'middle');
                            return;
                        }
                    }
                    if (_self.s4) {
                        _self.question.answer += 'D,';
                        if (_self.status0 && _self.question.option4.trim() == '') {
                            _self.$vux.toast.text('选项D不能为空', 'middle');
                            return;
                        }
                    }
                    if (_self.s5) {
                        _self.question.answer += 'E,';
                        if (_self.status1 && _self.question.option5.trim() == '') {
                            _self.$vux.toast.text('选项E不能为空', 'middle');
                            return;
                        }
                    }
                    if (_self.s6) {
                        _self.question.answer += 'F,';
                        if (_self.status2 && _self.question.option6.trim() == '') {
                            _self.$vux.toast.text('选项F不能为空', 'middle');
                            return;
                        }
                    }

                    //判断已填写的选项之前的选项不能为空
                    let count = 0;
                    for (let i = 1; i <= 6; i++) {
                        if (_self.question['option' + i].trim() != '') {
                            for (let k = 1; k < i; k++) {
                                if (_self.question['option' + k].trim() == '') {
                                    _self.$vux.toast.text('前面的选项不能为空', 'middle');
                                    return;
                                }
                            }
                        }
                    }
                    _self.$vux.loading.show({
                        text: 'Loading'
                    })
                    publishQuestion({question: this.question, "modify": this.modify, "type": "1"}).then((response) => {
                        _self.$vux.loading.hide()
                        console.log("*****",this.question);
                        // _self.$vux.toast.text(response.message, 'middle')
                        if (response.success) {
                            // _self.$vux.toast.text("提交成功", 'middle');
                            _self.show = true;
                            // this.$router.push("/publishQuestion/" + this.question.meetId)
                        } else {
                        }
                    }).catch((error) => {
                        console.log(error)
                    })
                }
            },

            addOption: function () {
                let _self = this;

                if (_self.status0 == false) {
                    _self.status0 = true;
                    return;
                }

                if (_self.status1 == false) {
                    _self.status1 = true;
                    return;
                }
                if (_self.status2 == false) {
                    _self.status2 = true;
                    return;
                }
                if (_self.status0 == true && _self.status1 == true && _self.status2 == true) {
                    _self.$vux.toast.text("选项最多为6个", 'middle')
                    return;
                }
            },

            cancel: function () {
                let _self = this;
                console.log($(".opNum li").length);
                if ($(".opNum li").length == 3) {
                    _self.$vux.toast.text("选项最少为3个", 'middle');
                    return;
                }
                if ($(".opNum li").length == 6) {
                    _self.status2 = false;
                    _self.question.s6 = false;
                    _self.question.option6 = ''
                    console.log($(".opNum li").length);
                    return;
                }
                if ($(".opNum li").length == 5) {
                    _self.status1 = false;
                    _self.question.s5 = false;
                    _self.question.option5 = ''
                    return;
                }

                if ($(".opNum li").length == 4) {
                    _self.status0 = false;
                    _self.question.s4 = false;
                    _self.question.option4 = ''
                    return;
                }


            },
            toIndex: function () {
                this.$router.push('/index')
            }
        },
        mounted() {
            let height = $(window).height();
            $(".publishSelect").css("minHeight",height - 100)//一开始就让按钮在底部
            $(window).resize(function () {
            });
            this.qid = this.$route.params.qid;
            let _self = this;
            console.log(this.qid);
            //修改题目
            if (_self.qid != undefined && _self.qid != '') {
                getQuestionByQid({'qid': _self.qid}).then((response) => {
                    console.log(response)
                    // _self.$vux.toast.text(response.message, 'middle')
                    if (response.success) {
                        console.log('111:', response);
                        _self.question = response.data;
                        _self.status0 = _self.question.option4 && _self.question.option4.trim() != '';
                        _self.status1 = _self.question.option5 && _self.question.option5.trim() != '';
                        _self.status2 = _self.question.option6 && _self.question.option6.trim() != '';
                        let answers = new Array();
                        answers = _self.question.answer.split(",");
                        for (let i = 0; i < answers.length; i++) {
                            console.log(answers[i]); //分割后的字符输出
                        }
                        console.log("answers:" + answers);
                        for (let i = 0; i < answers.length; i++) {
                            if (answers[i] == 'A') {
                                this.s1 = true;
                            } else if (answers[i] == 'B') {
                                this.s2 = true;
                            } else if (answers[i] == 'C') {
                                this.s3 = true;
                            } else if (answers[i] == 'D') {
                                this.s4 = true;
                            } else if (answers[i] == 'E') {
                                this.s5 = true;
                            } else if (answers[i] == 'F') {
                                this.s6 = true;
                            }
                        }
                        this.modify = true;
                        this.question.answer = '';
                    } else {
                    }
                }).catch((error) => {
                    console.log(error)
                })
            } else {
            }
            this.question.meetId = this.$route.params.mid;

        },
    }


</script>

<style lang="less">
    .publishSelect {

        position:relative;

        .publish-select {
            textarea {
                height: 2.5rem;
            }
        }
        .option {
            background-color: #FFFFFF;
            margin-top: 35px;
            line-height: 20px;
        }

        .option1 {
            margin-top: 0.1rem;
        }

        .rigth-check {
            margin-right: 50px;
        }

        .publish-option {
            border-top: solid 0.5px #FFFFFF;
            margin-top: 0.15rem;
            text-align: center;
            span {
                color: #c3373a;
                font-size: 15px;
                font-family: "微软雅黑";
                /*text-align: center;*/
                /*vertical-align: -8px;*/
                line-height: 0.7rem;
            }

        }
        .fr {
            margin-right: 0.5rem;
            margin-top: 5px;
        }

        .answer {
            position: absolute;
            left: 5.5rem;
        }

        .cancel {
            margin-left: 0.2rem;
            margin-top: 0.1rem;
        }
        .publish-option {
            height: 0.7rem;

        }

        //选中框
        .demo5-item {
            width: 1.6rem;
            line-height: .6rem;
            text-align: center;
            border-radius: 3px;
            border: 1px solid #ccc;
            background-color: #fff;
            margin-left: .1rem;
            margin-bottom: .2rem;
            font-size: 13px;
        }
        .demo6-item {
            width: 3rem;
            line-height: .8rem;
            text-align: center;
            border-radius: 3px;
            border: 1px solid #ccc;
            background-color: #fff;
            margin-left: .27rem;
            margin-bottom: .2rem;
            font-size: 13px;
        }
        .demo5-item-selected {
            /*background: #ffffff url(../../images/meeting/active.png) no-repeat right bottom;*/
            border-color: #c3373a;
        }
        .vux-checker-box {
            margin: .2rem 0 0 .3rem;
        }
        .weui-search-bar__cancel-btn {
            display: none !important;
        }
        .weui-cells {
            font-size: 14px;
            margin-top: 0.1rem;
        }
        .weui-search-bar {
            background-color: #EBE7DB !important;
        }
        .weui-search-bar__cancel-btn {
            color: #c3373a !important;
        }
        .weui-icon-checked:before {
            color: #c3373a !important;
        }
        .vux-search-fixed {
            position: relative !important;
        }
        .weui-cell__ft {
            color: #c3373a !important;
        }
        .weui-cell vux-x-textarea {
            padding: 0 !important;
        }

        .vux-x-icon {
            fill: #c3373a;
        }
        .cell-x-icon {
            display: block;
            fill: green;
        }
        .publish-meeting, .select-join-user, .select-summary-user {
            width: 100%;
            position: fixed;
            bottom: 0px;
            color: #fff;
            background: #c3373a;
            line-height: 40px;
            text-align: center;
        }

        .vux-check-icon > .weui-icon-success:before, .vux-check-icon > .weui-icon-success-circle:before {
            color: #c3373a !important;
        }
        .weui-btn {
            border-radius: 0 !important;
        }
        .bottomBg>img{
            height: 60px;
            width:100%;
        }
        .bottomBg{
            position:absolute;
            bottom:-100px;
        }
        .seat{
            height:40px;
            width:100%;
        }

    }

</style>
