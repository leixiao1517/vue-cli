
<template>
    <section class="question-detail">
        <div class="comm-head-logo">
            <div class="logo">
                <img src="../../assets/images/common/icon-logo.png" alt="">
            </div>
            <div class="back" @click="toIndex">
                回到首页
            </div>
        </div>

        <!-- 选择题 -->
        <div class="question" v-if="question.type == 1">
            <checklist :title="question.title" :options="options" v-model="selected" :disabled="question.answered == 1 ? true:false"></checklist>
        </div>
        <!-- 问答题 -->
        <group class="wenda" :title="question.title" v-if="question.type == 2">
            <img class="left-top" src="../../assets/images/meeting/left-top.png">
            <x-textarea :rows="21" :max="500" placeholder="请输入答案" v-model="answer.answer" autosize :disabled="question.answered == 1 ? true:false"></x-textarea>
        </group>
        <!-- 答题状态 -->
        <x-button class="submitButton" @click.native="submitQuestion()" v-if="question.answered != 1">提交</x-button>
        <x-button class="submitButton" v-if="question.result == 0">答错了</x-button>
        <x-button class="submitButton" v-if="question.result == 1">答对了</x-button>
        <x-button class="submitButton" v-if="question.result == 2 && question.answered == 1">查看中</x-button>
        <!-- 下一题 -->
        <div class="next-question" v-show="nextOne">
            <div class="answer-result" :class="{'active1':tipStatus == 1,'active2':tipStatus == 2}">
                <p>参考答案：{{question.answer}}</p>
                <p style="overflow:scroll;overflow-y:hidden;word-wrap:break-word;">你的答案：{{answer.answer}}</p>
                <x-button class="nextButton" @click.native="nextQuestion()" v-if="null != nextQid">下一题</x-button>
                <x-button class="nextButton" @click.native="returnQuestions()" v-if="null == nextQid">完成</x-button>
            </div>
        </div>
    </section>
</template>

<script>
    import $ from 'jquery'
    import {Group,Checklist,XButton,XTextarea} from 'vux'
    import {getQuestion,saveAnswer,addExamCredits} from '../../api/api'

    export default {
        components: {
            Group,
            Checklist,
            XButton,
            XTextarea
        },
        data () {
            return {
                nextOne:false,
                nextQid:Number,
                tipStatus:1,
                question:{},
                options:[],
                selected:[],
                answer:{}
            }
        },
        methods: {
            //答题
            initQuestion:function () {
                let _self = this
                getQuestion({qid:_self.question.qid}).then((response) => {
                    console.log(response)
                    if(response.success){
                        _self.question = response.data
                        _self.answer.qid= _self.question.qid
                        if(null != _self.question.userAnswer  && _self.question.userAnswer.length > 0){
                            _self.answer.answer= _self.question.userAnswer//简答题如果已经答过
                        }
                        if (1 == _self.question.type){ //选择题
                            if (1 == _self.question.answered) { //已答
                                _self.selected = _self.question.userAnswer.split(",")
                            }
                            if (null != _self.question.option1 && _self.question.option1.length > 0){
                                let q = {};
                                q.key = 'A'
                                q.value = 'A.' + _self.question.option1
                                _self.options.push(q)
                            }
                            if (null != _self.question.option2 && _self.question.option2.length > 0){
                                let q = {};
                                q.key = 'B'
                                q.value = 'B.' + _self.question.option2
                                _self.options.push(q)
                            }
                            if (null != _self.question.option3 && _self.question.option3.length > 0){
                                let q = {};
                                q.key = 'C'
                                q.value = 'C.' + _self.question.option3
                                _self.options.push(q)
                            }
                            if (null != _self.question.option4 && _self.question.option4.length > 0){
                                let q = {};
                                q.key = 'D'
                                q.value = 'D.' +_self.question.option4
                                _self.options.push(q)
                            }
                            if (null != _self.question.option5 && _self.question.option5.length > 0){
                                let q = {};
                                q.key = 'E'
                                q.value = 'E.' +_self.question.option5
                                _self.options.push(q)
                            }
                            if (null != _self.question.option6 && _self.question.option6.length > 0){
                                let q = {};
                                q.key = 'F'
                                q.value = 'F.' +_self.question.option6
                                _self.options.push(q)
                            }
                        } else {

                        }

                    } else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }).catch((error) => {
                    console.log(error)
                })


            },
            //检测结果
            submitQuestion:function () {
                let _self = this;
                if (1 == _self.question.type) { //选择题
                    let flag = 0;
                    let answer = _self.question.answer.split(",")//标准答案
                    let userAnswer = _self.selected;//用户答案
                    if (answer.length == userAnswer.length) {
                        for (let a = 0; a < answer.length; a++) {
                            for (let ua = 0; ua < userAnswer.length; ua++) {
                                if (answer[a] == userAnswer[ua]) {
                                    flag++
                                }
                            }
                        }
                        console.log(flag + "," + userAnswer.length)
                        if (flag == userAnswer.length) {
                            console.log("答对了---", flag)
                            _self.answer.result = 1;
                            _self.tipStatus = 0
                        } else {
                            console.log("答错了---")
                            _self.answer.result = 0;
                            _self.tipStatus = 1
                        }
                    } else {
                        console.log("答错了---")
                        _self.answer.result = 0;
                        _self.tipStatus = 1
                    }
                    _self.answer.answer = _self.selected.join(",")
                } else {
                    _self.tipStatus = 2
                }
                _self.save();//保存结果
            },
            //保存答案
            save:function () {
                let _self = this
                saveAnswer(_self.answer).then((response) => {
                    console.log(response)
                    if (response.success) {
                        _self.nextOne = true
                        _self.nextQid = response.data
                    }
                })
            },
            //下一个题目
            nextQuestion:function () {
                this.question = {}
                this.question.qid = this.nextQid
                this.nextOne = false
                this.options = []
                this.selected = []
                this.answer.answer = ''
                this.answer.result = 2
                this.initQuestion()
            },
            //返回列表页
            returnQuestions:function () {
                addExamCredits({}).then((response) => {
                })
                this.$router.push("/questionList/" + this.question.meetId)
            },
            toIndex: function () {
                this.$router.push('/index')
            }
        },
        mounted () {
            this.question.qid = this.$route.params.qid;
            this.answer.meetId = this.$route.query.meetId;
            this.initQuestion();
        }
    }
</script>

<style lang="less">
    .question-detail{

        .weui-textarea{
            background-color:white;
        }
        .submitButton{
            width:100%;
            position: fixed;
            bottom: 0px;
            color: #fff;
            background: #c3373a;
            line-height: 40px ;
            text-align: center;
        }
        .weui-cells__title{
            color:#313131;
        }
        .wenda{
            .weui-cell {
                padding: 20px 45px;
            }
            .weui-cell__bd{
                padding-bottom: 30px;
            }
            .left-top{
                position: absolute;
                top:0;
                height:50px;
            }
        }
        .next-question{
            position: fixed;
            left:0;
            top:0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,.5);
        }
        .next-question>div>p{
            margin-bottom: 15px;
            text-align: center;
            color: #a12730;
            font-size: 16px;
        }
        .answer-result{
            width:200px;
            height:130px;
            left: 50%;
            position: absolute;
            top: 50%;
            margin-left: -150px;
            margin-top: -180px;
            padding: 60px 50px 50px 50px;
            background: url("../../assets/images/meeting/answer-right.png") no-repeat;
            background-size: cover;
        }
        .answer-result.active1{
            background-image: url("../../assets/images/meeting/answer-error.png");
        }
        .answer-result.active2{
            background-image: url("../../assets/images/meeting/answer-tip.png");
        }
        .nextButton{
            width:130px;
            color: #fff;
            background: #c3373a;
            line-height: 40px ;
            text-align: center;
            margin-top: 45px;
        }
    }

</style>
