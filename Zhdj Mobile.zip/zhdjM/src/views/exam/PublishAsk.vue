<template>
    <section class="publish-meeting">
        <div class="comm-head-logo">
            <div class="logo">
                <img src="../../assets/images/common/icon-logo.png" alt="">
            </div>
            <div class="back" @click="toIndex">
                回到首页
            </div>
        </div>

        <!-- 发布问答题页面 -->
        <section class="first-part">
            <section class="topArea">
                <section class="meeting-info">
                    <x-input placeholder="请输入标题(20字以内)" v-model="question.title"></x-input>
                    <x-textarea :max="200" placeholder="请输入答案(200字以内)" v-model="question.answer" auto></x-textarea>
                </section>
            </section>

            <x-button class="publish-meeting" @click.native="publishQuestion()">提交</x-button>

        </section>


        <confirm v-model="show" confirm-text="出下一题" cancel-text="完成"
                 title="提交成功!"
                 @on-cancel="onDone"
                 @on-confirm="onNext"
        >
            <!--<p style="text-align:center;">{{ $t('Are you sure?') }}</p>-->
        </confirm>

    </section>
</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import {Confirm, Checker, CheckerItem, Group, Cell, XTextarea, XInput, Datetime, Search, XButton} from 'vux'
    import {publishQuestion, getQuestionByQid} from '../../api/api'

    export default {
        components: {
            Confirm,
            Checker,
            CheckerItem,
            Group,
            Cell,
            XTextarea,
            XInput,
            Search,
            XButton
        },
        data() {
            return {
                format: 'YYYY-MM-DD HH:mm',//时间格式化
                question: {qid: '', uid: '', title: '', answer: '', meetId: '', type: '2'},//题目
                leaveShow: false,//离开当前页提示 标记
                modify: false,
                show:false
            }
        },
        methods: {
            vertify() {
                let _self = this
                if ('' == _self.question.title.trim() || _self.question.title.length > 20) {
                    _self.$vux.toast.text('标题不能为空且长度限制20字', 'middle')
                    return false;
                }
                if ('' == _self.question.answer.trim() || _self.question.answer.length > 200) {
                    _self.$vux.toast.text('内容不能为空且长度限制200字', 'middle')
                    return false;
                }
                return true;
            },
            //提交题目
            publishQuestion: function () {
                let _self = this
                if (_self.vertify()) {
                    publishQuestion({question: _self.question, modify: _self.modify}).then((response) => {
                        console.log(response)
                        if (response.success) {
                            _self.show = true;
                        } else {
                        }
                    }).catch((error) => {
                        console.log(error)
                    })
                }
            },
            //搜索
            onSubmit(type) {
                let _self = this;
            },
            //确认离开
            powerLeave() {
                this.$router.push(this.path)
            },
            //留下
            stayHere() {
                this.path = ''
            },
            showFilter() {
                console.log('on showFilter')
            },

            onDone:function () {
                this.$router.push("/publishQuestion/" + this.question.meetId)
            },

            onNext:function () {
                window.location.reload();
            },
            toIndex: function () {
                this.$router.push('/index')
            }
        },
        mounted() {
            let height = $(window).height();
            $(".topArea").css("height", height)//一开始就让按钮在底部
            $(window).resize(function () {
                let height = $(window).height();
            });

            this.qid = this.$route.params.qid;
            let _self = this;
            console.log(this.qid);

            if (_self.qid != undefined && _self.qid != '') {
                getQuestionByQid({'qid': _self.qid}).then((response) => {
                    console.log(response)
                    if (response.success) {
                        _self.question = response.data;
                        this.modify = true;
                    } else {
                    }
                }).catch((error) => {
                    console.log(error)
                })

            } else {
                this.editable = true
            }

            this.question.meetId = this.$route.params.mid;

        },
    }

</script>

<style lang="less">
    @import "../../assets/css/meeting/publishMeeting";
</style>
