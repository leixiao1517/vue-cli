<!--起始页开始-->
<template>
    <section class="detailsExam">
        <div class="comm-head-logo">
            <div class="logo">
                <img src="../../assets/images/common/icon-logo.png" alt="">
            </div>
            <div class="back" @click="toIndex">
                回到首页
            </div>
        </div>

        <div class="top">
            <img src="../../assets/images/countExam/topIcon.png" />
            <span>答题详情</span>
            <!--<div class="btnBox">-->
                <!--<button id="btnActive">已答</button>-->
                <!--<button>未答</button>-->
            <!--</div>-->
        </div>
        <div v-infinite-scroll="loadUser" infinite-scroll-disabled="busy" infinite-scroll-distance="10">
            <div class="list" v-for="(user, index) in meetingUserList" :key="index" v-if="meetingUserList.length > 0">
                <img :src="user.headImg | imgPath" />
                <span>{{user.userName}}</span>
                <div :class="user.exam == 2 ?'active':''">
                    {{user.exam == 2 ?"未答":"已答"}}
                </div>
            </div>
            <loading></loading>
            <div class="no-data" v-if="meetingUserList.length == 0"><p>没有答题详情数据</p></div>
        </div>

        <img src="../../assets/images/countExam/contentBg.png" class="contentBg"/>
    </section>
</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import {getAnswerDetail} from '../../api/api'
    import loading from '../../components/common/loading.vue'

    export default {
        components: {
            loading
        },
        data () {
            return {
                meetId:Number,
                meetingUserList:[],
                pageNo:1,
                size:15,
                totalPage:1,
                busy:false,
            }
        },
        methods: {
            //答题列表
            initUserList:function () {
                let _self = this
                getAnswerDetail({curPage:_self.pageNo,meetId:_self.meetId,exam:'flag'}).then((response) => {
                    console.log(response)
                    $(".load-more").hide()
                    if(response.success) {
                        _self.meetingUserList = _self.meetingUserList.concat(response.data.page.rows);
                        _self.totalPage = response.data.page.pageCount;
                        _self.pageNo++;
                        _self.busy = false;
                    } else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }).catch((error) => {
                    $(".load-more").hide()
                })
            },
            loadUser:function () {
                if(this.pageNo > this.totalPage || this.busy){
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show()
                this.initUserList();
            },
            toIndex: function () {
                this.$router.push('/index')
            }
        },
        mounted () {
            this.meetId = this.$route.params.meetId;
        }
    }
</script>

<style lang="less">
    .detailsExam{
        .top{
            background-color:#ffffff;
            height:0.8rem;
            width:100%;
        }
        .top>img{
            height:0.5rem;
            width:0.5rem;
            margin-top:0.15rem;
            margin-left:0.3rem;
            float:left;
        }
        .top>span{
            height:0.8rem;
            line-height:0.8rem;
            font-weight:normal;
            margin-left:0.2rem;
            font-size:0.33rem;
        }
        .btnBox{
            float:right;
        }
        .btnBox>button{
            height:0.8rem;
            width:1.2rem;
            background-color:white;
            float:left;
            color:#c3373a;
            font-size:0.33rem;
        }
        #btnActive{
            background-color:#c3373a;
            color:white;
        }
        .list{
            width:100%;
            height:1.2rem;
            border-top:1px solid #ebe7db;
            background-color:white;
        }
        .list>img{
            width:1rem;
            height:1rem;
            border-radius: 50%;
            background-color:skyblue;
            margin-top:0.1rem;
            margin-left:0.3rem;
            float:left;
        }
        .list>span{
            height:1.2rem;
            line-height:1.2rem;
            font-weight:normal;
            margin-left:0.2rem;
            font-size:0.33rem;
        }
        .list>div{
            height:1.2rem;
            line-height:1.2rem;
            font-weight:normal;
            font-size:0.33rem;
            float:right;
            margin-right:0.5rem;
            color:#327caf;
        }
        .list>div.active{
            color:#c3373a;
        }
        .contentBg{
            width:100%;
            height:1.3rem;
            margin-top:1.3rem;
        }
    }
</style>
