<template>
    <div class="three-meeting">
        <section>
            <div class="three-meeting-summary">
                <div class="three-meeting-resource angle" @click="selectMeetingType">
                    <popup-picker @on-change="searchMeetingType"
                                  title=""
                                  :data="meetingTypeList"
                                  v-model="meetingType">
                    </popup-picker>
                </div>
            </div>
        </section>

        <div v-infinite-scroll="loadThreeMeeting" infinite-scroll-disabled="busy"
             infinite-scroll-distance="10">
            <template v-if="threeMeetingList.length>0">
                <div class="comm-item-1" @click="toResourceDetail(threeMeeting.meetId)"
                     v-for="(threeMeeting,scrollIndex) in threeMeetingList" :key="scrollIndex">
                    <div class="c-img">
                        <img :src="threeMeeting.cover||defaultCover" alt="">
                    </div>
                    <div class="c-info">
                        <span><span class="o-ellipsis" style="display: inline-block;max-width:4.5rem;">{{threeMeeting.meetingType}}</span></span>
                        <p class="o-webkit-line2">{{threeMeeting.title}}</p>
                        <div class="author">
                            <div>{{threeMeeting.partyName}}</div>
                            <div>{{threeMeeting.modifyDate | dateFormat('YMD')}}</div>
                        </div>
                    </div>
                </div>
                <loading></loading>
            </template>
            <div class="no-data" v-if="threeMeetingList.length==0"><p>没有数据</p></div>
        </div>
    </div>
</template>

<script>
    import $ from 'jquery'
    import {PopupPicker} from 'vux'
    import loading from '../../components/common/loading.vue'
    import{getMeetingList} from '../../api/api'
    export default {

        components: {
            loading,
            PopupPicker
        },
        data () {
            return {
                threeMeetingList: [],
                tabDesc: '',
                curPage: 1,
                pageSize: 6,
                totalPage: 1,
                busy: false,
                meetingType: ['全部类型'],
                meetingTypeList: [[
                    '全部类型',
                    '支部党员大会',
                    '党支部委员会',
                    '党小组会',
                    '支部主题党日',
                    '组织生活会',
                    '民主评议',
                    '评选表彰',
                    '书记述职',
                    '党课',
                    '其他'
                ]],
                defaultCover: require('../../assets/images/meetinglist/pic-meeting-list-cover.png')
            }
        },

        methods: {

            toResourceDetail(meetId){
//                let type = $("#partyHistory" + scrollIndex).val();
//                let vid = $("#vid" + scrollIndex).val();
//                this.$router.push({path: url, query: {type: type, vid: vid}});
                this.$router.push('/meetingDetail/' + meetId);
            },

            loadThreeMeeting: function () {
                if (this.curPage > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initThreeMeetingList();
            },

            initThreeMeetingList: function () {
                let _self = this;
                $(".load-more").hide();
                getMeetingList({
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.threeMeetingList = _self.threeMeetingList.concat(response.data.list);
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            },


            searchMeetingType (val) {
                let item = ''
                let _self = this;
                _self.curPage = 1;
                if (val[0] == '全部类型') {
                    item = ''
                } else {
                    item = val[0]
                }

                getMeetingList({
                    meetingType: item,
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.threeMeetingList = response.data.list;
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false;
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))

            },
            selectMeetingType() {
                this.showSort = true
            }
        }
    }
</script>

<style lang="less">

    .three-meeting {
        height: 11.4rem;

        .three-meeting-summary {
            /*height: 1rem;*/
            background-color: #FFFFFF;
            margin-bottom: 1px;
            .three-meeting-resource {
                display: inline-block;
                font-size: 14px;
                margin: 2px;
                .vux-cell-value {
                    color: #4A4A4A;
                }
            }
            .angle {
                position: relative;
            }
            .angle:after {
                position: absolute;
                right: 4px;
                top: 20px;
                content: '';
                display: block;
                border-top: 4px solid #4A4A4A;
                border-left: 3px solid transparent;
                border-right: 3px solid transparent;
            }
            .three-meeting-sort {
                display: inline-block;
                float: right;
                margin: 14px 20px;
            }
        }

        .comm-item-1 {
            display: flex;
            padding: 25px 15px;
            background: white;
            border-bottom: 1px solid #ececec;
            .c-img {
                width: 30%;
                img {
                    width: 100%;
                    height: 95px;
                }
            }
            .c-info {
                display: flex;
                flex-direction: column;
                justify-content: space-between;
                flex: 1;
                padding-left: 10px;
                span {
                    span {
                        padding: 1px 4px;
                        color: #a6344f;
                        font-size: 10px;
                        border: 1px solid #a6344f;
                    }
                }
                p {
                    font-size: 16px;
                    color: #424242;
                }
                .author {
                    display: flex;
                    justify-content: space-between;
                    font-size: 12px;
                    color: #8c8c8c;
                    div {

                    }
                }
            }
            .fit {
                object-fit: fill;
            }
        }
    }

    @import '../../assets/css/content.less';
</style>
