<template>
    <section class="volunteer-activity-details">
        <div class="top-img-box">
            <swiper :list="img_list" :show-dots="false" auto></swiper>
        </div>
        <div class="column" style="margin-top:0.2rem">
            <span>活动时间：</span>
            <div v-if="Apply == '0'">
                <p><i>我要报名</i></p>
                <b></b>
            </div>
            <div v-if="Apply == '1'">
                <p style="background-color:white;color:#D0021B"><i>已报名</i></p>
            </div>
        </div>
        <div class="time-and-check">
            <span>2018年6月-7月</span>
            <b v-if="passed == '-1'">查看中</b>
            <b v-if="passed == '1'">已通过</b>
            <b v-if="passed == '0'">未通过</b>
        </div>
        <div class="column">
            <span>活动简介：</span>
        </div>
        <div class="activity-introduce">
            <p>7月22日晚，溧水区石湫街道向阳行政村和江苏第二师范学院外国语学院联合举办的党建活动月文艺演出活动，在向阳行政村举行。精彩纷呈的演出活动，在深入宣传党的十九大精神的同时，弘扬传统文化，唱响了幸福美好的新生活，得到了村民们的一致点赞。</p>
        </div>
        <div class="down">
            <img src="../../assets/images/countExam/right.png" />
        </div>
        <div class="activity-tab">
            <button :class="{change: _self.tab === '1'}" @click="_self.tab = '1'">活动过程</button>
            <button :class="{change: _self.tab === '2'}" @click="_self.tab = '2'">活动讨论</button>
        </div>
        <div class="activity-box process" v-if="_self.tab == '1'">
            <div class="activity-process-list">
                <div class="activity-process-top">
                    <img src="#">
                    <span>范冰冰</span>
                    <b>2018/06/12&nbsp;22:14:45</b>
                </div>
                <div class="activity-process-content">
                    <p>这几天的文艺汇演排练，同志们都非常积极地参与了，见到我们的党建活动有如此高的参与率，我觉得非常开心呀！</p>
                    <div v-if="type == 'img'">
                        <img src="#">
                        <img src="#">
                        <img src="#">
                    </div>
                    <div v-if="type == 'video'">
                        <video></video>
                    </div>
                </div>
            </div>
        </div>
        <div class="activity-box discuss" v-if="_self.tab == '2'">
            <div class="activity-process-list">
                <div class="activity-process-top">
                    <img src="#">
                    <span>范冰冰</span>
                    <b>2018/06/12&nbsp;22:14:45</b>
                </div>
                <div class="activity-process-content">
                    <p>这几天的文艺汇演排练，同志们都非常积极地参与了，见到我们的党建活动有如此高的参与率，我觉得非常开心呀！</p>
                </div>
            </div>
        </div>
        <span class="fixed-bottom">我要报名</span>
        <div class="fixed-box" v-if="list == '1'">
            <img src="#" />
            <img src="#" />
        </div>
    </section>
</template>


<script>
    import $ from 'jquery'
    import {Swiper,SwiperItem} from 'vux'

    export default {
        components: {
            Swiper,
            SwiperItem
        },
        data() {
            return {
                passed:'-1',
                img_list: [{
                    url: 'javascript:',
                    img: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vvsr72j20p00gogo2.jpg',
                    title: '送你一朵fua'
                }, {
                    url: 'javascript:',
                    img: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vw1k2wj20p00goq7n.jpg',
                    title: '送你一辆车'
                }, {
                    url: 'javascript:',
                    img: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vw50iwj20ff0aaaci.jpg',
                    title: '送你一次旅行',
//        fallbackImg: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vw50iwj20ff0aaaci.jpg' 如果img引入出现404错误时，使用此备用路径引入。
                }],
                tab:'1',
                type:'img',
                Apply:'0',
                list:'1',
            }
        },
        methods: {

        },
        mounted() {
            $('.volunteer-activity-details').css("min-height",$(window).height());
            $("html,body").scrollTop(0);
        }
    }
</script>

<style lang="less">

    .volunteer-activity-details{

        background-color:white;
        padding-bottom:0.8rem;
        .top-img-box>span{
            display:block;
            position:absolute;
            bottom:0;
            height:0.8rem;
            line-height:0.8rem;
            font-size:15px;
            width:100%;
            background:rgba(0,0,0,0.4);
            color:white;
        }
        .column{
            width:100%;
            height:0.8rem;
        }
        .column>span{
            display:inline-block;
            height:0.8rem;
            line-height:0.8rem;
            font-size:15px;
            text-align:center;
            margin-left:0.25rem;
            color:#D0021B;
            float:left;
        }
        .column>div{
            width:3.6rem;
            height:0.8rem;
            float:right;
            position:relative;
        }
        .column>div>p{
            display:block;
            width:2.8rem;
            height:0.8rem;
            float:right;
            line-height:0.8rem;
            color:white;
            text-align:center;
            background-color:#D0021B;
        }
        .column>div>p>i{
            font-style:normal;
            display:inline-block;
            float:right;
            width:2.4rem;
        }
        .column>div>b{
            float:left;
            height:0.8rem;
            width:0.8rem;
            transform:rotate(45deg);
            position:absolute;
            left:0.25rem;
            background-color:white;
            border-radius:3px;
        }
        .time-and-check{
            height:0.6rem;
            width:100%;
            line-height:0.6rem;
        }
        .time-and-check>span{
            float:left;
            font-size:12px;
            display:inline-block;
            margin-left:0.25rem;
        }
        .time-and-check>b{
            float:right;
            font-size:12px;
            display:inline-block;
            font-weight:normal;
            width:2.4rem;
            text-align:center;
        }
        .activity-introduce>p{
            display:block;
            margin-left:0.25rem;
            width:7rem;
            color:#4A4A4A;
            font-size:12px;
            line-height:0.45rem;
        }
        .down{
            height:0.56rem;
            width:100%;
            border-bottom:3px solid #F2F2F2;
        }
        .down>img{
            display:block;
            margin:0.1rem auto;
            width:0.2rem;
            height:0.36rem;
            transform:rotate(270deg);
        }
        .activity-tab{
            height:0.9rem;
            width:100%;
            background-color:skyblue;
            display:flex;
            border-bottom:1px solid #F2F2F2;
        }
        .activity-tab>button{
            flex:1;
            line-height:0.9rem;
            text-align:center;
            color:#D0021B;
            background-color:white;
        }
        .activity-tab>.change{
            background-color:#D0021B;
            color:white;
        }
        .activity-box{
            width:100%;
        }
        .activity-process-list{
            width:7.3rem;
            margin:0.2rem 0.1rem 0rem 0.1rem;
            min-height:2.4rem;
            padding-bottom:0.1rem;
        }
        .activity-process-top{
            width:100%;
            height:0.8rem;
        }
        .activity-process-top>img{
            height:0.8rem;
            width:0.8rem;
            float:left;
            border-radius:50%;
            background-color:skyblue;
        }
        .activity-process-top>span{
            display:inline-block;
            line-height:0.8rem;
            height:0.8rem;
            margin-left:0.2rem;
            color:#4A90E2;
        }
        .activity-process-top>b{
            display:inline-block;
            font-weight:normal;
            line-height:0.8rem;
            font-size:12px;
            float:right;
            margin-right:0.5rem;
            color:#9B9B9B;
        }
        .activity-process-content{
            margin:0.2rem 0.1rem 0 0.8rem;
            width:6rem;
        }
        .activity-process-content>p{
            font-size:13px;
            color:black;
        }
        .activity-process-content>div>img{
            width:1.8rem;
            height:1.8rem;
            margin-left:0.1rem;
            margin-top:0.1rem;
        }
        .activity-process-content>div>video{
            width:100%;
            background-color:skyblue;
        }
        .fixed-box{
            position:fixed;
            bottom:1rem;
            right:0.4rem;
        }
        .fixed-box>img{
            height:0.8rem;
            width:0.8rem;
            display:block;
            margin-top:0.1rem;
            background-color:skyblue;
        }
        .fixed-bottom{
            width:100%;
            height:0.8rem;
            background-color:#D0021B;
            color:white;
            display:block;
            text-align:center;
            line-height:0.8rem;
            position:fixed;
            bottom:0;
        }
    }



</style>
