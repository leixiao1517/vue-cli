<template>
    <section class="volunteer">
        <div class="column">
            <span>推荐活动</span>
        </div>
        <div class="top-img-box">
            <swiper :list="img_list" :show-dots="false" auto></swiper>
        </div>
        <div class="all-activity">
            <span>所有活动</span>
            <div class="activity-state">
                <b>报名中</b>
                <b>进行中</b>
                <b>往期精彩</b>
            </div>
        </div>
        <div class="activity-list">

            <div class="activity-box" @click="toUrl('VolunteerActivityDetails')" v-for="value in active_list">
                <div>
                    <div class="activity-img"></div>
                    <div class="activity-content">
                        <h3>{{value.title}}</h3>
                        <b>已有：<span>{{value.people}}</span>&nbsp;&nbsp;人报名</b>
                        <p>活动简介：{{value.details}}</p>
                    </div>
                </div>
                <img src="../../assets/images/countExam/right.png" />
            </div>

        </div>
    </section>
</template>


<script>
    import $ from 'jquery'
    import {Swiper,SwiperItem} from 'vux'


    export default {
        components: {
            Swiper,
            SwiperItem,
        },
        data() {
            return {
                img_list: [{
                    url: 'javascript:',
                    img: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vvsr72j20p00gogo2.jpg',
                    title: '送你一朵fua'
                }, {
                    url: 'javascript:',
                    img: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vw1k2wj20p00goq7n.jpg',
                    title: '送你一辆车'
                }, {
                    url: 'javascript:',
                    img: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vw50iwj20ff0aaaci.jpg',
                    title: '送你一次旅行',
//        fallbackImg: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vw50iwj20ff0aaaci.jpg' 如果img引入出现404错误时，使用此备用路径引入。
                }],
                active_list:[{
                    id: '1',
                    title: '开展庆“七一”系列党建活动',
                    people: '243',
                    details: '开展政治理论教育活动，6月14日至22日举办“不忘初心、牢记使命、做新时代合'
                },{
                    id: '2',
                    title: '1',
                    people: '196',
                    details: '1'
                },{
                    id: '3',
                    title: '2',
                    people: '168',
                    details: '2'
                },{
                    id: '4',
                    title: '3',
                    people: '214',
                    details: '3'
                }]
            }
        },
        methods: {
            toUrl:function(url){
                this.$router.push("/"+url)
            },
        },
        mounted() {
            $('.volunteer').css("min-height",$(window).height());
            $("html,body").scrollTop(0);
        }
    }
</script>

<style lang="less">

    .volunteer{

        background-color:white;
        .column{
            width:100%;
            background-color:#d0021b;
        }
        .column>span{
            display:inline-block;
            height:0.8rem;
            line-height:0.8rem;
            font-size:15px;
            text-align:center;
            margin-left:0.25rem;
            color:white;
        }
        .top-img-box>span{
            display:block;
            position:absolute;
            bottom:0;
            height:0.8rem;
            line-height:0.8rem;
            font-size:15px;
            width:100%;
            background:rgba(0,0,0,0.4);
            color:white;
        }
        .all-activity{
            width:100%;
            background-color:#F2F2F2;
        }
        .all-activity>span{
            display:inline-block;
            height:0.8rem;
            line-height:0.8rem;
            font-size:15px;
            text-align:center;
            margin-left:0.25rem;
            color:#d0021b;
            font-weight:bold;
        }
        .activity-state{
            float:right;
            margin-right:0.25rem;
        }
        .activity-state>b{
            display:inline-block;
            height:0.8rem;
            line-height:0.8rem;
            font-weight:normal;
            margin-right:0.1rem;
            color:#9B9B9B;
        }
        .activity-list{
            width:100%;
            background-color:#F2F2F2;
        }
        .activity-box:first-child{
            margin-top:0;
        }
        .activity-box{
            height:2rem;
            background-color:white;
            margin-top:0.1rem;
        }
        .activity-box>img{
            float:right;
            width:0.2rem;
            height:0.4rem;
            margin-top:0.8rem;
            margin-right:0.2rem;
            display:block;
        }
        .activity-box>div{
            float:left;
            height:1.6rem;
            width:6.75rem;
            display:block;
            margin:0.2rem 0 0 0.25rem;
        }
        .activity-img{
            height:1.6rem;
            width:2.4rem;
            background-color:skyblue;
            display:inline-block;
        }
        .activity-content{
            width:4.25rem;
            height:1.6rem;
            float:right;
        }
        .activity-content>h3{
            font-size:15px;
            line-height:0.4rem;
        }
        .activity-content>b{
            margin-top:0.1rem;
            font-size:12px;
            line-height:0.3rem;
            display:block;
            color:#9B9B9B;
            font-weight:normal;
        }
        .activity-content>b>span{
            color:#D0021B;
            font-weight:bold;
        }
        .activity-content>p{
            font-size:12px;
            margin-top:0.15rem;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
            color:#9B9B9B;
        }


    }



</style>
