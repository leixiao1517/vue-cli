<template>
    <section class="man">
        <div id="man">人工</div>
    </section>
</template>

<script>
    import * as echarts from 'echarts';
    export default {
        data () {
            return {
                x:["09:00","10:00","11:00"],
                y:[1,2,3],
                yTemp:["12:00","13:00","14:00"]
            }
        },
        methods:{
            //K线图
            man:function () {
                let _self = this
                let myChart = echarts.init(document.getElementById('man'));
                myChart.setOption({
                    title: {
                        text: '人工',
                        padding: 3,
                        textStyle: {
                            fontSize: 18,
                            fontWeight: 'bolder',
                            color: '#ff0000'          // 主标题文字颜色
                        },
                        subtextStyle: {
                            color: '#aaa'          // 副标题文字颜色
                        }
                    },
                    tooltip: {//悬浮提示框
                        showDelay: 20,
                        trigger: 'axis',
                        axisPointer: {
                            type: 'cross'
                        }
                    },
                    xAxis:  {//X轴
                        name:'时间轴',
                        type: 'category',
                        boundaryGap: false,
                        //设置轴线的属性
                        axisLine:{
                            symbol:['none','arrow']
                        },
                        axisLabel:{
                            interval: 0,
                            rotate:20
                        },
                        data: _self.x
                    },
                    yAxis: {//Y轴
                        name:'人工(立方米)',
                        type: 'value',
                        //设置轴线的属性
                        axisLine:{
                            symbol:['none','arrow']
                        },
                        axisLabel: {
                            formatter: '{value}℃'
                        },
                        axisPointer: {
                            snap: true
                        }
                    },
                    dataZoom: [
                        {   // 这个dataZoom组件，默认控制x轴。
                            type: 'slider', // 这个 dataZoom 组件是 slider 型 dataZoom 组件
                            start: 0,      // 左边在 0% 的位置。
                            end: 60         // 右边在 60% 的位置。
                        },
                        {   // 这个dataZoom组件，也控制x轴。
                            type: 'inside', // 这个 dataZoom 组件是 inside 型 dataZoom 组件
                            start: 0,      // 左边在 0% 的位置。
                            end: 60         // 右边在 60% 的位置。
                        }
                    ],
                    series: [
                        {
                            name:'人工',
                            type:'line',
                            smooth: true,
                            data: _self.y,
                            markPoint : {
                                data : [
                                    {type : 'max', name: '最大值'},
                                    {type : 'min', name: '最小值'}
                                ]
                            }
                        }
                    ],
                });
            }
        },
        mounted(){
            let _self = this;
            let inde = 0
            this.man()
            let changeData = setInterval(function () {
                if(_self.y.length > 5){
                    clearInterval(changeData)
                    return
                }
                _self.x.push(_self.yTemp[inde])
                _self.y.push(inde)
                inde ++
                console.log("x:",_self.x)
                _self.man()
            },2000)
        },
    }
</script>

<style lang="less" scoped>
    .man{
        #man{
            min-height:300px;
            width:100%;
            margin:auto;
        }
    }
</style>
