<template>
    <section  class="party-rules">
        <section style="height: 44px">
            <search
                v-model="searchVal"
                position="absolute"
                auto-scroll-to-top
                top="0px"
                @on-focus="onFocus"
                @on-cancel="onCancel"
                @on-submit="onSubmit"
                ref="search"></search>
        </section>
        <section>
            <div>
                <div v-infinite-scroll="loadPartyRules" infinite-scroll-disabled="busy"
                     infinite-scroll-distance="10">
                    <template v-if="partyRulesList.length>0">
                        <comm-item @click.native="toResourceDetail('/ResourceDetail',scrollIndex)"
                                   v-for="(partyRules,scrollIndex) in partyRulesList" :key="scrollIndex"

                                   :imgSrc="partyRules.videoImg"
                                   :type="partyRules.zyType"
                                   :info1="partyRules.title"
                                   :info2="partyRules.userName"
                                   :info3="partyRules.partyName"
                                   :info4="partyRules.modifyDate | dateFormat('YMD')">
                            <input :id="'partyRules' + scrollIndex" type="hidden" :value="partyRules.docType"/>
                            <input :id="'vid' + scrollIndex" type="hidden" :value="partyRules.vid"/>
                        </comm-item>
                        <loading></loading>
                    </template>
                    <div class="no-data" v-if="partyRulesList.length==0"><p>没有数据</p></div>
                </div>
            </div>
        </section>
    </section>
</template>

<script>
    import loading from '../../components/common/loading.vue'
    import{getResourceList} from '../../api/api'
    import {Search} from 'vux'
    import $ from 'jquery'
    import commItem from '../../components/common/commItem1.vue'
    export default {

        components: {
            loading,
            Search,
            commItem
        },
        data () {
            return {
                partyRulesList: [],
                curPage: 1,
                pageSize: 6,
                totalPage: 1,
                busy: false,
                searchVal:''
            }
        },

        methods: {
            toResourceDetail(url, scrollIndex){
                let type = $("#partyRules" + scrollIndex).val();
                let vid = $("#vid" + scrollIndex).val();
                this.$router.push({path: url, query: {type: type, vid: vid}});
            },

            loadPartyRules: function () {
                if (this.curPage > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initPartyRulesList();
            },

            initPartyRulesList: function () {
                let _self = this;

                $(".load-more").hide();
                getResourceList({
                    menu: '党内法规',
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.partyRulesList = _self.partyRulesList.concat(response.data.list);
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            },
            onFocus() {

            },
            onCancel() {
                console.log('cancelsearch '+this.searchVal)
            },
            onSubmit() {
                this.$refs.search.setBlur()
                let _self = this;
                _self.curPage = 1;
                getResourceList({
                    searchKey: _self.searchVal,
                    menu: '党内法规',
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.partyRulesList = response.data.list;
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false;
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            }
        }
    }
</script>

<style lang="less">

    .party-rules {
        height: 11.4rem;
    }

    @import '../../assets/css/content.less';
</style>
