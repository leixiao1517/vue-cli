<template>
    <div class="recommended">
        <div class="recommended-title">
            <span>本期推荐</span>
        </div>
        <div class="recommended-book">
            <img :src="recommendModel.bookImg | imgPath" @click="ViewTheBookDetails(recommendModel.bookId)"/>
            <div>
                <h4>{{recommendModel.bookTitle}}</h4>
                <p class="recommended-book-author">
                    <span>作者:{{recommendModel.bookAuthor}}</span><span>出版社:{{recommendModel.bookPubilsh}}</span></p>
                <p class="recommended-book-content">{{recommendModel.bookDescription}}</p>
            </div>
        </div>


        <div>
            <tab :line-width=2 v-model="tabIndex" active-color='#D0021B'>
                <tab-item class="vux-center" :selected="recommendSelected === item"
                          v-for="(item, tabIndex) in recommendTitlelist" @click.native="recommendSelectedItem(tabIndex)"
                          :key="tabIndex">{{item}}
                </tab-item>
            </tab>

            <div v-infinite-scroll="loadBooks" infinite-scroll-disabled="busy" infinite-scroll-distance="10">
                <div class="recommended-others" v-for="(book,scrollIndex) in booksList" :key="scrollIndex"
                     v-if="booksList.length > 0">
                    <div :link="'/recommend/' + book.bookId">
                        <img :src="book.bookImg | imgPath"/>
                        <div>
                            <h4>{{book.bookTitle}}</h4>
                            <p class="recommended-others-author">
                                <span>作者:{{book.bookAuthor}}</span><span>出版社:{{book.bookPubilsh}}</span>
                            </p>
                            <p class="recommended-others-content">
                                {{book.bookDescription}}</p>
                        </div>
                    </div>
                </div>
                <loading></loading>
            </div>
        </div>
        <div class="book-common">
            <mineBookCommon></mineBookCommon>
        </div>
    </div>


</template>

<script>
    import{Tab, TabItem} from 'vux'
    import mineBookCommon from './MineBookCommon'
    import loading from '../../components/common/loading.vue'
    import{getBooksDetail, getCurrentRecommend} from '../../api/api'

    const list = () => ['全部分类', '党员必读', '党史党章', '党建工作', '三会一课', '两学一做'];

    export default {

        components: {
            Tab,
            TabItem,
            mineBookCommon,
            loading
        },

        data () {
            return {
                recommendSelected: '党员必读',
                recommendTitlelist: list(),
                scrollIndex: 0,
                tabIndex: 0,
                booksList: [
                    {

                        bookId: 1,
                        bookImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                        bookTitle: '红色起点',
                        bookAuthor: '二狗子',
                        bookPubilsh: '一家牛逼出版社',
                        bookDescription: '哈哈哈哈哈哈哈哈哈哈哈'
                    },
                    {

                        bookId: 2,
                        bookImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                        bookTitle: '红色起点',
                        bookAuthor: '二狗子',
                        bookPubilsh: '一家牛逼出版社',
                        bookDescription: '哈哈哈哈哈哈哈哈哈哈哈'
                    },
                    {

                        bookId: 3,
                        bookImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                        bookTitle: '红色起点',
                        bookAuthor: '二狗子',
                        bookPubilsh: '一家牛逼出版社',
                        bookDescription: '哈哈哈哈哈哈哈哈哈哈哈'
                    },
                    {
                        bookId: 4,
                        bookImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                        bookTitle: '红色起点',
                        bookAuthor: '二狗子',
                        bookPubilsh: '一家牛逼出版社',
                        bookDescription: '哈哈哈哈哈哈哈哈哈哈哈'
                    },
                    {
                        bookId: 5,
                        bookImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                        bookTitle: '红色起点',
                        bookAuthor: '二狗子',
                        bookPubilsh: '一家牛逼出版社',
                        bookDescription: '哈哈哈哈哈哈哈哈哈哈哈'
                    },

                ],
                busy: false,
                pageNo: 1,
                size: 5,
                totalPage: 1,

                recommendModel: {
                    bookId: 1,
                    bookImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                    bookTitle: '红色起点',
                    bookAuthor: '二狗子',
                    bookPubilsh: '一家牛逼出版社',
                    bookDescription: '哈哈哈哈哈哈哈哈哈哈哈'
                }

            }
        },

        methods: {
            ViewTheBookDetails(bookId){
                console.log(bookId);
                this.$router.push("/recommend/" + bookId);
            },

            recommendSelectedItem(tabIndex){
                console.log(tabIndex)
            },

            initBooksList: function () {
                let _self = this;
                getBooksDetail({curPage: _self.pageNo, bookId: _self.bookId, book: 'flag'}).then((response) => {
                    console.log(response);
                    $(".load-more").hide();
                    if (response.success) {
                        _self.booksList = _self.booksList.concat(response.data.page.rows);
                        _self.totalPage = response.data.page.pageCount;
                        _self.pageNo++;
                        _self.busy = false;
                    } else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }).catch((error) => {
                    $(".load-more").hide()
                })
            },


            loadBooks: function () {
                if (this.pageNo > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initBooksList();
            },


        },
        mounted () {
            let _self = this;
            this.bookId = this.$route.params.bookId;

            getCurrentRecommend({bookId: _self.bookId}).then(data => {
                console.log('getRecommend', data);
                if (data.data == null) {
                    _self.$vux.toast.text(data.message, 'middle');
                    return;
                }
                _self.recommendModel = data.data.recommendModel;
            })

        }


    }
</script>

<style lang="less">
    .recommended {
        background-color: #FFFFFF;

        .recommended-title {
            height: 0.7rem;
            width: 100%;
            background-color: #D0021B;
            span {
                display: inline-block;
                margin-top: 6px;
                margin-left: 14px;
                font-size: 14px;
                color: #FFFFFF;
            }
        }

        .recommended-book {
            height: 4rem;
            margin: 12px 18px 14px;
            img {
                float: left;
                width: 134px;
                height: 178px;
                margin-right: 5px;
            }
        }

        .recommended-book-author {
            margin: 8px 0px 10px 0px;
            font-size: 10px;
            span {
                margin-right: 8px;
            }
        }

        .recommended-book-content {
            font-size: 12px;
        }

        .recommended-others {
            height: 2rem;
            padding: 8px 10px 0px 10px;
            img {
                float: left;
                height: 96px;
                width: 76px;
                margin-right: 5px;
            }
        }

        .recommended-others-content {
            font-size: 10px;
        }

        .recommended-others-author {
            font-size: 10px;
            margin: 8px 0px 10px 0px;
        }

        .recommended-others-author > span {
            margin-right: 0.25rem;
        }

        .book-common {
            position: fixed;
            bottom: 1.25rem;
            right: 0.1rem;
            height: 1.4rem;
            width: 1.4rem;
        }

    }


</style>
