<template>
    <div class="recommended-details">
        <div class="recommended-details-cover">
            <div>
                <h3>{{recommendModel.bookTitle}}</h3>
                <p class="recommended-details-author">
                    <span>作者:{{recommendModel.bookAuthor}}</span><span>出版社:{{recommendModel.bookPubilsh}}</span></p>
                <p class="recommended-details-content"><span>23333</span><span>13333</span></p>
            </div>
            <img :src="recommendModel.bookImg | imgPath"/>
        </div>
        <article>
            <div>推荐理由</div>
            <div class="content">
                <p v-html="recommendModel.bookRecommendReason"></p>
            </div>
        </article>

        <article>
            <div>内容简介</div>
            <div class="content">
                <p v-html="recommendModel.bookDescription"></p>

            </div>
        </article>
        <div class="related-recommend">
            <h2 class="title">喜欢这本书的人也喜欢</h2>
            <div class="list">
                <ul class="list-ul">
                    <li class="list-li" v-for="item in bookList">
                        <router-link :to="{ path: '/recommendDetails/'+item.bookId}">
                            <img :src="item.bookImg"/>
                            <p class="book-name">{{item.bookName}}</p>
                        </router-link>
                    </li>
                    <!--<li class="list-li">-->
                    <!--<router-link :to="{ path: '/recommendDetails/'}" @click.native="recommendDetails()">-->
                    <!--<img src="../../assets/images/book/test.png"/>-->
                    <!--<p class="book-name">这本书很牛逼</p>-->
                    <!--</router-link>-->
                    <!--</li>-->
                    <!--<li class="list-li">-->
                    <!--<router-link :to="{ path: '/recommendDetails/'}" @click.native="recommendDetails()">-->
                    <!--<img src="../../assets/images/book/test.png"/>-->
                    <!--<p class="book-name">这本书很牛逼</p>-->
                    <!--</router-link>-->
                    <!--</li>-->
                    <!--<li class="list-li">-->
                    <!--<router-link :to="{ path: '/recommendDetails/' }" @click.native="recommendDetails()">-->
                    <!--<img src="../../assets/images/book/test.png"/>-->
                    <!--<p class="book-name">这本书很牛逼</p>-->
                    <!--</router-link>-->
                    <!--</li>-->
                    <!--<li class="list-li">-->
                    <!--<router-link :to="{ path: '/recommendDetails/'}" @click.native="recommendDetails()">-->
                    <!--<img src="../../assets/images/book/test.png"/>-->
                    <!--<p class="book-name">这本书很牛逼</p>-->
                    <!--</router-link>-->
                    <!--</li>-->
                    <!--<li class="list-li">-->
                    <!--<router-link :to="{ path: '/recommendDetails/'}" @click.native="recommendDetails()">-->
                    <!--<img src="../../assets/images/book/test.png"/>-->
                    <!--<p class="book-name">这本书很牛逼</p>-->
                    <!--</router-link>-->
                    <!--</li>-->
                </ul>
            </div>
        </div>
        <div class="my-favorite" @click="myFavorite('./recommendBooks')">
            收藏到书单
        </div>
        <div class="download-book" @click="downloadBook('./recommendBooks')">
            下载电子书
        </div>
        <div class="book-common">
            <mineBookCommon></mineBookCommon>
        </div>

    </div>

</template>

<script>
    import mineBookCommon from './MineBookCommon'
    import{getCurrentRecommend, collectMyFavorite} from '../../api/api'

    export default {
        components: {
            mineBookCommon,
        },
        data () {
            return {
                bookList: [
                    {
                        bookId: 1,
                        bookName: '哈哈哈啊',
                        bookImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                    },
                    {
                        bookId: 2,
                        bookName: '哈哈哈啊',
                        bookImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                    },
                    {
                        bookId: 3,
                        bookName: '哈哈哈啊',
                        bookImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                    },
                    {
                        bookId: 4,
                        bookName: '哈哈哈啊',
                        bookImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                    },
                    {
                        bookId: 5,
                        bookName: '哈哈哈啊',
                        bookImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                    },
                    {
                        bookId: 6,
                        bookName: '哈哈哈啊',
                        bookImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                    },
                ],
                recommendModel: {
                    bookId: 1,
                    bookImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                    bookTitle: '红色起点',
                    bookAuthor: '二狗子',
                    bookPubilsh: '一家牛逼出版社',
                    bookDescription: '1914年，毛泽东进入湖南第一师范学习。据他的同班同学周世钊和蒋竹如回忆，该校每个周六打“牙祭”吃红烧肉，用湘潭酱油（老抽）加冰糖、料酒、大茴（八角）慢火煨成，肉用带皮的“五花三层”，八人一桌，足有四斤肉。从这时起，毛泽东就爱上了红烧肉这个菜。',
                    bookRecommendReason: '红烧肉可以大量补充能量，恢复体力，使人精力充沛。据历史记载，毛主席在指挥三大战役时，对警卫员李银桥说：“你只要隔三天给我吃一顿红烧肉，我就有精力打败敌人。”可见，主席对红烧肉的钟爱。',
                }
            }
        },
        methods: {
            myFavorite: function () {
                let _self = this;

                this.bookId = this.$route.params.bookId;

                collectMyFavorite({
                    bookId: _self.bookId
                }).then(data => {
                    if (data.success) {

                    } else {

                    }
                })
            },

            downloadBook: function () {

            }


        },

        mounted () {

            let _self = this;
            this.bookId = this.$route.params.bookId;

            getCurrentRecommend({bookId: _self.bookId}).then(data => {
                console.log('getRecommend', data);
                if (data.data == null) {
                    _self.$vux.toast.text(data.message, 'middle');
                    return;
                }
                _self.recommendModel = data.data.recommendModel;
            })

        }
    }
</script>

<style lang="less">

    .recommended-details {

        .recommended-details-cover {
            height: 2rem;
            padding: 8px 12px 14px;
            background-color: #ffffff;
            div {
                display: inline-block;
                max-width: 5rem;
            }
            img {
                float: right;
                height: 96px;
                width: 70px;

            }

        }

        .recommended-details-author {
            margin: 8px 0px 10px 0px;
            font-size: 10px;
            span {
                margin-right: 18px;
            }
        }

        .recommended-details-content {
            font-size: 4px;
            span {
                margin-right: 20px;
            }
        }

        .my-favorite {
            width: 20%;
            text-align: center;
            float: left;
            bottom: 0px;
            height: 1rem;
            line-height: 1rem;
            color: white;
            font-size: 0.2rem;
            background: #cf1814;
        }

        .download-book {
            width: 80%;
            text-align: center;
            float: left;
            bottom: 0px;
            height: 1rem;
            line-height: 1rem;
            color: #D0021B;
            font-size: 0.2rem;
            background: #FFFFFF;
        }

    }

    article {
        margin-top: 6px;
        background: white;
        div:first-child {
            width: 1.8rem;
            line-height: 30px;
            color: #D0021B;
            text-align: center;
        }
        .content {
            padding: 0.25rem;
            width: 7rem;
            p {
                display: inline-block;
                width: 7rem;
                margin-bottom: 5px;
                line-height: 26px;
                font-size: 12px;
            }

        }
    }

    .related-recommend {
        /*padding: 15px 0;*/
        margin-bottom: 5px;
        background-color: #fff;
        .title {
            margin-left: 15px;
            margin-bottom: 5px;
            /*text-indent: 5px;*/
            font-size: 14px;
            line-height: 16px;
            color: #D0021B;
        }
        .list {
            .list-ul {
                position: relative;
                overflow-x: auto;
                overflow-y: hidden;
                white-space: nowrap;
                text-indent: 7px;
                .list-li {
                    display: inline-block;
                    margin-right: 8px;
                    width: 100px;
                    /*white-space: normal;*/
                    img {
                        width: 100%;
                        height: 125px;
                    }
                    p {
                        overflow: hidden;
                        text-overflow: ellipsis;
                        white-space: nowrap;
                    }
                }
            }
        }
    }

    .book-common {
        position: fixed;
        bottom: 1.25rem;
        right: 0.1rem;
        height: 1.4rem;
        width: 1.4rem;
    }

</style>
