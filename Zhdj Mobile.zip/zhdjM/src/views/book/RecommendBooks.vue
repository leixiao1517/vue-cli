<template>
    <div class="recommend-books">
        <group>
            <x-input title="书名:" v-model="bookName"></x-input>
            <x-input title="作者:" v-model="author"></x-input>
            <selector ref="publishing" title="选择出版社" direction="rtl" :options="publishingList"
                      v-model="publishing"></selector>
            <selector ref="bookCategory" title="选择类别" direction="rtl" :options="list"
                      v-model="bookCategory"></selector>
        </group>

        <group title="简介">
            <x-textarea :max="200" name="description" v-model="bookDescription" placeholder="输入稿件描述"></x-textarea>
        </group>


        <group title="推荐理由">
            <x-textarea :max="200" name="description" v-model="bookRecommendReason" placeholder="输入推荐理由"></x-textarea>
        </group>


        <box gap="180px 60px 10px 60px">
            <flexbox>
                <flexbox-item>
                    <x-button type="warn" @click.native="submitBookInfo">发送</x-button>
                </flexbox-item>
            </flexbox>
        </box>

    </div>

</template>

<script>

    import{Group, XInput, Box, Flexbox, FlexboxItem, XButton, XTextarea, Selector}from 'vux'
    import {recommendBookLink} from '../../api/api'
    export default {
        components: {
            Group,
            XInput,
            Box,
            Flexbox,
            FlexboxItem,
            XButton,
            XTextarea,
            Selector

        },

        data () {
            return {
                bookName: '',
                author: '',
                bookCategory: 'gd',
                publishing: 'rm',
                list: [{key: 'gd', value: '广东'}, {key: 'gx', value: '广西'}],
                publishingList: [{key: 'rm', value: '人民出版社'}, {key: 'xh', value: '新华出版社'}],
                bookDescription: '',
                bookRecommendReason: '',

            }
        },

        methods: {

            check(){

            },


            submitBookInfo(){
                let _self = this;

                if (!_self.check()) {
                    return;
                }
                recommendBookLink({
                    bookName: _self.bookName,
                    author: _self.author,
                    publishing: _self.publishing,
                    bookCategory: _self.bookCategory,
                    bookDescription: _self.bookDescription,
                    bookRecommendReason: _self.bookRecommendReason
                }).then(data => {

                    if (data.success) {

                        this.$vux.confirm.show({
                            title: '提交成功',
                            content: '感谢您的推荐',
                            confirmText: '返回首页',
                            showCancelButton: false,

                            onCancel(){

                            },

                            onConfirm(){

                            }
                        })
                    }
                    else {
                        this.$vux.toast.text("请检查网络连接！");
                    }
                })
            }

        }
    }
</script>

<style lang="less">
    .recommend-books {
        .weui-cells {
            margin-top: 0px !important;
            font-size: 0.27rem;
        }
    }
</style>
