<template>
    <div class="recommend-list">
        <tab :line-width=2 v-model="tabIndex" active-color='#D0021B'>
            <tab-item class="vux-center" :selected="booksListSelected === item"
                      v-for="(item, tabIndex) in booksTitleList"
                      @click.native="booksListSelectedItem(tabIndex)"
                      :key="tabIndex">{{item}}
            </tab-item>
        </tab>
        <div v-infinite-scroll="loadBooks" infinite-scroll-disabled="busy" infinite-scroll-distance="20">
            <div class="recommend-list-cover" v-for="(book,scrollIndex) in booksList" :key="scrollIndex"
                 v-if="booksList.length > 0">
                <div :link="'/recommend/' + book.bookId">
                    <img :src="book.bookImg | imgPath"/>
                    <div>
                        <h5>{{book.bookTitle}}</h5>
                        <p class="recommend-list-author">
                            <span>作者:{{book.bookAuthor}}</span><span>出版社:{{book.bookPubilsh}}</span>
                        </p>
                        <p class="recommend-list-content" style="font-size: 10px;">{{book.bookDescription}}</p>
                    </div>
                </div>
            </div>
            <loading></loading>
        </div>
        <div class="my-recommend" @click="toRecommend('./recommendBooks')">
            我要推荐
        </div>
    </div>
</template>

<script>
    import{Tab, TabItem, XButton} from 'vux'
    import loading from '../../components/common/loading.vue'
    import{getBooksDetail} from '../../api/api'

    const booksTitleList = () => ['全部收藏', '我的推荐', '党史党章', '党建工作', '三会一课', '两学一做'];

    export default {

        components: {
            Tab,
            TabItem,
            XButton,
            loading
        },

        data () {
            return {

                booksListSelected: '我的推荐',
                booksTitleList: booksTitleList(),
                tabIndex: 0,
                scrollIndex: 0,
                booksList: [
                    {
                        bookId: 1,
                        bookImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                        bookTitle: '红色起点',
                        bookAuthor: '二狗子',
                        bookPubilsh: '一家牛逼出版社',
                        bookDescription: '哈哈哈哈哈哈哈哈哈哈哈'
                    },
                    {
                        bookId: 2,
                        bookImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                        bookTitle: '红色起点',
                        bookAuthor: '二狗子',
                        bookPubilsh: '一家牛逼出版社',
                        bookDescription: '哈哈哈哈哈哈哈哈哈哈哈'
                    },
                    {
                        bookId: 3,
                        bookImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                        bookTitle: '红色起点',
                        bookAuthor: '二狗子',
                        bookPubilsh: '一家牛逼出版社',
                        bookDescription: '哈哈哈哈哈哈哈哈哈哈哈'
                    },
                    {
                        bookId: 4,
                        bookImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                        bookTitle: '红色起点',
                        bookAuthor: '二狗子',
                        bookPubilsh: '一家牛逼出版社',
                        bookDescription: '哈哈哈哈哈哈哈哈哈哈哈'
                    },
                    {
                        bookId: 5,
                        bookImg: 'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',
                        bookTitle: '红色起点',
                        bookAuthor: '二狗子',
                        bookPubilsh: '一家牛逼出版社',
                        bookDescription: '哈哈哈哈哈哈哈哈哈哈哈'
                    },
                ],
                busy: false,
                pageNo: 1,
                size: 5,
                totalPage: 1,
            }
        },

        methods: {
            toRecommend: function (url) {
                this.$router.push(url)
            },

            booksListSelectedItem(tabIndex){

            },


            initBooksList: function () {
                let _self = this;
                getBooksDetail({curPage: _self.pageNo, bookId: _self.bookId, book: 'flag'}).then((response) => {
                    console.log(response);
                    $(".load-more").hide();
                    if (response.success) {
                        _self.booksList = _self.booksList.concat(response.data.page.rows);
                        _self.totalPage = response.data.page.pageCount;
                        _self.pageNo++;
                        _self.busy = false;
                    } else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }).catch((error) => {
                    $(".load-more").hide()
                })
            },

            loadBooks: function () {
                if (this.pageNo > this.totalPage || this.busy) {
                    this.busy = true;

                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initBooksList();
            },
        },

    }
</script>

<style lang="less">

    .recommend-list {

        background-color: #FFFFFF;

        .my-recommend {
            position: fixed;
            bottom: 0px;
            height: 1.0rem;
            width: 100%;
            text-align: center;
            line-height: 1.0rem;
            font-size: 0.2rem;
            color: white;
            background: #cf1814;
        }

        .recommend-list-cover {
            height: 2rem;
            padding: 14px 10px 0px 10px;
            img {
                float: left;
                width: 70px;
                height: 96px;
                margin-right: 5px;
            }
        }
        .recommend-list-title {
            font-size: 14px;
        }
        .recommend-list-author {
            margin: 8px 0px 10px 0px;
            font-size: 10px;

            span {
                margin-right: 12px;
            }
        }

        .recommend-list-content {
            font-size: 10px;
        }
    }
</style>
