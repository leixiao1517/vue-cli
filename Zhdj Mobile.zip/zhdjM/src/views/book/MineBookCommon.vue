<template>
    <section class="mine-book-list">
        <span @click="toBookList">我的书架</span>
    </section>
</template>

<script>
    export default {
        data () {
            return {}
        },
        methods: {
            toBookList: function () {
                this.$router.push("/mineBookList")
            }
        },
    }
</script>

<style lang="less">

    .mine-book-list {
        height: 1.3rem;
        width: 1.3rem;
        border-radius: 50%;
        color: white;
        background-color: #4A90E2;
        color: #FFFFFF;
    }

    .mine-book-list > span {
        display: inline-block;
        height: 0.7rem;
        width: 0.7rem;
        font-size: 0.3rem;
        line-height: 0.4rem;
        text-align: center;
        margin-top: 0.25rem;
        margin-left: 0.3rem;
    }

</style>
