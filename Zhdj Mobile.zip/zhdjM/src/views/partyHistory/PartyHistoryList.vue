<template>
    <section>
        <section style="height: 44px">
            <search
            v-model="searchVal"
            position="absolute"
            auto-scroll-to-top
            top="44px"
            @on-focus="onFocus"
            @on-cancel="onCancel"
            @on-submit="onSubmit"
            ref="search"></search>
        </section>

        <section>
            <div v-infinite-scroll="loadPartyHistory" infinite-scroll-disabled="busy"
                 infinite-scroll-distance="10">
                <template v-if="partyHistoryList.length>0">

                    <comm-item @click.native="toResourceDetail('/ResourceDetail',scrollIndex)"
                               v-for="(partyHistory,scrollIndex) in partyHistoryList" :key="scrollIndex"

                               :imgSrc="partyHistory.videoImg"
                               :type="partyHistory.zyType"
                               :info1="partyHistory.title"
                               :info2="partyHistory.userName"
                               :info3="partyHistory.partyName"
                               :info4="partyHistory.modifyDate | dateFormat('YMD')">
                        <input :id="'partyHistory' + scrollIndex" type="hidden" :value="partyHistory.docType"/>
                        <input :id="'vid' + scrollIndex" type="hidden" :value="partyHistory.vid"/>
                    </comm-item>

                    <loading></loading>
                </template>
                <div class="no-data" v-if="partyHistoryList.length==0"><p>没有数据</p></div>
            </div>

        </section>

    </section>
</template>

<script>
    import{getResourceList} from '../../api/api'
    import {Search} from 'vux'
    import loading from '../../components/common/loading.vue'
    import commItem from '../../components/common/commItem1.vue'
    import $ from 'jquery'

    export default {

        components: {

            loading,
            Search,
            commItem
        },
        data () {
            return {
                partyHistoryList: [],
                tabDesc: '党史',
                curPage: 1,
                pageSize: 10,
                showSort: false,
                totalPage: 1,
                busy: false,
                searchVal:''
            }
        },

        methods: {

            toResourceDetail(url, scrollIndex){
                let type = $("#partyHistory" + scrollIndex).val();
                let vid = $("#vid" + scrollIndex).val();
                this.$router.push({path: url, query: {type: type, vid: vid}});
            },

            loadPartyHistory: function () {
                if (this.curPage > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initPartyHistoryList();
            },

            initPartyHistoryList: function () {
                let _self = this;
                $(".load-more").hide();

                getResourceList({
                    menu: '党史党章',
                    tabDesc: _self.tabDesc,
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.partyHistoryList = _self.partyHistoryList.concat(response.data.list);
                        _self.resourceCount = response.data.total;
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            },

            onFocus() {

            },
            onCancel() {
                console.log('cancelsearch '+this.searchVal)
            },
            onSubmit() {
                this.$refs.search.setBlur()

                let _self = this;
                _self.curPage = 1;
                getResourceList({
                    searchKey: _self.searchVal,
                    menu: '党史党章',
                    tabDesc: _self.tabDesc,
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.partyHistoryList = response.data.list;
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false;
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))


            }
        },

    }
</script>

<style lang="less">
    .party-history-list {
    }
</style>
