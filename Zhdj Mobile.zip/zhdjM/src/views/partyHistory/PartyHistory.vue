<template>
    <div class="party-history">
        <section>
            <tab :line-width=2 active-color='#D0021B'>
                <tab-item class="vux-center" :selected="partyHistorySelected === PartyHistoryItem"
                          v-for="(PartyHistoryItem, index) in partyHistoryTitleList"
                          @on-item-click="PartyHistorySelectedItem"
                          :key="index">{{PartyHistoryItem}}
                </tab-item>
            </tab>
            <div class="party-history-router">
                <router-view></router-view>
            </div>
        </section>
    </div>
</template>

<script>
    import $ from 'jquery'
    import {Tab, TabItem} from 'vux'

    export default {
        name: 'library',

        components: {
            Tab,
            TabItem,
        },
        data () {
            return {
                partyHistorySelected: '党史',
                partyHistoryTitleList: ['党史', '党章'],

            }
        },

        methods: {

            PartyHistorySelectedItem: function (index) {
                if (index === 0) {
                    this.$router.replace('/PartyHistory')
                }

                if (index === 1) {
                    this.$router.replace('/PartyConstitutionList')
                }
            },

        },

        mounted(){
            let routeName = this.$route.name;
            console.log("mounted=" + routeName);

            if (routeName == 'PartyHistoryList') {
                this.partyHistorySelected = '党史'
            } else if (routeName == 'PartyConstitutionList') {
                this.partyHistorySelected = '党章'
            }
        },

    }
</script>


<style lang="less">

    .party-history {

        .party-history-router {
            height: 11.4rem;
        }

    }
</style>

