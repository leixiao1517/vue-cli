<template>
    <section>
        <section style="height: 44px">
            <search
                v-model="searchVal"
                position="absolute"
                auto-scroll-to-top
                top="44px"
                @on-focus="onFocus"
                @on-cancel="onCancel"
                @on-submit="onSubmit"
                ref="search"></search>
        </section>
        <section>
            <div v-infinite-scroll="loadPartyConstitution" infinite-scroll-disabled="busy"
                 infinite-scroll-distance="10">
                <template v-if="partyConstitutionList.length>0">

                    <comm-item @click.native="toResourceDetail('/ResourceDetail',scrollIndex)"
                               v-for="(partyConstitution,scrollIndex) in partyConstitutionList" :key="scrollIndex"

                               :imgSrc="partyConstitution.videoImg"
                               :type="partyConstitution.zyType"
                               :info1="partyConstitution.title"
                               :info2="partyConstitution.userName"
                               :info3="partyConstitution.partyName"
                               :info4="partyConstitution.modifyDate | dateFormat('YMD')">
                        <input :id="'partyConstitution' + scrollIndex" type="hidden"
                               :value="partyConstitution.docType"/>
                        <input :id="'vid' + scrollIndex" type="hidden" :value="partyConstitution.vid"/>
                    </comm-item>
                    <loading></loading>
                </template>
                <div class="no-data" v-if="partyConstitutionList.length==0"><p>没有数据</p></div>
            </div>
        </section>

    </section>
</template>
<script>
    import{getResourceList} from '../../api/api'
    import {Search} from 'vux'
    import loading from '../../components/common/loading.vue'
    import $ from 'jquery'
    import commItem from '../../components/common/commItem1.vue'

    export default {

        components: {
            loading,
            Search,
            commItem
        },
        data () {
            return {
                partyConstitutionList: [],
                tabDesc: '党章',
                curPage: 1,
                pageSize: 10,
                busy: false,
                totalPage: 1,
                searchVal: ''

            }
        },

        methods: {

            toResourceDetail(url, scrollIndex){
                let type = $("#partyConstitution" + scrollIndex).val();
                let vid = $("#vid" + scrollIndex).val();
                this.$router.push({path: url, query: {type: type, vid: vid}});
            },

            loadPartyConstitution: function () {
                if (this.curPage > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initPartyConstitutionList();
            },

            initPartyConstitutionList: function () {
                let _self = this;
                $(".load-more").hide();
                getResourceList({
                    menu: '党史党章',
                    tabDesc: _self.tabDesc,
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.partyConstitutionList = _self.partyConstitutionList.concat(response.data.list);
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            },


            onFocus() {

            },
            onCancel() {
                console.log('cancelsearch ' + this.searchVal)
            },
            onSubmit() {
                this.$refs.search.setBlur()

                let _self = this;
                _self.curPage = 1;
                getResourceList({
                    searchKey: _self.searchVal,
                    menu: '党史党章',
                    tabDesc: _self.tabDesc,
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.partyConstitutionList = response.data.list;
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false;
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))


            }

        },

    }
</script>

<style lang="less">
    .party-constitution-list {
    }

</style>
