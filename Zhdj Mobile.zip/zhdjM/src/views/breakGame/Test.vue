<!--起始页开始-->
<template>

    <section class="test">

            <button class="beginTime" @click="timeRun">开始计时</button>
            <p> {{ t }}</p>
            <button class="stopTime" @click="timeStop">停止计时</button>
    </section>

</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import { Badge  } from 'vux'
    import { mobileClient } from '../../config/config'

    export default {
        components: {

        },
        data() {
            return {
                t:'',
                s:'',
                m:'',
                runid:undefined
            }
        },
        methods: {
            toUrl: function (enterUrl) {
                this.$router.push("/" + enterUrl)
            },


            timeRun: function (){
                let self = this;
                let s = 0;
                let m = 0;
                self.runid = setInterval(function(){
                    s += 1;
                    if (s > 0 && (s % 60) == 0) {
                        m += 1;
                        s = 0;
                    }
//                    console.log(s);
                    self.t = m + "分" + s + "秒";
                    }, 1000);

            },
            timeStop:function(){
                clearInterval(this.runid);
            }
//            timeStop:function(){
//                clearInterval(run);
//            }

//                console.log(s);
//                var t = m + "分" + s + "秒"
//                console.log(t);
//                return t;


//                let days = parseInt(_self.startDifference / (1000 * 60 * 60 * 24));
//                let hours = parseInt((_self.startDifference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
//                let minutes = parseInt((_self.startDifference % (1000 * 60 * 60)) / (1000 * 60));
//                let moreTime = days + " 天 " + hours + " 小时 " + minutes + " 分";
//                console.log(moreTime);
//                _self.moreTime = moreTime;
//            if (s > 0 && (s % 60) == 0) {
//        m += 1;
//        s = 0;
//    }

        },

    mounted() {
//        console.log(colorListLength)

        }
    }
</script>

<style lang="less">


    .test{


    }

</style>




