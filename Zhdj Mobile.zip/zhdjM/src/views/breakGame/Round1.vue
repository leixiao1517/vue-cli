<!--起始页开始-->
<template>

    <section class="firstStage">
        <div id="swiper1" class="swiper-container1 round1Window">
            <div class="swiper-wrapper firstWindow">
                <!-- 第一页 -->
                <div class="swiper-slide stage1Bg1"  :style="{width:'100%',backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/gameRound/01.gif)'}">

                </div>
                <!-- 第二页 -->
                <div class="swiper-slide stage1Bg2"  :style="{width:'100%',backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/gameRound/02.gif)'}">

                </div>
                <!-- 第三页 -->
                <div class="swiper-slide stage1Bg3" :style="{width:'100%',backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/gameRound/03.gif)'}">
                    <button class="alertR1" @click="openAlertR1"></button>

                </div>
                <div class="swiper-pagination"></div>

            </div>

            <div class="showAlertR1">

                <!--确认开始答题-->
                <div class="alertStatus answerR1Begin" :style="{backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/gameRound/beginAnswer.png)'}">
                    <!--内部答题确认弹窗-->
                    <div class="statusBox inSide">
                        <h5>答题开始确认</h5>
                        <b class="centerText">本关共10题，正确率≥80%即进入下一关，否则需重新闯关。确定开启本关？</b>
                    <div class="readyBottom" @click="gameBeginInSide"><span>确定</span></div>
                    </div>
                    <!--=====================-->
                    <!--外部答题确认弹窗-->
                    <div class="statusBox outSide">
                        <h5>答题开始确认</h5>
                        <b class="centerText">本关共3题，全部答对才能获取闯关装备，否则直接进入下一关。确定开启本关？</b>
                        <div class="readyBottom" @click="gameBeginOutSide"><span>确定</span></div>
                    </div>
                    <!--=====================-->

                    <img src="../../assets/images/gameRound/closeWindow.png" class="closeWindow" @click="closeAlertR1"/>
                </div>

                <!--答题闯关成功-->
                <div class="alertStatus answerR1Success" :style="{display:'none',backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/gameRound/beginAnswer.png)'}">
                    <!--内部答题成功8-10题-->
                    <div class="statusBox inSide">
                        <h5>恭喜您！闯关成功！</h5>
                        <b class="centerText">成为一名光荣的劳动者</b>
                        <h4><i>答对:{{ this.correctR1 }}题</i></h4>
                        <b class="centerText">接下来您将进入<i style="font-weight:bold">改革开放时期</i></b>
                        <div class="readyBottom" @click="nextRound"><span>继续闯关</span></div>
                    </div>
                    <!--===========================-->
                    <!--外部答题没有答对3题-->
                    <div class="statusBox outSide">
                        <h5>很遗憾!</h5>
                        <h4><i>未全部答对，已失去获取闯关装备资格</i></h4>
                        <b class="centerText">接下来您将进入<i style="font-weight:bold">改革开放时期</i></b>
                        <div class="readyBottom" @click="nextRound"><span>继续闯关</span></div>
                    </div>
                    <!--===========================-->
                </div>

                <!--答题闯关失败-->
                <div class="alertStatus answerR1Fail" :style="{display:'none',backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/gameRound/beginAnswer.png)'}">
                    <div class="statusBox">
                        <h5>很遗憾，闯关失败！</h5>
                        <h4><i>答对:{{ this.correctR1 }}题</i></h4>
                        <b class="centerText">正确率不足80%，好好学习，天天向上</b>
                        <div class="readyBottom" @click="toUrl('gameStart')"><span>重新闯关</span></div>
                    </div>
                </div>

                <!--完美答题(100%)-->
                <div class="alertStatus answerR1Perfect" :style="{display:'none',backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/gameRound/beginAnswer.png)'}">
                    <!--内部完美答题弹窗-->
                    <div class="statusBox inSide">
                        <h5>恭喜您！闯关成功！</h5>
                        <b class="centerText">成为一名光荣的劳动者</b>
                        <h4><i>答对:{{ this.correctR1 }}题</i></h4>
                        <b class="centerText">全部正确，可进入和+生态圈获取装备</b>
                        <div class="readyBottom" @click="getEquipment"><span>获取装备</span></div>
                    </div>
                    <!--====================-->
                    <!--外部完美答题弹窗 3题-->
                    <div class="statusBox outSide">
                        <h5>恭喜您！闯关成功！</h5>
                        <b class="centerText">成为一名光荣的劳动者</b>
                        <b class="centerText">全部正确，可进入和+生态圈获取装备</b>
                        <div class="readyBottom" @click="getEquipment"><span>获取装备</span></div>
                    </div>
                    <!--====================-->
                </div>

                <!--答题环节部分-->
                    <!--内部答题环节弹窗-->
                <div class="contentAlert inSideQuestion">
                    <div class="questionTop">
                        <b class="questionNur" >第 {{ curIndexR1 + 1 }} / 10 题</b>
                        <b class="timer">{{ t1 }}</b>
                        <img src="../../assets/images/gameRound/timeIcon.png"/>
                    </div>
                    <div class="questionCenter">
                        <b>{{ curContentR1.title }}</b>
                        <div class="answerList" style="margin-top:0.3rem;" @click="nextTitle(1)" v-if="curContentR1.optionA != null"><span>A.{{ curContentR1.optionA }}</span></div>
                        <div class="answerList" style="margin-top:0.3rem;" @click="nextTitle(2)" v-if="curContentR1.optionB != null"><span>B.{{ curContentR1.optionB }}</span></div>
                        <div class="answerList" style="margin-top:0.3rem;" @click="nextTitle(3)" v-if="curContentR1.optionC != null"><span>C.{{ curContentR1.optionC }}</span></div>
                    </div>
                    <div class="questionBottom">
                        <div style="padding-top:0.3rem"></div>
                        <div class="answerList" @click="nextTitle(4)" v-if="curContentR1.optionD != null"><span>D.{{ curContentR1.optionD }}</span></div>
                    </div>
                        <img src="../../assets/images/gameRound/round1Title.png" class="roundTitle"/>
                </div>
                    <!--=======================-->
                    <!--外部答题环节弹窗-->
                <div class="contentAlert outSideQuestion">
                    <div class="questionTop">
                        <b class="questionNur" >第 {{ curIndexR1 + 1 }} / 3 题</b>
                        <b class="timer">{{ t1 }}</b>
                        <img src="../../assets/images/gameRound/timeIcon.png"/>
                    </div>
                    <div class="questionCenter">
                        <b>{{ curContentR1.title }}</b>
                        <div class="answerList" style="margin-top:0.3rem;" @click="nextTitle(1)" v-if="curContentR1.optionA != null"><span>A.{{ curContentR1.optionA }}</span></div>
                        <div class="answerList" style="margin-top:0.3rem;" @click="nextTitle(2)" v-if="curContentR1.optionB != null"><span>B.{{ curContentR1.optionB }}</span></div>
                        <div class="answerList" style="margin-top:0.3rem;" @click="nextTitle(3)" v-if="curContentR1.optionC != null"><span>C.{{ curContentR1.optionC }}</span></div>
                    </div>
                    <div class="questionBottom">
                        <div style="padding-top:0.3rem"></div>
                        <div class="answerList" @click="nextTitle(4)" v-if="curContentR1.optionD != null"><span>D.{{ curContentR1.optionD }}</span></div>
                    </div>
                    <img src="../../assets/images/gameRound/round1Title.png" class="roundTitle"/>
                </div>
                    <!--======================-->
            </div>

        </div>


    </section>

</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import { Badge  } from 'vux'
    import { imageRootPath } from '../../config/config'
//    import Swiper from 'swiper';
    import Swiper from '../../../static/zhongyan/zhdj/breakgame/swiper-4.3.3.min'
    import {stageCommit} from '../../api/api'
    export default {
        components: {

        },
        props:['inner'],
        data () {
            return {
                swiper1:{},
                t1:'00:00',
                spendT1:'',
                s:'',
                m:'',
                runid:undefined,
                topicContentR1:['title','optionA','optionB','optionC','optionD'],
                qList:[],
                curContentR1:{},
                curIndexR1:0,
                correctR1:0,
                X:'',
                checkGetEquipmentR1:'',
                s1:'',
                second1:'',
                add:'',
                imageRootPath

            }
        },
        methods: {
            toUrl:function(enterUrl){
                this.$router.push("/" + enterUrl);
            },
            openAlertR1:function(){
                $(".allowUp").css("display","none");
                $(".showAlertR1").fadeIn();
                this.swiper1.allowSlidePrev= false;
                this.swiper1.allowSlideNext= false;
                sessionStorage.removeItem("checkGetEquipmentR1");
                sessionStorage.removeItem("checkGetEquipmentR2");
                sessionStorage.removeItem("checkGetEquipmentR3");
                //父子组件传参方法
//                if (this.inner == 0){
//                    $('.inSide').css("display","block");
//                }else if (this.inner == 1){
//                    $('.outSide').css("display",'block');
//                }

            },
            gameBeginInSide:function(){
                $(".answerR1Begin").css("display","none");
                $(".inSideQuestion").css("display","block");

                //added by xiaohan below
                this.$emit('startTimer', 'round1');
                //added by xiaohan above
            },
            gameBeginOutSide:function(){
                $(".answerR1Begin").css("display","none");
                $(".outSideQuestion").css("display","block");

                //added by xiaohan below
                this.$emit('startTimer', 'round1');
                //added by xiaohan above
            },
            //added by xiaohan below
            setTimeText: function(str){
                this.t1 = str;
            },

            setQuestionList:function(qList){
                this.qList = qList;
                this.curContentR1 = this.qList[this.curIndexR1];

            },
            //added by xiaohan above

            closeAlertR1:function(){
                $(".answerR1Begin").css("display","block");
                $(".contentAlert").css("display","none");
                $(".showAlertR1").css("display","none")
                this.swiper1.allowSlidePrev= true;
                this.swiper1.allowSlideNext= true;

            },
            nextRound:function(){
                $(".showAlertR1").fadeOut();
                $(".allowUp").css("display", "block");
                let round1 = $(".round1").height();
                $(".round1").animate({marginTop: (-1 * Round1) + 'px'},500,"linear", function() {
                    $(this).hide()
                });
//                console.log("t1:"+this.t1);
            },
            nextTitle: function (X) {
                let _self = this;
                if (X == this.curContentR1.answer) {
                    this.correctR1++;
//                    console.log("正确回答个数", this.correctR1 + "个");
                }
                if (this.innerStatus == 0) {
                    if (this.curIndexR1 < 9) {
                        this.curIndexR1++;
                        this.curContentR1 = _self.qList[this.curIndexR1];
                    }
                    else if (this.curIndexR1 == 9) {
                        //停止计时器
                        this.$emit('pauseTimer');
                        if (this.correctR1 < 8) {
                            $('.answerR1Fail').css('display', 'block');
                            $('.contentAlert').css('display', 'none');
                        }
                        else if (this.correctR1 >= 8 && this.correctR1 < 10) {
                            $('.answerR1Success').css('display', 'block');
                            $('.contentAlert').css('display', 'none');
                            $('.equipmentType1').css("z-index", "-100");
                            $('.equipmentType1Fail').css("z-index", "-100");
                            $(".luckBegin1").css("display", "none");
                            this.$emit('addCorrectNum', _self.correctR1);
                        }
                        else if (this.correctR1 >= 10) {
                            $('.answerR1Perfect').css('display', 'block');
                            $('.contentAlert').css('display', 'none');
                            this.$emit('addCorrectNum', _self.correctR1);
                        }
                    }
                }
                if (this.innerStatus == 1){
                        if (this.curIndexR1 < 2 ) {
                            this.curIndexR1++;
                            this.curContentR1 = _self.qList[this.curIndexR1];
                        }
                        else if (this.curIndexR1 == 2) {
                            //停止计时器
                            this.$emit('pauseTimer');
                            if (this.correctR1 >= 0 && this.correctR1 < 3) {
                                $('.answerR1Success').css('display', 'block');
                                $('.contentAlert').css('display', 'none');
                                $('.equipmentType1').css("z-index", "-100");
                                $('.equipmentType1Fail').css("z-index", "-100");
                                $(".luckBegin1").css("display", "none");
                                this.$emit('addCorrectNum', _self.correctR1);
                            }
                            else if (this.correctR1 >= 3) {
                                $('.answerR1Perfect').css('display', 'block');
                                $('.contentAlert').css('display', 'none');
                                this.$emit('addCorrectNum', _self.correctR1);
                            }
                        }
//                        console.log("curIndexR1:"+this.curIndexR1);
                    }
                },
            getEquipment:function(){
                $(".showAlertR1").css("display","none");
                $(".luckRoundBox").css("display","block");

                // 刷新gif
                this.$emit('refreshLuckRound')

                let _self = this;
                stageCommit({eid:1}).then((response) => {
//                    console.log(response);
                    _self.checkGetEquipmentR1 = response.data.add;
                    _self.firstFlag = response.data.first;
                    sessionStorage.setItem('checkGetEquipmentR1', _self.checkGetEquipmentR1);
                    sessionStorage.setItem('firstFlag', _self.firstFlag);
                    if(response.success){
                    } else {
                        this.$vux.toast.text(response.message, 'middle');
                    }
                });
            },
        },
        mounted() {
            //本地存储调取数据判断内外版本
            let _self = this;
            _self.innerStatus = sessionStorage.getItem('inner');
            _self.swiper1 = new Swiper('.round1Window', {
                direction: 'vertical',
                allowSlidePrev: true,
                allowSlideNext: true,
                height: $(window).height(),
                on:{

                }
            });
            _self.swiper1.on('slideChange', function(){
                let ind = _self.swiper1.activeIndex
                if (ind == 2){
                    $(".allowUp").hide()
                } else {
                    $(".allowUp").show()
                }
            });


            $(".round1Window,.background").height($(window).height());

//            console.log("innerStatus:"+this.innerStatus);
            if (_self.innerStatus == 0){
                $('.inSide').css("display","block");
            }else if(_self.innerStatus == 1){
                $('.outSide').css("display",'block');
            }

        }

    }

</script>

<style lang="less">

    .firstStage{

        position:relative;

        .swiper-wrapper{
            width:100%;
        }
        .stage1Bg1{
            /*background:url(../../assets/images/gameRound/01.gif) no-repeat;*/
            background-repeat: no-repeat;
            background-size:cover;
            width:100%;
        }
        .stage1Bg2{
            /*background:url(../../assets/images/gameRound/02.gif) no-repeat;*/
            background-repeat: no-repeat;
            background-size:cover;
            width:100%;
        }
        .stage1Bg3{
            /*background:url(../../assets/images/gameRound/03.gif) no-repeat;*/
            background-repeat: no-repeat;
            background-size:cover;
            width:100%;
        }
        .showAlertR1{
            display:none;
            position:fixed;
            background-color:rgba(0,0,0,0.8);
            bottom:0;
            top:0;
            left:0;
            z-index:999;
            width:100%;
        }
        .contentAlert{
            height:100%;
            width:7rem;
            margin:0 auto;
            padding-top:1.3rem;
            z-index:200;
            position:relative;
            display:none;
        }
        .alertR1{
            position: absolute;
            top:38%;
            left:2.7rem;
            z-index:100;
            height:2.5rem;
            width:2.5rem;
            opacity: 0;
        }
    }

</style>
