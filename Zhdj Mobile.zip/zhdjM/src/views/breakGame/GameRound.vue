<!--起始页开始-->
<template>

    <section class="gameRound">

        <div class="swiper-container roundWindow">
            <div class="swiper-wrapper allround">

                <div class="swiper-slide round1">
                    <round1 ref="round1" @startTimer="startTimer"  @refreshLuckRound="refreshLuckRound" @pauseTimer="pauseTimer" @addCorrectNum="addCorrectNum"
                            :inner=inner></round1>
                </div>

                <div class="swiper-slide round2">
                    <round2 ref="round2" @startTimer="startTimer"  @refreshLuckRound="refreshLuckRound" @pauseTimer="pauseTimer" @addCorrectNum="addCorrectNum"
                            :inner=inner></round2>
                </div>

                <div class="swiper-slide round3">
                    <round3 ref="round3" @startTimer="startTimer"  @refreshLuckRound="refreshLuckRound" @pauseTimer="pauseTimer" @addCorrectNum="addCorrectNum"
                            @reportResult="reportResult" :totalCorrectNum=correctNum :inner=inner></round3>
                </div>

                <div class="swiper-pagination"></div>
            </div>
        </div>

        <div class="allowUp"></div>
        <div class="luckRoundBox">
            <luckRound  ref="luckRound"></luckRound>
        </div>

    </section>

</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import { Badge  } from 'vux'
    import { mobileClient } from '../../config/config'
    import  round1  from './Round1.vue'
    import  round2  from './Round2.vue'
    import  round3  from './Round3.vue'
    import  luckRound from './LuckRound.vue'
//    import  Swiper from 'swiper';
    import Swiper from '../../../static/zhongyan/zhdj/breakgame/swiper-4.3.3.min'
    import {gameQuestion, finish} from '../../api/api'


    export default {
        components: {
            round1,
            round2,
            round3,
            luckRound
        },
        data () {
            return {
                n: 0,
                timer: null,
                timeText: '',
                correctNum: 0,
                inner: 999,
            }
        },
        methods: {
            toUrl:function(enterUrl){
                this.$router.push("/" + enterUrl)
            },

            toDub: function (n) {
                return n < 10 ? "0" + n : "" + n;
            },

            startTimer: function (round) {
                let _self = this;
                clearInterval(_self.timer);
                _self.timer = setInterval(function () {
                    _self.n++;
                    var m = parseInt(_self.n / 60);
                    var s = parseInt(_self.n % 60);
                    _self.timeText = _self.toDub(m) + ":" + _self.toDub(s);

                    if (round == 'round1'){
                        _self.$refs.round1.setTimeText(_self.timeText);
                    }
                    else if(round == 'round2'){
                        _self.$refs.round2.setTimeText(_self.timeText);
                    }
                    else if(round == 'round3'){
                        _self.$refs.round3.setTimeText(_self.timeText);
                    }

                }, 1000);
            },
            pauseTimer: function () {
                let _self = this;
                sessionStorage.setItem('timeText', _self.timeText);
                clearInterval(_self.timer);
            },
            resetTimer: function () {
                let _self  = this;
                _self.timeTex = '';
                _self.n = 0;
            },

            addCorrectNum: function(num){
                this.correctNum += num;
            },

            reportResult: function () {
                let _self  = this;
                finish({useTime:_self.n * 1000, score:_self.correctNum}).then((response) => {

                })
            },
            refreshLuckRound: function () {//刷新子组件luckround img
                this.$refs.luckRound.refreshImg()
            }

        },
        mounted() {
            //stop audio
            let audio = this.GLOBAL.getAudioEle();
            audio.pause();

            $(".allround,.luckRoundBox").height($(window).height());

//            new Swiper('.roundWindow', {
//                loop: false,
//                paginationClickable: true,
//                direction: 'vertical',
//                pagination: '.roundWindow',
//                allowSlidePrev: false,
//                allowSlideNext: false,
//            })




            gameQuestion({}).then((response) => {
//                console.log(response);
                this.$refs.round1.setQuestionList(response.data.QuestionList1);
                this.$refs.round2.setQuestionList(response.data.QuestionList2);
                this.$refs.round3.setQuestionList(response.data.QuestionList3);
//                this.$refs.round1.getInnerR1(response.data.inner);
                this.inner = response.data.inner;

            })

        }


    }
</script>

<style lang="less">
    .gameRound{

        @import "../../assets/css/reset.css";
        @import "../../assets/css/swiper.min.css";


        .round1{
            width: 100%;
            .round2{display:none};
            .round3{display:none};
            .btn1{
                position: absolute;
                bottom: 60px;
                z-index:300;
            }
            background: #f5ecda;
        }
        .round2{
            width: 100%;
            position: relative;
            .btn2{
                position: absolute;
                bottom: 40px;
                z-index:300;
            }
            background: #f5ecda;
        }
        .round3{
            width: 100%;
            position: relative;
            /*button{*/
                /*position: absolute;*/
                /*bottom: 20px;*/
            /*}*/
            background: #f5ecda;
        }
        img{
            width:100%;
        }
        .allowUp{
            height:32px;
            width:24px;
            position:fixed;
            z-index:50;
            bottom:0.33rem;
            left:50%;
            margin-left: -12px;
            background:url(../../assets/images/gameRound/upArrow.png) center;
            background-size:23px 32px;
            animation: upFadeIn 1.5s infinite ease-in-out;

        }
        @-webkit-keyframes upFadeIn {
            0%,
            30% {opacity: 0;-webkit-transform: translate(0, 10px)
            }
            60% {opacity: 1;-webkit-transform: translate(0, 0)
            }
            100% {opacity: 0;-webkit-transform: translate(0, 0)
            }
        }
        @-moz-keyframes upFadeIn {
            0%,
            30% {opacity: 0;-moz-transform: translate(0, 10px)
            }
            60% {opacity: 1;-moz-transform: translate(0, 0)
            }
            100% {opacity: 0;-moz-transform: translate(0, 0)
            }
        }
        @-ms-keyframes upFadeIn {
            0%,
            30% {opacity: 0;-ms-transform: translate(0, 10px)
            }
            60% {opacity: 1;-ms-transform: translate(0, 0)
            }
            100% {opacity: 0;-ms-transform: translate(0, 0)
            }
        }
        @keyframes upFadeIn {
            0%,
            30% {opacity: 0;transform: translate(0, 10px)
            }
            60% {opacity: 1;transform: translate(0, 0)
            }
            100% {opacity: 0;transform: translate(0, 0)
            }
        }

        .questionTop{
            background:url(../../assets/images/gameRound/questionAlertTop.png) no-repeat;
            background-size:cover;
            width:7rem;
            height:0.8rem;
            position:relative;
        }
        .questionNur{
            position:absolute;
            top:0.3rem;
            left:0.5rem;
            font-size:0.30rem;
            line-height:0.5rem;
            color:#e61620;
        }
        .timer{
            position:absolute;
            top:0.3rem;
            right:0.5rem;
            font-size:0.30rem;
            line-height:0.5rem;
            color:#e61620;
        }
        .questionTop>img{
            position:absolute;
            top:0.35rem;
            right:1.65rem;
            height:0.35rem;
            width:0.35rem;
        }
        .questionCenter{
            background:url(../../assets/images/gameRound/questionAlertCenter.png) no-repeat;
            background-size:7rem 7rem;
            width:7rem;
            min-height:1rem;

        }
        .questionCenter>b{
            color:white;
            font-size:0.28rem;
            font-weight:normal;
            width:6rem;
            word-wrap:break-word;
            display:block;
            margin-left:0.5rem;
            padding-top:0.2rem;
            line-height:0.45rem;

        }
        .questionBottom{
            background:url(../../assets/images/gameRound/questionAlertbottom.png) no-repeat;
            background-size:100% 100%;
            width:7rem;
            height:2.3rem;

        }
        .answerList{
            display:block;
            width:6rem;
            margin-left:0.5rem;
            min-height:0.6rem;
            line-height:0.6rem;
            font-size:0.3rem;
            background-color:#eee0c0;
            border-radius:10px;
        }
        .answerList>span{
            width: 5.5rem;
            margin-left:0.25rem;
            display:block;
            font-size:0.27rem;
        }
        .roundTitle{
            position:absolute;
            top: 0.75rem;
            left: 2rem;
            /*height: 0.8rem;*/
            width: 3rem;
        }
        .closeWindow{
            position:absolute;
            top:0;
            right: 0.1rem;
            width:0.5rem;
        }
        .alertStatus{
            position:relative;
            width:7rem;
            height:5.2rem;
            /*background:url(../../assets/images/gameRound/beginAnswer.png) no-repeat;*/
            background-repeat: no-repeat;
            background-size:cover;
            display:block;
            margin:2.7rem auto;
        }
        .statusBox{
            position:relative;
            top:1.3rem;
            width:6.3rem;
            height:3.6rem;
            margin-left:0.35rem;
        }
        .centerText{
            width:5.8rem;
            font-size:0.3rem;
            font-weight:normal;
            color:white;
            text-align:center;
            display:block;
            margin:0.1rem auto;
        }
        .readyBottom{
            position:absolute;
            background:url(../../assets/images/gameRound/btnImg.png) no-repeat;
            background-size:2.4rem 0.7rem;
            top:2.9rem;
            left:1.95rem;
            height:0.7rem;
            width:2.4rem;
        }
        .readyBottom>span{
            height:0.7rem;
            width:2.4rem;
            display:block;
            line-height:0.7rem;
            text-align:center;
            font-size:16px;
            color:#dc202a;
        }
        .statusBox>h5{
            width: 5.4rem;
            text-align:center;
            height:0.7rem;
            font-size:0.38rem;
            margin:0.1rem auto;
            color:white;
            line-height:0.7rem;
            font-weight:normal;
        }
        .statusBox>h4{
            margin: 0.1rem auto;
            color: white;
            font-size: 0.33rem;
            text-align: center;
            font-weight:normal;
        }
        .luckRoundBox{
            display:none;
            width:100%;
            position:fixed;
            top:0;
            left:0;
            z-index:999;
        }
        .inSide{
            display:none;
        }
        .outSide{
            display:none;
        }



    }

</style>
