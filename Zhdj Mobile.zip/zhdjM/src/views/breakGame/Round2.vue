<!--起始页开始-->
<template>

    <section class="secondStage">
        <div id="swiper2" class="swiper-container round2Window">
            <div class="swiper-wrapper secondWindow">
                <!-- 第一页 -->
                <div class="swiper-slide stage2Bg1"  :style="{width:'100%',backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/gameRound/04.gif)'}">

                </div>
                <!-- 第二页 -->
                <div class="swiper-slide stage2Bg2"  :style="{width:'100%',backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/gameRound/05.gif)'}">

                </div>
                <!-- 第三页 -->
                <div class="swiper-slide stage2Bg3"  :style="{width:'100%',backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/gameRound/06.gif)'}">
                    <button class="alertR2" @click="openAlertR2"></button>

                </div>
                <div class="swiper-pagination"></div>
            </div>
            <div class="showAlertR2">
                <!--确认开始答题-->
                <div class="alertStatus answerR2Begin" :style="{backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/gameRound/beginAnswer.png)'}">
                    <!--=================================-->
                    <div class="statusBox inSide">
                        <h5>答题开始确认</h5>
                        <b class="centerText">本关共10题，正确率≥80%即进入下一关，否则需重新闯关。确定开启本关？</b>
                        <div class="readyBottom" @click="gameBeginInSide"><span>确定</span></div>
                    </div>
                    <!--=================================-->
                    <div class="statusBox outSide">
                        <h5>答题开始确认</h5>
                        <b class="centerText">本关共3题，全部答对才能获取闯关装备，否则直接进入下一关。确定开启本关？</b>
                        <div class="readyBottom" @click="gameBeginOutSide"><span>确定</span></div>
                    </div>
                    <!--===============================-->
                    <img src="../../assets/images/gameRound/closeWindow.png" class="closeWindow" @click="closeAlertR2"/>
                </div>

                <!--答题闯关成功-->
                <div class="alertStatus answerR2Success" :style="{display:'none',backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/gameRound/beginAnswer.png)'}">

                    <!--===============================-->
                    <div class="statusBox inSide">
                        <h5>恭喜您！闯关成功！</h5>
                        <b class="centerText">远超录取线，进入天下和书院深造</b>
                        <h4><i>答对:{{ this.correctR2 }}题</i></h4>
                        <b class="centerText">接下来您将进入<i style="font-weight:bold">走进新时代</i></b>
                        <div class="readyBottom" @click="nextRound"><span>继续闯关</span></div>
                    </div>
                    <!--================================-->
                    <div class="statusBox outSide">
                        <h5>很遗憾!</h5>
                        <h4><i>未全部答对，已失去获取闯关装备资格</i></h4>
                        <b class="centerText">接下来您将进入<i style="font-weight:bold">走进新时代</i></b>
                        <div class="readyBottom" @click="nextRound"><span>继续闯关</span></div>
                    </div>
                    <!--================================-->
                </div>

                <!--答题闯关失败-->
                <div class="alertStatus answerR2Fail" :style="{display:'none',backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/gameRound/beginAnswer.png)'}">
                    <div class="statusBox">
                        <h5>很遗憾，闯关失败！</h5>
                        <h4><i>答对:{{ this.correctR2 }}题</i></h4>
                        <b class="centerText">正确率不足80%，好好学习，天天向上</b>
                        <div class="readyBottom" @click="toUrl('gameStart')"><span>重新闯关</span></div>
                    </div>
                </div>

                <!--完美答题(100%)-->
                <div class="alertStatus answerR2Perfect" :style="{display:'none',backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/gameRound/beginAnswer.png)'}">
                    <!--=======================================-->
                    <div class="statusBox inSide">
                        <h5>恭喜您！闯关成功！</h5>
                        <b class="centerText">远超录取线，进入天下和书院深造</b>
                        <h4><i>答对:{{ this.correctR2 }}题</i></h4>
                        <b class="centerText">全部正确，可进入和+生态圈获取装备</b>
                        <div class="readyBottom" @click="getEquipment"><span>获取装备</span></div>
                    </div>
                    <!--=======================================-->
                    <div class="statusBox outSide">
                        <h5>恭喜您！闯关成功！</h5>
                        <b class="centerText">远超录取线，进入天下和书院深造</b>
                        <b class="centerText">全部正确，可进入和+生态圈获取装备</b>
                        <div class="readyBottom" @click="getEquipment"><span>获取装备</span></div>
                    </div>
                    <!--=========================================-->
                </div>

                <!--===========================-->
                <div class="contentAlert inSideQuestion">
                    <div class="questionTop">
                        <b class="questionNur">第 {{ curIndexR2 + 1 }} / 10 题</b>
                        <b class="timer">{{ t2 }}</b>
                        <img src="../../assets/images/gameRound/timeIcon.png"/>
                    </div>
                    <div class="questionCenter">
                        <b>{{ curContentR2.title }}</b>
                        <div class="answerList" style="margin-top:0.3rem;" @click="nextTitle(1)" v-if="curContentR2.optionA != null"><span>A.{{ curContentR2.optionA }}</span></div>
                        <div class="answerList" style="margin-top:0.3rem;" @click="nextTitle(2)" v-if="curContentR2.optionB != null"><span>B.{{ curContentR2.optionB }}</span></div>
                        <div class="answerList" style="margin-top:0.3rem;" @click="nextTitle(3)" v-if="curContentR2.optionC != null"><span>C.{{ curContentR2.optionC }}</span></div>
                    </div>
                    <div class="questionBottom">
                        <div style="padding-top:0.3rem"></div>
                        <div class="answerList" @click="nextTitle(4)" v-if="curContentR2.optionD != null"><span>D.{{ curContentR2.optionD }}</span></div>
                    </div>
                    <img src="../../assets/images/gameRound/round2Title.png" class="roundTitle"/>
                </div>
                <!--=============================-->
                <div class="contentAlert outSideQuestion">
                    <div class="questionTop">
                        <b class="questionNur">第 {{ curIndexR2 + 1 }} / 3 题</b>
                        <b class="timer">{{ t2 }}</b>
                        <img src="../../assets/images/gameRound/timeIcon.png"/>
                    </div>
                    <div class="questionCenter">
                        <b>{{ curContentR2.title }}</b>
                        <div class="answerList" style="margin-top:0.3rem;" @click="nextTitle(1)" v-if="curContentR2.optionA != null"><span>A.{{ curContentR2.optionA }}</span></div>
                        <div class="answerList" style="margin-top:0.3rem;" @click="nextTitle(2)" v-if="curContentR2.optionB != null"><span>B.{{ curContentR2.optionB }}</span></div>
                        <div class="answerList" style="margin-top:0.3rem;" @click="nextTitle(3)" v-if="curContentR2.optionC != null"><span>C.{{ curContentR2.optionC }}</span></div>
                    </div>
                    <div class="questionBottom">
                        <div style="padding-top:0.3rem"></div>
                        <div class="answerList" @click="nextTitle(4)" v-if="curContentR2.optionD != null"><span>D.{{ curContentR2.optionD }}</span></div>
                    </div>
                    <img src="../../assets/images/gameRound/round2Title.png" class="roundTitle"/>
                </div>
                <!--===============================-->
            </div>
        </div>


    </section>

</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import { Badge  } from 'vux'
    import { imageRootPath } from '../../config/config'
//    import Swiper from 'swiper';
    import Swiper from '../../../static/zhongyan/zhdj/breakgame/swiper-4.3.3.min'
    import {stageCommit} from '../../api/api'

    export default {
        components: {

        },
//        props:['inner'],
        data () {
            return {
                swiper2:{},
                t2:'',
                spendT2:'',
                s:'',
                m:'',
                runid:undefined,
                topicContentR2:['title','optionA','optionB','optionC','optionD'],
                curContentR2:[],
                curIndexR2:0,
                correctR2:0,
                imageRootPath
            }
        },
        methods: {

            toUrl:function(enterUrl){
                this.$router.push("/" + enterUrl)
            },
            openAlertR2:function(){
                $(".showAlertR2").fadeIn();
                $(".allowUp").css("display","none");
                this.swiper2.allowSlidePrev= false;
                this.swiper2.allowSlideNext= false;


                //父子组件传参方法
//                if (this.inner == 0){
//                    $('.inSide').css("display","block");
//                }else if (this.inner == 1){
//                    $('.outSide').css("display",'block');
//                }
            },
            gameBeginInSide:function(){
                $(".answerR2Begin").css("display","none");
                $(".inSideQuestion").css("display","block");
                let _self = this;
                _self.t2 = sessionStorage.getItem('timeText');
                this.$emit('startTimer', 'round2');
            },
            gameBeginOutSide:function(){
                $(".answerR2Begin").css("display","none");
                $(".outSideQuestion").css("display","block");
                let _self = this;
                _self.t2 = sessionStorage.getItem('timeText');
                this.$emit('startTimer', 'round2');
            },

            //added by xiaohan below
            setTimeText: function(str){
                this.t2 = str;
            },
            setQuestionList:function(qList){
                this.qList = qList;
                this.curContentR2 = this.qList[this.curIndexR2];
            },
            //added by xiaohan above

            closeAlertR2:function(){
                $(".answerR2Begin").css("display","block");
                $(".contentAlert").css("display","none");
                $(".showAlertR2").css("display","none")
                this.swiper2.allowSlidePrev= true;
                this.swiper2.allowSlideNext= true;
            },
            nextRound:function(){
                $('.equipmentType2').css("z-index","-100");
                $('.equipmentType2Fail').css("z-index","-100");
                $(".luckBegin2").css("display","none");
                $(".allowUp").css("display", "block");
                $(".showAlertR2").fadeOut();
                let round2 = $(".round2").height()
                $(".round2").animate({marginTop: (-1 * Round2) + 'px'},500,"linear", function() {
                    $(this).hide()
                });
            },
            nextTitle:function(X) {
                let _self = this;
                if (X == this.curContentR2.answer) {
                    this.correctR2++;
//                    console.log("正确回答个数", this.correctR2 + "个");
                }
                if (this.innerStatus == 0) {
                    if (this.curIndexR2 < 9) {
                        this.curIndexR2++;
                        this.curContentR2 = _self.qList[this.curIndexR2];
                    }
                    else if (this.curIndexR2 == 9) {
                        //停止计时器
                        this.$emit('pauseTimer');
                        if (this.correctR2 < 8) {
                            $('.answerR2Fail').css('display', 'block');
                            $('.contentAlert').css('display', 'none');
                        }
                        else if (this.correctR2 >= 8 && this.correctR2 < 10) {
                            $('.answerR2Success').css('display', 'block');
                            $('.contentAlert').css('display', 'none');
                            this.$emit('addCorrectNum', _self.correctR2);
                        }
                        else if (this.correctR2 >= 10) {
                            $('.answerR2Perfect').css('display', 'block');
                            $('.contentAlert').css('display', 'none');
                            this.$emit('addCorrectNum', _self.correctR2);
                        }
                    }
                }
                if (this.innerStatus == 1){
                    if (this.curIndexR2 < 2) {
                        this.curIndexR2++;
                        this.curContentR2 = _self.qList[this.curIndexR2];
                    }
                    else if (this.curIndexR2 == 2) {
                        //停止计时器
                        this.$emit('pauseTimer');
                        if (this.correctR2 >= 0 && this.correctR2 < 3) {
                            $('.answerR2Success').css('display', 'block');
                            $('.contentAlert').css('display', 'none');
                            this.$emit('addCorrectNum', _self.correctR2);
                        }
                        else if (this.correctR2 >= 3) {
                            $('.answerR2Perfect').css('display', 'block');
                            $('.contentAlert').css('display', 'none');
                            this.$emit('addCorrectNum', _self.correctR2);
                        }
                    }
                }
            },
            getEquipment:function(){
                $(".showAlertR2").css("display","none");
                $(".luckRoundBox").css("display","block");

                // 刷新gif
                this.$emit('refreshLuckRound')

                let _self = this;
                stageCommit({eid:2}).then((response) => {
                    _self.checkGetEquipmentR2 = response.data.add;
                    _self.firstFlag = response.data.first;
                    sessionStorage.setItem('checkGetEquipmentR2', _self.checkGetEquipmentR2);
                    sessionStorage.setItem('firstFlag', _self.firstFlag);
                    if(response.success){
                    } else {
                        this.$vux.toast.text(response.message, 'middle')
                    }
                });
            },
            },
        mounted () {
            let _self = this;
            $(".secondWindow,.background").height($(window).height());
            _self.swiper2 = new Swiper ('.round2Window', {
                loop: false,
                paginationClickable: true,
                direction: 'vertical',
                height:$(window).height()
            });
            _self.swiper2.on('slideChange', function(){
                let ind = _self.swiper2.activeIndex
                if (ind == 2){
                    $(".allowUp").hide()
                } else {
                    $(".allowUp").show()
                }
            });
            //本地缓存调取数据判断内外版本

            _self.innerStatus = sessionStorage.getItem('inner');
            if (_self.innerStatus == 0){
                $('.inSide').css("display","block");
            }else if (_self.innerStatus == 1){
                $('.outSide').css("display",'block');
            }
        }
    }
</script>

<style lang="less">


    .secondStage{

        .stage2Bg1{
            /*background:url(../../assets/images/gameRound/04.gif) no-repeat;*/
            background-repeat: no-repeat;
            background-size:cover;
            width:100%;
        }

        .stage2Bg2{
            /*background:url(../../assets/images/gameRound/05.gif) no-repeat;*/
            background-repeat: no-repeat;
            background-size:cover;
            width:100%;
        }

        .stage2Bg3{
            /*background:url(../../assets/images/gameRound/06.gif) no-repeat;*/
            background-repeat: no-repeat;
            background-size:cover;
            width:100%;
        }

        .swiper-wrapper{
            width:100%;
        }
        .background{
            width:100%;
        }
        .showAlertR2{
            display:none;
            position:fixed;
            background-color:rgba(0,0,0,0.8);
            bottom:0;
            top:0;
            left:0;
            z-index:999;
            width:100%;
        }
        .contentAlert{
            height:10.5rem;
            width:7rem;
            margin:0 auto;
            padding-top:1.3rem;
            z-index:200;
            position:relative;
        }
        .alertR2{
            position: absolute;
            top:29%;
            left:4.5rem;
            z-index:100;
            height:2.5rem;
            width:2.5rem;
            opacity: 0;
        }





    }

</style>
