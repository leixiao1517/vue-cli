<template>
    <section class="preload">
        <div style="width:150px;height:150px;margin: 200px auto auto">
            <x-circle
                :percent="percent"
                :stroke-width="5"
                stroke-color="#d3272e">
                <span class="tip">加载中{{ percent }}%...</span>
            </x-circle>
        </div>
    </section>
</template>

<script>

    import { XCircle } from 'vux'
    import { imageRootPath,imageRootPath1 } from '../../config/config'

    export default {
        components: {
            XCircle
        },
        data () {
            return {
                percent: 0,
            }
        },
        mounted () {
            let preloadArray = [
                {src:'breakGame/beginGame1st.gif',isLoad:false},
                {src:'breakGame/beginGame2rd.gif',isLoad:false},
                {src:'breakGame/ruleWindow.png',isLoad:false},
                {src:'gameRound/01.gif',isLoad:false},
                {src:'gameRound/02.gif',isLoad:false},
                {src:'gameRound/03.gif',isLoad:false},
                {src:'gameRound/04.gif',isLoad:false},
                {src:'gameRound/05.gif',isLoad:false},
                {src:'gameRound/06.gif',isLoad:false},
                {src:'gameRound/07.gif',isLoad:false},
                {src:'gameRound/08.gif',isLoad:false},
                {src:'gameRound/beginAnswer.png',isLoad:false},
                {src:'luckRound/luckRoundBg.gif',isLoad:false},
                {src:'luckRound/theAirCraftInside.gif',isLoad:false},
                {src:'luckRound/theAirCraftOutside.gif',isLoad:false},
                {src:'luckRound/theCrownInside.gif',isLoad:false},
                {src:'luckRound/theCrownOutside.gif',isLoad:false},
                {src:'luckRound/theMedalInside.gif',isLoad:false},
                {src:'luckRound/theMedalOutside.gif',isLoad:false},
                {src:'luckRound/equipmentFailBg.png',isLoad:false},
                {src:'hostFlag/fireWorks.gif',isLoad:false},
//                {src:'breakGame/sound/startSound.mp3',isLoad:false},
//                {src:'breakGame/sound/hostSound.mp3',isLoad:false},
            ]

            let urlholder = imageRootPath + 'zhongyan/zhdj/breakgame/images/'

            let urlholder1 = imageRootPath1 + 'zhongyan/zhdj/breakgame/images/'

            let img = {}

            // 所有图片预加载
            preloadArray.forEach(preload=>{
                img =new Image();
                if (preload.src.indexOf("beginGame1st") > 0 || preload.src.indexOf("luckRoundBg") > 0){
                    img.src = urlholder1 + preload.src
                } else {
                    img.src = urlholder + preload.src
                }
                img.onload = function () {
                    preload.isLoad = true
                }
            })


            //已经预加载的个数
            let progressNum = 0
            //重试次数
            let retryNum = 100

            // 计算已经预加载个数
            let iId = setInterval(()=> {
                retryNum--
                progressNum = 0

                preloadArray.forEach(preload=>{
                    if (preload.isLoad){
                        progressNum ++
                    }
                })

                this.percent = parseInt(progressNum*100 / preloadArray.length)
                if (progressNum ==preloadArray.length || retryNum<0){
                    clearInterval(iId)
                    let inner = this.$route.query.inner
                    if(1== inner || 0 == inner){
                        sessionStorage.setItem('inner', inner);
                    }
                    // 开始游戏
                    this.$router.push('gameStart')
                }

            },200)


        },
        methods: {

        }
    }

</script>

<style lang="less">
.preload{
    .tip{
        font-size: 12px;
    }
}
</style>
