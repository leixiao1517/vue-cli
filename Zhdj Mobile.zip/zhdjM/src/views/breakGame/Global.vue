<script type="text/javascript">
    let audio = null;
    let flagMusic = null;

    let audioObj = new Map();

    function setAudioEle(ele) {
        audio = ele;
    }

    function getAudioEle () {
        return audio;
    }

    function setFlagMusic(ele) {
        flagMusic = ele;
    }

    function getFlagMusic() {
        return flagMusic;
    }

    function setAudioElement(name, obj) {
        audioObj.set(name, obj);
    }

    function getAudioElement(name) {
        return audioObj.get(name);
    }

    export default
    {
        setAudioEle,
        getAudioEle,
        setFlagMusic,
        getFlagMusic,
        setAudioElement,
        getAudioElement,
    }
</script>
