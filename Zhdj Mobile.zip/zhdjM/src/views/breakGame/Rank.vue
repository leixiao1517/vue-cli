<!--起始页开始-->
<template>
    <div class="index">

        <div class="turnBack" @click="back"><img src="../../assets/images/rankPic/turnBack.png"/><b>返回</b></div>
        <div class="title">
            <img v-if="rid == 1" src="../../assets/images/rankPic/pioneer.png" height="30" width="132"/>
            <img v-if="rid == 2" src="../../assets/images/rankPic/honor.png" height="30" width="132"/>
            <img v-if="rid == 3" src="../../assets/images/rankPic/fort.png" height="30" width="132"/>
            <img v-if="rid == 4" src="../../assets/images/rankPic/langya.png" height="30" width="132"/>
        </div>

        <div class="switch" @click="showMenu()">
            <span v-if="rid == 1">和+先锋榜&nbsp;<img src="../../assets/images/rankPic/trigle.png" height="7" width="16" @click="showMenu();"/></span>
            <span v-if="rid == 2">和+灯塔榜&nbsp;<img src="../../assets/images/rankPic/trigle.png" height="7" width="16" @click="showMenu();"/></span>
            <span v-if="rid == 3">和+堡垒榜&nbsp;<img src="../../assets/images/rankPic/trigle.png" height="7" width="16" @click="showMenu();"/></span>
            <span v-if="rid == 4">和+琅琊榜&nbsp;<img src="../../assets/images/rankPic/trigle.png" height="7" width="16" @click="showMenu();"/></span>
            <!--<img src="../../assets/images/rankPic/trigle.png" height="7" width="16" @click="showMenu();"/>-->
        </div>


        <div class="rank-mask dp-none">
            <img @click="closeRank" style="z-index:0;position: absolute;top:60px;right:28px" src="../../assets/images/rankPic/cha.png" height="45" width="27"/>
            <div class="out-bg">
            <p class="item" @click="choose(1);">和+先锋榜</p>
            <p class="item mt" @click="choose(2);">和+灯塔榜</p>
            <p class="item mt" @click="choose(3);">和+堡垒榜</p>
            <p class="item mt" @click="choose(4);">和+琅琊榜</p>
            </div>
        </div>

        <div class="mainBox">
            <div class="main" v-for="(value,index) in rankitem">
                <!-- 第一名 -->
                <div class="r123 r1top r1" v-if="index == 0">
                <img v-if = "rid ==1 || rid == 2" class="headImg" :src="rankitem[0].headImg | imgPath"/>
                <span v-if = "rid ==1 || rid == 2" class="userName">{{rankitem[0].userName}}</span>
                <span v-if = "rid ==3 || rid == 4" class="unitName">{{rankitem[0].unitName}}</span>
                <span v-if="rid == 1" class="scorep">{{rankitem[0].score}}题</span>
                <!--<img v-if="rid == 2 || rid == 3" src="../../assets/images/mutiRank/flag.png" height="30" width="28"/>-->
                <span v-if="rid == 1" style="display:inline-block;margin-left:0.1rem;">{{rankitem[0].useTime}}</span>
                    <span v-if="rid == 2" style="margin-left: 30px">{{rankitem[0].flagCount}}次</span>
                    <span v-if="rid == 3" style="margin-left: 20px">{{rankitem[0].unitFlag}}次</span>
                    <span v-if="rid == 4" style="margin-left: 0.3rem;display:inline-block;width:1.2rem;text-align:center">{{rankitem[0].positive}}%</span>
                </div>

                <!-- 第二名 -->
                <div class="r123 r2" v-if="index == 1">
                    <img  v-if = "rid ==1 || rid == 2" class="headImg" :src="rankitem[1].headImg | imgPath" />
                    <span v-if = "rid ==1 || rid == 2" class="userName">{{rankitem[1].userName}}</span>
                    <span v-if = "rid ==3 || rid == 4" class="unitName">{{rankitem[1].unitName}}</span>
                    <span v-if="rid == 1" class="scorep">{{rankitem[1].score}}题</span>
                    <!--<img v-if="rid == 2" src="../../assets/images/mutiRank/flag.png" height="30" width="28"/>-->
                    <span v-if="rid == 1" style="display:inline-block;margin-left:0.1rem;">{{rankitem[1].useTime}}</span>
                    <span v-if="rid == 2" style="margin-left: 30px">{{rankitem[1].flagCount}}次</span>
                    <span v-if="rid == 3" style="margin-left: 20px">{{rankitem[1].unitFlag}}次</span>
                    <span v-if="rid == 4" style="margin-left: 0.3rem;display:inline-block;width:1.2rem;text-align:center">{{rankitem[1].positive
                        }}%</span>
                </div>


                <!-- 第三名 -->
                <div class="r123 r3" v-if="index == 2">
                    <img  v-if = "rid ==1 || rid == 2" class="headImg" :src="rankitem[2].headImg | imgPath"/>
                    <span v-if = "rid ==1 || rid == 2" class="userName">{{rankitem[2].userName}}</span>
                    <span v-if = "rid ==3 || rid == 4" class="unitName">{{rankitem[2].unitName}}</span>
                    <span v-if="rid == 1" class="scorep">{{rankitem[2].score}}题</span>
                    <!--<img v-if="rid == 2 || rid == 3" src="../../assets/images/mutiRank/flag.png" height="30" width="28"/>-->
                    <span v-if="rid == 1 " style="display:inline-block;margin-left:0.1rem;">{{rankitem[2].useTime}}</span>
                    <span v-if="rid == 2  " style="margin-left: 30px">{{rankitem[2].flagCount}}次</span>
                    <span v-if="rid == 3" style="margin-left: 20px">{{rankitem[2].unitFlag}}次</span>
                    <span v-if="rid == 4" style="margin-left: 0.3rem;display:inline-block;width:1.2rem;text-align:center">{{rankitem[2].positive}}%</span>
                </div>
                <!--<div style="border-bottom: solid 1px whitesmoke;margin:15px auto auto auto;width: 65%;"></div>-->


                <div class="rankitem" v-if="index > 2">
                        <span style="margin-left:0.3rem;width: 0.3rem;display: inline-block;text-align: center">{{index + 1}}</span>
                        <img  v-if = "rid ==1 || rid == 2" class="headImgItem" :src="value.headImg | imgPath"/>
                        <span v-if = "rid ==1 || rid == 2" class="userName">{{value.userName}}</span>
                        <span v-if = "rid ==3 || rid == 4" class="rankItemunitName">{{value.unitName}}</span>
                        <span v-if="rid == 1" class="scorep">{{value.score}}题</span>
                        <span v-if="rid == 1" style="display:inline-block;margin-left:0.1rem;">{{value.useTime}}</span>
                        <span v-if="rid == 2" style="margin-left: 30px">{{value.flagCount}}次</span>
                        <span v-if="rid == 3" style="margin-left: 20px">{{value.unitFlag}}次</span>
                        <span v-if="rid == 4" style="margin-left: 0.3rem;display:inline-block;width:1.2rem;text-align:center">{{value.positive}}%</span>
                </div>
            </div>

            <div v-if="rid == 1 || rid == 2" class="myrank">
                <span style="margin-left: 30px">我的排名:</span><span style="color: #DE212A">{{user.rownum}}</span> 名
                <span v-if="rid == 1" style="margin-left: 30px;color: #DE212A">{{user.score}}题</span>
                <span v-if="rid == 2" style="margin-left: 75px;color: #DE212A">{{user.flagCount}}次</span>
                <span v-if="rid == 1" style="margin-left: 20px;color: #DE212A">{{user.useTime}}</span>
            </div>
        </div>

    </div>
</template>
<!--起始页结束
-->

<script>
    import $ from 'jquery'
    import {pioneer,honor,fort,inner} from '../../api/api'
    import {
        Checker,
        CheckerItem,
        Group,
        CheckIcon,
        Cell,
        XTextarea,
    } from 'vux'
    export default {
        components: {
            Checker,
            CheckerItem,
            Group,
            Cell,
            XTextarea,
            CheckIcon,
        },
        data () {
            return {
            show:false,
            rankitem:["userName","score","useTime","flagCount","unitName","positive","headImg"],
            user:{flagCount:'',rownum:''},
            rid:1,
            innerUser:'',
            }
        },
        methods: {
            toUrl:function(enterUrl){
                this.$router.push("/" + enterUrl)
            },
            remind:function(){
                this.$vux.toast.text('敬请期待')
            },

            showMenu:function () {
                // this.show = true;
                $(".rank-mask").fadeIn();

            },
            closeRank:function () {
                $(".rank-mask").fadeOut();
            },

            choose:function (rid) {
                let _self = this;
                this.rid = rid;
                //和+先锋榜
                if( this.rid == 1){
                    pioneer({}).then(data=>{
//                        console.log(data)
                        _self.rankitem = data.data.list;
                        _self.user.rownum = data.data.rownum;
//                        console.log('++++++++++++++',data.data);
                            var item =  $('.item').eq(rid-1);

                            console.info(item.html())
                            item.css("background-color","#E2232E");
                            item.css("color","white")
                            item.siblings("p").css("background-color","white").css("color","red");
                    })

                //荣耀旗手榜
                }else if( this.rid == 2){
                    honor({}).then(data=>{
                        _self.rankitem = data.data.list;
                        _self.user.rownum = data.data.rownum;
                        _self.user.flagCount = data.data.flagCount;
//                        console.log('++++++++++++++',data.data);
                        var item =  $('.item').eq(rid-1);
                        console.info(item.html())
                        item.css("background-color","#E2232E");
                        item.css("color","white");
                        item.siblings("p").css("background-color","white").css("color","red");
                    })

                 //和+堡垒榜
                }else if( this.rid == 3){
                    fort({fort:"fort1"}).then(data=>{
                        _self.rankitem = data.data;
                        // _self.user = data.data.user;
//                        console.log('++++++++++++++',data.data);
                        var item =  $('.item').eq(rid-1);
                        console.info(item.html())
                        item.css("background-color","#E2232E");
                        item.css("color","white");
                        item.siblings("p").css("background-color","white").css("color","red");
                    })
                //和+琅琊榜
                }else if( this.rid == 4){
                    fort({fort:"fort2"}).then(data=>{
                        _self.rankitem = data.data;
                        // _self.user = data.data.user;
//                        console.log('++++++++++++++',data.data);
                        var item =  $('.item').eq(rid-1);
                        console.info(item.html())
                        item.css("background-color","#E2232E");
                        item.css("color","white");
                        item.siblings("p").css("background-color","white").css("color","red");
                    })
                }else {
                }
                $(".rank-mask").hide();

            },
            initRank:function () {
                let _self = this;
                $(".index").css("height",$(window).height());
                inner({}).then(data=>{
                    if(data.success){
                        _self.innerUser = data.data.inner;
                    }else{
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                    //内部用户
                    if(_self.innerUser == 0){
                            pioneer({}).then(data=>{
                                _self.rankitem = data.data.list;
                                _self.user.rownum = data.data.rownum;
                                _self.user.useTime = data.data.useTime;
                                _self.user.score = data.data.score;
                                if(_self.user.rownum == -1){
                                    _self.user.rownum = '暂无';
                                }
                                if(_self.user.score == -1){
                                    _self.user.score = '暂无';
                                }

                                if(_self.user.useTime == '-1'){
                                    _self.user.useTime = '暂无';
                                }
                                // console.log('++++++++++++++',data.data);
                                if(data.data.from == 1){
                                    var item =  $('.item').eq(0);
                                    console.info(item.html())
                                    item.css("background-color","#E2232E");
                                    item.css("color","white");
                                }
                            })
                    }
                    //外部用户
                    if(_self.innerUser == 1){
                        var item =  $('.switch').hide();
                        honor({}).then(data=>{
//                            console.log("``````",data);
                            _self.rid = 2;
                            _self.choose(2);
                            _self.rankitem = data.data.list;
                            _self.user.rownum = data.data.rownum;
                            _self.user.flagCount = data.data.flagCount;
//                            console.log('++++++++++++++',data.data);
                            var item =  $('.item').eq(1);
                            console.info(item.html())
                            item.css("background-color","#E2232E");
                            item.css("color","white");
                            item.siblings("p").css("background-color","white").css("color","red");
                        })
                    }
                })
            },
            back:function(){
                this.$router.go(-1)
            },
        },
        mounted () {
            //stop audio
            let audio = this.GLOBAL.getAudioEle();
            audio.pause();

            this.initRank();
            $('.mainBox').css("height",$(window).height() - $(".title").height() - 5 - $(".switch").height() - 40 - $(".main").height() - ($(".main").height())/2 )
        }
    }
   </script>

<style lang="less">
    .index {


        background: url(../../assets/images/rankPic/background.jpg)  no-repeat;
        background-size: 100% 100%;
        position:relative;

    .title{
        padding-top: 5px;
        /*padding-bottom: 10px;*/
        text-align: center ;
    }

    .title img{
        /*padding-top:10px;*/
        border-bottom: solid 1px;
        color: white;
        padding-bottom: 2px;

    }

    .switch{
        text-align: center;
        color: #E2473E;
        font-size: 12px;
        font-weight: bold;
    }
    .switch span {
        padding-bottom: -10px;
    }
    .item{
        width: 4.5rem;
        height: 0.6rem;
        background-color: white;
        margin: auto;
        color: #E2232D;
        border-radius: 5px;
        line-height: 0.6rem;
        font-size: 16px;
        font-family: 微软雅黑;
        text-align: center;
        margin-top: 140px;
    }

        .rank-mask{
            background-color: rgba(0,0,0,.6);
            width: 100%;
            height: 100%;
            position: fixed;
            top: 0;
            z-index: 999;
        }
        .out-bg{
            position: fixed;
            top: 2rem;
            left: 10%;
            background: url(../../assets/images/rankPic/allrank.png)  center;
            background-size: cover;
            height: 70%;
            width: 80%;
            margin: auto;
            border-radius: 10px;
        }
        .mt{
            margin-top: 30px;
        }

        .r123{
            width: 85%;
            height: 45px;
            margin: 0;
            margin: auto;
            margin-top: 5px;
            line-height: 45px;
            color: #D31822;
        }

        .r1top{
            /*margin-top: 48px;*/
        }

        .r1{
            background: url(../../assets/images/rankPic/1.png)  round;
            background-size: cover;
        }

        .r2{
            background: url(../../assets/images/rankPic/2.png)  round;
            background-size: cover;
        }

        .r3{
            background: url(../../assets/images/rankPic/3.png)  round;
            background-size: cover;
        }

        .rankitem{
            width: 85%;
            height: 40px;
            margin: 0;
            margin: auto;
            margin-top: 10px;
            color: white;
            line-height: 40px;
            position: relative;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
        }

        .scorep{
            display: inline-block;
            width: 1.2rem;
        }

        .userName{
            display: inline-block;
            width: 1.2rem;
            margin-left: 20px;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
            vertical-align: top;
        }

        .unitName{
            display: inline-block;
            width: 3rem;
            margin-left: 1.6rem;
        }

        .rankItemunitName{
            display:inline-block;
            width: 3rem;
            margin-left: 0.9rem;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
            vertical-align: top;
        }

        .headImg{
            height:35px;
            width:35px;
            border-radius:50%;
            background-color:red;
            float:left;
            margin-top: 7px;
            margin-left: 1rem;
        }


        .headImgItem{
            height:35px;
            width:35px;
            border-radius:50%;
            background-color:red;
            margin-left: 0.35rem;
        }

        .myrank{
            position: absolute;
            bottom:25px;
            left: 45px;
            width: 80%;
            height: 40px;
            background: url(../../assets/images/rankPic/myrank.png)  round;
            background-size: cover;
            line-height: 40px;
        }
        .mainBox{
            width:100%;
            margin-top:0.8rem;
            overflow:auto;
        }
        ::-webkit-scrollbar{display:none;width: 0;height: 0;}

        .turnBack{
            position:absolute;
            float:left;
            height:0.8rem;
            margin-left:0.2rem;
        }
        .turnBack>b{
            text-align:center;
            line-height:0.8rem;
            font-size:0.3rem;
            margin-left:0.27rem;
            color:#d51924;
            font-weight:normal;
            border-bottom:1px solid #d51924;
        }
        .turnBack>img{
            position:absolute;
            height:0.3rem;
            width:0.18rem;
            top:0.25rem;
        }
    }
</style>
