<!--起始页开始-->
<template>

    <section class="prizeInformation">

        <div class="topTitle">
            <img src="../../assets/images/prizeInformation/prizeTitle.png"/>
        </div>

        <div class="seat"></div>
        <div class="rankResult">
            <div class="top1-3">
                <img src="../../assets/images/prizeInformation/firstPrize.png"/>
                <div class="top1-3Content">
                    <div v-for="(userInfo,index) in list" v-if="index<1">
                        <img :src="userInfo.headImg"/>
                        <span>{{userInfo.userName}}</span>
                    </div>
                    <div style="border-left:2px solid #da4143;border-right:2px solid #da4143"
                         v-for="(userInfo,index) in list" v-if="index<2 && index>0">
                        <img :src="userInfo.headImg"/>
                        <span>{{userInfo.userName}}</span>
                    </div>
                    <div v-for="(userInfo,index) in list" v-if="index<3 && index>1">
                        <img :src="userInfo.headImg"/>
                        <span>{{userInfo.userName}}</span>
                    </div>
                    <b class="bgTree"></b>
                </div>
            </div>
            <div class="top20Before">
                <img src="../../assets/images/prizeInformation/secondPrize.png"/>
                <div class="listBox">
                    <div class="topList" v-for="(userInfo,index) in list" v-if="index>2 && index<23">
                        <img :src="userInfo.headImg"/>
                        <span>&nbsp;{{userInfo.userName}}</span>
                    </div>
                </div>
            </div>
            <div class="top50Before">
                <img src="../../assets/images/prizeInformation/thirdPrize.png"/>
                <div class="listBox">
                    <div class="topList" v-for="(userInfo,index) in list" v-if="index>22 && index<73">
                        <img :src="userInfo.headImg"/>
                        <span>&nbsp;{{userInfo.userName}}</span>
                    </div>
                </div>
            </div>
        </div>


        <div class="myPrize">
            <img src="../../assets/images/prizeInformation/havePrize.png"
                 style="height:0.3rem;width:4.89rem;padding-top:0.2rem"
                 v-if="rownum <= 73 && !alreadyExist" @click="showDialog(alreadyExist)"/>

            <img src="../../assets/images/prizeInformation/noPrize.png"
                 v-if="rownum > 73"/>

            <img src="../../assets/images/prizeInformation/havePrizeed.png"
                 style="height:0.3rem;width:6rem;padding-top:0.2rem"
                 v-if="rownum <= 73 && alreadyExist" @click="showDialog(alreadyExist)"
            />
        </div>

        <div v-transfer-dom id="test">
            <x-dialog v-model="showDialogStyle">
                <br>
                <span style="font-size:16px;">填写信息</span>

                <group label-width="5.5em">
                    <x-input title="姓&emsp;名" v-model="realName" placeholder="请输入您的真实姓名" :disabled="alreadyExist" ></x-input>
                    <x-input title="手机号" v-model="userPhone" placeholder="请输入联系方式" :disabled="alreadyExist"></x-input>
                    <x-textarea  title="地&emsp;址" v-model="userAddress" placeholder="请输入您的地址" :rows="2" :disabled="alreadyExist"></x-textarea >
                </group>
                <br>
                <box gap="40px 10px">
                    <flexbox>
                        <flexbox-item>
                            <x-button type="warn" @click.native="showDialogStyle=false">取消</x-button>
                        </flexbox-item>
                        <flexbox-item v-show="isShow">
                            <x-button type="warn" @click.native="getUserInformation" >提交</x-button>
                        </flexbox-item>
                    </flexbox>
                </box>
            </x-dialog>
        </div>
    </section>


</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import {
        Badge,
        XDialog,
        Group,
        TransferDomDirective as TransferDom,
        XInput,
        XButton,
        Box,
        Flexbox,
        FlexboxItem,
        XTextarea,
    } from 'vux'
    import {mobileClient} from '../../config/config'
    import {pioneer, honor, fort, inner, billboard} from '../../api/api'

    export default {
        directives: {
            TransferDom
        },

        components: {
            XDialog,
            Group,
            XInput,
            XButton,
            Box,
            Flexbox,
            FlexboxItem,
            XTextarea,
        },
        data () {
            return {
                havePrize: 1,
                list: {},
                userInfo: '',
                rownum: '',
                showDialogStyle: false,
                realName: '',
                userPhone: '',
                userAddress: '',
                alreadyExist: false,
                isShow:true,

            }
        },
        methods: {
            showDialog: function (alreadyExist) {
                this.showDialogStyle = true;
                this.isShow = !alreadyExist;
            },

            getUserInformation: function () {

                let _self = this;
                if (this.realName == '') {
                    this.$vux.toast.text('姓名未填写')
                    return false
                } else if (this.userAddress == '') {
                    this.$vux.toast.text('地址未填写')
                    return false
                }

                else if (!(/^1[3|4|5|7|8]\d{9}$/.test(this.userPhone))) {
                    this.$vux.toast.text('手机号码格式不正确')
                    return false
                }

                billboard({
                    realName: _self.realName,
                    userPhone: _self.userPhone,
                    userAddress: _self.userAddress

                }).then((response) => {
                    if (response.success){
                        _self.$vux.toast.text("提交成功", 'middle');
                        _self.alreadyExist=true;
                        console.log(response);
                        _self.realName=response.data.realName;
                        _self.userPhone=response.data.userPhone;
                        _self.userAddress=response.data.userAddress;

                        _self.showDialogStyle = false;
                    }else {
                        _self.$vux.toast.text("网络错误", 'middle');
                    }
                });
            },

        },
        mounted() {
            let _self = this;
            $(".prizeInformation").height($(window).height());
            $(".rankResult").height($(window).height() - $(".seat").height() - $(".myPrize").height() * 3 - $(".topTitle").height());
            _self.innerUser = _self.$route.query.inner;
            honor({}).then((data) => {
                console.log('++++++++++',data.data);
                _self.list = data.data.list;
                _self.rownum = data.data.rownum;
            })

            getBillboard({}).then((response)=>{
                console.log(response);
                _self.alreadyExist = response.data.alreadyExist;
                if (_self.alreadyExist){
                    _self.realName=response.data.realName;
                    _self.userPhone=response.data.userPhone;
                    _self.userAddress=response.data.userAddress;
                }
            });
        }
    }

</script>

<style lang="less">
    .prizeInformation {
        background: url(../../assets/images/rankPic/background.jpg) no-repeat;
        background-size: 100% 100%;
        position: relative;

        .topTitle {
            padding-top: 0.3rem;
            height: 0.6rem;
            width: 2.16rem;
            margin: 0 auto;
            border-bottom: 1px solid white;
        }
        .topTitle > img {
            height: 0.6rem;
            width: 2.16rem;
        }
        .rankResult {
            height: 9.8rem;
            width: 80%;
            margin: 1.2rem auto 0 auto;
            overflow: auto;
        }
        ::-webkit-scrollbar {
            display: none;
            width: 0;
            height: 0;
        }
        .top1-3 {
            height: 3rem;
            width: 100%;
        }
        .top1-3 > img {
            height: 0.5rem;
            width: 3.4rem;
        }
        .top1-3Content {
            background: url(../../assets/images/prizeInformation/firstPrizeBox.png) no-repeat;
            background-size: 100% 100%;
            width: 100%;
            height: 2.5rem;
            display: flex;
            position: relative;
        }
        .top1-3Content > div {
            flex: 1;
            height: 0.8rem;
            margin-top: 0.8rem;
            position: relative;
            z-index: 2;
        }
        .top1-3Content > div > img {
            height: 0.8rem;
            width: 0.8rem;
            border-radius: 50%;
            display: block;
            margin: -0.2rem auto;
        }
        .top1-3Content > div > span {
            width: 1.4rem;
            height: 0.4rem;
            display: block;
            margin: 0.3rem auto;
            text-align: center;
            color: #d51924;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
            line-height: 0.4rem;
            font-size: 0.28rem;
        }
        .bgTree {
            position: absolute;
            bottom: 0;
            left: 50%;
            margin-left: -1.2rem;
            background: url(../../assets/images/prizeInformation/prizeTree.png) no-repeat;
            background-size: 100% 100%;
            height: 2rem;
            width: 2.4rem;
            z-index: 1;
        }
        .top20Before {
            margin-top: 0.33rem;
            width: 100%;
        }
        .top20Before > img {
            width: 100%;
        }
        .listBox {
            margin-top: 0.15rem;
        }
        .topList {
            width: 2.95rem;
            height: 0.8rem;
            display: inline-block;
            margin-top:0.15rem;
        }
        .top50Before {
            margin-top: 0.33rem;
            width: 100%;
        }
        .top50Before > img {
            width: 100%;
        }
        .topList > img {
            height: 0.8rem;
            width: 0.8rem;
            border-radius: 50%;
            float: left;
            margin-left: 0.1rem;
        }
        .topList > span {
            display: inline-block;
            height: 0.8rem;
            width: 1.8rem;
            line-height: 0.8rem;
            text-align: left;
            color: white;
            font-size: 0.28rem;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
            margin-left: 0.1rem;
        }
        .myPrize {
            height: 0.7rem;
            width: 6.6rem;
            margin: 0.1rem auto 0 auto;
            background: url(../../assets/images/rankPic/myrank.png) no-repeat;
            background-size: 100% 100%;
        }
        .myPrize > img {
            height: 0.35rem;
            display: block;
            padding-top: 0.175rem;
            margin: 0 auto;
        }
        .seat {
            height: 1.2rem;
            position: absolute;
        }
    }
</style>
