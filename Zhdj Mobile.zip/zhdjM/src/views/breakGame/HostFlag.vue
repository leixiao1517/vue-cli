<!--起始页开始-->
<template>

    <section class="hostFlag">

        <!--<keep-alive>-->
            <!--<audio id="flagMusic" :src="imageRootPath + 'zhongyan/zhdj/breakgame/images/breakGame/sound/hostSound.mp3'" preload></audio>-->
        <!--</keep-alive>-->

        <div class="imgBg1">
            <img class="pole" src="../../assets/images/hostFlag/flagpole.png">
            <img class="banner" src="../../assets/images/hostFlag/flagBanner.gif">
            <div class="fireWorks" :style="{backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/hostFlag/fireWorks.gif)'}"></div>
        </div>
        <div class="flagAlertWindow enough" style="display:none">
            <div class="flagAlertBox">
                <div>
                    <p><b>很遗憾！装备不足！</b></p>
                    <p>请返回首页继续答题，集齐3个不同装备再来升旗哟~</p>
                    <p style="margin-top:0.6rem">
                        <button class="closeAlert" @click="toUrl('gameUserInfo')">知道了</button>
                    </p>
                </div>
            </div>
        </div>

        <div class="flagAlertWindow hoistFlag" style="display:none">
            <div class="flagAlertBox">
                <div>
                    <p><b>恭喜您！升旗成功</b></p>
                    <p>已升旗次数：{{flagTCount.flagCount}}次</p>
                    <p>您还有{{flagTCount.restCount}}次升旗机会</p>
                    <p style="margin-top:0.6rem">
                        <button class="closeAlert" @click="closeAlert" v-if="flagTCount.restCount > 0">继续升旗</button>
                        <button class="closeAlert" @click="toUrl('gameUserInfo')">确认</button>
                    </p>
                </div>
            </div>
        </div>

        <div class="flagAlertWindow noHoistFlag" style="display:none">
            <div class="flagAlertBox">
                <div>
                    <p><b>错误</b></p>
                    <p>后台数据出错，请稍后再试</p>
                    <p style="margin-top:0.6rem">
                        <button class="closeAlert" @click="toUrl('gameUserInfo')">确认</button>
                    </p>
                </div>
            </div>
        </div>


        <button class="clickToUp" @click="flagUp">开始升旗</button>

    </section>

</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import { Badge  } from 'vux'
    import { imageRootPath } from '../../config/config'
    import { hoistFlag,getUserEquipmentByUid } from '../../api/api'
    export default {
        components: {

        },
        data () {
            return {
                flagRownum:'',
                flagTCount:'',
                imageRootPath
            }
        },
        methods: {
            flagUp:function(){
                let _self = this;
                hoistFlag({"":""}).then((response) => {
                    _self.flagTCount = response.data;
//                hoistFlag=-1 其他错误不能升级
//                enough=-1 装备不够 不能升级
//                hoistFlag=1 升旗成功
                        _self.flagStatus = response.data;
                        if( _self.flagStatus.hoist == -1){
//                            hoistFlag = -1 后台错误等情况
                            $('.noHoistFlag').css('display','block');
                            return;
                        }
                        else if(_self.flagStatus.hoist == 1){
//                            hoistFlag = 1满足升旗情况
                            $('.clickToUp').fadeOut();
                            $('.banner').fadeIn();
                            $('.fireWorks').css("display","block");

                            //音频播放控制
//                            let flagSound = document.getElementById("flagMusic");
//                            flagSound.play();
                            let flagMusic = _self.GLOBAL.getFlagMusic();
                            flagMusic.currentTime = 0;
                            flagMusic.oncanplay = flagMusic.play();

                            $('.banner').animate({bottom:"6.5rem"},2000);
                            setTimeout(function(){
                                $('.hoistFlag').css('display','block');
                            },3000)
                        }
                        else if(_self.flagStatus.enough == -1){
//                            enough=-1 装备不足情况
                            $('.enough').css('display','block');
                        }
                    });
            },
            closeAlert:function(){
                $('.flagAlertWindow').css('display','none');
                $('.banner').css('display','none');
                $('.banner').animate({bottom:"2rem"});
                $('.clickToUp').fadeIn();
                $('.fireWorks').css("display","none");
            },
            toUrl:function(enterUrl){
                this.$router.push("/" + enterUrl);
            },
        },
        mounted () {
            $(".imgBg1,.imgBg2,.flagAlertWindow").height($(window).height());
        },
        beforeDestroy: function () {
            let _self = this;
            let flagMusic = _self.GLOBAL.getFlagMusic();
            flagMusic.pause();
        },
    }

</script>

<style lang="less">


    .hostFlag{

        position:relative;


        .imgBg1{
            width:100%;
            background:url(../../assets/images/hostFlag/flagBg.jpg) center;
            background-size: cover;
            position:relative;
        }
        .imgBg2{
            width:100%;
            display:none;
        }
        .clickToUp{
            height:0.6rem;
            width:40%;
            font-size:0.3rem;
            background-color:#c73736;
            border-radius:5px;
            position:absolute;
            bottom:0.8rem;
            margin-left:30%;
            line-height:0.6rem;
            color:white;
        }
        .pole{
            height:6.9rem;
            width:1.8rem;
            position:absolute;
            bottom:1.8rem;
        }
        .banner{
            position:absolute;
            bottom:2.0rem;      /*6.5rem*/
            left:1.05rem;
            width:1.8rem;
            height:1.8rem;
            display:none;
        }
        .flagAlertWindow{
            position:fixed;
            background-color:rgba(0,0,0,0.7);
            top:0;
            left:0;
            width:100%;
            z-index:300;
        }
        .flagAlertBox{
            background:url(../../assets/images/hostFlag/flagAlertBg.png) no-repeat;
            background-size:cover;
            width:7rem;
            height:5.2rem;
            display:block;
            margin:3rem auto;
            z-index:350;
            position:relative;
        }
        .flagAlertBox>div{
            display:block;
            width:6.4rem;
            margin-left:0.3rem;
            height:2.4rem;
            position:absolute;
            top:1.3rem;
            color:white;

        }
        .flagAlertBox>div>p{
            text-align:center;
            margin-top:0.3rem;
        }
        .flagAlertBox>div>p>b{
            font-size:0.3rem;
        }
        .closeAlert{
            background:url(../../assets/images/hostFlag/btn.png) no-repeat;
            background-size:100% 100%;
            height:0.8rem;
            width:1.6rem;
            color:#c3373a;
            text-align:center;
            line-height:0.8rem;
            margin-left:0.2rem;
        }
        .fireWorks{
            background-size:100% 100%;
            position:absolute;
            top:0;
            left:0;
            height:7.4rem;
            width:7.4rem;
            display:none;
        }


    }

</style>
