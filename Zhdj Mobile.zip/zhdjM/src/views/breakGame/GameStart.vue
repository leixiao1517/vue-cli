<!--起始页开始-->
<template>

    <section class="gameStart">

        <div class="firstBg">
            <img id="beginGame1st" style="width:100%;pointer-events:none" :src="imageRootPath1 + 'zhongyan/zhdj/breakgame/images/breakGame/beginGame1st.gif'" alt="11">
        </div>
        <div class="secondBg">
            <div class="topArea">
                <div class="topImg" id="leftIn"></div>
            </div>
            <div class="centerArea">
                <div class="imgIcon">
                    <img src="../../assets/images/breakGame/userIcon.png" class="userIcon" id="fadeIn1" @click="toUrl('gameUserInfo')"/>
                    <img src="../../assets/images/breakGame/rankIcon.png" class="rankIcon" id="fadeIn2" @click="toUrl('rank')"/>
                </div>
            </div>
            <div class="bottomArea" id="fadeIn3">
                    <div class="welcomeContent"></div>
                    <img src="../../assets/images/breakGame/startBtn.png" class="startBtn " @click="toUrl('gameRound')"/>
                    <img src="../../assets/images/breakGame/bottomRule.png" class="bottomRule " @click="openRule"/>
                    <img src="../../assets/images/breakGame/produceImg.png" class="produceImg "/>
            </div>
            <div class="ruleWindow" >
                <!--内部版本规则说明-->
                <div class="ruleContent inSide" :style="{backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/breakGame/ruleWindow.png)'}">
                    <img src="../../assets/images/breakGame/ruleText.png" class="ruleText"/>
                    <div class="ruleArea">
                        <p>1.活动时间：7月1日-7月31日，期间可无限次数进入闯关答题；</p>
                        <p>2.单轮闯关共有三关，三关的答对题数之和，答题时间之和，即为本轮闯关成绩；</p>
                        <p>3.每一关均随机抽取10题，正确率≥80%，则可进入下一关，否则需要重新开始闯关；正确率=100%，则进入和+生态圈地图，一定几率抽取本关的闯关装备；</p>
                        <p>4.每集齐三关装备，可点击头像进入个人中心升旗一次，每日升旗次数不限；</p>
                        <p>5.实时排行榜分为:</p>
                        <p>和+先锋榜:按个人闯关最优成绩排行</p>
                        <p>和+灯塔榜:按个人升旗次数排行</p>
                        <p>和+堡垒榜:按单位升旗总数排行</p>
                        <p>和+琅琊榜:按单位闯关参与率排行</p>
                        <p>6.奖项设置:</p>
                        <p @click="toGuize()" style="text-decoration:underline">查看详情(链接)</p>
                        <p>7.活动结束后，将根据最终的排行榜确认各大奖项，请关注 (湖南中烟) 企业号，获取最新信息。</p>
                        <img src="../../assets/images/breakGame/twoCodeInside.jpg" class="rule2Code"/>
                    </div>
                    <div class="bottomBtn" @click="closeRule"><b>确定</b></div>
                </div>

                <!--外部版本规则说明-->
                <div class="ruleContent outSide" :style="{backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/breakGame/ruleWindow.png)'}">
                    <img src="../../assets/images/breakGame/ruleText.png" class="ruleText"/>
                    <div class="ruleArea">
                        <p>1、活动时间：7月1日-7月31日，不限次数闯关；</p>
                        <p>2、闯关赛共三关，每关3题，全部正确即可获取装备，否则直接进入下一关；</p>
                        <p>3、每集齐3个不同装备，可进入个人中心升旗一次；</p>
                        <p>4、排行榜按个人升旗次数进行实时排行；</p>
                        <p>5、奖项设置：</p>
                        <p>一等奖：3名（排行榜第1-3名）</p>
                        <p>二等奖：20名（排行榜第4-23名）</p>
                        <p>三等奖：50名（排行榜第24-73名）</p>
                        <p>6、活动结束后，将根据最终的排行榜确认奖项并发放奖品，请关注(天下和书院)微信公众号，获取最新信息。</p>
                        <img src="../../assets/images/breakGame/twoCodeOutside.jpg" class="rule2Code"/>
                    </div>
                    <div class="bottomBtn" @click="closeRule"><b>确定</b></div>
                </div>

            </div>
            <!--<audio id="myMedia1" src=""></audio>-->
        </div>
    </section>

</template>
<!--起始页结束-->

<script>
    import Vue from 'vue';
    import $ from 'jquery'
    import { Badge  } from 'vux'
    import { imageRootPath,imageRootPath1 } from '../../config/config'
    export default {
        components: {
            inner:'',
        },
        data () {
            return {
                imageRootPath,
                imageRootPath1
            }
        },
        methods: {
            toUrl:function (enterUrl) {
                this.$router.push("/" + enterUrl)
            },
            openRule:function(){
                $(".ruleWindow").fadeIn();

            },
            closeRule:function(){
                $(".ruleWindow").fadeOut();
            },
            toGuize:function () {
              window.location.href = "http://app.vangv.cn/weixin/mobile.php?act=module&name=site&id=8502&weid=11&do=detail"
            },
            playAudio: function () {
                let audio = this.GLOBAL.getAudioEle();
                audio.currentTime = 0;
                audio.oncanplay = audio.play();
            }
        },

        mounted () {

            //时间戳方法 重置gif的缓存
            let restImg = new Date().getTime();
            //------------------------------------------
            var img1 = new Image();
            img1.src = imageRootPath + "zhongyan/zhdj/breakgame/images/breakGame/beginGame1st.gif";
            img1.onload = function () {
//                $(".firstBg").css("background","url(" + mobileClient + "static/breakGame/img/beginGame1st.gif?" + restImg + ") center")
//                $(".firstBg").css("background-size","cover")
                let myimg = document.getElementById('beginGame1st')
                $(myimg).css('width',$(window).width()).css('height',$(window).height())
                myimg.stop()
                myimg.play()

                setTimeout(function(){
                    $(".firstBg").css("z-index","50");
                    $(".secondBg").css("display","block")
                    document.getElementById("leftIn").style.animation="leftFadeIn 0.5s";
                    document.getElementById("fadeIn1").style.animation="beginFadeIn 1s";
                    document.getElementById("fadeIn2").style.animation="beginFadeIn 1s";
                    document.getElementById("fadeIn3").style.animation="beginFadeIn 1s";
                },2000)

            }
//            var img2 = new Image();
//            img2.src = mobileClient + "static/breakGame/img/beginGame2rd.gif";
//            img2.onload = function () {
                $(".secondBg").css("background","url(" + imageRootPath + "zhongyan/zhdj/breakgame/images/breakGame/beginGame2rd.gif) center")
                $(".secondBg").css("background-size","cover")

//            }

            $(".gameStart,.firstBg,.secondBg,.ruleWindow").height($(window).height());



            $("#myMedia1").attr("src", imageRootPath+"zhongyan/zhdj/breakgame/images/breakGame/sound/startSound.mp3");
//            let myMedia1 = document.getElementById("myMedia1");
//            myMedia1.oncanplay = myMedia1.play();

//            window.onload=function(){
//                let myMedia1 = document.getElementById("myMedia1");
//                myMedia1.oncanplay = myMedia1.play();
//            }

//            setTimeout(function () {
//                document.addEventListener("WeixinJSBridgeReady", function () {
//                    alert('wx ready!');
//                }, false);
//            }, 10000)

            //inner 0 是内部人员
            //inner 1 是外部人员
            this.inner = sessionStorage.getItem("inner");
//            console.log("inner",this.inner);
            if(this.inner == 0){
                $(".inSide").css("display","block");
                $(".produceImg").css("display","none");
            }else if(this.inner == 1){
                $(".outSide").css("display","block");
            }

            //play audio
            let _self = this;
            let wx = Vue.wechat;
            wx.ready(function () {
                _self.playAudio();
            })

        }
    }
</script>

<style lang="less" scoped>


    .gameStart{

        width:100%;
        position:relative;

            .rule2Code{
                display:block;
                margin:0.2rem auto;
                width:1.5rem;
                height:1.5rem;
            }
            .firstBg{
                width:100%;
                position:absolute;
                z-index:150;
                background-size:100% 100%;
            }
            .secondBg{
                width:100%;
                position:absolute;
                z-index:100;
                display: none;
            }
            .topImg{
                background:url(../../assets/images/breakGame/topImg.png) no-repeat;
                background-size:100% 100%;
                height:2rem;
                width:5.5rem;
                margin-left:0.6rem;
                margin-top:0.45rem;

            }
            .topArea{
                width:100%;
            }
            .centerArea{
                position:relative;
            }
            .imgIcon{
                position:absolute;
                width:1.5rem;
                height:1.4rem;
                right:0.4rem;
                margin-top:0.1rem;
            }
            .imgIcon>img{
                height: 0.55rem;
                margin-top:0.2rem;
            }
            .bottomArea{
                position:absolute;
                bottom:0.25rem;
                width:100%;
            }
            .bottomArea>img{
                display:block;
            }
            .welcomeContent{
                background:url(../../assets/images/breakGame/welcomeContent.png) no-repeat;
                background-size:100% 100%;
                height:0.8rem;
                width:3.36rem;
                margin:0 auto;
            }
            .startBtn{
                height:0.71rem;
                margin:0.2rem auto;
            }
            .bottomRule{
                height:0.3rem;
                width:1.23rem;
                margin:0.2rem auto;
            }
            /*.produceImg{*/
                /*height:0.4rem;*/
                /*width:2.08rem;*/
                /*margin:0.2rem auto;*/
            /*}*/
            .ruleWindow{
                display:none;
                position:fixed;
                background-color:rgba(0,0,0,0.8);
                bottom:0;
                top:0;
                left:0;
                z-index:100;
                width:100%;
            }
            .ruleContent{
                position:relative;
                /*background:url(../../assets/images/breakGame/ruleWindow.png) no-repeat;*/
                background-repeat: no-repeat;
                background-size:100% 100%;
                width:7.4rem;
                height:9.62rem;
                margin:1rem auto;
                z-index:200;
            }
            .bottomBtn{
                background:url(../../assets/images/breakGame/btnImg.png) no-repeat;
                background-size:100% 100%;
                position:absolute;
                bottom:0;
                left:2.5rem;
                height:0.8rem;
                width:2.4rem;
                margin:0.3rem auto;
            }
            .bottomBtn>b{
                height:0.8rem;
                width:2.4rem;
                display:block;
                line-height:0.8rem;
                text-align:center;
                font-size:16px;
                color:#dc202a;
            }
            .ruleText{
                position:absolute;
                width:2rem;
                height:0.5rem;
                left:2.7rem;
                top:-0.3rem;

            }
            .ruleArea{
                height:7.6rem;
                width:6.4rem;
                overflow:auto;
                position: absolute;
                top: 0.66rem;
                left: 0.5rem;
            }
            .produceImg{
                display:block;
                margin:0 auto;
                height:0.54rem;
                width:3rem;
            }
            .outSide{
                display:none;
            }
            .inSide{
                display:none;
            }

            //移动端的滚动条清除
            ::-webkit-scrollbar{display:none;width: 0;height: 0;}

            .ruleArea>p{
                color:white;
                font-size:0.253rem;
                margin-top:0.2rem;
                line-height:0.36rem;
            }
            #leftFadeIn{
                animation-delay:2s;
                -webkit-animation-delay:2s;
            }
            @keyframes leftFadeIn
            {
                    from{opacity: 0;-webkit-transform: translate(100px, 0)}
                    to{opacity: 1;-webkit-transform: translate(0, 0)}
            }
            @-moz-keyframes leftFadeIn
            {
                from{opacity: 0;-webkit-transform: translate(100px, 0)}
                to{opacity: 1;-webkit-transform: translate(0, 0)}
            }
            @-ms-keyframes leftFadeIn
            {
                from{opacity: 0;-webkit-transform: translate(100px, 0)}
                to{opacity: 1;-webkit-transform: translate(0, 0)}
            }
            @-webkit-keyframes leftFadeIn
            {
                from{opacity: 0;-webkit-transform: translate(100px, 0)}
                to{opacity: 1;-webkit-transform: translate(0, 0)}
            }
            #beginFadeIn{
                animation-delay:2s;
                -webkit-animation-delay:2s;
            }
            @keyframes beginFadeIn{
                0%{opacity: 0};
                25%{opacity: 0};
                50%{opacity: 0};
                75%{opacity: 0.75};
                100%{opacity: 1};
            }

    }
</style>
