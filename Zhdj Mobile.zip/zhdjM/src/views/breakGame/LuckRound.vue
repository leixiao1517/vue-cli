<!--起始页开始-->
<template>

    <section class="luckRound">
        <img id="bgTreasureBox" style="" :src="imageRootPath + 'zhongyan/zhdj/breakgame/images/luckRound/luckRoundBg.gif'" alt="">

        <img src="../../assets/images/luckRound/luckBegin.png"  class="luckBegin1" @click="luckBegin1" style="z-index:299"/>
        <img src="../../assets/images/luckRound/luckBegin.png"  class="luckBegin2" @click="luckBegin2" style="z-index:298"/>
        <img src="../../assets/images/luckRound/luckBegin.png"  class="luckBegin3" @click="luckBegin3" style="z-index:297"/>

            <div class="equipmentWindow equipmentType1" style="display:none">
                    <img :src="imageRootPath + 'zhongyan/zhdj/breakgame/images/luckRound/theMedalInside.gif'" class="equipmentImg inSide"/>
                    <img :src="imageRootPath + 'zhongyan/zhdj/breakgame/images/luckRound/theMedalOutside.gif'" class="equipmentImg outSide"/>
                <div class="equipmentText">
                    <p>恭喜获得装备</p>
                    <p class="inSide"><b style="color:#ffff00">天天向上军功章1个</b></p>
                    <p class="outSide"><b style="color:#ffff00">军功章1个</b></p>
                    <p style="font-size:0.24rem">集齐3个不同装备可升旗一次</p>
                    <p>接下来您将进入&nbsp;&nbsp;<b style="color:#ffff00">改革开放时期</b></p>
                    <button class="equipmentBtn" @click="toRound2">继续闯关</button>
                </div>
            </div>
            <div class="equipmentWindow equipmentType1Fail" style="display:none">
                <div class="equipmentFail" :style="{backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/luckRound/equipmentFailBg.png)'}">
                    <div class="equipmentFailText">
                        <h4>很遗憾,获取装备失败</h4>
                        <p>革命尚未成功，同志仍需努力</p>
                    </div>
                    <div class="equipmentFailBtn" @click="toRound2">
                        <p>继续闯关</p>
                    </div>
                </div>
            </div>

            <div class="equipmentWindow equipmentType2" style="display:none">
                <img :src="imageRootPath + 'zhongyan/zhdj/breakgame/images/luckRound/theCrownInside.gif'" class="equipmentImg inSide"/>
                <img :src="imageRootPath + 'zhongyan/zhdj/breakgame/images/luckRound/theCrownOutside.gif'" class="equipmentImg outSide"/>
                <div class="equipmentText">
                    <p>恭喜获得装备</p>
                    <p class="inSide"><b style="color:#ffff00">芙蓉王皇冠1个</b></p>
                    <p class="outSide"><b style="color:#ffff00">皇冠1个</b></p>
                    <p style="font-size:0.24rem">集齐3个不同装备可升旗一次</p>
                    <p>接下来您将&nbsp;&nbsp;<b style="color:#ffff00">走进新时代</b></p>
                    <button class="equipmentBtn" @click="toRound3">继续闯关</button>
                </div>
            </div>
            <div class="equipmentWindow equipmentType2Fail" style="display:none">
                <div class="equipmentFail" :style="{backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/luckRound/equipmentFailBg.png)'}">
                    <div class="equipmentFailText">
                        <h4>很遗憾,获取装备失败</h4>
                        <p>革命尚未成功，同志仍需努力！</p>
                    </div>
                    <div class="equipmentFailBtn" @click="toRound3">
                        <p>继续闯关</p>
                    </div>
                </div>
            </div>

            <div class="equipmentWindow equipmentType3" style="display:none">
                <img :src="imageRootPath + 'zhongyan/zhdj/breakgame/images/luckRound/theAirCraftInside.gif'" class="equipmentImg inSide"/>
                <img :src="imageRootPath + 'zhongyan/zhdj/breakgame/images/luckRound/theAirCraftOutside.gif'" class="equipmentImg outSide"/>
                <div class="equipmentText">
                    <p>恭喜获得装备</p>
                    <p class="inSide"><b style="color:#ffff00">和天下航母通行证1个</b></p>
                    <p class="outSide"><b style="color:#ffff00">航母通行证1个</b></p>
                    <p style="font-size:0.24rem">集齐3个不同装备可升旗一次</p>
                    <p><b style="color:#ffff00">幸福都是奋斗出来的！</b></p>
                    <button class="toGameStart" @click="toUrl('gameStart')">重新闯关</button>
                    <button class="toUserInfo" @click="toUrl('gameUserInfo')">个人中心</button>
                </div>
            </div>
            <div class="equipmentWindow equipmentType3Fail" style="display:none">
                <div class="equipmentFail" :style="{backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/luckRound/equipmentFailBg.png)'}">
                    <div class="equipmentFailText">
                        <h4>很遗憾,获取装备失败</h4>
                        <p>革命尚未成功，同志仍需努力！</p>
                    </div>
                    <div class="equipmentFailBtn" @click="toUrl('gameStart')">
                        <p>重新闯关</p>
                    </div>
                </div>
            </div>

            <div class="equipmentWindow equipmentTypeFirst" style="display:none">
                <div class="equipmentFail" :style="{backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/luckRound/equipmentFailBg.png)'}">
                    <div class="equipmentFailText">
                        <h4>温馨提示</h4>
                        <p>您已集齐3个装备，可以通过个人中心进行升旗</p>
                    </div>
                    <div class="equipmentFailBtn" @click="closeAlertFrist">
                        <p>知道了</p>
                    </div>
                </div>
            </div>

    </section>

</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import { Badge  } from 'vux'
    import { imageRootPath } from '../../config/config'
    export default {
        components: {
            checkGetEquipmentR1:'',
            checkGetEquipmentR2:'',
            checkGetEquipmentR3:'',
            correctR1:'',
            correctR2:'',
            correctR3:'',
            updateRestCount:'',

        },
        data () {
            return {
                imageRootPath

            }
        },
        methods: {

            toUrl:function(enterUrl){
                this.$router.push("/" + enterUrl)
                $(".equipmentType3").css("display","none");
                $(".luckRound").css("display","none");
            },
            luckBegin1:function(){
                let _self = this;

                this.updateRestCount = sessionStorage.getItem("updateRestCount");
                this.checkGetEquipmentR1 = sessionStorage.getItem("checkGetEquipmentR1");
                this.firstFlag = sessionStorage.getItem("firstFlag");
                if(this.checkGetEquipmentR1 == -1){
                    $('.equipmentType1').css("z-index","-100");
                    $(".equipmentType1Fail").css("display","block");

                    //挖宝失败的音乐
                    let getEquipmentFailMusic = _self.GLOBAL.getAudioElement("getEquipmentFailMusic");
                    getEquipmentFailMusic.currentTime = 0;
                    getEquipmentFailMusic.oncanplay = getEquipmentFailMusic.play();

                }else if(this.checkGetEquipmentR1 == 1){
                    $('.equipmentType1Fail').css("z-index","-100");
                    $(".equipmentType1").css("display","block");

                    //挖宝成功的音乐
                    let getEquipmentSuccMusic = _self.GLOBAL.getAudioElement("getEquipmentSuccMusic");
                    getEquipmentSuccMusic.currentTime = 0;
                    getEquipmentSuccMusic.oncanplay = getEquipmentSuccMusic.play();
                }
                if(this.firstFlag == 1){
                    $(".equipmentTypeFirst").css("display","block");
                }
            },
            luckBegin2:function(){
                let _self = this;
                this.checkGetEquipmentR2 = sessionStorage.getItem("checkGetEquipmentR2");
                this.firstFlag = sessionStorage.getItem("firstFlag");
                if(this.checkGetEquipmentR2 == -1){
                    $('.equipmentType2').css("z-index","-100");
                    $(".equipmentType2Fail").css("display","block");

                    //挖宝失败的音乐
                    let getEquipmentFailMusic = _self.GLOBAL.getAudioElement("getEquipmentFailMusic");
                    getEquipmentFailMusic.currentTime = 0;
                    getEquipmentFailMusic.oncanplay = getEquipmentFailMusic.play();

                }else if(this.checkGetEquipmentR2 == 1){
                    $('.equipmentType2Fail').css("z-index","-100");
                    $(".equipmentType2").css("display","block");

                    //挖宝成功的音乐
                    let getEquipmentSuccMusic = _self.GLOBAL.getAudioElement("getEquipmentSuccMusic");
                    getEquipmentSuccMusic.currentTime = 0;
                    getEquipmentSuccMusic.oncanplay = getEquipmentSuccMusic.play();
                }
                if(this.firstFlag == 1){
                    $(".equipmentTypeFirst").css("display","block");
                }
            },
            luckBegin3:function(){
                let _self = this;
                this.checkGetEquipmentR3 = sessionStorage.getItem("checkGetEquipmentR3");
                this.firstFlag = sessionStorage.getItem("firstFlag");
                if (this.checkGetEquipmentR3 == -1) {
                    $('.equipmentType3').css("z-index", "-100");
                    $(".equipmentType3Fail").css("display", "block");

                    //挖宝失败的音乐
                    let getEquipmentFailMusic = _self.GLOBAL.getAudioElement("getEquipmentFailMusic");
                    getEquipmentFailMusic.currentTime = 0;
                    getEquipmentFailMusic.oncanplay = getEquipmentFailMusic.play();
                }
                else if (this.checkGetEquipmentR3 == 1) {
                    $('.equipmentType3Fail').css("z-index", "-100");
                    $(".equipmentType3").css("display", "block");

                    //挖宝成功的音乐
                    let getEquipmentSuccMusic = _self.GLOBAL.getAudioElement("getEquipmentSuccMusic");
                    getEquipmentSuccMusic.currentTime = 0;
                    getEquipmentSuccMusic.oncanplay = getEquipmentSuccMusic.play();
                }

                if(this.firstFlag == 1){
                    $(".equipmentTypeFirst").css("display","block");
                }
            },
            toRound2:function(){
                $(".equipmentType1").css("display","none");
                $(".equipmentType1Fail").css("display","none");
                $(".luckRoundBox").css("display","none");
                $(".luckBegin1").css("display","none");
                $(".allowUp").css("display","block");
                $(".showAlertR1").fadeOut();
                let round1 = $(".round1").height();
                $(".round1").animate({marginTop: (-1 * round1) + 'px'},500,"linear", function() {
                    $(this).hide()
                });
            },
            toRound3:function(){
                $(".equipmentType2").css("display","none");
                $(".equipmentType2Fail").css("display","none");
                $(".luckRoundBox").css("display","none");
                $(".luckBegin2").css("display","none");
                $(".allowUp").css("display","block");
                $(".showAlertR2").fadeOut();
                let round2 = $(".round2").height()
                $(".round2").animate({marginTop: (-1 * round2) + 'px'},500,"linear", function() {
                    $(this).hide()
                });
            },
            closeAlertFrist:function(){
                $(".equipmentTypeFirst").css("display","none");
            },
            refreshImg: function () {//让gif重新播放
                let TreasureBoxImg = new Image()
                TreasureBoxImg.onload = function () {
                    let TreasureBox =  document.getElementById('bgTreasureBox')
                    TreasureBox.stop()
                    TreasureBox.play()
                }
                TreasureBoxImg.src = imageRootPath + 'zhongyan/zhdj/breakgame/images/luckRound/luckRoundBg.gif'
            }
        },
        mounted () {
            $(".luckRound,.equipmentWindow").height($(window).height());
//            $(".luckRound").css("background","url(" + imageRootPath + "zhongyan/zhdj/breakgame/images/luckRound/luckRoundBg.gif" + ") center")
//            $(".luckRound").css("background-size","cover")

//            this.refreshImg()


            //本地获取inner方法
            let _self = this;
            _self.inner = sessionStorage.getItem('inner');
            if(this.inner == 0){
                $(".inSide").css("display","block");
            }else if
            (this.inner == 1){
                $(".outSide").css("display","block");
            }
        },
        beforeDestroy: function () {
            let _self = this;

            let getEquipmentFailMusic = _self.GLOBAL.getAudioElement("getEquipmentFailMusic");
            getEquipmentFailMusic.pause();

            let getEquipmentSuccMusic = _self.GLOBAL.getAudioElement("getEquipmentSuccMusic");
            getEquipmentSuccMusic.pause();
        },
    }
</script>

<style lang="less">

            /* 1.56*height=width */
            /*4.48rem height 7rem wdith*/
    .luckRound{
            position:relative;

            #bgTreasureBox{
                position: fixed;
                width: 100%;
                height: 100%;
                pointer-events: none;
            }

        .luckBegin1,.luckBegin2,.luckBegin3{
            height:1rem;
            width:2.58rem;
            position:absolute;
            bottom:2.2rem;
            left:2.45rem;
        }
        .equipmentWindow{
            position:fixed;
            background-color:rgba(0,0,0,0.7);
            top:0;
            left:0;
            width:100%;
            z-index:300;
        }
        .equipmentImg{
            width:7rem;
            height:7rem;
            display:block;
            margin:0 auto;
        }
        .equipmentText{
            height:5.6rem;
            width:7rem;
            color:white;
            text-align:center;
            margin:0 auto;
            position:relative;
        }
        .equipmentText>p{
            margin-top:0.4rem;
            font-size:0.3rem;
            font-weight:bold;
        }
        .equipmentBtn{
            margin-top:0.3rem;
            height:0.8rem;
            width:2.4rem;
            border:2px solid #c3373a;
            color:#c3373a;
            border-radius:5px;
            background-color:white;
        }
        .toUserInfo{
            margin-top:0.3rem;
            height:0.8rem;
            width:2.4rem;
            border:2px solid #c3373a;
            color:#c3373a;
            border-radius:5px;
            margin-left:0.3rem;
            background-color:white;
        }
        .toGameStart{
            margin-top:0.3rem;
            height:0.8rem;
            width:2.4rem;
            border:2px solid #c3373a;
            background-color:white;
            color:#c3373a;
            border-radius:5px;
        }
        .equipmentFail{
            /*background:url(../../assets/images/luckRound/equipmentFailBg.png) no-repeat;*/
            background-repeat: no-repeat;
            background-size:100% 100%;
            width:7rem;
            height:4.92rem;
            display:block;
            margin:2.7rem auto;
            position:relative;
        }
        .equipmentFailBtn{
            background:url(../../assets/images/luckRound/btnImg.png) no-repeat;
            background-size:cover;
            width:2.4rem;
            height:0.8rem;
            position:absolute;
            bottom:0.33rem;
            left:2.3rem;
        }
        .equipmentFailBtn>p{
            height:0.8rem;
            line-height:0.8rem;
            font-size:0.30rem;
            text-align:center;
            width:2.4rem;
            color:#c3373a;
        }
        .equipmentFailText{
            position:absolute;
            top:1.4rem;
            left:0.3rem;
            color:white;
            width:6.4rem;
            height:3rem;
        }
        .equipmentFailText>h4{
            text-align:center;
            font-size:0.33rem;
            height:0.8rem;
            line-height:0.8rem;
        }
        .equipmentFailText>p{
            text-align:center;
            font-size:0.27rem;
            height:0.5rem;
            line-height:0.5rem;
            margin-top:0.33rem
        }
        .inSide{
            display:none;
        }
        .outSide{
            display:none;
        }
    }

</style>
