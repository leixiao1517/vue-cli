<!--起始页开始-->
<template>

    <section class="gameUserInfo">
        <div class="userTop">
            <div class="userImg">
                <div class="turnBack" @click="toUrl('gameStart')"><img src="../../assets/images/gameUser/turnBack.png"/><b>首页</b></div>
                <img :src="gameUserInfo.headImg" class="userImg"/>
                <b>{{ gameUserInfo.userName }}</b>
            </div>
            <div class="topRule">
                <b @click="openRule">闯关规则</b>
            </div>
        </div>
        <div class="maxPlayer">
            <b><span style="color:#e0242e">{{ gameUserInfo.totalPeople }}</span><span style="color:#323232">人参与闯关赛</span></b>
        </div>
        <div class="centerArea">
            <div class="score">
                <div class="score1">
                    <div class="bestScore">
                        <img src="../../assets/images/gameUser/bestImg.png" class="bestImg">
                        <div class="bestBox">
                            <p>答对:<span style="color:#e0242e">{{gameUserInfo.score}}</span>题</p>
                            <p>用时:<span style="color:#e0242e">{{minutes}}</span>分<span style="color:#e0242e">{{seconds}}</span>秒</p>
                        </div>
                        <b>成绩排名 : {{scoreRownum}}</b>
                    </div>
                </div>
                <div class="score2">
                    <div class="allHost">
                        <img src="../../assets/images/gameUser/allHostImg.png" class="allHostImg">
                        <p>{{gameUserInfo.flagCount}}</p>
                        <b>升旗排名 : {{flagRownum}}</b>
                    </div>
                </div>
            </div>

            <div class="allRank" @click="toUrl('rank')"></div>

            <div class="equipBox">
                <img src="../../assets/images/gameUser/myEquipImg.png" class="myEquip">
            </div>
            <div class="equipCount">
                <div class="type1">
                    <img src="../../assets/images/gameUser/type1.png" class="typeImg inSide" style="height:1.2rem">
                    <img src="../../assets/images/gameUser/type1Out.png" class="typeImg outSide" style="height:1.2rem">
                    <b>{{gameUserInfo.medal}}</b>
                </div>
                <div class="type2">
                    <img src="../../assets/images/gameUser/type2.png" class="typeImg inSide" style="height:1.2rem">
                    <img src="../../assets/images/gameUser/type2Out.png" class="typeImg outSide" style="height:1.2rem">
                    <b>{{gameUserInfo.crown}}</b>
                </div>
                <div class="type3">
                    <img src="../../assets/images/gameUser/type3.png" class="typeImg inSide" style="height:1.2rem">
                    <img src="../../assets/images/gameUser/type3Out.png" class="typeImg outSide" style="height:1.2rem">
                    <b>{{gameUserInfo.passport}}</b>
                </div>
            </div>
        </div>
        <img src="../../assets/images/gameUser/hostBtn.png" class="hostBtn" @click="inspectFlag">
        <p class="bottomText">集齐三个不同装备可升旗一次呦！</p>

        <div class="flagAlertWindow enough">
            <div class="flagAlertBox">
                <div>
                    <p><b>很遗憾！装备不足！</b></p>
                    <p>请返回首页继续答题，集齐3个不同装备再来升旗哟~</p>
                    <p style="margin-top:0.9rem">
                        <button class="closeAlert" @click="closeFlagAlert">知道了</button>
                    </p>
                </div>
            </div>
        </div>

        <div class="ruleWindow" >
            <!--内部版本规则说明-->
            <div class="ruleContent inSide" :style="{backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/breakGame/ruleWindow.png)'}">
                <img src="../../assets/images/breakGame/ruleText.png" class="ruleText"/>
                <div class="ruleArea">
                    <p>1.活动时间：7月1日-7月31日，期间可无限次数进入闯关答题；</p>
                    <p>2.单轮闯关共有三关，三关的答对题数之和，答题时间之和，即为本轮闯关成绩；</p>
                    <p>3.每一关均随机抽取10题，正确率≥80%，则可进入下一关，否则需要重新开始闯关；正确率=100%，则进入和+生态圈地图，一定几率抽取本关的闯关装备；</p>
                    <p>4.每集齐三关装备，可点击头像进入个人中心升旗一次，每日升旗次数不限；</p>
                    <p>5.实时排行榜分为:</p>
                    <p>和+先锋榜:按个人闯关最优成绩排行</p>
                    <p>和+灯塔榜:按个人升旗次数排行</p>
                    <p>和+堡垒榜:按单位升旗总数排行</p>
                    <p>和+琅琊榜:按单位闯关参与率排行</p>
                    <p>6.奖项设置:</p>
                    <p>详见 (智慧党建) 企业号历史文章（链接）。</p>
                    <p>7.活动结束后，将根据最终的排行榜确认各大奖项，请关注 (湖南中烟) 企业号，获取最新信息。</p>
                    <img src="../../assets/images/breakGame/twoCodeInside.jpg" class="rule2Code"/>
                </div>
                <div class="bottomBtn" @click="closeRule"><b>确定</b></div>
            </div>

            <!--外部版本规则说明-->
            <div class="ruleContent outSide" :style="{backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/breakGame/ruleWindow.png)'}">
                <img src="../../assets/images/breakGame/ruleText.png" class="ruleText"/>
                <div class="ruleArea">
                    <p>1、活动时间：7月1日-7月31日，不限次数闯关；</p>
                    <p>2、闯关赛共三关，每关3题，全部正确即可获取装备，否则直接进入下一关；</p>
                    <p>3、每集齐3个不同装备，可进入个人中心升旗一次；</p>
                    <p>4、排行榜按个人升旗次数进行实时排行；</p>
                    <p>5、奖项设置：</p>
                    <p>一等奖：3名（排行榜第1-3名）</p>
                    <p>二等奖：20名（排行榜第4-23名）</p>
                    <p>三等奖：50名（排行榜第24-73名）</p>
                    <p>6、活动结束后，将根据最终的排行榜确认奖项并发放奖品，请关注(天下和书院)微信公众号，获取最新信息。</p>
                    <img src="../../assets/images/breakGame/twoCodeOutside.jpg" class="rule2Code"/>
                </div>
                <div class="bottomBtn" @click="closeRule"><b>确定</b></div>
            </div>
        </div>
    </section>

</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import { Badge  } from 'vux'
    import { imageRootPath } from '../../config/config'
    import { getUserEquipmentByUid,hoistFlag } from '../../api/api'
    export default {
        components: {},
        data() {
            return {
                gameUserInfo: '',
                spendTime: '',
                minutes: '',
                seconds: '',
                flagRownum:'',
                scoreRownum:'',
                imageRootPath
            }
        },
        methods: {
            toUrl: function (enterUrl) {
                this.$router.push("/" + enterUrl)
            },
            openRule: function () {
                $(".ruleWindow").fadeIn();
            },
            closeRule: function () {
                $(".ruleWindow").fadeOut();
            },
            inspectFlag:function(){
                if(this.gameUserInfo.restCount > 0){
                    this.$router.push("/hostFlag");
                }else if(this.gameUserInfo.restCount == 0){
                    $(".flagAlertWindow").fadeIn();
                }
            },
            closeFlagAlert:function(){
                $(".flagAlertWindow").fadeOut();
            }
        },
        mounted() {
            //stop audio
            let audio = this.GLOBAL.getAudioEle();
            audio.pause();

            $('.gameUserInfo,.ruleWindow,.flagAlertWindow').height($(window).height());
            let _self = this;
            getUserEquipmentByUid({rid: this.rid}).then((response) => {
//                console.log(response);
                _self.gameUserInfo = response.data.user;
                _self.spendTime = response.data.user.useTime;
                _self.minutes = parseInt((this.spendTime % (1000 * 60 * 60)) / (1000 * 60));
                _self.seconds = parseInt((this.spendTime % (1000 * 60)) / 1000);
                _self.scoreRownum = response.data.scoreRownum;
                _self.flagRownum = response.data.flagRownum;
            })
            this.inner = sessionStorage.getItem("inner");
            if (this.inner == 1) {
                $(".score1").css("display", "none");
                $(".outSide").css("display","block");
                $(".inSide").css("display","none");
            }
            else if(this.inner == 0){
                $(".outSide").css("display","none");
                $(".inSide").css("display","block");
            }
        },
    }
</script>

<style lang="less">


    .gameUserInfo {


        background-color: #ebe8da;

        .rule2Code {
            display: block;
            margin: 0.2rem auto;
            width: 1.5rem;
            height: 1.5rem;
        }
        .userTop {
            height: 1rem;
            width: 100%;
        }
        .userImg {
            float: left;
            height: 1rem;
        }
        .userImg > b {
            font-size: 0.32rem;
            line-height: 1rem;
            margin-left: 0.2rem;
            font-weight: normal;
        }
        .userImg > img {
            height: 0.9rem;
            width: 0.9rem;
            margin-top: 0.05rem;
            margin-left: 0.2rem;
            border-radius: 50%;
        }
        .topRule {
            float: right;
            height: 0.9rem;
            position: relative;
        }
        .topRule > b {
            position: absolute;
            right: 0;
            top: 0;
            font-size: 0.27rem;
            width: 1.9rem;
            height: 0.7rem;
            line-height: 0.7rem;
            text-align: center;
            margin-top: 0.15rem;
            margin-right: 0.2rem;
            background: url(../../assets/images/gameUser/userRule.png) no-repeat;
            background-size: 100% 100%;
            color: #e0242e;
        }
        .centerArea {
            background: url(../../assets/images/gameUser/tree.png) no-repeat;
            background-size: 3rem 3rem;
            background-position: 2.35rem 0.3rem;
        }
        .maxPlayer {
            height: 0.8rem;
            width: 6.8rem;
            display: block;
            margin: 0.04rem auto;
            background: url(../../assets/images/gameUser/countBg.png) no-repeat;
            background-size: 100% 100%;
            border-radius: 3px;
            line-height: 0.8rem;
            text-align: center;
            font-size: 16px;
        }
        .score {
            margin-top: 0.2rem;
            display: flex;
            height: 2.7rem;
            width: 100%;
        }
        .score1 {
            flex: 1;
            height: 2.7rem;
        }
        .score2 {
            flex: 1;
            height: 2.7rem;
        }
        .bestScore {
            height: 100%;
            width: 3rem;
            margin: 0 auto;
        }
        .allHost {
            height: 100%;
            width: 3rem;
            margin: 0 auto;
        }
        .bestImg {
            height: 0.42rem;
            margin-left: 0.5rem;
        }
        .allHostImg {
            height: 0.42rem;
            margin-left: 0.5rem;
        }
        .bestScore > .bestBox > p {
            padding-top: 0.3rem;
            text-align: center;
            line-height: 0.3rem;
            font-size: 0.33rem;
        }
        .bestBox {
            height: 1.5rem;
            width: 100%;
        }
        .bestScore > b {
            text-align: center;
            line-height: 0.6rem;
            font-size: 0.33rem;
            width: 100%;
            height: 0.6rem;
            display: inline-block;
            background-color: #df252d;
            color: white;
            font-weight: normal;
            border-radius: 4px;
        }
        .allHost > p {
            height: 1.5rem;
            line-height: 1.5rem;
            font-size: 0.5rem;
            color: #df252d;
            text-align: center;
        }
        .allHost > b {
            margin-bottom: 1px;
            text-align: center;
            line-height: 0.6rem;
            font-size: 0.33rem;
            width: 100%;
            height: 0.6rem;
            display: inline-block;
            background-color: #df252d;
            color: white;
            font-weight: normal;
            border-radius: 4px;
        }
        .allRank {
            width: 7.04rem;
            height: 0.8rem;
            display: block;
            margin: 0.025rem auto;
            background:url(../../assets/images/gameUser/allRank.png) no-repeat;
            background-size:100% 100%;

        }
        .equipBox {
            width: 100%;
            margin-top: 0.2rem;
        }
        .myEquip {
            height: 0.45rem;
            width: 4rem;
            margin: 0 auto;
            display: block;
        }
        .equipCount {
            display: flex;
            margin-top: 0.2rem;
        }
        .equipCount > div {
            flex: 1;
            height: 2.3rem;
        }
        .equipCount > div > b {
            height: 0.6rem;
            width: 1rem;
            background-color: white;
            font-weight: normal;
            display: block;
            margin: 0.15rem auto;
            line-height: 0.6rem;
            text-align: center;
            font-size: 0.33rem;

        }
        .typeImg {
            display: block;
            margin: 0.1rem auto;
            position: relative;
            /*z-index:200;*/
        }
        .hostBtn {
            display: block;
            width: 1.6rem;
            height: 1.6rem;
            margin: 0 auto;
        }
        .bottomText {
            font-size: 0.33rem;
            text-align: center;
            margin-top: 0.2rem;
            color: #e0242e;
        }
        .ruleWindow {
            display: none;
            position: fixed;
            background-color: rgba(0, 0, 0, 0.8);
            bottom: 0;
            top: 0;
            left: 0;
            z-index: 100;
            width: 100%;
        }
        .ruleContent {
            position: relative;
            /*background: url(../../assets/images/breakGame/ruleWindow.png) no-repeat;*/
            background-repeat: no-repeat;
            background-size: 100% 100%;
            width: 7.4rem;
            height: 9.62rem;
            margin: 1rem auto;
            z-index: 200;
        }
        .bottomBtn {
            background: url(../../assets/images/breakGame/btnImg.png) no-repeat;
            background-size: 100% 100%;
            position: absolute;
            bottom: 0;
            left: 2.5rem;
            height: 0.8rem;
            width: 2.4rem;
            margin: 0.3rem auto;
        }
        .bottomBtn > b {
            height: 0.8rem;
            width: 2.4rem;
            display: block;
            line-height: 0.8rem;
            text-align: center;
            font-size: 16px;
            color: #dc202a;
        }
        .ruleText {
            position: absolute;
            width: 2rem;
            height: 0.5rem;
            left: 2.7rem;
            top: -0.3rem;
        }
        .ruleArea {
            height: 7.6rem;
            width: 6.4rem;
            overflow: auto;
            position: absolute;
            top: 0.66rem;
            left: 0.5rem;
        }

        //移动端的滚动条清除
        ::-webkit-scrollbar {
            display: none;
            width: 0;
            height: 0;
        }

        .ruleArea > p {
            color: white;
            font-size: 0.253rem;
            margin-top: 0.2rem;
            line-height:0.36rem;
        }
        .turnBack {
            display: inline-block;
            float: left;
            height: 1rem;
            position: relative;
            margin-left: 0.33rem;
        }
        .turnBack > b {
            text-align: center;
            line-height: 1rem;
            font-size: 0.3rem;
            margin-left: 0.27rem;
            color: #d51924;
            font-weight: normal;
            border-bottom: 1px solid #d51924;
        }
        .turnBack > img {
            position: absolute;
            height: 0.3rem;
            width: 0.18rem;
            top: 0.35rem;
        }
        .outSide {
            display: none;
        }
        .inSide {
            display: none;
        }
        .flagAlertWindow {
            position: fixed;
            background-color: rgba(0, 0, 0, 0.7);
            top: 0;
            left: 0;
            width: 100%;
            z-index: 300;
            display:none;
        }
        .flagAlertBox {
            background: url(../../assets/images/hostFlag/flagAlertBg.png) no-repeat;
            background-size: cover;
            width: 7rem;
            height: 5.2rem;
            display: block;
            margin: 3rem auto;
            z-index: 350;
            position: relative;
        }
        .flagAlertBox > div {
            display: block;
            width: 6.4rem;
            margin-left: 0.3rem;
            height: 2.4rem;
            position: absolute;
            top: 1.3rem;
            color: white;

        }
        .flagAlertBox > div > p {
            text-align: center;
            margin-top: 0.3rem;
        }
        .flagAlertBox > div > p > b {
            font-size: 0.3rem;
        }
        .closeAlert {
            background: url(../../assets/images/hostFlag/btn.png) no-repeat;
            background-size: 100% 100%;
            height: 0.8rem;
            width: 1.6rem;
            color: #c3373a;
            text-align: center;
            line-height: 0.8rem;

        }
    }

</style>
