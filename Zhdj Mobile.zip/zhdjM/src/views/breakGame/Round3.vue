<!--起始页开始-->
<template>

    <section class="thirdStage">
        <div id="swiper3" class="swiper-container round3Window">
            <div class="swiper-wrapper thirdWindow">
                <!-- 第一页 -->
                <div class="swiper-slide stage3Bg1" :style="{width:'100%',backgroundImage:'url(' + imageRootPath + 'zhongyan/zhdj/breakgame/images/gameRound/07.gif)'}">

                </div>
                <!-- 第二页 -->
                <div class="swiper-slide stage3Bg2" :style="{width:'100%',backgroundImage:'url(' + imageRootPath + 'zhongyan/zhdj/breakgame/images/gameRound/08.gif)'}">
                    <button class="alertR3" @click="openAlertR3"></button>
                </div>
                <div class="swiper-pagination"></div>
            </div>
            <div class="showAlertR3">
                <!--确认开始答题-->
                <div class="alertStatus answerR3Begin" :style="{backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/gameRound/beginAnswer.png)'}">
                    <!--======================-->
                    <div class="statusBox inSide">
                        <h5>答题开始确认</h5>
                        <b class="centerText">本关共10题，正确率≥80%即进入下一关，否则需重新闯关。确定开启本关？</b>
                        <div class="readyBottom" @click="gameBeginInSide"><span>确定</span></div>
                    </div>
                    <!--======================-->
                    <div class="statusBox outSide">
                        <h5>答题开始确认</h5>
                        <b class="centerText">本关共3题，全部答对才能获取闯关装备，否则直接进入下一关。确定开启本关？</b>
                        <div class="readyBottom" @click="gameBeginOutSide"><span>确定</span></div>
                    </div>
                    <!--========================-->
                    <img src="../../assets/images/gameRound/closeWindow.png" class="closeWindow"    @click="closeAlertR3"/>
                </div>

                <!--答题闯关成功-->
                <div class="alertStatus answerR3Success" :style="{display:'none',backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/gameRound/beginAnswer.png)'}">
                    <!--========================-->
                    <div class="statusBox inSide">
                        <h5>恭喜您！闯关成功！</h5>
                        <b class="centerText">厉害了，我的国！</b>
                        <h4><i>答对:{{this.correctR3}}题</i></h4>
                        <b class="centerText">幸福都是奋斗出来的！</b>
                        <b class="centerText" style="font-size:0.27rem"><i>本轮总成绩：{{totalCorrectNum}}题</i>&nbsp;&nbsp;&nbsp;<i>{{t3}}</i></b>
                        <span>
                        <div class="round3EndBottom left" @click="toUrl('gameStart')"><span>再次闯关</span></div>
                        <div class="round3EndBottom right" @click="toUrl('gameUserInfo')"><span>个人中心</span></div>
                        </span>
                    </div>
                    <!--========================-->
                    <div class="statusBox outSide">
                        <h5>很遗憾，闯关失败！</h5>
                        <b class="centerText">未全部答对，本次闯关结束</b>
                        <b class="centerText">幸福都是奋斗出来的！</b>
                        <span>
                        <div class="round3EndBottom left" @click="toUrl('gameStart')"><span>再次闯关</span></div>
                        <div class="round3EndBottom right" @click="toUrl('gameUserInfo')"><span>个人中心</span></div>
                        </span>
                    </div>
                </div>

                <!--答题闯关失败-->
                <div class="alertStatus answerR3Fail" :style="{display:'none',backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/gameRound/beginAnswer.png)'}">
                    <div class="statusBox">
                        <h5>很遗憾，闯关失败！</h5>
                        <h4><i>答对:{{this.correctR3}}题</i>&nbsp;&nbsp;&nbsp;&nbsp;<i>用时:{{t3}}</i></h4>
                        <b class="centerText">正确率不足80%，好好学习，天天向上</b>
                        <div class="readyBottom" @click="toUrl('gameStart')"><span>重新闯关</span></div>
                    </div>
                </div>

                <!--完美答题(100%)-->
                <div class="alertStatus answerR3Perfect" :style="{display:'none',backgroundImage:'url('+imageRootPath+'zhongyan/zhdj/breakgame/images/gameRound/beginAnswer.png)'}">
                    <!--========================-->
                    <div class="statusBox inSide">
                        <h5>恭喜您！闯关成功！</h5>
                        <b class="centerText">厉害了，我的国！</b>
                        <h4><i>答对:{{this.correctR3}}题</i></h4>
                        <b class="centerText">全部正确，可进入和+生态圈获取装备</b>
                        <b class="centerText" style="font-size:0.27rem;font-weight:bolder"><i>本轮总成绩：{{totalCorrectNum}}题</i>&nbsp;&nbsp;&nbsp;<i>{{t3}}</i></b>
                        <div class="readyBottom" @click="getEquipment"><span>获取装备</span></div>
                    </div>
                    <!--========================-->
                    <div class="statusBox outSide">
                        <h5>恭喜您！闯关成功！</h5>
                        <b class="centerText">厉害了，我的国！</b>
                        <b class="centerText">全部正确，可进入和+生态圈获取装备</b>
                        <div class="readyBottom" @click="getEquipment"><span>获取装备</span></div>
                    </div>
                    <!--========================-->
                </div>

                <!--====================-->
                <div class="contentAlert inSideQuestion">
                    <div class="questionTop">
                        <b class="questionNur">第 {{ curIndexR3 + 1 }} / 10 题</b>
                        <b class="timer">{{ t3 }}</b>
                        <img src="../../assets/images/gameRound/timeIcon.png"/>
                    </div>
                    <div class="questionCenter">
                        <b>{{ curContentR3.title }}</b>
                        <div class="answerList" style="margin-top:0.3rem;" @click="nextTitle(1)" v-if="curContentR3.optionA != null"><span>A.{{ curContentR3.optionA }}</span></div>
                        <div class="answerList" style="margin-top:0.3rem;" @click="nextTitle(2)" v-if="curContentR3.optionB != null"><span>B.{{ curContentR3.optionB }}</span></div>
                        <div class="answerList" style="margin-top:0.3rem;" @click="nextTitle(3)" v-if="curContentR3.optionC != null"><span>C.{{ curContentR3.optionC }}</span></div>
                    </div>
                    <div class="questionBottom">
                        <div style="padding-top:0.3rem"></div>
                        <div class="answerList" @click="nextTitle(4)" v-if="curContentR3.optionD != null"><span>D.{{ curContentR3.optionD }}</span></div>
                    </div>
                        <img src="../../assets/images/gameRound/round3Title.png" class="roundTitle"/>
                </div>
                <!--=======================-->
                <div class="contentAlert outSideQuestion">
                    <div class="questionTop">
                        <b class="questionNur">第 {{ curIndexR3 + 1 }} / 3 题</b>
                        <b class="timer">{{ t3 }}</b>
                        <img src="../../assets/images/gameRound/timeIcon.png"/>
                    </div>
                    <div class="questionCenter">
                        <b>{{ curContentR3.title }}</b>
                        <div class="answerList" style="margin-top:0.3rem;" @click="nextTitle(1)" v-if="curContentR3.optionA != null"><span>A.{{ curContentR3.optionA }}</span></div>
                        <div class="answerList" style="margin-top:0.3rem;" @click="nextTitle(2)" v-if="curContentR3.optionB != null"><span>B.{{ curContentR3.optionB }}</span></div>
                        <div class="answerList" style="margin-top:0.3rem;" @click="nextTitle(3)" v-if="curContentR3.optionC != null"><span>C.{{ curContentR3.optionC }}</span></div>
                    </div>
                    <div class="questionBottom">
                        <div style="padding-top:0.3rem"></div>
                        <div class="answerList" @click="nextTitle(4)" v-if="curContentR3.optionD != null"><span>D.{{ curContentR3.optionD }}</span></div>
                    </div>
                    <img src="../../assets/images/gameRound/round3Title.png" class="roundTitle"/>
                </div>
                <!--==========================-->

            </div>
        </div>
    </section>
</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import { Badge  } from 'vux'
    import { imageRootPath } from '../../config/config'
//    import Swiper from 'swiper';
    import Swiper from '../../../static/zhongyan/zhdj/breakgame/swiper-4.3.3.min'

    import {stageCommit} from '../../api/api'

    export default {
        components: {

        },
        props:['totalCorrectNum', 'inner'],
        data () {
            return {
                swiper3:{},
                spendT3:'',
                t1:'',
                t2:'',
                t3:'',
                s:'',
                m:'',
                runid:undefined,
                topicContentR3:['title','optionA','optionB','optionC','optionD'],
                curContentR3:[],
                curIndexR3:0,
                correctR3:0,
                s1:'',
                s2:'',
                s3:'',
                score:'',
                imageRootPath
            }
        },
        methods: {

            toUrl:function(enterUrl){
                this.$router.push("/" + enterUrl)
            },
            openAlertR3:function(){
                $(".allowUp").css("display","none");
                $(".showAlertR3").fadeIn();
                this.swiper3.allowSlidePrev= false;
                this.swiper3.allowSlideNext= false;
                //父子组件传参方法
//                if (this.inner == 0){
//                    $('.inSide').css("display","block");
//                }else if (this.inner == 1){
//                    $('.outSide').css("display",'block');
//                }
            },
            closeAlertR3:function(){
                $(".allowUp").css("display", "block");
                $(".answerR3Begin").css("display","block");
                $(".contentAlert").css("display","none");
                $(".showAlertR3").css("display","none")
                this.swiper3.allowSlidePrev= true;
                this.swiper3.allowSlideNext= true;
            },
            gameBeginInSide:function(){
                $(".answerR3Begin").css("display","none");
                $(".inSideQuestion").css("display","block");
                let _self = this;
                _self.t3 = sessionStorage.getItem('timeText');
                this.$emit('startTimer', 'round3');
            },
            gameBeginOutSide:function(){
                $(".answerR3Begin").css("display","none");
                $(".outSideQuestion").css("display","block");
                let _self = this;
                _self.t3 = sessionStorage.getItem('timeText');
                this.$emit('startTimer', 'round3');
            },

            setTimeText: function(str){
                this.t3 = str;
            },
            setQuestionList:function(qList){
                this.qList = qList;
                this.curContentR3 = this.qList[this.curIndexR3];
            },

            nextTitle:function(X){
                let _self = this;
                if (X == this.curContentR3.answer) {
                    this.correctR3++;
//                    console.log("正确回答个数", this.correctR3 + "个");
                }
                if (this.innerStatus == 0) {
                    if (this.curIndexR3 < 9) {
                        this.curIndexR3++;
                        this.curContentR3 = _self.qList[this.curIndexR3];
                    }
                    else if (this.curIndexR3 == 9) {
                        //停止计时器
                        this.$emit('pauseTimer');
                        if (this.correctR3 < 8) {
                            $('.answerR3Fail').css('display','block');
                            $('.contentAlert').css('display','none');
                        }
                        else if (this.correctR3 >= 8 && this.correctR3 < 10) {
                            $(".allowUp").css("display","block");
                            $('.answerR3Success').css('display','block');
                            $('.contentAlert').css('display','none');
                            this.$emit('addCorrectNum', _self.correctR3);
                            this.$emit('reportResult');
                        }
                        else if (this.correctR3 >= 10) {
                            $('.answerR3Perfect').css('display','block');
                            $('.contentAlert').css('display','none');
                            this.$emit('addCorrectNum', _self.correctR3);
                            this.$emit('reportResult');
                        }
                    }
                }
                if (this.innerStatus == 1){
                    if (this.curIndexR3 < 2) {
                        this.curIndexR3++;
                        this.curContentR3 = _self.qList[this.curIndexR3];
                    }
                    else if (this.curIndexR3 == 2) {
                        //停止计时器
                        this.$emit('pauseTimer');
                        if (this.correctR3 >= 0 && this.correctR3 < 3) {
                            $(".allowUp").css("display","block");
                            $('.answerR3Success').css('display','block');
                            $('.contentAlert').css('display','none');
                            this.$emit('addCorrectNum', _self.correctR3);
                            this.$emit('reportResult');
                        }
                        else if (this.correctR3 >= 3) {
                            $('.answerR3Perfect').css('display','block');
                            $('.contentAlert').css('display','none');
                            this.$emit('addCorrectNum', _self.correctR3);
                            this.$emit('reportResult');
                        }
                    }
                }

            },

            getEquipment:function(){
                $(".showAlertR3").css("display","none");
                $(".luckRoundBox").css("display","block");

                // 刷新gif
                this.$emit('refreshLuckRound')

                let _self = this;
                stageCommit({eid:3}).then((response) => {
//                    console.log(response);
                    _self.checkGetEquipmentR3 = response.data.add;
                    _self.firstFlag = response.data.first;
                    sessionStorage.setItem('checkGetEquipmentR3', _self.checkGetEquipmentR3);
                    sessionStorage.setItem('firstFlag', _self.firstFlag);
                    if(response.success){
                    } else {
                        this.$vux.toast.text(response.message, 'middle')
                    }
                });
            }

        },
        mounted () {
            let _self = this;
            $(".thirdWindow,.background").height($(window).height());
            _self.swiper3 = new Swiper ('.round3Window', {
                loop: false,
                paginationClickable: true,
                direction: 'vertical',
                height:$(window).height()
            });
            _self.swiper3.on('slideChange', function(){
                let ind = _self.swiper3.activeIndex
                if (ind == 1){
                    $(".allowUp").hide()
                } else {
                    $(".allowUp").show()
                }
            });
            //本地缓存方法
            _self.innerStatus = sessionStorage.getItem('inner');
            if (_self.innerStatus == 0){
                $('.inSide').css("display","block");
            }else if (_self.innerStatus == 1){
                $('.outSide').css("display",'block');
            }
        }
    }
</script>

<style lang="less">

    .thirdStage{

        .stage3Bg1{
            /*background:url(../../assets/images/gameRound/07.gif) no-repeat;*/
            background-repeat: no-repeat;
            background-size:cover;
            width:100%;
        }

        .stage3Bg2{
            /*background:url(../../assets/images/gameRound/08.gif) no-repeat;*/
            background-repeat: no-repeat;
            background-size:cover;
            width:100%;
        }

        .swiper-wrapper{
            width:100%;
        }
        .background{
            width:100%;
        }
        .showAlertR3{
            display:none;
            position:fixed;
            background-color:rgba(0,0,0,0.8);
            bottom:0;
            top:0;
            left:0;
            z-index:100;
            width:100%;
        }
        .contentAlert{
            height:10.5rem;
            width:7rem;
            margin:0 auto;
            padding-top:1.3rem;
            z-index:200;
            position:relative;

        }
        .alertR3{
            position: absolute;
            top:32%;
            left:2.1rem;
            z-index:100;
            height:2.5rem;
            width:2.5rem;
            opacity: 0;
        }
        .round3EndBottom{
            background:url(../../assets/images/gameRound/btnImg.png) no-repeat;
            background-size:2.4rem 0.7rem;
            height:0.7rem;
            width:2.4rem;
        }
        .round3EndBottom>span{
            height:0.7rem;
            width:2.4rem;
            display:block;
            line-height:0.7rem;
            text-align:center;
            font-size:16px;
            color:#dc202a;
        }
        .left{
            display:inline-block;
            width:2.4rem;
        }
        .right{
            display:inline-block;
        }
        .statusBox>span{

            width:5.4rem;
            text-align:center;
            display:block;
            margin:0.33rem auto;
        }




    }

</style>
