<template>
    <section class="library">
        <section style="height: 44px">
            <search
                v-model="searchVal"
                position="absolute"
                auto-scroll-to-top
                top="44px"
                @on-focus="onFocus"
                @on-cancel="onCancel"
                @on-submit="onSubmit"
                ref="search"></search>
        </section>
        <div v-infinite-scroll="loadBookLibrary" infinite-scroll-disabled="busy"
             infinite-scroll-distance="10">
            <template v-if="bookLibraryList.length>0">
                <comm-item @click.native="toResourceDetail('/ResourceDetail',scrollIndex)"
                           v-for="(bookLibrary,scrollIndex) in bookLibraryList" :key="scrollIndex"
                           :imgSrc="bookLibrary.videoImg"
                           :type="bookLibrary.zyType"
                           :info1="bookLibrary.title"
                           :info2="bookLibrary.userName"
                           :info3="bookLibrary.partyName"
                           :info4="bookLibrary.modifyDate | dateFormat('YMD')">
                    <input :id="'bookLibrary' + scrollIndex" type="hidden" :value="bookLibrary.docType"/>
                    <input :id="'vid' + scrollIndex" type="hidden" :value="bookLibrary.vid"/>
                </comm-item>
                <loading></loading>
            </template>
            <div class="no-data" v-if="bookLibraryList.length==0"><p>没有数据</p></div>
        </div>

    </section>
</template>

<script>

    import{getResourceList} from '../../api/api'
    import $ from 'jquery'
    import {Search} from 'vux'
    import loading from '../../components/common/loading.vue'
    import commItem from '../../components/common/commItem1.vue'
    export default {
        name: 'hello',
        components: {
            loading,
            Search,
            commItem
        },
        data () {
            return {
                bookLibraryList: [],
                curPage: 1,
                pageSize: 10,
                totalPage: 1,
                busy: false,
                searchVal:''
            }
        },

        methods: {
            toResourceDetail(url, scrollIndex){
                let type = $("#bookLibrary" + scrollIndex).val();
                let vid = $("#vid" + scrollIndex).val();
                this.$router.push({path: url, query: {type: type, vid: vid}});
            },

            loadBookLibrary: function () {
                if (this.curPage > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initBookResourceList();
            },
            initBookResourceList: function () {
                let _self = this;
                $(".load-more").hide();
                getResourceList({
                    menu: '书籍库',
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.bookLibraryList = _self.bookLibraryList.concat(response.data.list);
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            },

            onFocus() {

            },
            onCancel() {
                console.log('cancelsearch '+this.searchVal)
            },
            onSubmit() {
                this.$refs.search.setBlur()
                let _self = this;
                _self.curPage = 1;
                getResourceList({
                    searchKey: _self.searchVal,
                    menu: '书籍库',
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.bookLibraryList = response.data.list;
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false;
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))


            }
        },

    }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="less">

    .book-library {
        height: 1rem;
        padding: 20px 10px 10px 20px;
        border-bottom: 1px solid #f1f1f1;
    }


</style>
