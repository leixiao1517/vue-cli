<template>
    <section class="pic-library">
        <section style="height: 44px">
            <search
                v-model="searchVal"
                position="absolute"
                auto-scroll-to-top
                top="44px"
                @on-focus="onFocus"
                @on-cancel="onCancel"
                @on-submit="onSubmit"
                ref="search"></search>
        </section>
        <div v-infinite-scroll="loadPicLibrary" infinite-scroll-disabled="busy"
             infinite-scroll-distance="10">
            <template v-if="picLibraryList.length>0">
                    <comm-item @click.native="toResourceDetail('/ResourceDetail',scrollIndex)"
                               v-for="(picLibrary,scrollIndex) in picLibraryList" :key="scrollIndex"

                               :imgSrc="picLibrary.videoImg"
                               :type="picLibrary.zyType"
                               :info1="picLibrary.title"
                               :info2="picLibrary.userName"
                               :info3="picLibrary.partyName"
                               :info4="picLibrary.modifyDate | dateFormat('YMD')">
                        <input :id="'picLibrary' + scrollIndex" type="hidden" :value="picLibrary.docType"/>
                        <input :id="'vid' + scrollIndex" type="hidden" :value="picLibrary.vid"/>
                    </comm-item>
                <loading></loading>
            </template>
            <div class="no-data" v-if="picLibraryList.length==0"><p>没有数据</p></div>
        </div>

    </section>

</template>

<script>
    import loading from '../../components/common/loading.vue'
    import{getResourceList} from  '../../api/api'
    import $ from 'jquery'
    import {Search} from 'vux'
    import commItem from '../../components/common/commItem1.vue'
    export default {
        name: 'hello',

        components: {
            loading,
            Search,
            commItem
        },
        data () {
            return {
                picLibraryList: [],
                curPage: 1,
                pageSize: 8,
                totalPage: 1,
                busy: false,
                searchVal:''
            }
        },
        methods: {
            toResourceDetail(url, scrollIndex){
                let type = $("#picLibrary" + scrollIndex).val();
                let vid = $("#vid" + scrollIndex).val();
                this.$router.push({path: url, query: {type: type, vid: vid}});
            },
            initPicResourceList: function () {
                let _self = this;
                $(".load-more").hide();
                getResourceList({
                    menu: '图片库',
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.picLibraryList = _self.picLibraryList.concat(response.data.list);
                        _self.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false
                    }
                    else {
                        this.$vux.toast.text(response.message, 'middle')
                    }
                }))
            },

            loadPicLibrary: function () {
//                console.log("curPage:", this.curPage);
                if (this.curPage > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initPicResourceList();

            },

            onFocus() {

            },
            onCancel() {
                console.log('cancelsearch '+this.searchVal)
            },
            onSubmit() {
                this.$refs.search.setBlur()
                let _self = this;
                _self.curPage = 1;
                getResourceList({
                    searchKey: _self.searchVal,
                    menu: '图片库',
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.picLibraryList = response.data.list;
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false;
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))


            }

        },

    }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="less">
    .pic-library {

    }


</style>
