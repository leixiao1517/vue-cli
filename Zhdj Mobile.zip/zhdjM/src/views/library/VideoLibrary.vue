<template>
    <section class="high-lights">
        <section style="height: 44px">
            <search
                v-model="searchVal"
                position="absolute"
                auto-scroll-to-top
                top="44px"
                @on-focus="onFocus"
                @on-cancel="onCancel"
                @on-submit="onSubmit"
                ref="search"></search>
        </section>

        <div v-infinite-scroll="loadVideoLibrary" infinite-scroll-disabled="busy"
             infinite-scroll-distance="10">
            <template v-if="videoList.length>0">
                <comm-item @click.native="toResourceDetail('/ResourceDetail',scrollIndex)"
                           v-for="(video,scrollIndex) in videoList" :key="scrollIndex"

                           :imgSrc="video.videoImg"
                           :type="video.zyType"
                           :info1="video.title"
                           :info2="video.userName"
                           :info3="video.partyName"
                           :info4="video.modifyDate | dateFormat('YMD')">
                    <input :id="'video' + scrollIndex" type="hidden" :value="video.docType"/>
                    <input :id="'vid' + scrollIndex" type="hidden" :value="video.vid"/>
                </comm-item>
                <loading></loading>
            </template>
            <div class="no-data" v-if="videoList.length==0"><p>没有数据</p></div>
        </div>
    </section>

</template>

<script>

    import{getResourceList} from '../../api/api'
    import loading from '../../components/common/loading.vue'
    import $ from 'jquery'
    import {Search} from 'vux'
    import commItem from '../../components/common/commItem1.vue'
    export default {
        components: {
            loading,
            Search,
            commItem
        },
        data () {
            return {
                videoList: [],
                curPage: 1,
                pageSize: 8,
                totalPage: 1,
                busy: false,
                searchVal:''
            }
        },

        methods: {

            toResourceDetail(url, scrollIndex){
                let type = $("#video" + scrollIndex).val();
                let vid = $("#vid" + scrollIndex).val();
                this.$router.push({path: url, query: {type: type, vid: vid}});
            },

            loadVideoLibrary: function () {
                if (this.curPage > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initVideoResourceList();
            },

            initVideoResourceList: function () {
                let _self = this;
                $(".load-more").hide();
                getResourceList({
                    menu: '视频库',
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.videoList = _self.videoList.concat(response.data.list);
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            },

            onFocus() {

            },
            onCancel() {
                console.log('cancelsearch '+this.searchVal)
            },
            onSubmit() {
                this.$refs.search.setBlur()
                let _self = this;
                _self.curPage = 1;
                getResourceList({
                    searchKey: _self.searchVal,
                    menu: '视频库',
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.videoList = response.data.list;
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false;
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            }
        },
    }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="less">

    .high-lights {
        /*background-color: #ffffff;*/

    }


</style>
