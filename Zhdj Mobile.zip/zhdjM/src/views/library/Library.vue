<template>
    <div class="library">
        <section>
            <tab :line-width=2 active-color='#D0021B'>
                <tab-item class="vux-center" :selected="librarySelected === libraryItem ? true:false"
                          v-for="(libraryItem, index) in libraryTitleList"
                          @on-item-click="librarySelectedItem"
                          :key="index">{{libraryItem}}
                </tab-item>
            </tab>
            <div class="library-router">
                <router-view></router-view>
            </div>
        </section>
    </div>

</template>

<script>
    import $ from 'jquery'
    import {Tab, TabItem} from 'vux'

    export default {
        name: 'library',

        components: {
            Tab,
            TabItem,

        },
        data () {
            return {
                librarySelected: '视频库',
                libraryTitleList: ['书籍库','图片库','视频库',  ],
            }
        },

        methods: {
            librarySelectedItem: function (index) {
                if (index === 0) {
                    this.$router.replace('/BookLibrary')
                }
                else if (index === 1) {
                    this.$router.replace('/PicLibrary')
                }
                else {
                    this.$router.replace('/Library')
                }

            },

        },
        mounted(){
            let routeName = this.$route.name;
//            console.log("mounted=" + routeName)

            if (routeName == 'PicLibrary') {
                this.librarySelected = '图片库'
            } else if (routeName == 'BookLibrary') {
                this.librarySelected = '书籍库'
            } else {
                this.librarySelected = '视频库'
            }
        },
        updated(){
//        	let routeName = this.$route.name
//
//            console.log("updated=" + routeName)
//
//
//            if(routeName=='PicLibrary'){
//        		this.librarySelected='图片库'
//            }else if(routeName=='BookLibrary'){
//                this.librarySelected='书籍库'
//            }else {
//                this.librarySelected='视频库'
//            }
        }

    }
</script>


<style lang="less">
    .library {
        .library-router {
            height: 11.4rem;
        }
    }
</style>
