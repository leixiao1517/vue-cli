<!--党费缴纳开始-->
<template>

    <section class="icbc" v-html="payHtml">
        {{payHtml}}
    </section>

</template>
<!--党费缴纳结束-->

<script>
    import {fee} from '../../api/api'

    export default {
        data () {
            return {
                payHtml:'',
            }
        },
        methods: {
            pay:function () {
                let _self = this
                _self.$vux.loading.show({
                    text: 'Loading'
                })
                fee({}).then((response) => {
                    console.log(response)
                    if(response.success){
                        _self.payHtml = response.message //得到form表单
                        setTimeout(() => {
                            document.forms[0].submit() //提交表单
                        }, 300)
                    } else {

                    }
                    setTimeout(() => {
                        _self.$vux.loading.hide()
                    }, 1000)
                }).catch((error) => {
                    console.log(error)
                })
            }
        },
        mounted () {
            this.pay()
        }
    }
</script>
