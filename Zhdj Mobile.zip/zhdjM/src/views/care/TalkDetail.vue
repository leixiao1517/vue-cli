
<template>
    <section class="talk-detail">
        <div class="title-area">
            <p class="title">{{talk.title}}</p>
            <p>{{talk.hoster}} [{{talk.partName}} {{talk.branchName}}]</p>
            <span>参与人数：{{talk.count}}</span>
        </div>

        <!-- 文字区 -->
        <div class="content">
            <div>过程简述</div>
            <div>
                {{talk.content}}
            </div>
        </div>

        <!-- 发表的图片区 -->
        <div class="image">
            <img src="../../assets/images/survey/survey.png"/>
        </div>
    </section>
</template>

<script>
    import { Group, Cell } from 'vux'

    export default {
        components: {
            Group,
            Cell,
        },
        data () {
            return {
                tid:'',
                talk:{
                    title:'哈哈哈',
                    content:'好好好',
                    hoster:'古月',
                    count:'22',
                    partName:'机关党委',
                    branchName:'XX支部',
                },
            }
        },
        methods: {
            getUserAnswer:function (index) {
                console.log(index+","+this.researchData.questions[index].userAnswer)
            },
        },
        mounted () {
            this.tid = this.$route.query.tid
            console.log(this.tid)
        }
    }
</script>
<style lang="less">
    .talk-detail{
        .title-area{
            padding: 10px;
            font-size: 12px;
            color: #4A4A4A;
            background-color: #fff;
            .title{
                margin-bottom: 10px;
                font-size: 16px;
                font-weight: bold;
                color: #000000;
            }
        }
        .content{
            margin: 2px 0;
            background-color: #fff;
            padding: 10px 10px 50px 10px;
        }
        .content div:first-child{
            color: #D0021B;
            font-weight: bold;
            line-height: 30px;
        }
        .content div{
            color: #4A4A4A;
        }
        .image{
            width: 100%;
            height: 200px;
            padding: 10px;
            background-color: #fff;
            img{
                width:100%;
                height:100%;
            }
        }

    }
</style>
