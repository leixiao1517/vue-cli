<template>
    <section class="party-care">
        <!-- Tab页签 -->
        <tab>
            <tab-item v-for="(item,index) in level1" :key="index" :selected="index===0" @on-item-click="onItemClick(item.pid)">{{ item.partyName }}</tab-item>
        </tab>

        <!-- 列表信息 -->
        <div class="list">
            <flexbox orient="vertical" v-for="(care ,index) in cares" :key="index" @click.native="toTalk(care.vid);">
                <flexbox-item><div class="flex-demo">{{care.title}}</div></flexbox-item>
                <flexbox-item><div class="mini-font mt10 flex-demo">发起人：{{care.createUser}}[{{care.partyName}} {{care.branchName}}]</div></flexbox-item>
                <flexbox-item><div class="mini-font flex-demo">参与人数：{{care.count}}</div></flexbox-item>
            </flexbox>
        </div>
    </section>
</template>

<script>
    import { Flexbox, FlexboxItem,Tab, TabItem,} from 'vux'

    export default {
        components: {
            Flexbox,
            FlexboxItem,
            Tab,
            TabItem,
        },
        data() {
            return {
                cares: [{
                    vid:1,
                    title: '标题一标题一标题一标题一标题一',
                    createUser: '古月',
                    partyName: '机关党委',
                    branchName: '技术支部',
                    count:1
                }, {
                    vid:2,
                    title: '标题二标题一标题一标题一标题一标题一',
                    createUser: '古月2',
                    partyName: '机关党委',
                    branchName: '安保支部',
                    count:123
                }],
                level1:[
                    {pid:1,partyName:'机关党委'},
                    {pid:2,partyName:'四平党委'},
                    {pid:2,partyName:'四平党委'},
                ]
            }
        },
        methods: {
            toTalk:function (vid) {
                this.$router.push("care/" + vid)
            }
        },
        mounted() {
            let _self = this

        }
    }

</script>

<style lang="less">
    .party-care {
        .list{
            padding-left: 10px;
            background: #ffffff;
            font-size: 16px;
            color: #000000;
            .vux-flexbox{
                border-bottom: solid 1px #F2F2F2;
                padding: 10px 0 10px 0;
            }
            .mini-font{
                font-size: 12px;
                color: #4A4A4A;
            }
        }
    }
</style>
