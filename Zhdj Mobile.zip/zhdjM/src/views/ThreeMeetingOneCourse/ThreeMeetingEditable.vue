<template>
    <section class="three-meeting-editable">
        <div class="editable-tab">
            <span :class="{active: _self.tab === '0'}" @click="_self.tab = '0'">编辑</span>
            <span :class="{active: _self.tab === '1'}" @click="_self.tab = '1'">我提交的</span>
        </div>
        <div class="editable-box" v-if="tab == '0'">
            <div class="text-area">
                <group>
                    <x-textarea :max="200" :height="270" :placeholder="'请输入内容详情'"></x-textarea>
                </group>
            </div>
            <div class="editable-up">
                <span>提交</span>
            </div>
        </div>
        <div class="submitted-box" v-if="tab == '1'">
            <div class="submitted-list"  v-for="value in submittedData">
                <b>
                    <span>{{ value.submittedContent }}</span>
                    <i @click="toUrl('ThreeMeetingSubmitted')">详情&nbsp;></i>
                </b>
            </div>
        </div>
    </section>
</template>


<script>
    import $ from 'jquery'
    import { XTextarea, Group } from 'vux'

    export default {
        components: {
            XTextarea,
            Group,
        },
        data() {
            return {
                tab:'0',
                submittedData:[
                    {
                        submittedNumber:'1',
                        submittedContent:'会议听取了全国人大宪法法律委副主任委员徐辉作的关于电子商务法草案审议结果的报告。草案四审稿规定',
                    }, {
                        submittedNumber:'2',
                        submittedContent:'会议听取了全国人大宪法法律委副主任委员徐辉作的关于电子商务法草案审议结果的报告。草案四审稿规定',
                    }, {
                        submittedNumber:'3',
                        submittedContent:'会议听取了全国人大宪法法律委副主任委员徐辉作的关于电子商务法草案审议结果的报告。草案四审稿规定',
                    }],
            }
        },
        methods: {
            toUrl:function(url){
                this.$router.push("/"+url)
            },
        },
        mounted() {
            $('.three-meeting-editable').css("min-height",$(window).height());
            $("html,body").scrollTop(0);
        }
    }
</script>

<style lang="less">

    .three-meeting-editable{

        background-color:#f2f2f2;
        .editable-tab{
            display:flex;
            height:0.8rem;
            border-bottom:1px solid #f2f2f2;
            background-color:white;
        }
        .editable-tab>span{
            flex:1;
            height:0.8rem;
            line-height:0.8rem;
            font-size:14px;
            text-align:center;
        }
        .editable-tab>.active{
            color:#D0021B;
            border-bottom:1px solid #D0021B;
        }
        .weui-cells{
            margin-top:0;
        }
        .weui-textarea{
            font-size:14px;
        }
        .weui-textarea-counter{
            color:#D0021B;
        }
        .editable-up{
            margin:2.4rem auto 0 auto;
            height:0.8rem;
        }
        .editable-up>span{
            display:block;
            background-color:#D0021B;
            color:white;
            height:0.8rem;
            width:4.5rem;
            line-height:0.8rem;
            text-align:center;
            margin:0 auto;
        }
        .submitted-list{
            height:1.4rem;
            width:100%;
            border-bottom:1px solid #f6f6f6;
            background-color:white;
        }
        .submitted-list>b:first-child{
            padding:0.1rem 0;
            margin:0 0.25rem;
        }
        .submitted-list>b{
            display:block;
            font-weight:normal;
            width:7rem;
            height:1.2rem;
            margin:0.1rem 0.25rem;
        }
        .submitted-list>b>span{
            float:left;
            width:5.8rem;
            height:1.2rem;
            line-height:0.6rem;
            font-size:14px;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
        }
        .submitted-list>b>i{
            height:1.2rem;
            line-height:1.2rem;
            font-size:14px;
            text-align:center;
            font-style:normal;
            margin-left:0.2rem;
            display:inline-block;
            color:#D0021B;
        }

    }



</style>
