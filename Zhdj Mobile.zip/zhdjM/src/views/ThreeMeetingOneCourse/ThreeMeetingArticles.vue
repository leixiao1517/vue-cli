<template>
    <section class="three-meeting-articles">
        <h3>{{ articles.title }}</h3>
        <div class="articles-infoBox">
            <div class="articles-info-initiator">
                <p class="title" style="display:block">{{articles.cearter}}【{{articles.firstClass}}&nbsp;{{articles.secondClass}}】</p>
            </div>
            <div class="articles-info-Date">
                <div><b style="float:right;margin-right:0.1rem;"></b></div>
                <div>{{articles.date}} {{articles.time}}</div>
                <div><b style="float:left;margin-left:0.1rem;"></b></div>
            </div>
        </div>
      <div class="active-articles-content">
        <p>{{articles.contentOne}}</p>
        <img :src="articles.imgOne" />
        <p>{{articles.contentTwo}}</p>
        <img :src="articles.imgTwo" />
          <p>{{articles.contentThree}}</p>
      </div>
    </section>
</template>


<script>
    import $ from 'jquery'

  export default {
    components: {

    },
    data() {
      return {
          articles:{
              title:'党的十九大以来以习近平同志为核心的党中央坚定不移推进全面深化改革述评',
              cearter:'张三德',
              firstClass:'市书记党委',
              secondClass:'中烟支部',
              time:'10:13:22',
              date:'2018-08-22',
              contentOne:'不忘初心，方得始终。中国共产党人的初心和使命，就是为中国人民谋幸福，为中华民族谋复兴。这个初心和使命是激励中国共产党人不断前进的根本动力。',
              contentTwo:'当前，国内外形势正在发生深刻复杂变化，我国发展仍处于重要战略机遇期，前景十分光明，挑战也十分严峻。我们要永远保持建党时中国共产党人的奋斗精神，永远保持对人民的赤子之心。一切向前走，都不能忘记走过的路；走得再远、走到再光辉的未来，也不能忘记走过的过去，不能忘记为什么出发。',
              contentThree:'本书在深刻阐述中国共产党人的初心和使命的基础上，对“红船精神”昭示的中国共产党人的初心、新时代中国共产党的历史使命、新思想领航新征程、以人民为中心、永葆奋斗者的姿态、讲政德涵养政治生态、增强看齐意识、当好新时代的答卷人等进行了阐述，并号召全党同志一定要登高望远、居安思危，勇于变革、勇于创新，永不僵化、永不停滞，团结带领全国各族人民决胜全面建成小康社会，奋力夺取新时代中国特色社会主义伟大胜利。',
              imgOne: 'http://img.alicdn.com/tfs/TB1GLugjhtnkeRjSZSgXXXAuXXa-520-280.jpg_q90_.webp',
              imgTwo: 'http://img.alicdn.com/tfs/TB1GLugjhtnkeRjSZSgXXXAuXXa-520-280.jpg_q90_.webp',
          }
      }
    },
    methods: {

    },
    mounted() {
        $('.three-meeting-articles').css("min-height",$(window).height());
        $("html,body").scrollTop(0);
    }
  }
</script>

<style lang="less">

  .three-meeting-articles{

      background-color:white;

  h3{
      width:4.8rem;
      margin:auto;
      padding-top:12px;
      color:black;
      font-size:18px;
  }

  .articles-infoBox{
      width:100%;
      height:1.4rem;
  }
  .articles-info-initiator{
      height:0.5rem;
      width:100%;
  }
  .title{
      height:0.5rem;
      width:4rem;
      line-height:0.5rem;
      font-size:12px;
      margin:6px auto;
      text-align:center;
  }
  .articles-info-Date{
      display:flex;
      height:0.7rem;
  }
  .articles-info-Date>div{
      flex:1;
      font-size:10px;
      text-align:center;
      line-height:0.7rem;
  }
  .articles-info-Date>div>b{
      margin-top:0.35rem;
      height:1px;
      border-top:1px solid gray;
      display:inline-block;
      width:2rem;
  }
  .active-articles-content{
      width:7rem;
      margin:0 auto;
      padding-top:6px;
    }
  .active-articles-content>img{
      width:7rem;
      padding:0.2rem 0;
  }
      .active-articles-content>p{
          padding:0.2rem 0;

      }

  }



</style>
