<template>
    <section class="three-meeting-one-course">
        <div class="top-banner">
            <swiper :list="top_list" :show-dots="false" :show-desc-mask="false" auto></swiper>
        </div>
        <div class="column">
            <span style="color:#D0021B;">最新会议成果</span>
        </div>
        <div class="newest-content">
            <div class="newest-box">
                <div class="newest-list">
                    <div class="newest-img-box" @click="toUrl('ThreeMeetingDetails')"></div>
                    <div class="newest-text-box">
                        <h3 @click="toUrl('ThreeMeetingDetails')">2018年中烟第X次党员代表大会</h3>
                        <p>党的十九大报告博大精深，内涵丰富，是中国特色社会主义进入新时代的宣言书，是建设社会主义现代化强国的动员令，是实现中华民族伟大复兴的总蓝…</p>
                        <div class="exhibition-top">
                            <img src="#">
                            <span>范冰冰</span>
                            <b>2018/06/12&nbsp;22:14</b>
                        </div>
                        <div class="exhibition-details">
                            <span style="color:#D0021B"><b style="font-size:17px">15</b>人打卡</span>
                            <span style="color:#D0021B"><b style="font-size:17px">15</b>人参与</span>
                            <span style="color:#D0021B"><b style="font-size:17px">13</b>篇心得</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="column" style="border-top:3px solid #F6F6F6">
            <span>全部会议</span>
            <b>已开展：3224次会议&nbsp;></b>
        </div>
        <div class="exhibition-box">

            <div class="exhibition-list">
                <div class="exhibition-top">
                    <img src="#">
                    <span>范冰冰</span>
                    <b>2018/06/12&nbsp;22:14</b>
                </div>
                <div class="exhibition-content">
                    <h3>2017-11-3加强党性修养是共产党员终身践行的课题</h3>
                    <p>《准则》中第一条就坚定理想信念，“理想信念动摇是最危险的动摇，理想信念滑坡是最危险的滑坡。全党同志必须把对马克思主义的信仰、对社会主义和共产主义的信念作为毕生追求，在改造客观世界的同时不断改造主观世界，解决好…</p>
                </div>

                <div class="exhibition-no-img " v-if="exhibitionType == '0'"></div>

                <div class="exhibition-one-img" v-if="exhibitionType == '1'">
                    <img src="#"/>
                </div>

                <div class="exhibition-two-img" v-if="exhibitionType == '2'">
                    <img src="#"/>
                    <img src="#"/>
                </div>

                <div class="exhibition-more-img" v-if="exhibitionType == '3'">
                    <img src="#"/>
                    <img src="#"/>
                    <img src="#"/>
                    <img src="#"/>
                    <img src="#"/>
                    <img src="#"/>
                </div>

                <div class="exhibition-banner-img" v-if="exhibitionType == '4'">
                    <swiper :list="exhibition_list" :show-dots="false" auto :show-desc-mask="false"></swiper>
                </div>
                <div class="exhibition-details">
                    <span><b>15</b>人打卡</span>
                    <span><b>15</b>人参与</span>
                    <span><b>13</b>篇心得</span>
                </div>
            </div>

        </div>



    </section>
</template>


<script>
    import $ from 'jquery'
    import {Swiper,SwiperItem} from 'vux'

    export default {
        components: {
            Swiper,
            SwiperItem,
        },
        data() {
            return {
                top_list: [{
                    url: 'javascript:',
                    img: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vvsr72j20p00gogo2.jpg',
                }, {
                    url: 'javascript:',
                    img: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vw1k2wj20p00goq7n.jpg',
                }, {
                    url: 'javascript:',
                    img: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vw50iwj20ff0aaaci.jpg',
//        fallbackImg: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vw50iwj20ff0aaaci.jpg' 如果img引入出现404错误时，使用此备用路径引入。
                }],
                exhibition_list: [{
                    url: 'javascript:',
                    img: 'http://img.alicdn.com/tfs/TB1g1YpvTqWBKNjSZFAXXanSpXa-520-280.jpg_q90_.webp',
                }, {
                    url: 'javascript:',
                    img: '//img.alicdn.com/tfs/TB1leTxvHZnBKNjSZFGXXbt3FXa-520-280.jpg_q90_.webp',
                }],

            exhibitionType:'2',
            }
        },
        methods: {
            toUrl:function(url){
                this.$router.push("/"+url)
            },
        },
        mounted() {
            $('.three-meeting-one-course').css("min-height",$(window).height());
            $("html,body").scrollTop(0);
        }
    }
</script>

<style lang="less">

    .three-meeting-one-course{

        background-color:white;
        .column{
            width:100%;
        }
        .column>span{
            display:inline-block;
            height:0.8rem;
            line-height:0.8rem;
            font-size:15px;
            text-align:center;
            margin-left:0.25rem;
            font-weight:bold;
        }
        .column>b{
            float:right;
            display:inline-block;
            height:0.8rem;
            line-height:0.8rem;
            margin-right:0.4rem;
            font-size:12px;
            color:#D0021B;
        }
        .newest-box{
            width:7.5rem;
            border-top:1px solid #f6f6f6;
        }
        .newest-list{
            width:7rem;
            margin:0.15rem 0.25rem;
        }
        .newest-list>.newest-img-box{
            width:100%;
            height:3.6rem;
            background-color:skyblue;
        }
        .newest-text-box>h3{
            line-height:0.6rem;
            font-size:15px;
        }
        .newest-text-box>p{
            line-height:0.4rem;
            font-size:11px;
            color:#9B9B9B;
        }
        .before-list{
            display:inline-block;
            width:3rem;
            height:2.4rem;
            background-color:skyblue;
            margin-right:0.25rem;
            position:relative;
        }
        .before-content>div:first-child{
            margin-left:0.25rem;
        }
        .before-list>span{
            height:0.5rem;
            position:absolute;
            bottom:0;
            width:100%;
            background:rgba(0,0,0,0.4);
            line-height:0.5rem;
            font-size:12px;
            color:white;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
        }
        .exhibition-box{
            width:100%;
        }
        .exhibition-list{
            width:7rem;
            min-height:2.4rem;
            padding-bottom:0.1rem;
            margin-left:0.25rem;
        }
        .exhibition-top{
            width:100%;
            height:0.8rem;
            margin-top:0.2rem;
        }
        .exhibition-top>img{
            height:0.8rem;
            width:0.8rem;
            float:left;
            border-radius:50%;
            background-color:skyblue;
        }
        .exhibition-top>span{
            display:inline-block;
            line-height:0.8rem;
            height:0.8rem;
            margin-left:0.2rem;
            color:#4A90E2;
        }
        .exhibition-top>b{
            display:inline-block;
            font-weight:normal;
            line-height:0.8rem;
            font-size:12px;
            float:right;
            color:#9B9B9B;
        }
        .exhibition-content>h3{
            font-weight:normal;
            margin-top:0.2rem;
            font-size:14px;
            color:black;
        }
        .exhibition-content>p{
            margin-top:0.2rem;
            font-size:12px;
            color:#9B9B9B;
        }
        .exhibition-details{
            display:flex;
            height:0.8rem;
            border-bottom:1px solid #F2F2F2;
            border-top:1px solid #F2F2F2;
            margin-top:0.3rem;
            margin-bottom:0.3rem;
        }
        .exhibition-details>span{
            flex:1;
            line-height:0.8rem;
            height:0.8rem;
            font-size:12px;
            color:#9B9B9B;
            text-align:center;
        }
        .exhibition-details>span>b{
            color:#D0021B;
        }

        .exhibition-one-img>img{
            margin-top:0.2rem;
            width:7rem;
            height:3.6rem;
            background-color:skyblue;
        }
        .exhibition-two-img{
            display:flex;
        }
        .exhibition-two-img>img{
            flex:1;
            height:3.2rem;
            margin-right:0.1rem;
            background-color:skyblue;
        }
        .exhibition-more-img>img{
            margin-top:0.15rem;
            margin-right:0.15rem;
            width:2.1rem;
            height:2.1rem;
            background-color:skyblue;
        }
        .vux-swiper{
            margin-top:0.2rem;
        }
    }



</style>
