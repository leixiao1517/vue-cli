<template>
    <section class="three-meeting-details">
        <div class="top-img-box">
            <swiper :list="img_list" :show-dots="false" auto :show-desc-mask="false"></swiper>
        </div>
        <div class="top-text-box">
            <div class="top-text-content">
                <h3>高扬爱国主义奋斗主旋律，引领创新建功新时代</h3>
                <p>刘德华&nbsp;【一级单位名称&nbsp;二级单位名称】</p>
                <p>2017-12-13 16:55</p>
                <b @click="toUrl('ThreeMeetingArticles')">查看详情</b>
            </div>
        </div>
        <div class="column">
            <span>心得体会</span>
            <span class="set-hot"><b>共134条</b></span>
            <div>
                <check-icon :value.sync="read" type="plain">仅看我的</check-icon>
            </div>
        </div>
        <div class="activity-box process">

            <div class="activity-process-list" v-for="value in processList" v-if="read == value.readMe || read != value.readAll">
                <div class="activity-process-top">
                    <img src="#">
                    <div>
                        <span>{{ value.creater }}</span>
                        <p>{{value.firstClass}}&nbsp;{{value.secondClass}}</p>
                    </div>
                    <b>2018/06/12&nbsp;22:14:45</b>
                </div>
                <div class="activity-process-content">
                    <p>
                        <b>【精选】</b>
                        {{value.content}}
                        <i class="revisability" v-if="value.revisability == '1'">修改</i>
                    </p>
                </div>
            </div>

        </div>
        <div class="btn">
            <span @click="toUrl('ThreeMeetingEditable')">写心得</span>
        </div>

    </section>
</template>


<script>
    import $ from 'jquery'
    import {Swiper,SwiperItem,CheckIcon } from 'vux'

    export default {
        components: {
            Swiper,
            SwiperItem,
            CheckIcon,
        },
        data() {
            return {
                img_list: [{
                    url: 'javascript:',
                    img: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vvsr72j20p00gogo2.jpg',
                }, {
                    url: 'javascript:',
                    img: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vw1k2wj20p00goq7n.jpg',
                }, {
                    url: 'javascript:',
                    img: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vw50iwj20ff0aaaci.jpg',
//        fallbackImg: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vw50iwj20ff0aaaci.jpg' 如果img引入出现404错误时，使用此备用路径引入。
                }],
                read: false,
                revisability:'1',
                processList:[{
                    id:'1',
                    revisability:'0',
                    creater:'范冰冰',
                    firstClass:'中烟党委',
                    secondClass:'长沙支部',
                    date:'2018/06/12',
                    time:'10:24:32',
                    content:'这几天的文艺汇演排练，同志们都非常积极地参与了，见到我们的党建活动有如此高的参与率，我觉得非常开心呀！',
                    readMe:'0',
                    readAll:'1',
                },{
                    id:'2',
                    revisability:'0',
                    creater:'范冰冰',
                    firstClass:'中烟党委',
                    secondClass:'长沙支部',
                    date:'2018/09/15',
                    time:'20:24:46',
                    content:'2',
                    readMe:'0',
                    readAll:'1',
                },{
                    id:'3',
                    revisability:'1',
                    creater:'范冰冰',
                    firstClass:'中烟党委',
                    secondClass:'长沙支部',
                    date:'2018/09/15',
                    time:'20:24:46',
                    content:'3',
                    readMe:'1',
                    readAll:'1',
                },{
                    id:'4',
                    revisability:'1',
                    creater:'范冰冰',
                    firstClass:'中烟党委',
                    secondClass:'长沙支部',
                    date:'2018/09/15',
                    time:'20:24:46',
                    content:'4',
                    readMe:'1',
                    readAll:'1',
                },{
                    id:'5',
                    revisability:'0',
                    creater:'范冰冰',
                    firstClass:'中烟党委',
                    secondClass:'长沙支部',
                    date:'2018/06/12',
                    time:'10:24:32',
                    content:'5',
                    readMe:'0',
                    readAll:'1',
                },{
                    id:'6',
                    revisability:'0',
                    creater:'范冰冰',
                    firstClass:'中烟党委',
                    secondClass:'长沙支部',
                    date:'2018/06/12',
                    time:'10:24:32',
                    content:'6',
                    readMe:'0',
                    readAll:'1',
                }],
            }
        },
        methods: {
            toUrl:function(url){
                this.$router.push("/"+url)
            },
        },
        mounted() {
            $('.three-meeting-one-course').css('min-height',$(window).height());
            $("html,body").scrollTop(0);
        }
    }
</script>

<style lang="less">

    .three-meeting-details{

        background-color:white;
        padding-bottom:0.8rem;
        .top-text-content{
            width:7rem;
            min-height:2.7rem;
            margin:0.2rem auto 0 auto;
        }
        .top-text-content>h3{
            font-size:16px;
            font-weight:normal;
        }
        .top-text-content>p{
            font-size:12px;
            margin-top:0.2rem;
            color:#9B9B9B;
        }
        .top-text-content>b{
            font-weight:normal;
            display:block;
            text-align:center;
            width:7rem;
            height:0.4rem;
            font-size:12px;
            margin-top:0.2rem;
            line-height:0.4rem;
        }
        .column{
            width:100%;
            border-top:5px solid #F2F2F2;
        }
        .column>span{
            display:inline-block;
            height:0.8rem;
            line-height:0.8rem;
            font-size:14px;
            text-align:center;
            margin-left:0.25rem;

        }
        .column>.set-hot>b{
            height:0.8rem;
            line-height:0.8rem;
            display:inline-block;
            font-weight:normal;
            font-size:10px;
            color:#D0021B;
        }
        .column>div{
            display:inline-block;
            float:right;
            height:0.8rem;
            line-height:0.8rem;
            margin-right:0.2rem;
        }
        .vux-check-icon>span{
            height:0.8rem;
            line-height:0.8rem;
            display:inline-block;
            font-size:14px;
        }
        .activity-box{
            width:100%;
        }
        .activity-process-list{
            width:7.3rem;
            margin:0.2rem 0.1rem 0rem 0.1rem;
            min-height:2.4rem;
            padding-bottom:0.1rem;
        }
        .activity-process-top{
            width:100%;
            height:0.8rem;
        }
        .activity-process-top>img{
            height:0.8rem;
            width:0.8rem;
            float:left;
            border-radius:50%;
            background-color:skyblue;
        }
        .activity-process-top>div{
            display:inline-block;
            height:0.8rem;
            margin-left:0.2rem;
        }
        .activity-process-top>div>span{
            height:0.5rem;
            line-height:0.5rem;
            color:#4A90E2;
            display:block;
        }
        .activity-process-top>div>p{
            height:0.3rem;
            line-height:0.3rem;
            color:#9B9B9B;
            display:block;
            font-size:10px
        }
        .activity-process-top>b{
            display:inline-block;
            font-weight:normal;
            line-height:0.8rem;
            font-size:12px;
            float:right;
            margin-right:0.5rem;
            color:#9B9B9B;
        }
        .activity-process-content{
            margin:0.2rem 0.1rem 0 0.8rem;
            width:6rem;
        }
        .activity-process-content>p{
            font-size:13px;
            color:black;
        }
        .activity-process-content>p>b{
            color:#D0021B;
        }
        .revisability{
            color:#4A90E2;
            font-style:normal;
        }
        .btn>span{
            height:0.8rem;
            line-height:0.8rem;
            text-align:center;
            font-size:14px;
            background-color:#D0021B;
            color:#FFFFFF;
            position:fixed;
            bottom:0;
            width:100%;
        }
    }



</style>
