<!--起始页开始-->
<template>
    <section class="index">
        <img src="../assets/images/breakGame/noservice-outer.jpg">
    </section>
</template>
<!--起始页结束-->
<script>
    import $ from 'jquery'
    export default {
        components: {

        },
        data () {
            return {

            }
        },
        methods: {
        },
        mounted () {
            let height = $(window).height();
            $(".index img").css("height",height);
        }
    }
</script>

<style lang="less">
    .index{
        img{
            width:100%;
        }
    }
</style>
