<template>
    <section class="two-learn-submitted">
        <div class="submitted-content">
            <p>会议听取了全国人大宪法法律委副主任委员徐辉作的关于电子商务 法草案审议结果的报告。草案四审稿规定了从事电子商务活动应当 履行环境保护义务，明确了电子商务平台经营者的补充责任，完善 了对商品和服务交付的有关规定。</p>
        </div>
        <div class="submitted-result">
            <p v-if="passed == '0' ">查看不通过，理由：</p>
            <p v-if="passed == '1' ">查看已通过</p>
            <p v-if="passed == '-1'">查看中</p>
            <p>内容为抄袭</p>
        </div>
    </section>
</template>


<script>
    import $ from 'jquery'


    export default {
        components: {

        },
        data() {
            return {
                passed:'0',
            }
        },
        methods: {
            toUrl:function(url){
                this.$router.push("/"+url)
            },
        },
        mounted() {
            $('.two-learn-submitted').css("min-height",$(window).height());
            $("html,body").scrollTop(0);
        }
    }
</script>

<style lang="less">

    .two-learn-submitted{
        background-color:#f2f2f2;
        .submitted-content{
            background-color:white;
            width:100%;
            padding-bottom:0.6rem;
        }
        .submitted-content>p{
            display:block;
            width:7rem;
            padding-top:0.2rem;
            margin:0 auto 0 auto;
            color:#707070;
            font-size:15px;
        }
        .submitted-result{
            border-top:5px solid #f2f2f2;
            background-color:white;
            width:100%;
            padding-bottom:1rem;
        }
        .submitted-result>p{
            display:block;
            width:7rem;
            padding-top:0.2rem;
            margin:0 auto 0 auto;
            color:#707070;
            font-size:15px;
        }

    }



</style>
