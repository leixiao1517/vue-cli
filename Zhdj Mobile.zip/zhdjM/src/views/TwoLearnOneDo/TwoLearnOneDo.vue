<template>
    <section class="two-learn-one-do">
        <div class="top-banner">
            <swiper :list="img_list" :show-dots="false" :show-desc-mask="false" auto></swiper>
        </div>
        <div class="column">
            <span style="color:#D0021B;">最新活动成果</span>
        </div>
        <div class="newest-content">
            <div class="newest-box">
                <div class="newest-list">
                    <div class="newest-img-box" @click="toUrl('TwoLearnDetails')"></div>
                    <div class="newest-text">
                        <h3>中烟开展2016年度党性锻炼培训活动</h3>
                        <b>来自各个厂的青年党员和老党员积极参与活动、活动顺利开展</b>
                        <p style="bottom:0.4rem;">学习时间：2018-04-13</p>
                        <p style="bottom:0;">参与人数：120人</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="column" style="border-top:3px solid #F6F6F6">
            <span>往期活动成果</span>
            <b>更多</b>
        </div>
        <div class="before-content">
            <div class="before-list" @click="toUrl('TwoLearnDetails')">
                <span>&nbsp;开启智慧党建新领域，人民奥诶见爱唯欧积分</span>
            </div>
            <div class="before-list" @click="toUrl('TwoLearnDetails')">
                <span>&nbsp;评论员观察：人在事上练，安慰佛我加我诶附近</span>
            </div>
            <div class="before-list" @click="toUrl('TwoLearnDetails')">
                <span>&nbsp;红船听涛：新时代的新星啊诶哦皮肤就爱我配附件</span>
            </div>
        </div>
        <div class="column" style="border-top:3px solid #F6F6F6">
            <span>学习成果展示</span>
        </div>
        <div class="exhibition-box">

            <div class="exhibition-list">
                <div class="exhibition-top">
                    <img src="#">
                    <span>范冰冰</span>
                    <b>2018/06/12&nbsp;22:14</b>
                </div>
                <div class="exhibition-content">
                    <h3>2017-11-3加强党性修养是共产党员终身践行的课题</h3>
                    <p>《准则》中第一条就坚定理想信念，“理想信念动摇是最危险的动摇，理想信念滑坡是最危险的滑坡。全党同志必须把对马克思主义的信仰、对社会主义和共产主义的信念作为毕生追求，在改造客观世界的同时不断改造主观世界，解决好…</p>
                </div>
                <div class="exhibition-details">
                    <span><b>15</b>人打卡</span>
                    <span><b>15</b>人参与</span>
                    <span><b>13</b>篇心得</span>
                </div>
            </div>
            <div class="exhibition-list">
                <div class="exhibition-top">
                    <img src="#">
                    <span>范冰冰</span>
                    <b>2018/06/12&nbsp;22:14</b>
                </div>
                <div class="exhibition-content">
                    <h3>2017-11-3加强党性修养是共产党员终身践行的课题</h3>
                    <p>《准则》中第一条就坚定理想信念，“理想信念动摇是最危险的动摇，理想信念滑坡是最危险的滑坡。全党同志必须把对马克思主义的信仰、对社会主义和共产主义的信念作为毕生追求，在改造客观世界的同时不断改造主观世界，解决好…</p>
                </div>
                <div class="exhibition-img">
                    <img src="#"/>
                </div>
            </div>

        </div>



    </section>
</template>


<script>
    import $ from 'jquery'
    import {Swiper,SwiperItem} from 'vux'


    export default {
        components: {
            Swiper,
            SwiperItem,
        },
        data() {
            return {
                img_list:[{
                    url: 'javascript:',
                    img: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vvsr72j20p00gogo2.jpg',
                }, {
                    url: 'javascript:',
                    img: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vw1k2wj20p00goq7n.jpg',
                }, {
                    url: 'javascript:',
                    img: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vw50iwj20ff0aaaci.jpg',
//        fallbackImg: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vw50iwj20ff0aaaci.jpg' 如果img引入出现404错误时，使用此备用路径引入。
                }],
            }
        },
        methods: {
            toUrl:function(url){
                this.$router.push("/"+url)
            },
        },
        mounted() {
            $('.two-learn-one-do').css("min-height",$(window).height());
            $("html,body").scrollTop(0);
        }
    }
</script>

<style lang="less">

    .two-learn-one-do{

        background-color:white;
        .column{
            width:100%;
        }
        .column>span{
            display:inline-block;
            height:0.8rem;
            line-height:0.8rem;
            font-size:15px;
            text-align:center;
            margin-left:0.25rem;
            font-weight:bold;
        }
        .column>b{
            float:right;
            display:inline-block;
            height:0.8rem;
            line-height:0.8rem;
            margin-right:0.4rem;
            font-size:12px;
            color:#9B9B9B;
        }
        .newest-box{
            height:3rem;
            width:7.5rem;
            border-top:1px solid #f6f6f6;
        }
        .newest-list{
            height:2.7rem;
            width:7rem;
            margin:0.15rem 0.25rem;
            display:flex;
        }
        .newest-list>div{
            flex:1;
        }
        .newest-list>.newest-img-box{
            background-color:skyblue;
        }
        .newest-text{
            position:relative;
            margin-left:0.1rem;
        }
        .newest-text>h3{
            font-size:15px;
        }
        .newest-text>b{
            font-size:12px;
            color:#9B9B9B;
            font-weight:normal;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
        }
        .newest-text p{
            font-size:10px;
            color:#9b9b9b;
            position:absolute;
            line-height:0.3rem;
        }
        .before-content{
            margin-top:0.1rem;
            height:2.55rem;
            overflow-x:auto;
            white-space:nowrap;
        }

        ::-webkit-scrollbar{
            display:none;
            width: 0;
            height: 0;
        }

        .before-list{
            display:inline-block;
            width:3rem;
            height:2.4rem;
            background-color:skyblue;
            margin-right:0.25rem;
            position:relative;
        }
        .before-content>div:first-child{
            margin-left:0.25rem;
        }
        .before-list>span{
            height:0.5rem;
            position:absolute;
            bottom:0;
            width:100%;
            background:rgba(0,0,0,0.4);
            line-height:0.5rem;
            font-size:12px;
            color:white;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
        }
        .exhibition-box{
            width:100%;
        }
        .exhibition-list{
            width:7rem;
            min-height:2.4rem;
            padding-bottom:0.1rem;
            margin-left:0.25rem;
        }
        .exhibition-top{
            width:100%;
            height:0.8rem;
        }
        .exhibition-top>img{
            height:0.8rem;
            width:0.8rem;
            float:left;
            border-radius:50%;
            background-color:skyblue;
        }
        .exhibition-top>span{
            display:inline-block;
            line-height:0.8rem;
            height:0.8rem;
            margin-left:0.2rem;
            color:#4A90E2;
        }
        .exhibition-top>b{
            display:inline-block;
            font-weight:normal;
            line-height:0.8rem;
            font-size:12px;
            float:right;
            color:#9B9B9B;
        }
        .exhibition-content>h3{
            font-weight:normal;
            margin-top:0.2rem;
            font-size:14px;
            color:black;
        }
        .exhibition-content>p{
            margin-top:0.2rem;
            font-size:12px;
            color:#9B9B9B;
        }
        .exhibition-details{
            display:flex;
            height:0.8rem;
            border-bottom:1px solid #F2F2F2;
            border-top:1px solid #F2F2F2;
            margin-top:0.2rem;
        }
        .exhibition-details>span{
            flex:1;
            line-height:0.8rem;
            height:0.8rem;
            font-size:12px;
            color:#9B9B9B;
            text-align:center;
        }
        .exhibition-details>span>b{
            color:#D0021B;
        }
        .exhibition-img>img{
            width:7rem;
            height:3.6rem;
        }
    }



</style>
