<template>
    <section class="must-read">
        <div class="top-tab">
            <div><b :class="{tabActive: _self.tab === '1'}" @click="_self.tab = '1'">精选</b></div>
            <div><b :class="{tabActive: _self.tab === '2'}" @click="_self.tab = '2'">时政新闻</b></div>
            <div><b :class="{tabActive: _self.tab === '3'}" @click="_self.tab = '3'">公司动态</b></div>
            <div><b :class="{tabActive: _self.tab === '4'}" @click="_self.tab = '4'">知识热点</b></div>
        </div>
        <div class="column">
            <span>最新推荐</span>
            <span class="set-top"><b>置顶</b></span>
        </div>
        <div class="new-content">
            <swiper :list="img_list" :show-dots="false" auto></swiper>
        </div>
        <div class="column">
            <span>党员必读</span>
            <span class="set-hot"><b>热</b></span>
        </div>
        <div class="hot-content" @click="toUrl('Articles')">
            <div class="img-hot"></div>
            <b>
                <div>
                    <h3 class="title-hot">人民论坛：把“立证德”放在最前面</h3>
                    <b class="initiator-hot">李洪星</b>
                </div>
                <div>
                    <p>来源：人民网—人民日报</p>
                    <p>2018年07月26日&nbsp;08:08</p>
                </div>
            </b>
        </div>
        <div class="column" style="border-top:1px solid #F6F6F6;margin-top:0.15rem;">
            <span>热门推荐</span>
        </div>
        <div class="recommend-content">
            <div class="recommend-list" @click="toUrl('Articles')">
                <span>&nbsp;开启智慧党建新领域，人民奥诶见爱唯欧积分</span>
            </div>
            <div class="recommend-list" @click="toUrl('Articles')">
                <span>&nbsp;评论员观察：人在事上练，安慰佛我加我诶附近</span>
            </div>
            <div class="recommend-list" @click="toUrl('Articles')">
                <span>&nbsp;红船听涛：新时代的新星啊诶哦皮肤就爱我配附件</span>
            </div>
        </div>
        <div class="column" style="border-top:1px solid #F6F6F6;margin-top:0.15rem" @click="toUrl('Articles')">
            <span>精彩推荐</span>
        </div>
        <div class="wonderful-content">
            <div class="wonderful-box" @click="toUrl('Articles')">
                <div class="wonderful-list">
                    <div class="wonderful-img-box"></div>
                    <div class="wonderful-text">
                        <h3>习近平出席金砖国家工商论坛并发表重要讲话</h3>
                        <b>强调推动金砖合作再出发&nbsp;实现金砖国家共同发展</b>
                        <p style="bottom:0.4rem;">来源：人民网—人民日报</p>
                        <p style="bottom:0;">2018年07月26日&nbsp;06:47</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>


<script>
    import $ from 'jquery'
        import {Swiper,SwiperItem} from 'vux'

    export default {
        components: {
            Swiper,
            SwiperItem,
        },
        data() {
            return {
                tab:'1',
                img_list: [{
                    url: 'javascript:',
                    img: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vvsr72j20p00gogo2.jpg',
                    title: '送你一朵fua'
                }, {
                    url: 'javascript:',
                    img: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vw1k2wj20p00goq7n.jpg',
                    title: '送你一辆车'
                }, {
                    url: 'javascript:',
                    img: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vw50iwj20ff0aaaci.jpg',
                    title: '送你一次旅行',
                    //        fallbackImg: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vw50iwj20ff0aaaci.jpg' 如果img引入出现404错误时，使用此备用路径引入。
                }],
            }
        },
        methods: {
            toUrl:function(url){
                this.$router.push("/"+url)
            }
        },
        mounted() {
            $('.must-read').css("min-height",$(window).height());
            $("html,body").scrollTop(0);
        }
    }
</script>

<style lang="less">

    .must-read{

        background-color:white;
        .top-tab{
            height:0.8rem;
            display:flex;
            border-bottom:1px solid #f2f2f2;
        }
        .top-tab>div{
            flex:1;
        }
        .top-tab>div>b{
            display:block;
            width:70%;
            height:0.8rem;
            line-height:0.8rem;
            text-align:center;
            font-weight:normal;
            font-size:14px;
            margin:0 auto;
        }
        .tabActive{
            color:#D0021B;
            border-bottom:1px solid #D0021B;
        }
        .column{
            width:100%;
        }
        .column>span{
            display:inline-block;
            height:0.8rem;
            line-height:0.8rem;
            font-size:12px;
            text-align:center;
            margin-left:0.25rem;
            font-weight:bold;
        }
        .column>.set-top{
            display:inline-block;
            color:#D0021B;
            margin-left:0.05rem;
            border:1px solid #D0021B;
            font-size:12px;
            height:0.4rem;
            width:0.8rem;
            line-height:0.4rem;
            text-align:center;
            border-radius:3px;
            padding:1px 0;
        }

        .new-content{
            width:7rem;
            display:block;
            margin-left:0.25rem;
            position:relative;
        }
        .new-content>div{
            /*height:4.2rem;*/
            /*width:7rem;*/
        }
        .new-content>span{
            position:absolute;
            bottom:0;
            left:0;
            height:1.2rem;
            width:100%;
            display:block;
            background:rgba(0,0,0,0.4);
            color:white;
        }
        .new-content>span>b{
            display:block;
            margin-left:0.2rem;
        }
        .column>.set-hot{
            display:inline-block;
            color:#D0021B;
            margin-left:0.05rem;
            border:1px solid #D0021B;
            font-size:12px;
            height:0.4rem;
            width:0.4rem;
            line-height:0.4rem;
            text-align:center;
            border-radius:3px;
            padding:1px 0;
        }
        .hot-content{
            height:2.1rem;
            width:100%;
        }
        .img-hot{
            background-color:skyblue;
            height:2.1rem;
            width:2.8rem;
            margin-left:0.25rem;
            display:inline-block;
        }
        .hot-content>b{
            width:4rem;
            height:2.1rem;
            margin-right:0.25rem;
            display:inline-block;
            float:right;
        }
        .title-hot{
            font-size:13px;
        }
        .initiator-hot{
            height:0.4rem;
            line-height:0.4rem;
            display:block;
            font-size:12px;
            font-weight:normal;
        }
        .hot-content>b>div:first-child{
            height:1.25rem;
            width:100%;
        }
        .hot-content>b>div>p{
            line-height:0.425rem;
            height:0.425rem;
            font-size:12px;
            font-weight:normal;
        }
        .recommend-content{
            margin-top:0.1rem;
            height:2.55rem;
            overflow-x:auto;
            white-space:nowrap;
        }

        ::-webkit-scrollbar{
            display:none;
            width: 0;
            height: 0;
        }

        .recommend-list{
            display:inline-block;
            width:3rem;
            height:2.4rem;
            background-color:skyblue;
            margin-right:0.25rem;
            position:relative;
        }
        .recommend-content>div:first-child{
            margin-left:0.25rem;
        }
        .recommend-list>span{
            height:0.5rem;
            position:absolute;
            bottom:0;
            width:100%;
            background:rgba(0,0,0,0.4);
            line-height:0.5rem;
            font-size:12px;
            color:white;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
        }
        .wonderful-box{
            height:3rem;
            width:7.5rem;
            border-top:1px solid #f6f6f6;
        }
        .wonderful-list{
            height:2.7rem;
            width:7rem;
            margin:0.15rem 0.25rem;
            display:flex;
        }
        .wonderful-list>div{
            flex:1;
        }
        .wonderful-list>.wonderful-img-box{
            background-color:skyblue;
        }
        .wonderful-text{
            position:relative;
            margin-left:0.1rem;
        }
        .wonderful-text>h3{
            font-size:14px;
        }
        .wonderful-text>b{
            font-size:12px;
            color:#9B9B9B;
            font-weight:normal;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
        }
        .wonderful-text p{
            font-size:10px;
            color:#9b9b9b;
            position:absolute;
            line-height:0.3rem;
        }
    }



</style>
