<template>
    <div v-infinite-scroll="loadStudyDatum" infinite-scroll-disabled="busy"
         infinite-scroll-distance="10">
        <template v-if="fileSpiritList.length>0">

            <comm-item @click.native="toResourceDetail('/ResourceDetail',scrollIndex)"
                       v-for="(fileSpirit,scrollIndex) in fileSpiritList" :key="scrollIndex"
                       :imgSrc="fileSpirit.videoImg"
                       :type="fileSpirit.zyType"
                       :info1="fileSpirit.title"
                       :info2="fileSpirit.userName"
                       :info3="fileSpirit.partyName"
                       :info4="fileSpirit.modifyDate | dateFormat('YMD')">
                <input :id="'fileSpirit' + scrollIndex" type="hidden" :value="fileSpirit.docType"/>
                <input :id="'vid' + scrollIndex" type="hidden" :value="fileSpirit.vid"/>
            </comm-item>

            <loading></loading>
        </template>
        <div class="no-data" v-if="fileSpiritList.length==0"><p>没有数据</p></div>
    </div>
</template>

<script>
    import{getResourceList} from '../../../api/api'
    import commItem from '../../../components/common/commItem1.vue'
    import loading from '../../../components/common/loading.vue'
    import $ from 'jquery'
    export default {
        name: "FileSpiritList",
        components: {
            commItem,
            loading
        },
        data () {
            return {
                tabDesc:'文件精神',
                curPage: 1,
                pageSize: 10,
                totalPage: 1,
                busy: false,
                fileSpiritList:[]
            }
        },
        methods:{
            loadStudyDatum: function () {
                if (this.curPage > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initNineteenTopic();
            },

            toResourceDetail(url, scrollIndex){
                let type = $("#fileSpirit" + scrollIndex).val();
                let vid = $("#vid" + scrollIndex).val();
                this.$router.push({path: url, query: {type: type, vid: vid}});
            },
            initNineteenTopic: function () {
                let _self = this;
                $(".load-more").hide();
                getResourceList({
                    menu: '十九大精神',
                    tabDesc:_self.tabDesc,
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.fileSpiritList = _self.fileSpiritList.concat(response.data.list);
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            },
        },
    }
</script>

<style scoped>

</style>
