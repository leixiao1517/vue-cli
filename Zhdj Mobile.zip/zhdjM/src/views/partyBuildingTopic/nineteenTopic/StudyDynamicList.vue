<template>
    <div v-infinite-scroll="loadStudyDynamic" infinite-scroll-disabled="busy"
         infinite-scroll-distance="10">
        <template v-if="studyDynamicList.length>0">

            <comm-item @click.native="toResourceDetail('/ResourceDetail',scrollIndex)"
                       v-for="(studyDynamic,scrollIndex) in studyDynamicList" :key="scrollIndex"
                       :imgSrc="studyDynamic.videoImg"
                       :type="studyDynamic.zyType"
                       :info1="studyDynamic.title"
                       :info2="studyDynamic.userName"
                       :info3="studyDynamic.partyName"
                       :info4="studyDynamic.modifyDate | dateFormat('YMD')">
                <input :id="'studyDynamic' + scrollIndex" type="hidden" :value="studyDynamic.docType"/>
                <input :id="'vid' + scrollIndex" type="hidden" :value="studyDynamic.vid"/>
            </comm-item>

            <loading></loading>
        </template>
        <div class="no-data" v-if="studyDynamicList.length==0"><p>没有数据</p></div>
    </div>
</template>

<script>
    import{getResourceList} from '../../../api/api'
    import commItem from '../../../components/common/commItem1.vue'
    import loading from '../../../components/common/loading.vue'
    import $ from 'jquery'
    export default {
        name: "StudyDynamicList",
        components: {
            commItem,
            loading
        },
        data () {
            return {
                tabDesc:'学习动态',
                curPage: 1,
                pageSize: 10,
                totalPage: 1,
                busy: false,
                studyDynamicList:[]
            }
        },
        methods:{
            loadStudyDynamic: function () {
                if (this.curPage > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initNineteenTopic();
            },

            toResourceDetail(url, scrollIndex){
                let type = $("#studyDynamic" + scrollIndex).val();
                let vid = $("#vid" + scrollIndex).val();
                this.$router.push({path: url, query: {type: type, vid: vid}});
            },
            initNineteenTopic: function () {
                let _self = this;
                $(".load-more").hide();
                getResourceList({
                    menu: '十九大精神',
                    tabDesc:_self.tabDesc,
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.studyDynamicList = _self.studyDynamicList.concat(response.data.list);
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            },
        },
    }
</script>

<style scoped>

</style>
