<template>
    <section class="nineteenth-topic" >
        <div class="comm-head-logo">
            <div class="logo">
                <img src="../../../assets/images/common/icon-logo.png" alt="">
            </div>
            <div class="back" @click="toIndex">
                回到首页
            </div>
        </div>

        <div class="img">
            <img src="../../../assets/images/partyBuildingTopic/pic-nineteenthTopic-head.png" alt="">
        </div>

        <div class="resource-detail-content" @click="playVideo()">
            <div class="resource-detail-area">
                <!-- 播放图标 -->
                <i v-show="showFlag"></i>
                <!-- 播放遮罩 -->
                <div class="resource-detail-mask" v-show="showFlag"></div>
                <video class="video" id="video"  name="media" webkit-playsinline="true" playsinline="true"
                       x5-playsinline="true"
                       :poster="poster" controls
                       src="https://media.vangv.com/OUT/media/12b247cc6b080f71113103e80c6a8b55.mp4.mp4">
                </video>
            </div>
        </div>

        <tab :line-width=2 active-color='#D0021B'>
            <tab-item class="vux-center" :selected="$route.name=='FileSpiritList'"
                      @on-item-click="onSelectedItem"
                      key="0">文件精神
            </tab-item>
            <tab-item class="vux-center" :selected="$route.name=='StudyDatumList'"
                      @on-item-click="onSelectedItem"
                      key="1">学习资料
            </tab-item>
            <tab-item class="vux-center" :selected="$route.name=='StudyDynamicList'"
                      @on-item-click="onSelectedItem"
                      key="2">学习动态
            </tab-item>
            <tab-item class="vux-center" :selected="$route.name=='StudyConditionList'"
                      @on-item-click="onSelectedItem"
                      key="3">学习情况
            </tab-item>
        </tab>

        <div>
            <router-view></router-view>
        </div>

    </section>
</template>

<script>
    import {Tab, TabItem} from 'vux'
    import commItem from '../../../components/common/commItem1.vue'
    import $ from 'jquery'
    export default {
        name: 'nineteenTopic',
        components: {
            Tab,
            TabItem,
            commItem
        },
        data () {
            return {
                index:0,
                poster:require('../../../assets/images/partyBuildingTopic/pic-nineteenthTopicVideo.png'),
                showFlag: true
            }
        },

        methods: {
            onSelectedItem (index){
                if (index === 0) {
                    this.$router.replace('/NineteenthTopic')
                }else if (index === 1) {
                    this.$router.replace('/NineteenthTopic/StudyDatumList')
                }else if (index === 2) {
                    this.$router.replace('/NineteenthTopic/StudyDynamicList')
                }else if (index === 3) {
                    this.$router.replace('/NineteenthTopic/StudyConditionList')
                }

            },
            playVideo: function () {
                if (this.showFlag) {
                    this.showFlag = false;
                    $('#video').trigger('play');
                } else {
                    this.showFlag = true;
                    $('#video').trigger('pause');
                }
            },
            toIndex: function () {
                this.$router.push('/index')
            }
        }
    }
</script>

<style lang="less">

    .nineteenth-topic {
        .img{
            img{
                width: 100%;
            }
        }
        /*.video{*/
            /*font-size: 0;*/
            /*video{*/
                /*width: 100%;*/
                /*height: 3.2rem;*/
                /*object-fit: fill;*/
            /*}*/
        /*}*/


        .resource-detail-content {
            font-size: 0;
            img {
                height: 360px;
                width: 100%;
            }

            .resource-detail-area {
                position: relative;
                .resource-detail-mask {
                    position: absolute;
                    left: 0;
                    top: 0;
                    width: 100%;
                    height: 100%;
                    background: rgba(0, 0, 0, 0.5);
                    z-index: 111;
                }
                i {
                    display: inline-block;
                    position: absolute;
                    width: 70px;
                    height: 70px;
                    left: 50%;
                    margin-left: -35px;
                    top: 50%;
                    margin-top: -35px;
                    background: url("../../../assets/images/survey/icon_video_detail.png") no-repeat;
                    background-size: 70px;
                    z-index: 112;
                }

                .video {
                    width: 100%;
                    height: 4.2rem;
                    object-fit: fill; //poster全铺满video
                }

            }
        }


    }

</style>
