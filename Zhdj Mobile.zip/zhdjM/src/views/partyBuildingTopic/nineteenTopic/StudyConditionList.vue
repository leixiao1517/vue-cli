<template>
    <div v-infinite-scroll="loadStudyCondition" infinite-scroll-disabled="busy"
         infinite-scroll-distance="10">
        <template v-if="studyConditionList.length>0">

            <comm-item @click.native="toResourceDetail('/ResourceDetail',scrollIndex)"
                       v-for="(studyCondition,scrollIndex) in studyConditionList" :key="scrollIndex"
                       :imgSrc="studyCondition.videoImg"
                       :type="studyCondition.zyType"
                       :info1="studyCondition.title"
                       :info2="studyCondition.userName"
                       :info3="studyCondition.partyName"
                       :info4="studyCondition.modifyDate | dateFormat('YMD')">
                <input :id="'studyCondition' + scrollIndex" type="hidden" :value="studyCondition.docType"/>
                <input :id="'vid' + scrollIndex" type="hidden" :value="studyCondition.vid"/>
            </comm-item>

            <loading></loading>
        </template>
        <div class="no-data" v-if="studyConditionList.length==0"><p>没有数据</p></div>
    </div>
</template>

<script>
    import{getResourceList} from '../../../api/api'
    import commItem from '../../../components/common/commItem1.vue'
    import loading from '../../../components/common/loading.vue'
    import $ from 'jquery'
    export default {
        name: "StudyConditionList",
        components: {
            commItem,
            loading
        },
        data () {
            return {
                tabDesc:'studyCondition',
                curPage: 1,
                pageSize: 10,
                totalPage: 1,
                busy: false,
                studyConditionList:[]
            }
        },
        methods:{
            loadStudyCondition: function () {
                if (this.curPage > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initNineteenTopic();
            },

            toResourceDetail(url, scrollIndex){
                let type = $("#studyCondition" + scrollIndex).val();
                let vid = $("#vid" + scrollIndex).val();
                this.$router.push({path: url, query: {type: type, vid: vid}});
            },
            initNineteenTopic: function () {
                let _self = this;
                $(".load-more").hide();
                getResourceList({
                    menu: '十九大精神',
                    tabDesc:_self.tabDesc,
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.studyConditionList = _self.studyConditionList.concat(response.data.list);
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            },
        },
    }
</script>

<style scoped>

</style>
