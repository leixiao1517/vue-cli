<template>
    <section class="nineteenth-topic" >
        <div class="img">
            <img src="../../../assets/images/partyBuildingTopic/pic-studyTopic.png" alt="">
        </div>


        <tab :line-width=2 active-color='#D0021B' :scroll-threshold="4">
            <tab-item class="vux-center" :selected="$route.name=='CentralSpiritList'"
                      @on-item-click="onSelectedItem"
                      key="0">中央精神
            </tab-item>
            <tab-item class="vux-center" :selected="$route.name=='WorkTrendList'"
                      @on-item-click="onSelectedItem"
                      key="1">工作动态
            </tab-item>
            <tab-item class="vux-center" :selected="$route.name=='PartyConstitutionList'"
                      @on-item-click="onSelectedItem"
                      key="2">党章党规
            </tab-item>
            <tab-item class="vux-center" :selected="$route.name=='SeriesOfSpeechList'"
                      @on-item-click="onSelectedItem"
                      key="3">系列讲话
            </tab-item>

            <tab-item class="vux-center" :selected="$route.name=='LearnEducationSchemeList'"
                      @on-item-click="onSelectedItem"
                      key="4">学习教育方案
            </tab-item>

            <tab-item class="vux-center" :selected="$route.name=='PioneerStoryList'"
                      @on-item-click="onSelectedItem"
                      key="5">先锋故事
            </tab-item>

            <tab-item class="vux-center" :selected="$route.name=='LearningServicesList'"
                      @on-item-click="onSelectedItem"
                      key="6">学习服务
            </tab-item>
        </tab>

        <div>
            <router-view></router-view>
        </div>

    </section>
</template>

<script>
    import {Tab, TabItem} from 'vux'
    import commItem from '../../../components/common/commItem1.vue'
    export default {
        name: 'studyTopic',
        components: {
            Tab,
            TabItem,
            commItem
        },
        data () {
            return {
                index:0
            }
        },

        methods: {
            onSelectedItem (index){
                if (index === 0) {
                    this.$router.replace('/studyTopic')
                }else if (index === 1) {
                    this.$router.replace('/studyTopic/WorkTrendList')
                }else if (index === 2) {
                    this.$router.replace('/studyTopic/PartyConstitutionList')
                }else if (index === 3) {
                    this.$router.replace('/studyTopic/SeriesOfSpeechList')
                }else if (index === 4) {
                    this.$router.replace('/studyTopic/LearnEducationSchemeList')
                }else if (index === 5) {
                    this.$router.replace('/studyTopic/PioneerStoryList')
                }else if (index === 6) {
                    this.$router.replace('/studyTopic/LearningServicesList')
                }

            }
        }
    }
</script>

<style lang="less">

    .nineteenth-topic {
        .img{
            img{
                width: 100%;
            }
        }
        .video{
            font-size: 0;
            video{
                width: 100%;
                height: 3.2rem;
                object-fit: fill;
            }
        }
    }

</style>
