<template>
    <div v-infinite-scroll="loadStudyDynamic" infinite-scroll-disabled="busy"
         infinite-scroll-distance="10">
        <template v-if="seriesOfSpeechList.length>0">

            <comm-item @click.native="toResourceDetail('/ResourceDetail',scrollIndex)"
                       v-for="(seriesOfSpeech,scrollIndex) in seriesOfSpeechList" :key="scrollIndex"
                       :imgSrc="seriesOfSpeech.videoImg"
                       :type="seriesOfSpeech.zyType"
                       :info1="seriesOfSpeech.title"
                       :info2="seriesOfSpeech.userName"
                       :info3="seriesOfSpeech.partyName"
                       :info4="seriesOfSpeech.modifyDate | dateFormat('YMD')">
                <input :id="'seriesOfSpeech' + scrollIndex" type="hidden" :value="seriesOfSpeech.docType"/>
                <input :id="'vid' + scrollIndex" type="hidden" :value="seriesOfSpeech.vid"/>
            </comm-item>

            <loading></loading>
        </template>
        <div class="no-data" v-if="seriesOfSpeechList.length==0"><p>没有数据</p></div>
    </div>
</template>

<script>
    import{getResourceList} from '../../../api/api'
    import commItem from '../../../components/common/commItem1.vue'
    import loading from '../../../components/common/loading.vue'
    import $ from 'jquery'
    export default {
        name: "SeriesOfSpeechList",
        components: {
            commItem,
            loading
        },
        data () {
            return {
                tabDesc:'系列讲话',
                curPage: 1,
                pageSize: 10,
                totalPage: 1,
                busy: false,
                seriesOfSpeechList:[]
            }
        },
        methods:{
            loadStudyDynamic: function () {
                if (this.curPage > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initNineteenTopic();
            },

            toResourceDetail(url, scrollIndex){
                let type = $("#seriesOfSpeech" + scrollIndex).val();
                let vid = $("#vid" + scrollIndex).val();
                this.$router.push({path: url, query: {type: type, vid: vid}});
            },
            initNineteenTopic: function () {
                let _self = this;
                $(".load-more").hide();
                getResourceList({
                    menu: '两学一做',
                    tabDesc:_self.tabDesc,
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.seriesOfSpeechList = _self.seriesOfSpeechList.concat(response.data.list);
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            },
        },
    }
</script>

<style scoped>

</style>
