<template>
    <div v-infinite-scroll="loadStudyDatum" infinite-scroll-disabled="busy"
         infinite-scroll-distance="10">
        <template v-if="learningServicesList.length>0">

            <comm-item @click.native="toResourceDetail('/ResourceDetail',scrollIndex)"
                       v-for="(learningServices,scrollIndex) in learningServicesList" :key="scrollIndex"
                       :imgSrc="learningServices.videoImg"
                       :type="learningServices.zyType"
                       :info1="learningServices.title"
                       :info2="learningServices.userName"
                       :info3="learningServices.partyName"
                       :info4="learningServices.modifyDate | dateFormat('YMD')">
                <input :id="'learningServices' + scrollIndex" type="hidden" :value="learningServices.docType"/>
                <input :id="'vid' + scrollIndex" type="hidden" :value="learningServices.vid"/>
            </comm-item>

            <loading></loading>
        </template>
        <div class="no-data" v-if="learningServicesList.length==0"><p>没有数据</p></div>
    </div>
</template>

<script>
    import{getResourceList} from '../../../api/api'
    import commItem from '../../../components/common/commItem1.vue'
    import loading from '../../../components/common/loading.vue'
    import $ from 'jquery'
    export default {
        name: "LearningServicesList",
        components: {
            commItem,
            loading
        },
        data () {
            return {
                tabDesc:'学习服务',
                curPage: 1,
                pageSize: 10,
                totalPage: 1,
                busy: false,
                learningServicesList:[]
            }
        },
        methods:{
            loadStudyDatum: function () {
                if (this.curPage > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initNineteenTopic();
            },

            toResourceDetail(url, scrollIndex){
                let type = $("#learningServices" + scrollIndex).val();
                let vid = $("#vid" + scrollIndex).val();
                this.$router.push({path: url, query: {type: type, vid: vid}});
            },
            initNineteenTopic: function () {
                let _self = this;
                $(".load-more").hide();
                getResourceList({
                    menu: '两学一做',
                    tabDesc:_self.tabDesc,
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.learningServicesList = _self.learningServicesList.concat(response.data.list);
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            },
        },
    }
</script>

<style scoped>

</style>
