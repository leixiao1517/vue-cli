<template>
    <div v-infinite-scroll="loadStudyDatum" infinite-scroll-disabled="busy"
         infinite-scroll-distance="10">
        <template v-if="partyConstitutionList.length>0">

            <comm-item @click.native="toResourceDetail('/ResourceDetail',scrollIndex)"
                       v-for="(partyConstitution,scrollIndex) in partyConstitutionList" :key="scrollIndex"
                       :imgSrc="partyConstitution.videoImg"
                       :type="partyConstitution.zyType"
                       :info1="partyConstitution.title"
                       :info2="partyConstitution.userName"
                       :info3="partyConstitution.partyName"
                       :info4="partyConstitution.modifyDate | dateFormat('YMD')">
                <input :id="'partyConstitution' + scrollIndex" type="hidden" :value="partyConstitution.docType"/>
                <input :id="'vid' + scrollIndex" type="hidden" :value="partyConstitution.vid"/>
            </comm-item>

            <loading></loading>
        </template>
        <div class="no-data" v-if="partyConstitutionList.length==0"><p>没有数据</p></div>
    </div>
</template>

<script>
    import{getResourceList} from '../../../api/api'
    import commItem from '../../../components/common/commItem1.vue'
    import loading from '../../../components/common/loading.vue'
    import $ from 'jquery'
    export default {
        name: "PartyConstitutionList",
        components: {
            commItem,
            loading
        },
        data () {
            return {
                tabDesc:'党章党规',
                curPage: 1,
                pageSize: 10,
                totalPage: 1,
                busy: false,
                partyConstitutionList:[]
            }
        },
        methods:{
            loadStudyDatum: function () {
                if (this.curPage > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initNineteenTopic();
            },

            toResourceDetail(url, scrollIndex){
                let type = $("#partyConstitution" + scrollIndex).val();
                let vid = $("#vid" + scrollIndex).val();
                this.$router.push({path: url, query: {type: type, vid: vid}});
            },
            initNineteenTopic: function () {
                let _self = this;
                $(".load-more").hide();
                getResourceList({
                    menu: '两学一做',
                    tabDesc:_self.tabDesc,
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.partyConstitutionList = _self.partyConstitutionList.concat(response.data.list);
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            },
        },
    }
</script>

<style scoped>

</style>
