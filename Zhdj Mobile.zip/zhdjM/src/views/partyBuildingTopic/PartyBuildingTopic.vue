<template>
    <section class="party-building">

        <div class="party-building-content" v-for="(Topic,index) in TopicList">
            <div class="party-building-pic" @click="partyBuildLink(index)">
                <img :src="Topic.coverImg"/>
            </div>
            <div class="party-building-title">{{Topic.title}}</div>
            <div class="party-building-time">{{Topic.time}}</div>
        </div>
    </section>
</template>

<script>
    import $ from 'jquery'
    import {mobileServer} from '../../config/config'
    export default {
        name: 'hello',
        data () {
            return {
                TopicList: [
                    {
                        coverImg: require('../../assets/images/partyBuildingTopic/nineteen.png'),
                        title: '湖南中烟学习贯彻党的十九大精神',
                        time: '2018-01-10'
                    },
                    {
                        coverImg: require('../../assets/images/library/partyTopic.png'),
                        title: '不忘初心 牢记使命”庆祝中国共产党建党97周年:湖南中烟趣味知识答题闯关赛',
                        time: '2017-06-26'
                    },
//                    {
//                        coverImg: require('../../assets/images/partyBuildingTopic/studyTopic.png'),
//                        title: '学党章党规 学系列讲话 做合格党员',
//                        time: '2016-06-03'
//                    },

                ]
            }
        },

        methods: {
            partyBuildLink: function (index) {
                if(index==0){
                    this.$router.push('/NineteenthTopic')
                }
// if(index==1){
//                    //两学一做
//                    this.$router.push('/StudyTopic')
 //               }
                else if(index==1){
                    //19大专题

                    window.location.href = mobileServer + "wy/login"
                }

            },
        }
    }
</script>

<style lang="less">

    .party-building {
        height: 12.5rem;
        background-color: #FFFFFF;

        .party-building-content {

            .party-building-pic {
                width: 100%;
                img {
                    height: 3rem;
                    width: 90%;
                    padding: 10px 18px 5px 18px;
                }

            }

            .party-building-title {
                font-size: 14px;
                color: #323232;
                padding-left: 18px;
                padding-right: 18px;
                padding-top: 5px;
            }
            .party-building-time {
                font-size: 12px;
                padding-left: 18px;
                padding-top: 5px;
                color: #969696;
            }

        }
    }

</style>
