<template>
    <section class="basic-dynamic">
        <section>
            <div class="basic-dynamic-summary">
                <div class="basic-dynamic-resource angle" @click="selectUnit">
                    <popup-picker @on-change="searchUnit"
                                  title=""
                                  :data="unitList"
                                  v-model="unitName">
                                  </popup-picker>

                </div>


            </div>

        </section>
        <section>
            <div>
                <div v-infinite-scroll="loadBasicDynamic" infinite-scroll-disabled="busy"
                     infinite-scroll-distance="10">
                    <template v-if="basicDynamicList.length>0">

                        <comm-item @click.native="toResourceDetail('/ResourceDetail',scrollIndex)"
                                   v-for="(basicDynamic,scrollIndex) in basicDynamicList" :key="scrollIndex"

                                   :imgSrc="basicDynamic.videoImg"
                                   :type="basicDynamic.zyType"
                                   :info1="basicDynamic.title"
                                   :info2="basicDynamic.userName"
                                   :info3="basicDynamic.partyName"
                                   :info4="basicDynamic.modifyDate | dateFormat('YMD')">
                            <input :id="'basicDynamic' + scrollIndex" type="hidden" :value="basicDynamic.docType"/>
                            <input :id="'vid' + scrollIndex" type="hidden" :value="basicDynamic.vid"/>
                        </comm-item>

                        <loading></loading>
                    </template>
                    <div class="no-data" v-if="basicDynamicList.length==0"><p>没有数据</p></div>
                </div>
                <!--<div class="class-room-footer">-->
                <!--<img src="../../assets/images/library/publish-meeting.png"/>-->
                <!--</div>-->
            </div>

            <div style="width: 200px">

            </div>


        </section>
    </section>
</template>

<script>
    import loading from '../../components/common/loading.vue'
    import{getResourceList} from '../../api/api'
    import {Actionsheet,PopupPicker,Group } from 'vux'
    import commItem from '../../components/common/commItem1.vue'
    import $ from 'jquery'
    export default {

        components: {
            loading,
            Actionsheet,
            commItem,
            PopupPicker,
            Group
        },
        data () {
            return {
                showSort: false,
                unitList: [[
                    '全部单位',
                    '公司总部',
                    '市场营销中心',
                    '技术中心',
                    '长沙卷烟厂',
                    '常德卷烟厂',
                    '郴州卷烟厂',
                    '零陵卷烟厂',
                    '吴忠卷烟厂',
                    '四平卷烟厂',
                    '物流公司',
                    '金叶薄片公司',
                ]],
                resourceCount: '',
                basicDynamicList: [],
                curPage: 1,
                pageSize: 6,
                totalPage: 1,
                busy: false,
                sortTotalPage: 1,
                keyTemp: 1,
                unitName: ['全部单位'],
            }
        },

        methods: {

            toResourceDetail(url, scrollIndex){
                console.log('--------' + url)
                let type = $("#basicDynamic" + scrollIndex).val();
                let vid = $("#vid" + scrollIndex).val();
                this.$router.push({path: url, query: {type: type, vid: vid}});
            },

            loadBasicDynamic: function () {
                if (this.curPage > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initBasicDynamicList();
            },

            initBasicDynamicList: function () {
                let _self = this;

                $(".load-more").hide();
                getResourceList({
                    menu: '基层动态',
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.basicDynamicList = _self.basicDynamicList.concat(response.data.list);
                        _self.resourceCount = response.data.total;
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            },

            searchUnit (val) {
                let item = ''
                let _self = this;
                _self.curPage = 1;
                if (val[0] == '全部单位') {
                    item = ''
                }else{
                    item = val[0]
                }

                getResourceList({
                    committeeName: item,
                    menu: '基层动态',
                    tabDesc: _self.tabDesc,
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.basicDynamicList = response.data.list;
                        _self.resourceCount = response.data.total;
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false;
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))

            },
            selectUnit() {
                this.showSort = true
            }
        }
    }
</script>

<style lang="less">

    .basic-dynamic {
        height: 11.4rem;

        .basic-dynamic-summary {
            /*height: 1rem;*/
            background-color: #FFFFFF;
            margin-bottom: 1px;
            .basic-dynamic-resource {
                display: inline-block;
                font-size: 14px;
                margin: 2px;
                .vux-cell-value{
                    color: #4A4A4A;
                }
            }
            .angle{
                position: relative;
            }
            .angle:after {
                position: absolute;
                right: 16px;
                top: 20px;
                content: '';
                display: block;
                border-top: 4px solid #4A4A4A;
                border-left: 3px solid transparent;
                border-right: 3px solid transparent;
            }
            .basic-dynamic-sort {
                display: inline-block;
                float: right;
                margin: 14px 20px;
            }
        }

        .basic-dynamic-list {
            height: 1.7rem;
            /*margin: 10px 10px 0px 10px;*/
            margin-bottom: 1px;
            padding-left: 20px;
            padding-right: 20px;
            background-color: #FFFFFF;

            .basic-dynamic-title {
                font-size: 14px;
                color: #323232;
                display: block;
                text-overflow: ellipsis;
                overflow: hidden;
                white-space: nowrap;
            }
            .basic-dynamic-type {
                color: #969696;
            }

            .basic-dynamic-list-content {
                margin: 0px 5px 5px 0px;
                font-size: 12px;
                color: #969696;
                .basic-dynamic-date {
                    float: right;
                }
                .basic-dynamic-userName {
                    padding-left: .6rem;
                }
            }
        }

        .basic-dynamic-footer {
            padding-bottom: 2px;
            img {
                width: 100%;
            }
        }

    }

    @import '../../assets/css/content.less';
</style>
