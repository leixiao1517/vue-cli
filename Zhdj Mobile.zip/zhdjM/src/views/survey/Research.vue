<template>
    <section class="own-research">
        <group title="选择项目">
            <template v-for="(research , index) in myResearch">
                <cell :title="research.title" :link="'/vote/' + research.vid">
                    <div class="research-status">参加</div>
                </cell>
            </template>
        </group>
    </section>
</template>

<script>
    import { Group, Cell } from 'vux'

    export default {
        components: {
            Group,
            Cell,
        },
        data () {
            return {
                myResearch:[{title:'规律的双方各电耗更待何时高大上更多时候更多时候割发代首割发代首更多时候广东省分公司电话个1',vid:1},{title:'22',vid:2},{title:'3',vid:3}],
            }
        },
        methods: {

        },
        mounted () {

        }
    }
</script>
<style lang="less">
    .own-research{
        background: #ffffff;
        padding-bottom: 30px;
        .research-status{
            color:#D0021B;
            font-size: 12px;
        }
        .weui-cells{
            margin-top:0px;
            font-size: 14px;
        }
        .weui-cells__title{
            line-height: 40px;
            margin-top:0px;
            margin-bottom:0px;
        }
    }
</style>
