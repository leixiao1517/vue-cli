<template>
    <section class="survey">
        <img class="survey-banner" src="../../assets/images/survey/survey.png">
        <grid :cols="2">
            <grid-item :link="{path:'/voice'}">
                <img slot="icon" src="../../assets/images/survey/icon-voice.png">
                <span class="grid-center">党员心声</span>
            </grid-item>
            <grid-item :link="{path:'/research'}">
                <img slot="icon" src="../../assets/images/survey/icon-survey.png">
                <span class="grid-center">项目调研</span>
            </grid-item>
            <grid-item :link="{path:'/vote'}">
                <img slot="icon" src="../../assets/images/survey/icon-vote.png">
                <span class="grid-center">民意投票</span>
            </grid-item>
            <grid-item :link="{path:'/secretary'}">
                <img slot="icon" src="../../assets/images/survey/icon-mail.png">
                <span class="grid-center">书记信箱</span>
            </grid-item>
        </grid>
    </section>
</template>

<script>
    import { Grid, GridItem } from 'vux'
    import $ from 'jquery'

    export default {
        components: {
            Grid,
            GridItem,
        },
        data () {
            return {

            }
        },
        methods: {
        },
        mounted () {

        }
    }
</script>

<style lang="less">
    .survey{
        .survey-banner{
            width: 100%;
            height: 180px;
            margin-bottom: 2px;
        }
        .grid-center {
            display: block;
            text-align: center;
            color: #666;
        }
        .weui-grids {
            background-color: #fff;
        }
        .weui-grid{
            height: 180px;
        }
        .weui-grid__icon{
            margin-top: 50px;
        }
    }
</style>
