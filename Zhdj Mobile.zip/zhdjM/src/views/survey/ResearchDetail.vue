<template>
    <section class="research-detail">
        <p>{{researchData.title}}</p>
        <group :title="question.title" v-for="(question , index) in researchData.questions" :key="index">
            <radio :options="question.options" v-model="question.userAnswer" @click.native="getUserAnswer(index)"></radio>
        </group>
    </section>
</template>

<script>
    import { Group, Radio } from 'vux'

    export default {
        components: {
            Group,
            Radio,
        },
        data () {
            return {
                researchData:{
                    title:'项目调研标题',
                    questions:[
                        {qid:1,title:'调研1',options:[1,2,3,4],answer:3,userAnswer:''},
                        {qid:1,title:'调研2',options:[1,2,3],answer:1,userAnswer:''},
                        {qid:1,title:'调研3',options:[1,2],answer:2,userAnswer:''}
                    ]
                },
            }
        },
        methods: {
            getUserAnswer:function (index) {
                console.log(index+","+this.researchData.questions[index].userAnswer)
            },
        },
        mounted () {

        }
    }
</script>
<style lang="less">
    .research-detail{
        background: #ffffff;
        padding-bottom: 30px;
        .research-status{
            color:#D0021B;
            font-size: 12px;
        }
        .weui-cells{
            margin-top:0px;
            font-size: 14px;
        }
        .weui-cells__title{
            line-height: 40px;
            margin-top:0px;
            margin-bottom:0px;
        }
    }
</style>
