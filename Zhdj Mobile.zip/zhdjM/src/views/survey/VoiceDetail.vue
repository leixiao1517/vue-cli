
<template>
    <section class="voice-detail">
        <h3 class="title">{{voice.title}}</h3>

        <!-- 文字区 -->
        <div class="content">
            <div>详情</div>
            <div>
                {{voice.content}}
            </div>
        </div>

        <!-- 发表的图片区 -->
        <div class="images clfix" v-if="null != imageList && imageList.length > 0">
            <div class="image" v-for="(img,index) in voice.imageList" :key="index">
                <img src="../../assets/images/survey/survey.png"/>
            </div>
        </div>

        <!-- 回复区 -->
        <div class="voice-comment">
            <span>收到回复:</span>
            <span>{{voice.comment}}</span>
            <p>{{voice.replyer}} [{{voice.partyName}} {{voice.branchName}}]</p>
        </div>
    </section>
</template>

<script>
    import { Group, Cell } from 'vux'

    export default {
        components: {
            Group,
            Cell,
        },
        data () {
            return {
                voice:{
                    title:'哈哈哈',
                    content:'好好好',
                    replyer:'古月',
                    partyName:'古月',
                    branchName: '技术支部',
                    comment:'一下',
                    imageList:['1','2','1','2','1','2','1','2','1']
                },
            }
        },
        methods: {

        },
        mounted () {
            console.log(this.$route.query.vid)
        }
    }
</script>
<style lang="less">
    .voice-detail{
        h3{
            background-color: #fff;
            line-height: 40px;
            text-align: center;
            padding: 0 10px;
        }
        .content{
            margin: 2px 0;
            background-color: #fff;
            padding: 10px 10px 50px 10px;
        }
        .content div:first-child{
            color: #D0021B;
            font-weight: bold;
            line-height: 30px;
        }
        .content div{
            color: #4A4A4A;
        }
        .images{
            background-color: #fff;
            padding: 10px;
            .image{
                float: left;
            }
            img{
                float: left;
                margin: .05rem;
                width: 1.3rem;
                height: 1.3rem;
                overflow: hidden;
            }
        }
        .voice-comment{
            margin-top: 2px;
            background: #fff;
            color: #4A4A4A;
            font-size: 12px;
            word-spacing: 5px;
            padding: 15px 10px;
        }
    }
</style>
