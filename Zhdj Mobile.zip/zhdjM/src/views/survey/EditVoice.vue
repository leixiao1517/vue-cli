
<template>
    <section class="edit-voice">
        <div class="voice-info">
            <x-input placeholder="请输入主题" v-model="voice.title"></x-input>
            <x-textarea :max="300" placeholder="请说出您的心声" v-model="voice.content" auto></x-textarea>
        </div>

        <!-- 上传图片 + -->
        <ul class="clfix" id="thelist">
            <li id="controlLi" v-show="fileNum < 9">
                <div id="filePicker"></div>
                <i></i>
            </li>
        </ul>
        <button @click="publishVoice">发表</button>
    </section>
</template>

<script>
    import {publishVoice,deleteVoice} from '../../api/api'
    import { XTextarea, XInput,Tab, TabItem ,CheckIcon } from 'vux'

    export default {
        components: {
            XTextarea,
            XInput,
            Tab,
            TabItem,
            CheckIcon
        },
        data () {
            return {
                fileNum:0,//文件个数
                flag:0,
                vid:0,
                seq:1,
                voice:{title:'',content:'',type:1},
                shareUploader:{},
            }
        },
        methods: {
            /*init webuploader*/
            initUpload:function () {
                let _self = this;

                //上传
                let $list = $("#thelist");   //这几个初始化全局的百度文档上没说明
                let thumbnailWidth = 100;   //缩略图高度和宽度 （单位是像素），当宽高度是0~1的时候，是按照百分比计算，具体可以看api文档
                let thumbnailHeight = 100;
                _self.vid = 0;
                let opt = {
                    // 选完文件后，是否自动上传。
                    auto: false,
                    // swf文件路径
                    swf: '../../assets/images/survey/Uploader.swf',
                    // 文件接收服务端。
                    server: '/uploadVoiceResource',
                    // 选择文件的按钮。可选。
                    // 内部根据当前运行是创建，可能是input元素，也可能是flash.
                    pick: '#filePicker',
                    // 只允许选择的文件。
                    accept: {
                        title: 'Image',
                        extensions: 'gif,jpg,jpeg,bmp,png',//限制上传类型
                        mimeTypes: 'image/*'
                    },
                    method: 'POST',
                    duplicate: false,
                    multiple: true,
                    compress:{
                        width: 1600,
                        height: 1600,
                        // 图片质量，只有type为`image/jpeg`的时候才有效。
                        quality: 50,
                        // 是否允许放大，如果想要生成小图的时候不失真，此选项应该设置为false.
                        allowMagnify: false,
                        // 是否允许裁剪。
                        crop: false,
                        // 是否保留头部meta信息。
                        preserveHeaders: true,
                        // 如果发现压缩后文件大小比原来还大，则使用原来图片
                        // 此属性可能会影响图片自动纠正功能
                        noCompressIfLarger: false,
                        // 单位字节，如果图片大小小于此值，不会采用压缩。
                        compressSize: 204800,
                        type: 'image/jpeg'
                    },
                    threads: 1,
                    fileNumLimit: 9,
                    fileSizeLimit: 10 * 1024 * 1024   // 10 M  限制上传资源的总大小
                };

                let uploader = new WebUploader.Uploader(opt);
                _self.shareUploader = uploader;
                // 当有文件添加进来的时候
                uploader.on('fileQueued', function (file) {  // webuploader事件.当选择文件后，文件被加载到文件队列中，触发该事件。等效于 uploader.onFileueued = function(file){...} ，类似js的事件定义。
                    console.log(file.type);

                    let $li = $(
                            '<li id="' + file.id + '" class="full">' +
                            '<img>' +
                            '<em></em>' +
                            '</li>'
                        ),
                        $img = $li.find('img');
                    // $list为容器jQuery实例
                    $list.append($li);
                    $("#controlLi").before($li);
                    // 创建缩略图
                    // 如果为非图片文件，可以不用调用此方法。
                    // thumbnailWidth x thumbnailHeight 为 100 x 100
                    uploader.makeThumb(file, function (error, src) {//webuploader方法
                        if (error) {
                            $img.replaceWith('<span>不能预览</span>');
                            return;
                        }
                        $img.attr('src', src);
                    }, thumbnailWidth, thumbnailHeight);
                    //改变文件个数
                    _self.fileNum = $(".full").length == undefined ? 0 : $(".full").length;
                });

                uploader.on('uploadBeforeSend', function (obj, data, header) {
                    console.log("uploadBeforeSend data:o%", data);
                    //设置上传文件时需要传到后台的参数
                    data.vid = _self.vid;
                    data.type = _self.voice.type;
                    data.fName = "share_" + _self.seq++;
                });

                // 文件上传过程中创建进度条实时显示。
                uploader.on('uploadProgress', function (file, percentage) {
                    console.log("uploadProgress=======" + file.id);
                    let $li = $("#" + file.id);
                    let $percent = $('<p class="progress"><span class="percentage"></span></p>').appendTo($li).find('span');
                    $percent.css('width', percentage * 100 + '%');
                });

                // 文件上传成功，给item添加成功class, 用样式标记上传成功。
                uploader.on('uploadSuccess', function (file, data) {
                    if(data.success){
                        _self.flag ++ ;
                        if(_self.flag == _self.fileNum){ //判断是否所有图片都上传成功
                            // 隐藏
                            _self.$vux.loading.hide()
                            uploader.destroy()//必须要在所有图片上传完成再destroy 否则直接跳转回来再上传图片的时候会出现问题：删除图片不成功
                            setTimeout(function () {
                                _self.$parent.onItemClick(2)
                            },500)
                        }
                    } else {
//                        _self.deleteVoice();
                    }

                    console.log("data:", data);
                    $('#' + file.id).addClass('upload-state-done');
                    let num = uploader.getStats().successNum;
                    if ($(".full").length == num) {
//                        window.location.href = "/share";
                    }
                });

                // 文件上传失败，显示上传出错。
                uploader.on('uploadError', function (file) {
                    // 隐藏
                    _self.$vux.loading.hide()
                    let $li = $('#' + file.id), $error = $li.find('div.error');
                    // 避免重复创建
                    if (!$error.length) {
                        $error = $('<div class="error"></div>').appendTo($li);
                    }
                    $error.text('上传失败');
                    _self.deleteVoice();
                });

                // 文件上传失败，显示上传出错。
                uploader.on('error', function (type) {
                    // 隐藏
                    _self.$vux.loading.hide()
                    if ("Q_EXCEED_NUM_LIMIT" == type) {
                        _self.$vux.toast.text("上传图片最多9个", 'middle')
                    } else if ("Q_TYPE_DENIED" == type) {
                        return false;
                    } else if ("Q_EXCEED_SIZE_LIMIT" == type) {
                        _self.$vux.toast.text("图片总大小不能超过100M噢~", 'middle')
                        return false;
                    }
                    return true;
                });

                //完成上传完了，成功或者失败，先删除进度条。
                uploader.on('uploadComplete', function (file) {
                    console.log("uploadComplete=======" + file.id);
                    $('#' + file.id).find('.progress').remove();
                });

            },
            //绑定发表事件
            publishVoice:function(){
                let _self = this
                if ($.trim(_self.voice.content) == "" && $(".full").length < 1) {
                    _self.$vux.toast.text("你什么都没留下", 'middle')
                    return;
                }
                let imgNum = $(".full").length == undefined ? 0 : $(".full").length;
                let imgs = "";
                for (let i = 1; i < imgNum + 1; i++) {
                    imgs += (",share_" + i + ".jpg");//存储图片路径
                }
                _self.voice.images = imgs.substring(1);
                // 显示
                _self.$vux.loading.show({text: 'Loading'})
                //保存说说内容  图片名字
                publishVoice(_self.voice).then((response) => {
                    // 隐藏
                    _self.$vux.loading.hide()
                    if (response.success) {
                        _self.vid = response.data;
                        console.log("_self.vid-==", _self.vid);
                        if(_self.fileNum == 0){//是否有文件
                            _self.$parent.onItemClick(2)
                        } else {
                            //上传图片
                            _self.shareUploader.upload();
                        }
                    } else if (response.message === "notLogin") {
                        window.location.href = "/user/login.html";
                    } else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }).catch((error) => {
                    console.log(error)
                });
            },
            deleteVoice:function () {
                let _self = this;
                //如果有一张图片上传失败，终止上传，删除数据库的记录
                deleteVoice({vid: _self.vid}).then((response) => {
                    if (response.success) {
                        _self.$vux.toast.text("服务器内部错误，页面即将刷新,请稍后重试", 'middle')
                    } else {
                        _self.$vux.toast.text("上传图片/视频失败，页面即将刷新,请稍后重试", 'middle')
                    }
                    setTimeout(function () {
                        window.location.reload()
                    },2000)
                }).catch((error) => {
                    console.log(error)
                });
            }
        },
        mounted () {
            this.initUpload()
            let _self = this;
            //绑定删除资源事件
            $(document).on('click', "#thelist em",function (obj) {
                let $this = $(obj.target);
                let $li = $this.parent();
                let fileId = $li.attr("id");
                $li.remove();
                _self.shareUploader.removeFile(fileId, true);//将添加的文件Id在缓存的文件列表里删掉，以免不能再次添加
                event.stopPropagation();
                _self.fileNum = $(".full").length == undefined ? 0 : $(".full").length;//判断文件个数，为0则在此可以选择类型
                if(_self.seq > 1){
                    _self.seq --;
                }

            })

            //让发表说说刚开始就出现在底部
            let height = $(window).height();
            $(".edit-voice").css("height",height - 44)
        }
    }
</script>


<style lang="less">
    @import "../../assets/css/survey/editVoice";
</style>
