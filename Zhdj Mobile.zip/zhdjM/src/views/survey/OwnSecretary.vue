<!--起始页开始-->
<template>
    <section class="own-voice">
        <group>
            <template v-for="(voice , index) in myVoice">
                <cell :title="voice.title" :link="'/voice/' + voice.vid">
                    <div class="voice-status">{{voiceStatus[voice.status]}}</div>
                </cell>
            </template>
        </group>
    </section>
</template>
<!--起始页结束-->
<script>
    import { Group, Cell } from 'vux'

    export default {
        components: {
            Group,
            Cell,
        },
        data () {
            return {
                voiceStatus:['待查看','查看通过','已推荐'],
                myVoice:[{title:'1',vid:1,status:0},{title:'22',vid:2,status:2},{title:'3',vid:3,status:1}],
            }
        },
        methods: {

        },
        mounted () {

        }
    }
</script>
<style lang="less">
    .own-voice{
        background: #ffffff;
        padding-bottom: 30px;
        .voice-status{
            color:#D0021B;
            font-size: 12px;
        }
        .weui-cells{
            margin-top:0px;
            font-size: 14px;
        }
    }
</style>
