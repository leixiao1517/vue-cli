<!--起始页开始-->
<template>
    <section class="party-voice">
        <tab>
            <tab-item :selected="tabType === 'edit' ? true : false" @on-item-click="onItemClick(1)" class="vux-center">编辑</tab-item>
            <tab-item :selected="tabType === 'own' ? true : false" @on-item-click="onItemClick(2)" class="vux-center">我的信件</tab-item>
        </tab>
        <router-view></router-view>
    </section>
</template>
<!--起始页结束-->
<script>
    import { Tab, TabItem } from 'vux'

    export default {
        components: {
            Tab,
            TabItem,
        },
        data () {
            return {
                tabType:'edit'
            }
        },
        methods: {
            onItemClick (index) {
                console.log("this.tabType---" ,this.tabType)
                if (index ===1){
                    this.tabType = "edit"
                    this.$router.replace('/secretary/edit');
                } else if (index === 2){
                    this.tabType = "own"
                    this.$router.replace('/secretary/own');
                }
            },
        },
        mounted () {
            this.tabType = this.$route.name;
            console.log(this.tabType)
        }
    }
</script>
