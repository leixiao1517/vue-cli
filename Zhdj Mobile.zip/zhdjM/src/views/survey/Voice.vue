<template>
    <div class="voice" v-if="undefined != imageRootPath">
        <div class="title">
            精选心声
            <div class="check-icon">
                <check-icon :value.sync="onlyMe" @click.native="changeFlag(0)">仅看我的</check-icon>
            </div>
        </div>
        <div v-transfer-dom>
            <previewer :list="showImageList" ref="previewer" :options="options"></previewer>
        </div>
        <div v-infinite-scroll="loadVoice" infinite-scroll-disabled="busy" infinite-scroll-distance="10">
            <div class="item-content clfix" :id="'voiceModel'+voice.vid" v-for="(voice,index) in voiceList" :key="index" v-if="voiceList.length > 0">
                <img class="user-head fl mr10" :src="voice.headImg | imgPath">
                <div>
                    <span class="nick-name">{{voice.nickName}}</span>
                    <span class="fr text-small">{{voice.createTime | dateFormat}}</span>
                    <p class="voice-content">
                        {{voice.content}}
                    </p>

                    <div class="img-content clfix">
                        <div :class="[voice.imageList.length == 1 ?'one': voice.imageList.length == 2 ? 'two': voice.imageList.length == 4 ? 'four':'']"
                             v-for="(item, index) in voice.imageList">
                            <img :id="'previewImg_' + voice.vid +'_' + index" class="previewer-demo-img" :src="item | imgPath(item)"
                                 @click="previewImg(index,voice.vid)">
                        </div>
                    </div>

                    <div class="voice-comment" v-if="null != voice.replyer">
                        <span>收到回复:</span>
                        <span>{{voice.comment}}</span>
                        <p>{{voice.replyer}} [{{voice.partyName}} {{voice.branchName}}]</p>
                    </div>
                </div>
            </div>
            <loading></loading>
        </div>

        <button class="to-voice" @click="toVoice">去发表</button>
    </div>
</template>

<script>
    import { Previewer , TransferDom,CheckIcon} from 'vux'
    import loading from '../../components/common/loading.vue'
    import {imageRootPath} from '../../config/config'
    import { getVoicesList, getUserByToken } from '../../api/api'
    export default {
        directives: {
            TransferDom
        },
        components: {
            Previewer,
            loading,
            CheckIcon
        },
        data () {
        return {
            onlyMe:false,
            showImageList: [],
            vid:Number,
            totalPage:Number,
            curPage:1,
            busy:false,
            voiceList:[
                {
                    vid:1,
                    headImg:'share_1.jpg',
                    nickName:'古月',
                    content:'哈哈哈哈哈哈',
                    replyer:'古月',
                    partyName:'古月',
                    branchName: '技术支部',
                    comment:'一下',
                    createTime: new Date(),
                    imageList:['share_1.jpg','share_1.jpg','share_3.jpg','share_4.jpg']
                },
                {
                    vid:2,
                    headImg:'share_1.jpg',
                    nickName:'古月',
                    content:'哈哈哈哈哈哈',
                    replyer:'古月',
                    partyName:'古月',
                    branchName: '技术支部',
                    comment:'一下',
                    createTime: new Date(),
                    imageList:['share_3.jpg','share_1.jpg','share_4.jpg']
                },
                {
                    vid:3,
                    headImg:'share_3.jpg',
                    nickName:'古月',
                    content:'哈哈哈哈哈哈',
                    createTime: new Date(),
                    imageList:['share_1.jpg','share_3.jpg']
                },
                {
                    vid:3,
                    headImg:'share_3.jpg',
                    nickName:'古月',
                    content:'哈哈哈哈哈哈',
                    replyer:'古月',
                    partyName:'古月',
                    branchName: '技术支部',
                    comment:'一下',
                    createTime: new Date(),
                    imageList:[]
                }
            ],
            user:{},
            uid:0,
            nickName:'',
            voices:{},
            content:'',
            imageList: [],
            imageRootPath,
            commentShow:false,
            playMid:'',
            showMid:0,
            options: {
                getThumbBoundsFn: this.getThumbBoundsFn
            }
        }
    },
    methods: {
        //点击事件
        toVoice: function () {
            this.$router.push('/partyVoice/edit');
        },
        fetchVoice:function () {
            $(".load-more").hide();
            let _self = this;
//            getVoicesList({ curPage: _self.curPage, pageSize:4}).then((response) => {
//                $(".load-more").hide();
//                if(response.success) {
//                    if(_self.curPage == 1){
//                        _self.voiceList = response.data.page.list;
//                    }else {
//                        _self.voiceList = _self.voiceList.concat(response.data.page.list);
//                    }
//                    _self.uid = response.data.uid;
//                    _self.nickName = response.data.nickName;
//                    _self.totalPage = response.data.page.pageCount;
//                    _self.curPage++;
//                    _self.busy = false;
//                } else {
//                    this.$vux.toast.text(response.message, 'middle')
//                }
//            }).catch((error) => {
//                console.log(error)
//            });
        },
        loadVoice: function() {
            if(this.curPage > this.totalPage || this.busy){
                this.busy = true;
                return;
            }
            this.busy = true;
            $(".load-more").show()
            this.fetchVoice();
        },
        previewImg(index,vid) {
            let _self = this;
            _self.vid = vid;//记录当前点中的分享，为了得到当前图片位置
            _self.showImageList.length = 0;//清空之前的预览list
            $("#voiceModel" + vid).find("img.previewer-demo-img").each(function () {//拼接当前点中的图片赋给预览list
                let image = {};
                image.src = $(this).attr("src");
                _self.showImageList.push(image);
            })
            _self.$refs.previewer.show(index);
        },
        getThumbBoundsFn(index){
            // find thumbnail element
            let thumbnail = document.getElementById("previewImg_" + this.vid + "_" + index)//得到当前的图片
            // get window scroll Y
            let pageYScroll = window.pageYOffset || document.documentElement.scrollTop
            // optionally get horizontal scroll
            // get position of element relative to viewport
            let rect = thumbnail.getBoundingClientRect()
            // w = width
            return {x: rect.left, y: rect.top + pageYScroll, w: rect.width}
        },
    },
    mounted () {

    }
  }
</script>

<style lang="less">
  @import "../../assets/css/survey/voice";
</style>
