<template>
    <section class="view-politics">
        <section style="height: 44px">
            <search
                v-model="searchVal"
                position="absolute"
                auto-scroll-to-top
                top="44px"
                @on-focus="onFocus"
                @on-cancel="onCancel"
                @on-submit="onSubmit"
                ref="search"></search>
        </section>
        <section>
            <div v-infinite-scroll="loadViewPolitics" infinite-scroll-disabled="busy"
                 infinite-scroll-distance="10">
                <template v-if="viewPoliticsList.length>0">
                    <comm-item @click.native="toResourceDetail('/ResourceDetail',scrollIndex)"
                               v-for="(viewPolitics,scrollIndex) in viewPoliticsList" :key="scrollIndex"

                               :imgSrc="viewPolitics.videoImg"
                               :type="viewPolitics.zyType"
                               :info1="viewPolitics.title"
                               :info2="viewPolitics.userName"
                               :info3="viewPolitics.partyName"
                               :info4="viewPolitics.modifyDate | dateFormat('YMD')">
                        <input :id="'viewPolitics' + scrollIndex" type="hidden" :value="viewPolitics.docType"/>
                        <input :id="'vid' + scrollIndex" type="hidden" :value="viewPolitics.vid"/>
                    </comm-item>
                    <!--<div class="no-data" style="display: none"></div>-->
                    <loading></loading>
                </template>
                <div class="no-data" v-if="viewPoliticsList.length==0"><p>没有数据</p></div>
            </div>
        </section>

    </section>
</template>

<script>
    import {getResourceList} from '../../api/api'
    import {Search} from 'vux'
    import loading from '../../components/common/loading.vue'
    import $ from 'jquery'
    import commItem from '../../components/common/commItem1.vue'

    export default {

        components: {
            loading,
            Search,
            commItem
        },
        data () {
            return {
                viewPoliticsList: [],
                tabDesc: '一图观政',
                curPage: 1,
                pageSize: 10,
                totalPage: 1,
                busy: false,
                searchVal: ''
            }
        },

        methods: {

            toResourceDetail(url, scrollIndex){
                let type = $("#viewPolitics" + scrollIndex).val();
                let vid = $("#vid" + scrollIndex).val();
                this.$router.push({path: url, query: {type: type, vid: vid}});
            },

            loadViewPolitics: function () {
                if (this.curPage > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initViewPoliticsList();
            },

            initViewPoliticsList: function () {
                let _self = this;
                $(".load-more").hide();
                getResourceList({
                    menu: '时政要闻',
                    tabDesc: _self.tabDesc,
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.viewPoliticsList = _self.viewPoliticsList.concat(response.data.list);
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            },
            onFocus() {

            },
            onCancel() {
                console.log('cancelsearch ' + this.searchVal)
            },
            onSubmit() {
                this.$refs.search.setBlur()
                let _self = this;
                _self.curPage = 1;
                getResourceList({
                    searchKey: _self.searchVal,
                    menu: '时政要闻',
                    tabDesc: _self.tabDesc,
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.viewPoliticsList = response.data.list;
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false;
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))


            }
        },

    }
</script>

<style lang="less">
    .view-politics {
    }
</style>

