<template>
    <section class="policy-elucidation">
        <section style="height: 44px">
            <search
                v-model="searchVal"
                position="absolute"
                auto-scroll-to-top
                top="44px"
                @on-focus="onFocus"
                @on-cancel="onCancel"
                @on-submit="onSubmit"
                ref="search"></search>
        </section>

        <section>
            <div v-infinite-scroll="loadPolicyElucidation" infinite-scroll-disabled="busy"
                 infinite-scroll-distance="10">
                <template v-if="policyElucidationList.length>0">
                    <comm-item @click.native="toResourceDetail('/ResourceDetail',scrollIndex)"
                               v-for="(policyElucidation,scrollIndex) in policyElucidationList" :key="scrollIndex"

                               :imgSrc="policyElucidation.videoImg"
                               :type="policyElucidation.zyType"
                               :info1="policyElucidation.title"
                               :info2="policyElucidation.userName"
                               :info3="policyElucidation.partyName"
                               :info4="policyElucidation.modifyDate | dateFormat('YMD')">
                        <input :id="'policyElucidation' + scrollIndex" type="hidden" :value="policyElucidation.docType"/>
                        <input :id="'vid' + scrollIndex" type="hidden" :value="policyElucidation.vid"/>
                    </comm-item>
                    <loading></loading>
                </template>
                <div class="no-data" v-if="policyElucidationList.length==0"><p>没有数据</p></div>
            </div>
        </section>

    </section>
</template>

<script>
    import{getResourceList} from '../../api/api'
    import {Search} from 'vux'
    import loading from '../../components/common/loading.vue'
    import $ from 'jquery'
    import commItem from '../../components/common/commItem1.vue'

    export default {

        components: {
            loading,
            Search,
            commItem
        },
        data () {
            return {
                policyElucidationList: [],
                tabDesc: '政策解读',
                curPage: 1,
                pageSize: 10,
                totalPage: 1,
                busy: false,
                searchVal:''
            }
        },

        methods: {

            toResourceDetail(url, scrollIndex){
                let type = $("#policyElucidation" + scrollIndex).val();
                let vid = $("#vid" + scrollIndex).val();
                this.$router.push({path: url, query: {type: type, vid: vid}});
            },

            loadPolicyElucidation: function () {
                if (this.curPage > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initPolicyElucidationList();
            },

            initPolicyElucidationList: function () {
                let _self = this;

                $(".load-more").hide();
                getResourceList({
                    menu: '时政要闻',
                    tabDesc: _self.tabDesc,
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.policyElucidationList = _self.policyElucidationList.concat(response.data.list);
                        _self.resourceCount = response.data.total;
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            },

            onFocus() {

            },
            onCancel() {
                console.log('cancelsearch '+this.searchVal)
            },
            onSubmit() {
                this.$refs.search.setBlur()
                let _self = this;
                _self.curPage = 1;
                getResourceList({
                    searchKey: _self.searchVal,
                    menu: '时政要闻',
                    tabDesc: _self.tabDesc,
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.policyElucidationList = response.data.list;
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false;
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))


            }
        },

    }
</script>

<style lang="less">

    .policy-elucidation {
    }
</style>

