<template>
    <div class="politics-news">
        <section>
            <tab :line-width=2 active-color='#D0021B'>
                <tab-item class="vux-center" :selected="politicsNewsSelected === PoliticsNewsItem"
                          v-for="(PoliticsNewsItem, index) in politicsNewsTitleList"
                          @on-item-click="PoliticsNewsSelectedItem"
                          :key="index">{{PoliticsNewsItem}}
                </tab-item>
            </tab>
            <div class="politics-news-router">
                <router-view></router-view>
            </div>
        </section>
    </div>
</template>

<script>
    import $ from 'jquery'
    import {Tab, TabItem} from 'vux'

    export default {
        name: 'library',

        components: {
            Tab,
            TabItem,
        },
        data () {
            return {
                politicsNewsSelected: '时政专题',
                politicsNewsTitleList: ['时政专题', '政策解读', '一图观政'],

            }
        },

        methods: {

            PoliticsNewsSelectedItem: function (index) {
                if (index === 0) {
                    this.$router.replace('/PoliticsNews')
                }

                if (index === 1) {
                    this.$router.replace('/PolicyElucidation')
                }

                if (index === 2) {
                    this.$router.replace('/ViewPolitics')
                }
            },

        },

        mounted(){
            let routeName = this.$route.name;
//            console.log("mounted=" + routeName)

            if (routeName == 'PoliticsTopic') {
                this.politicsNewsSelected = '时政专题'
            } else if (routeName == 'PolicyElucidation') {
                this.politicsNewsSelected = '政策解读'
            } else {
                this.politicsNewsSelected = '一图观政'
            }
        },

    }
</script>


<style lang="less">

    .politics-news {

        .politics-news-router {
            height: 11.4rem;
        }

    }
</style>

