<template>
    <section class="province-speech">
        <section style="height: 44px">
            <search
                v-model="searchVal"
                position="absolute"
                auto-scroll-to-top
                top="44px"
                @on-focus="onFocus"
                @on-cancel="onCancel"
                @on-submit="onSubmit"
                ref="search"></search>
        </section>
        <section>
            <div v-infinite-scroll="loadProvinceSpeech" infinite-scroll-disabled="busy"
                 infinite-scroll-distance="10">
                <template v-if="provinceSpeechList.length>0">
                    <comm-item @click.native="toResourceDetail('/ResourceDetail',scrollIndex)"
                               v-for="(provinceSpeech,scrollIndex) in provinceSpeechList" :key="scrollIndex"

                               :imgSrc="provinceSpeech.videoImg"
                               :type="provinceSpeech.zyType"
                               :info1="provinceSpeech.title"
                               :info2="provinceSpeech.userName"
                               :info3="provinceSpeech.partyName"
                               :info4="provinceSpeech.modifyDate | dateFormat('YMD')">
                        <input :id="'provinceSpeech' + scrollIndex" type="hidden" :value="provinceSpeech.docType"/>
                        <input :id="'vid' + scrollIndex" type="hidden" :value="provinceSpeech.vid"/>
                    </comm-item>
                    <loading></loading>
                </template>
                <div class="no-data" v-if="provinceSpeechList.length==0"><p>没有数据</p></div>
            </div>
        </section>

    </section>
</template>

<script>
    import{getResourceList} from '../../api/api'
    import {Search} from 'vux'
    import loading from '../../components/common/loading.vue'
    import $ from 'jquery'
    import commItem from '../../components/common/commItem1.vue'

    export default {

        components: {
            loading,
            Search,
            commItem
        },
        data () {
            return {
                provinceSpeechList: [],
                tabDesc: '省直',
                curPage: 1,
                pageSize: 8,
                busy: false,
                totalPage: 1,
                searchVal:''
            }
        },

        methods: {

            toResourceDetail(url, scrollIndex){
                let type = $("#provinceSpeech" + scrollIndex).val();
                let vid = $("#vid" + scrollIndex).val();
                this.$router.push({path: url, query: {type: type, vid: vid}});
            },

            loadProvinceSpeech: function () {
                if (this.curPage > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initProvinceSpeechList();
            },

            initProvinceSpeechList: function () {
                let _self = this;
                $(".load-more").hide();
                getResourceList({
                    menu: '领导言论',
                    tabDesc: _self.tabDesc,
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.provinceSpeechList = _self.provinceSpeechList.concat(response.data.list);
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            },

            onFocus() {

            },
            onCancel() {
                console.log('cancelsearch '+this.searchVal)
            },
            onSubmit() {
                this.$refs.search.setBlur()
                let _self = this;
                _self.curPage = 1;
                getResourceList({
                    searchKey: _self.searchVal,
                    menu: '领导言论',
                    tabDesc: _self.tabDesc,
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.provinceSpeechList = response.data.list;
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false;
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            }
        },

    }
</script>

<style lang="less">

    .province-speech {

        .province-speech-list {
            height: 1rem;
            padding: 20px 10px 10px 20px;
            border-bottom: 1px solid #f1f1f1;

            .province-speech-title{
                font-size: 14px;
            }

            .province-speech-list-content {
                font-size: 12px;
                color: #969696;
            }
            .province-speech-list-content p {
                display: inline-block;
            }

            .province-speech-list-count {
                float: right;
                min-width: .5rem;
                img {
                    float: left;
                    width: .3rem;
                    margin-top: 5px;
                }
                p {
                    float: right;
                    padding-right: .1rem;
                    width: 0.5rem;
                    font-size: 12px;
                    color: #969696;
                    text-align: center;
                }
            }

        }
        .province-speech-summary {
            height: 1rem;
            background-color: #FFFFFF;
            .province-speech-resource {
                display: inline-block;
                font-size: 14px;
                margin: 14px 20px;
            }

            .province-speech-sort {
                display: inline-block;
                float: right;
                margin: 14px 20px;
            }
        }

    }
</style>


