<template>
    <div class="leader-speech">
        <section>
            <tab :line-width=2 active-color='#D0021B'>
                <tab-item class="vux-center" :selected="leaderSpeechSelected === leaderSpeechItem"
                          v-for="(leaderSpeechItem, index) in leaderSpeechTitleList"
                          @on-item-click="PoliticsNewsSelectedItem"
                          :key="index">{{leaderSpeechItem}}
                </tab-item>
            </tab>
            <div class="leader-speech-router">
                <router-view></router-view>
            </div>
        </section>
    </div>
</template>

<script>
    import $ from 'jquery'
    import {Tab, TabItem} from 'vux'

    const leaderSpeechTitleList = () => ['中央', '省直','企业'];
    export default {
        name: 'library',

        components: {
            Tab,
            TabItem,
        },
        data () {
            return {
                leaderSpeechSelected: '中央',
                leaderSpeechTitleList: leaderSpeechTitleList(),

            }
        },
        methods: {

            PoliticsNewsSelectedItem: function (index) {
                if (index === 0) {
                    this.$router.replace('/CountrySpeech')
                }
                if (index === 1) {
                    this.$router.replace('/ProvinceSpeech')
                }
                if (index === 2) {
                    this.$router.replace('/CompanySpeech')
                }
            },

        },

        mounted(){
            let routeName = this.$route.name;
//            console.log("mounted=" + routeName)

            if (routeName == 'CountrySpeech') {
                this.leaderSpeechSelected = '中央'
            }else if(routeName == 'ProvinceSpeech'){
                this.leaderSpeechSelected = '省直'
            }
            else {
                this.leaderSpeechSelected = '企业'
            }
        },

    }
</script>


<style lang="less">

    .leader-speech {

        .leader-speech-router {
            height: 11.4rem;
        }

    }
</style>

