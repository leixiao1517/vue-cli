<template>
    <section class="company-speech">
        <section style="height: 44px">
            <search
                v-model="searchVal"
                position="absolute"
                auto-scroll-to-top
                top="44px"
                @on-focus="onFocus"
                @on-cancel="onCancel"
                @on-submit="onSubmit"
                ref="search"></search>
        </section>
        <section>
            <div v-infinite-scroll="loadCompanySpeech" infinite-scroll-disabled="busy"
                 infinite-scroll-distance="10">
                <template v-if="companySpeechList.length>0">
                    <comm-item @click.native="toResourceDetail('/ResourceDetail',scrollIndex)"
                               v-for="(companySpeech,scrollIndex) in companySpeechList" :key="scrollIndex"

                               :imgSrc="companySpeech.videoImg"
                               :type="companySpeech.zyType"
                               :info1="companySpeech.title"
                               :info2="companySpeech.userName"
                               :info3="companySpeech.partyName"
                               :info4="companySpeech.modifyDate | dateFormat('YMD')">
                        <input :id="'companySpeech' + scrollIndex" type="hidden" :value="companySpeech.docType"/>
                        <input :id="'vid' + scrollIndex" type="hidden" :value="companySpeech.vid"/>
                    </comm-item>
                    <loading></loading>
                </template>
                <div class="no-data" v-if="companySpeechList.length==0"><p>没有数据</p></div>
            </div>
        </section>
    </section>
</template>

<script>
    import{getResourceList} from '../../api/api'
    import {Search} from 'vux'
    import loading from '../../components/common/loading.vue'
    import $ from 'jquery'
    import commItem from '../../components/common/commItem1.vue'

    export default {

        components: {
            loading,
            Search,
            commItem
        },
        data () {
            return {
                companySpeechList: [],
                tabDesc: '企业',
                curPage: 1,
                pageSize: 8,
                busy: false,
                totalPage: 1,
                searchVal:''
            }
        },

        methods: {

            toResourceDetail(url, scrollIndex){
                let type = $("#companySpeech" + scrollIndex).val();
                let vid = $("#vid" + scrollIndex).val();
                this.$router.push({path: url, query: {type: type, vid: vid}});
            },

            loadCompanySpeech: function () {
                if (this.curPage > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initCompanySpeechList();
            },

            initCompanySpeechList: function () {
                let _self = this;
                $(".load-more").hide();
                getResourceList({
                    menu: '领导言论',
                    tabDesc: _self.tabDesc,
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.companySpeechList = _self.companySpeechList.concat(response.data.list);
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            },

            onFocus() {

            },
            onCancel() {
                console.log('cancelsearch '+this.searchVal)
            },
            onSubmit() {
                this.$refs.search.setBlur()
                let _self = this;
                _self.curPage = 1;
                getResourceList({
                    searchKey: _self.searchVal,
                    menu: '领导言论',
                    tabDesc: _self.tabDesc,
                    curPage: _self.curPage,
                    pageSize: _self.pageSize
                }).then((response => {
                    if (response.success) {
                        _self.companySpeechList = response.data.list;
                        this.totalPage = response.data.pageCount;
                        this.curPage++;
                        this.busy = false;
                    }
                    else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }))
            }
        },
    }
</script>

<style lang="less">

    .company-speech {

    }
</style>

