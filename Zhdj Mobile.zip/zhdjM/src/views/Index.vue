<!--起始页开始-->
<template>

    <section class="index">

        <img src="../assets/images/index/top.jpg" class="topBgImg" />

        <div class="topContent">
            <div class="textBox">
                <h4 class="userName">{{ getUserInfo.userName }}</h4>
                <h5 class="identity" v-if="null != getUserInfo.positions && '' != getUserInfo.positions">
                    <span>{{getUserInfo.positions}}</span>
                </h5>
                <h5 class="unitContent" v-if="null != getUserInfo.partyName && '' != getUserInfo.partyName">
                    <b class="company o-ellipsis">{{getUserInfo.partyName}}</b>
                </h5>
            </div>
            <div class="headBox">
                <img :src="getUserInfo.headImg | imgPath" class="headImg"/>
            </div>
        </div>

        <div class="menuBox">
            <div class="myApplication">

                <div class="contentTop">
                <h2>我的应用</h2>
                <div class="borderDiv"></div>
                </div>

                <div class="applicationContent posr">
                    <div class="iconBox"  @click="toUrl('myCredit')">
                        <img src="../assets/images/newIndex/myPoint.png">
                        <p>我的学分</p>
                    </div>
                    <div class="iconBox" @click="toUrl('meeting')">
                        <img src="../assets/images/newIndex/meeting.png">
                        <p>会议服务</p>
                        <tips :content="tip1" :position="position" v-if="getUserInfo.firstIn == 1"></tips>
                    </div>
                    <div class="iconBox" @click="fee">
                        <img src="../assets/images/newIndex/partydues.png">
                        <p>党费缴纳</p>
                    </div>
                    <div class="iconBox" @click="toUrl('myMessage')" style="position:relative">
                        <img src="../assets/images/newIndex/myMessage.png">
                        <p>我的消息</p>
                        <badge v-show="getUserInfo.msgNum==null||getUserInfo.msgNum==0?false:true" :text="getUserInfo.msgNum" style="position:absolute;top:0;"></badge>
                        <!--<badge :text="0" style="position:absolute;top:0;"></badge>-->
                    </div>
                    <!--<div class="iconBox" @click="remind">-->
                    <!--<img src="../assets/images/index/leave.png">-->
                    <!--<p>请假</p>-->
                    <!--</div>-->
                    <!--<div class="iconBox" @click="round">-->
                    <!--<img src="../assets/images/index/71.png">-->
                    <!--<p>七一闯关赛</p>-->
                    <!--</div>-->
                    <!--<div class="iconBox" @click="redirectToOuter('https://tam.hngytobacco.com/zt/cautionarytaless/mobile')">-->
                    <!--<img src="../assets/images/index/jwy.png">-->
                    <!--<p>敬畏月</p>-->
                    <!--</div>-->
                    <!--<badge :text="getUserInfo.msgNum" style="position: relative;left: 4.88rem;bottom: 3.55rem"></badge>-->
                </div>
            </div>

            <div class="myApplication">
                <div class="contentTop">
                    <h2>智慧党建</h2>
                    <div class="borderDiv"></div>
                </div>

                <!--<div class="iconBox" @click="remind">-->
                <!--<img src="../assets/images/index/answer.png">-->
                <!--<p>智慧问答</p>-->
                <!--</div>-->

                <!--<div class="iconBox" @click="toOutUrl('act=module&cid=16&weid=11&name=site&do=list')">-->
                <!--<img src="../assets/images/index/news.png">-->
                <!--<p>时政要闻</p>-->
                <!--</div>-->
                <!--<div class="iconBox" @click="remind">-->
                    <!--<img src="../assets/images/index/hot.png">-->
                    <!--<p>必读热点</p>-->
                <!--</div>-->
                <div class="iconBox" @click="togovStudyUrl">
                    <img src="../assets/images/newIndex/partyStudy.png">
                    <p>中心组学习</p>
                </div>

                <div class="iconBox" @click="toUrl('ThreeMeetingList')">
                    <img src="../assets/images/newIndex/threeMeeting.png">
                    <p>三会一课</p>
                </div>
                <div class="iconBox" @click="toUrl('PartyHistory')">
                    <img src="../assets/images/newIndex/history.png">
                    <p>党史党章</p>
                </div>


                <div class="iconBox" @click="toUrl('LeaderSpeech')">
                    <img src="../assets/images/newIndex/speech.png">
                    <p>领导言论</p>
                </div>
                <div class="iconBox" @click="toUrl('PoliticsNews')">
                    <img src="../assets/images/newIndex/news.png">
                    <p>时政要闻</p>
                </div>

                <div class="iconBox" @click="toUrl('PartyBuildingTopic')">
                    <img src="../assets/images/newIndex/partyTheme.png">
                    <p>党建专题</p>
                </div>

                <div class="iconBox" @click="toUrl('classRoom')">
                    <img src="../assets/images/newIndex/classroom.png">
                    <p>云课堂</p>
                </div>

                <div class="iconBox" @click="toUrl('partyRules')">
                    <img src="../assets/images/newIndex/partyRules.png">
                    <p>党内法规</p>
                </div>

                <div class="iconBox"@click="toUrl('basicDynamic')">
                <img src="../assets/images/newIndex/basicDynamic.png">
                <p>基层动态</p>
                </div>
            </div>

            <div class="myApplication">
                <div class="contentTop">
                    <h2>互动交流</h2>
                    <div class="borderDiv"></div>
                </div>
                <!--<div class="iconBox" @click="toOutUrl('act=module&id=132&name=wanyingphoto&do=index&weid=11')">-->
                <!--<img src="../assets/images/index/brandOwe.png">-->
                <!--<p>品牌感恩</p>-->
                <!--</div>-->

                <!--<div class="iconBox" @click="toOutUrl('act=module&cid=14&weid=11&name=site&do=list')">-->
                <!--&lt;!&ndash;<div class="iconBox" @click="toUrl('highlights')">&ndash;&gt;-->
                <!--<img src="../assets/images/index/playBack.png">-->
                <!--<p>精彩回放</p>-->
                <!--</div>-->
                <!--<div class="iconBox" @click="remind">-->
                <!--<img src="../assets/images/index/Volunteer.png">-->
                <!--<p>志愿者</p>-->
                <!--</div>-->
                <div class="iconBox" @click="toUrl('BookLibrary')">
                    <img src="../assets/images/newIndex/bookLibrary.png">
                    <p>书籍库</p>
                </div>
                <div class="iconBox" @click="toUrl('PicLibrary')">
                    <img src="../assets/images/newIndex/picLibrary.png">
                    <p>图片库</p>
                </div>

                <div class="iconBox" @click="toUrl('VideoLibrary')">
                    <img src="../assets/images/newIndex/videoLibrary.png">
                    <p>视频库</p>
                </div>

                <!--<div class="iconBox" @click="toUrl('survey')">-->
                <div class="iconBox" @click="round">
                    <img src="../assets/images/newIndex/game.png">
                    <p>闯关赛</p>
                </div>

                <!--<div class="iconBox" @click="remind">-->
                <div class="iconBox" @click="redirectToOuter('https://tam.hngytobacco.com/zt/cautionarytaless/mobile')">
                    <img src="../assets/images/newIndex/rever.png">
                    <p>敬畏月</p>
                </div>
                <!--</div>-->
            </div>

        </div>

        <div class="inseat"></div>

        <div class="footMenu">
            <button class="backIndex active" @click="toUrl('index')">首页</button>
            <button class="meeting" @click="toUrl('meeting')">会议</button>
            <button class="memberCost" @click="fee">党费</button>
            <button class="mine" @click="toUrl('userInfo')">我的</button>
        </div>
    </section>

</template>
<!--起始页结束-->

<script>
    import $ from 'jquery'
    import { fee,getUserInfo,checkFeeUpgradeStatus } from '../api/api'
    import { Badge  } from 'vux'
    import tips from '../components/common/tips.vue'
    import { mobileServer } from '../config/config'

    export default {
        components: {
            Badge,
            tips
        },
        data () {
            return {
                role:"",
                isSplashTemp:"",
                getUserInfo:{},
                arr:[],
                uid:2,
                fl:false,
                tip1:'目前仅开放会议相关服务',
                position:'vux-popover-arrow-up'
            }
        },
        methods: {
            toUrl:function(enterUrl){
                this.$router.push("/" + enterUrl)
            },
            remind:function(){
                this.$vux.toast.text('敬请期待')
            },
            round:function () {
                window.location.href = mobileServer + "wy/login"
            },

            //added by hlz below 2018-07-18
            toOutUrl:function (outUrl) {
                window.location.href="http://app.vangv.cn/weixin/mobile.php?"+outUrl;
//                window.location.href="http://app.vangv.cn/mobile.php?act=module&cid=16&weid=11&name=site&do=list";
            },

            redirectToOuter:function (url) {
                window.location.href = url;
            },

            toMeettingUrl:function () {
                window.location.href="http://app.vangv.cn/weixin/app/meetings/201603ddh.php";
            },

            togovStudyUrl:function () {
                window.location.href="http://app.vangv.cn/weixin/app/meetings/201503zxz.php";
            },
            fee:function () {
                let _self = this
                checkFeeUpgradeStatus({upId:1}).then(response=>{ //1代表工银配置
                    console.log(response);
                    if(response.success){
                        _self.$router.push("/fee");
                    } else {
                        _self.$vux.toast.text(response.message);
                    }
                })
            },
        },

        mounted () {
            $(".topBgImg,.menuBox,.footMenu,.seat").width($(window).width());
            $(".index").height($(window).height());
            let _self = this;
            _self.role = this.$route.query.role;

            getUserInfo({role:''}).then(response=>{
                if(response.success){
                    console.log('getUserInfo', response);
                    _self.getUserInfo = response.data;
                    console.log(_self.arr);
                }else{
                    this.$vux.toast.text(response.message);
                }
            })
        }
    }
</script>

<style lang="less">


    .index{
        position:relative;

        .topContent {
            position: absolute;
            top: 0.4rem;
            right: 0.5rem;
            height: 1.8rem;
            width: 5.8rem;
        }
        .textBox {
            float: left;
        }
        .textBox > h4 {
            font-weight: normal;
            color: #e52617;
            text-align: right;
            font-size: 0.35rem;
            width: 3.5rem;
        }
        .textBox > .identity {
            font-weight: normal;
            text-align: right;
            font-size: 0.27rem;
            width: 3.5rem;
            line-height: 0.6rem;
            height: 0.6rem;
        }
        .textBox > .unitContent {
            margin-top: 0.1rem;
            text-align: right;
            font-size: 0.27rem;
            width: 3.5rem;
            line-height: 0.3rem;
            height: 0.6rem;
        }
        .unitContent > b {
            font-weight: normal;
        }

        .headBox {
            margin-top: -0.2rem;
            margin-left: 0.4rem;
            float: left;
            height: 1.8rem;
            width: 1.8rem;
            border-radius: 50%;
            overflow: hidden;
        }
        .headImg {
            background-color: skyblue;
            height: 1.8rem;
            width: 1.8rem;
            float: right;
        }
        .menuBox {
            background-color: #ffffff;
        }
        .contentTop {
            height: 1rem;
        }
        .contentTop > h2 {
            float: left;
            margin-left: 10px;
            line-height: 1rem;
            color: #000000;
            font-weight: 400;
            font-size: 0.4rem;
        }
        .contentTop .borderDiv {
            float: left;
            border-top: 1px solid #f5deb3;
            width: 66%;
            margin-left: 0.3rem;
            margin-top: 6.5%;
        }
        .iconBox {
            position: relative;
            display: inline-block;
            height: 1.75rem;
            width: 1.25rem;
            margin-left: 0.45rem;
            margin-top: 0.2rem;
        }
        .iconBox img {
            height: 1.25rem;
            width: 1.25rem;
        }
        .iconBox p {
            margin-top: 0.2rem;
            text-align: center;
            font-size: .2rem;
        }
        .inseat {
            height: 1.5rem;
            background-color: white;
        }
        .footMenu {
            position: fixed;
            bottom: 0px;
            height: 1rem;
            background-color: #f8f4e4;
        }
        .backIndex {
            height: 1rem;
            text-align: center;
            line-height: 1rem;
            color: #ffffff;
            background-color: #9f252b;
        }
        .footMenu {
            display: flex;
        }
        .footMenu > button {
            flex: 1;
            height: 1rem;
            text-align: center;
            line-height: 1rem;
            color: #52514e;
            background-color: #f8f4e4;
            font-size: 0.3rem;
        }
        .backIndex {
            border-right: 1px solid #f5deb3;
        }
        .meeting {
            border-right: 1px solid #f5deb3;
        }
        .memberCost {
            border-right: 1px solid #f5deb3;
        }
        .active {
            background-color: #a0242c !important;
            color: #ffffff !important;
            border-right: 1px solid #a0242c;
        }
    }

</style>
