<template>
    <div class="resource-detail">
        <div class="comm-head-logo">
            <div class="logo">
                <img src="../../assets/images/common/icon-logo.png" alt="">
            </div>
            <div class="back" @click="toIndex">
                回到首页
            </div>
        </div>

        <div class="resource-detail-description">
            <div class="resource-detail-title">{{resource.title}}</div>

            <div class="time-author">
                <div class="resource-detail-time">{{resource.modifyDate | dateFormat}}</div>
                <div class="resource-detail-sharer">{{resource.userName}} {{ partyName }}</div>
            </div>

            <div class="resource-detail-plat">资源来源:和+云资源共享平台</div>
        </div>
        <div v-if="docType==1" class="pdf-content">
            <iframe :src="mobileClient+'static/pdfjs/web/viewer.html?r='+random +'&file=' + resource.url" width="100%" height="100%"></iframe>
            <!--<iframe :src="'../../../static/pdfjs/web/viewer.html?r='+random" width="100%" height="100%"></iframe>-->
        </div>

        <div v-if="docType==2" class="resource-detail-content" @click="playVideo(index)">
            <div class="resource-detail-area">
                <!-- 播放图标 -->
                <i v-show="index != showFlag"></i>
                <!-- 播放遮罩 -->
                <div class="resource-detail-mask" v-show="index != showFlag"></div>
                <video :id="'video_' + index" class="video" name="media" webkit-playsinline="true" playsinline="true"
                       x5-playsinline="true" controls
                       :poster="resource.videoImg"
                       :src="resource.url">
                </video>
            </div>
        </div>

        <div v-if="docType==3" class="resource-detail-content">
            <img :src="resource.url | imgPath" @click="show(0)" />

            <div v-transfer-dom>
                <previewer :list="list" ref="previewer" ></previewer>
            </div>
        </div>
        <!--<div class="resource-detail-footer">-->
            <!--<img src="../../assets/images/library/publish-meeting.png"/>-->
        <!--</div>-->
    </div>
</template>

<script>

    import{getResourceDetail, addResourceViews,addLessonCredits,getWXJsApiSignData} from '../../api/api'
    import{mobileClient,imageRootPath,mobileServer} from '../../config/config'
    import $ from 'jquery'
    import { wxShare} from '../../assets/js/common/wxjsapi.js'
    import { Previewer,TransferDom } from 'vux'
    export default {
        directives: {
            TransferDom
        },
        components: {
            Previewer
        },
        data () {
            return {
                index: 1,
                showFlag: -1,
                resource: {},
                docType: '',
                vid: Number,
                views: '',
                mobileClient,
                random:0,
                list: [{
                    // msrc: 'http://ww1.sinaimg.cn/thumbnail/663d3650gy1fplwu9ze86j20m80b40t2.jpg',
                    // src: 'http://ww1.sinaimg.cn/large/663d3650gy1fplwu9ze86j20m80b40t2.jpg',
                }]
            }


        },

        methods: {
            initResourceDetail: function () {
                let _self = this;
                let query = this.$route.query;
                _self.docType = query.type;
                _self.vid = query.vid;
                getResourceDetail({
                    vid: _self.vid,
                }).then((response => {
                    console.log(response)
                    if (response.success) {
                        _self.resource = response.data;
                        _self.list[0].msrc = _self.resource.url
                        _self.list[0].src = _self.resource.url

                        _self.views = response.data.views + 1;
                        addResourceViews({
                            vid: _self.vid,
                            views: _self.views,
                        }).then((response => {
                            if (response.success) {

                            } else {
                                _self.$vux.toast.text(response.message, 'middle')
                            }
                        }))
                        _self.WXShare(_self.resource.title,"分享来源:和+云资源共享平台",_self.resource.videoImg)
                    } else {
                        if("登录失效" == response.message){
                            _self.$router.push({path:'/transfer',query:{redirect:"/ResourceDetail?type="+_self.docType +"&vid=" + _self.vid}})
                        } else {
                            _self.$vux.toast.text(response.message, 'middle')
                        }
                    }
                }))
            },

            playVideo: function (index) {
                if (index == this.showFlag) {
                    this.showFlag = -1;
                    $('#video_' + index).trigger('pause');
                } else {
                    this.showFlag = index;
                    $('.video').trigger('pause');
                    $('#video_' + index).trigger('play');
                }
            },
            //用户停留10秒即增加积分
            stayFoo:function (meetId) {
                let _self = this;
                setTimeout(function(){
                    _self.stay(meetId)
                },30000);
            },
            stay:function (meetId) {
                let _self = this;
                addLessonCredits({objId:meetId,objType:6,stayConfirm:true}).then((response) => {
                    console.log(response);
                    if(response.success){
                        _self.$vux.toast.text(response.message, 'middle');
                    }
                }).catch((error) => {
                    console.log(error)
                })
            },
            WXShare:function (title,description,imgUrl) {
                let _self = this
                if(null == imgUrl || '' == imgUrl || imgUrl.indexOf("other") > 0){
                    imgUrl = imageRootPath + 'zhongyan/zhdj/resource/image/large-logo.jpg'
                }
                getWXJsApiSignData({}).then(function (rsp) {
                    console.log(rsp);
                    if(rsp.success){
//                        let link = mobileServer + "login";
                        let link = mobileClient + "#/ResourceDetail?type="+_self.docType +"&vid=" + _self.vid
                        let param = {
                            title: title, // 分享标题
                            desc:description,// 分享描述
                            link: link ,
                            imgUrl: imgUrl// 分享图标
                        };
                        wxShare(rsp.data,param);
                    } else {
//                        _self.$router.push({path:'/transfer',query:{redirect:"/ResourceDetail?type="+_self.docType +"&vid=" + _self.vid}})
                    }
                })
            },
            toIndex: function () {
                this.$router.push('/index')
            },
            show (index) {
                this.$refs.previewer.show(index)
            }
        },
        computed: {
            partyName() {
              let partyName = this.resource.partyName
              if(partyName){
                return '[' + partyName + ']'
              }else {
                  return ''
              }
          }
        },

        mounted(){
            this.initResourceDetail();
            this.random = Math.random();
            let query = this.$route.query;
            if(query.meetId){
                this.stayFoo(query.meetId);
            }
        }
    }
</script>

<style lang="less">

    .resource-detail {
        height: 13rem;

        .resource-detail-description {
            /*height: 155px;*/
            background-color: #FFFFFF;
            padding: 15px 0px 12px 0px;
            .resource-detail-title {
                /*width: 100%;*/
                /*height: 40px;*/
                /*text-align: center;*/
                padding-left: 15px;
                padding-right: 15px;
                font-size: 24px;
                color: #323232;
            }

            .time-author{
                margin-left: 15px;
                margin-right: 15px;
                padding-bottom: 15px;
                display: flex;
                border-bottom: 2px solid #d1d1d1;
            }

            .resource-detail-time {
                margin-top: 15px;
                margin-right: 15px;
                color: #969696;
            }

            .resource-detail-plat{
                margin-left: 15px;
                margin-top: 15px;
                margin-right: 15px;
                color: #969696;
            }
            .resource-detail-sharer {
                margin-top: 15px;
                color: #969696;
            }
        }

        .pdf-content{
            height:500px;
            iframe{
                border: none;
            }
        }
        .resource-detail-content {
            height: 400px;
            img {
                height: 360px;
                width: 100%;
            }

            .resource-detail-area {
                position: relative;
                .resource-detail-mask {
                    position: absolute;
                    left: 0;
                    top: 0;
                    width: 100%;
                    height: 97%;
                    background: rgba(0, 0, 0, 0.5);
                    z-index: 111;
                }
                i {
                    display: inline-block;
                    position: absolute;
                    width: 60px;
                    height: 60px;
                    left: 50%;
                    margin-left: -30px;
                    top: 50%;
                    margin-top: -30px;
                    background: url("../../assets/images/survey/icon_video_detail.png") no-repeat;
                    background-size: 60px;
                    z-index: 112;
                }

                .video {
                    width: 100%;
                    height: 4rem;
                    object-fit: fill; //poster全铺满video
                }

            }
        }

        .resource-detail-footer {
            padding-bottom: 1px;
            img {
                width: 100%;
            }
        }
    }

</style>
