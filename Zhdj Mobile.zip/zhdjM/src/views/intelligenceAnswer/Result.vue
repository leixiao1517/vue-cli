<template>
    <section class="result">
        <div class="question-list" v-for="value in questionTitle">
            <b>
                <span @click="toUrl('QuestionDetails')">{{value.questionContent}}</span>
                <img src="../../assets/images/countExam/right.png" />
            </b>
        </div>
    </section>
</template>


<script>
    import $ from 'jquery'

    export default {
        components: {

        },
        data() {
            return {
                tab:'1',
                questionTitle: [{
                    questionNumber:'1',
                    questionContent:'“三大规律”：（）规律、社会主义建设规律、人类社会发展规律。',
                }, {
                    questionNumber:'2',
                    questionContent:'全面小康“六个更加”：到建党一百年时建成经济更加发展、民主更加健全、科教更加进步、文化更加进步',
                }, {
                    questionNumber:'3',
                    questionContent:'全面小康“六个更加”：到建党一百年时建成经济更加发展、民主更加健全、科教更加进步、文化更加进步',
                }],
            }
        },
        methods: {
            toUrl:function(url){
                this.$router.push("/"+url)
            }
        },
        mounted() {
            $('.result').css("min-height",$(window).height());
        }
    }
</script>

<style lang="less">

    .result{
        background-color:white;
        .question-list{
            height:1.4rem;
            width:100%;
            border-bottom:1px solid #f6f6f6;
        }
        .question-list>b:first-child{
            padding:0.1rem 0;
            margin:0 0.25rem;
        }
        .question-list>b{
            display:block;
            font-weight:normal;
            width:7rem;
            height:1.2rem;
            margin:0.1rem 0.25rem;
        }
        .question-list>b>span{
            float:left;
            width:6.4rem;
            height:1.2rem;
            line-height:0.6rem;
            font-size:14px;
            overflow: hidden;
            text-overflow: ellipsis;
            display: -webkit-box;
            -webkit-box-orient: vertical;
            -webkit-line-clamp: 2;
        }
        .question-list>b>img{
            float:right;
            width:0.2rem;
            height:0.36rem;
            margin-top:0.42rem;
            display:inline-block;
        }
    }



</style>
