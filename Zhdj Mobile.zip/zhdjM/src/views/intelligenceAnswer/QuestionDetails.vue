<template>
    <section class="question-details">
        <div class="question-title">
            <div class="column">
                <span>题干</span>
            </div>
            <div class="question-content">
                <b>{{questionList[0].questionContent}}</b>
            </div>
        </div>
        <div class="choose-title">
            <div class="column">
                <span>选项</span>
            </div>
            <div class="choose-content">
                <b>A、{{questionList[0].answerA}}</b>
                <b>B、{{questionList[0].answerB}}</b>
                <b>C、{{questionList[0].answerC}}</b>
                <b>D、{{questionList[0].answerD}}</b>
            </div>
        </div>
        <div class="correct-box">
            <span class="correct">正确答案：{{questionList[0].correct}}</span>
        </div>
    </section>
</template>


<script>
    import $ from 'jquery'

    export default {
        components: {

        },
        data() {
            return {
                tab:'1',
                questionList: [{
                    questionNumber:'1',
                    questionContent:'1',
                    answerA:'11',
                    answerB:'22',
                    answerC:'33',
                    answerD:'44',
                    correct:'A',
                }, {
                    questionNumber:'2',
                    questionContent:'2',
                    answerA:'11',
                    answerB:'22',
                    answerC:'33',
                    answerD:'44',
                    correct:'B',
                }, {
                    questionNumber:'3',
                    questionContent:'3',
                    answerA:'11',
                    answerB:'22',
                    answerC:'33',
                    answerD:'44',
                    correct:'C',
                }, {
                    questionNumber:'4',
                    questionContent:'4',
                    answerA:'11',
                    answerB:'22',
                    answerC:'33',
                    answerD:'44',
                    correct:'D',
                }],
            }
        },
        methods: {

        },
        mounted() {
            $('.question-details').css("min-height",$(window).height());
            console.log(this.questionList);
        }
    }
</script>

<style lang="less">

    .question-details{

        background-color:white;
        .question-title{
            border-bottom:1px solid #f6f6f6;
        }
        .column{
            width:100%;
        }
        .column>span{
            display:inline-block;
            height:0.8rem;
            line-height:0.8rem;
            font-size:16px;
            text-align:center;
            margin-left:0.25rem;
            font-weight:bold;
            color:#d0021b;
        }
        .question-content>b{
            display:block;
            margin-left:0.25rem;
            width:7rem;
            font-size:14px;
            line-height:0.5rem;
            font-weight:normal;
            margin-bottom:0.25rem;
        }
        .choose-content>b:first-child{
            margin-top:0.1rem;
        }
        .choose-content>b{
            display:block;
            width:7rem;
            margin-left:0.25rem;
            font-weight:normal;
            font-size:14px;
            line-height:0.5rem;
            margin-top:0.4rem;
        }
        .correct-box{
            position:fixed;
            bottom:0;
            display:block;
            width:7.5rem;
        }
        .correct{
            line-height:0.75rem;
            height:0.75rem;
            font-size:16px;
            text-align:center;
            border:1px solid #d0021b;
            color:#d0021b;
            display:block;
            font-weight:bolder;
        }
    }



</style>
