<template>
    <section class="search-answer">
        <div class="search">
            <group>
                <x-input placeholder="输入想要查找的题目" :show-clear="false" :max="20"></x-input>
            </group>
            <button @click="toUrl('Result')">智能搜索</button>
        </div>
        <div class="column">
            <span>热门搜索</span>
        </div>
        <div class="search-hot search-list">
            <button @click="toUrl('QuestionDetails')">党的十九大</button>
            <button @click="toUrl('QuestionDetails')">党的十九大</button>
            <button @click="toUrl('QuestionDetails')">党的十九大</button>
            <button @click="toUrl('QuestionDetails')">党的十九大</button>
        </div>
        <div class="column">
            <span>历史搜索</span>
        </div>
        <div class="search-history search-list">
            <button @click="toUrl('QuestionDetails')">党的十九大</button>
            <button @click="toUrl('QuestionDetails')">党的十九大</button>
            <button @click="toUrl('QuestionDetails')">党的十九大</button>
            <button @click="toUrl('QuestionDetails')">党的十九大</button>
        </div>

    </section>
</template>


<script>
    import $ from 'jquery'
    import {XInput,Group} from 'vux'

    export default {
        components: {
            XInput,
            Group
        },
        data() {
            return {
                tab:'1',
            }
        },
        methods: {
            toUrl:function(url){
                this.$router.push("/"+url)
            }
        },
        mounted() {
            $('.search-answer').css("min-height",$(window).height());
        }
    }
</script>

<style lang="less">

    .search-answer{

        background-color:white;
        .search{
            height:0.8rem;
            background-color:skyblue;
            display:flex;
            flex-wrap: nowrap;
        }
        .search>input,button{
            height:0.8rem;
        }
        /*.search>.weui-cells{*/
            /*flex:0 5rem;*/
            /*padding:0 0.2rem;*/
            /*font-size:14px;*/

        /*}*/
        .search>button{
            flex:0 2.5rem;
            background-color:#D0021B;
            color:white;
        }
        .column{
            width:100%;
        }
        .column>span{
            display:inline-block;
            height:0.8rem;
            line-height:0.8rem;
            font-size:14px;
            text-align:center;
            margin-left:0.25rem;
            font-weight:bold;
        }
        .search-list>button{
            margin:0.1rem 0.25rem;
            height:0.7rem;
            line-height:0.7rem;
            text-align:center;
            color:#D0021B;
            background-color:white;
            border:1px solid #D0021B;
            border-radius:3px;
            width:3.2rem;
            font-size:14px;
        }
        .vux-no-group-title{
            margin-top:0;
            flex:0 5rem;
            padding:0 0.2rem;
            font-size:14px;
        }
        .weui-cell{
            padding:0;
            height:0.8rem;
            width:5rem;
        }

    }



</style>
