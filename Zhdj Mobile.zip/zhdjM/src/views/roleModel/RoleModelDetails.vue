<template>
    <section class="role-model-details">
        <h3>{{roleModelDetailsModel.roleModelDetailsTitle}}</h3>
        <div class="role-model-details-box">
            <p class="roleModel-details-title">{{roleModelDetailsModel.roleModelDetailsAuthor}}</p>
        </div>
        <divider>{{roleModelDetailsModel.roleModelDetailsRecommendDate}}</divider>
        <div class="role-model-details-content">
            <p v-html="roleModelDetailsModel.roleModelDetailsContent"></p>
        </div>
    </section>
</template>

<script>

    import{Divider} from 'vux'

    import{getContributionDetails} from '../../api/api'
    export default {

        components: {
            Divider,
        },
        data () {
            return {
                roleModelDetailsModel: {
                    roleModelDetailsTitle: '我是标题，我是标题，我是标题，我是标题，我是标题，我是标题，我是标题，我是标题，我是标题，我是标题',
                    roleModelDetailsAuthor: '二狗子',
                    roleModelDetailsRecommendDate: new Date(),
                    roleModelDetailsContent: '<p>我是内容1我是内容1我是内容1我是内容1我是内容1我是内容1我是内容1我是内容1我是内容1我是内容1我是内容1我是内容1我是内容1我是内容1我是内容1我是内容1我是内容1我是内容1我是内容1我是内容1我是内容1</p> <img class="roleModelDetails-content" src="https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png"/> <p> 我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2</p> <img class="roleModelDetails-content" src="https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png"/> <p> 我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2我是内容2</p>',
                }
            }
        },
        methods: {},
        mounted(){
            let _self = this;

            this.roleModelId = this.$route.params.roleModelId;

            getContributionDetails({roleModelId: _self.roleModelId}).then(data => {

                if (data.data == null) {
                    _self.$vux.toast.text(data.message, 'middle');
                    return;
                }

                _self.roleModelDetailsModel = data.data.roleModelDetailsModel;
            })

        }
    }
</script>

<style lang="less">

    .role-model-details {

        h3 {
            width: 80%;
            margin: 0.3rem auto
        }

        .role-model-details-box {
            width: 100%;
            height: 1.2rem;
        }
        .role-model-details-title {
            display: block;
            height: 2.1rem;
            width: 33%;
            line-height: 1.2rem;
            font-size: 0.3rem;
            margin: 0 auto;
            text-align: center;
        }

        .role-model-details-date > div {
            flex: 1;
            font-size: 0.3rem;
            text-align: center;
            line-height: 2.1rem;
        }

        .role-model-details-date > div > b {
            margin-top: 1rem;
            height: 1px;
            border-top: 1px solid gray;
            display: inline-block;
            width: 90%;
        }

        .role-model-details-content {
            width: 95%;
            margin: 0.3rem auto;
        }

    }


</style>
