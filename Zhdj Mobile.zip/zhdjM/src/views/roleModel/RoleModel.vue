<template>
    <div class="role-model">
        <div class="role-model-title"><span>本期推荐</span></div>
        <div>
            <swiper loop auto :list="currentRoleModel_list" :index="currentRoleModel_index"
                    @on-index-change="currentRoleModel_onIndexChange" @click.native="toRoleModelDetails"></swiper>
        </div>
        <div class="role-model-title"><span>往期推荐</span></div>

        <div v-infinite-scroll="loadRoleModels" infinite-scroll-disabled="busy" infinite-scroll-distance="10">

            <div class="role-model-article" v-for="(roleModel,index) in roleModelsList" :key="index"
                 v-if="roleModelsList.length > 0" @click="toRoleModelDetails">
                <div>
                    <h2>{{roleModel.roleModelTitle}}</h2>
                    <p><span>作者:{{roleModel.roleModelAuthor}}</span><span>时间:{{roleModel.roleModelPublishDate}}</span>
                    </p>
                </div>
            </div>
            <loading></loading>
        </div>
    </div>
</template>

<script>
    import{Swiper, Divider} from 'vux'
    import loading from '../../components/common/loading.vue'
    import{getRoleModelsDetail} from '../../api/api'

    const baseList = [{
        url: 'javascript:',
        img: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vvsr72j20p00gogo2.jpg',
        title: '送你一朵fua'
    }, {
        url: 'javascript:',
        img: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vw1k2wj20p00goq7n.jpg',
        title: '送你一辆车'
    }, {
        url: 'javascript:',
        img: 'https://static.vux.li/demo/5.jpg', // 404
        title: '送你一次旅行',
        fallbackImg: 'https://ww1.sinaimg.cn/large/663d3650gy1fq66vw50iwj20ff0aaaci.jpg'
    }];

    export default {

        components: {
            Swiper,
            Divider,
            loading
        },

        data () {
            return {
                currentRoleModel_list: baseList,
                currentRoleModel_index: 0,
                index: 0,
                roleModelsList: [

                    {
                        roleModelId: 1,
                        roleModelTitle: '红色起点哈哈哈啊哈哈哈哈哈哈哈哈啊哈哈啊啊啊啊啊啊啊啊',
                        roleModelAuthor: '二狗子',
                        roleModelPublishDate: new Date,
                    },
                    {
                        roleModelId: 2,
                        roleModelTitle: '红色起点哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈',
                        roleModelAuthor: '二狗子',
                        roleModelPublishDate: new Date,
                    },
                    {
                        roleModelId: 3,
                        roleModelTitle: '红色起点哈哈哈哈哈哈哈哈哈哈哈哈哈哈',
                        roleModelAuthor: '二狗子',
                        roleModelPublishDate: new Date,
                    },
                    {
                        roleModelId: 4,
                        roleModelTitle: '红色起点',
                        roleModelAuthor: '二狗子',
                        roleModelPublishDate: new Date,
                    },
//                    {
//                        roleModelId: 5,
//                        roleModelTitle: '红色起点',
//                        roleModelAuthor: '二狗子',
//                        roleModelPublishDate:new Date,
//                    },

                ],
                busy: false,
                pageNo: 1,
                size: 15,
                totalPage: 1,
            }
        },


        methods: {
            currentRoleModel_onIndexChange(index){
                this.currentRoleModel_index = index;
            },

            toRoleModelDetails(){
                this.$router.push("/roleModelDetails");
            },


            initRoleModelsList: function () {
                let _self = this;
                getRoleModelsDetail({
                    curPage: _self.pageNo,
                    roleModelId: _self.roleModelId,
                    roleModel: 'flag'
                }).then((response) => {
                    console.log(response);
                    $(".load-more").hide();
                    if (response.success) {
                        _self.roleModelsList = _self.roleModelsList.concat(response.data.page.rows);
                        _self.totalPage = response.data.page.pageCount;
                        _self.pageNo++;
                        _self.busy = false;
                    } else {
                        _self.$vux.toast.text(response.message, 'middle')
                    }
                }).catch((error) => {
                    $(".load-more").hide()
                })
            },

            loadRoleModels: function () {
                if (this.pageNo > this.totalPage || this.busy) {
                    this.busy = true;
                    return;
                }
                this.busy = true;
                $(".load-more").show();
                this.initRoleModelsList();
            },
        }
    }
</script>

<style lang="less">

    .role-model {
        background-color: #FFFFFF;

        .role-model-title {
            height: 34px;
            width: 100%;
            background-color: #D0021B;
            span {
                display: inline-block;
                margin-top: 6px;
                margin-left: 14px;
                font-size: 14px;
                color: #FFFFFF;
            }
        }
        .role-model-article {
            border-bottom: 1px solid #eaecef;
            height: 2rem;
            padding: 8px 12px 0px 12px;

            p {
                margin: 8px 0px 10px 0px;
                font-size: 10px;

                span {
                    margin-right: 0.25rem;
                }
            }
        }
        .weui-loadmore {
            width: 100%;
        }

    }

</style>
