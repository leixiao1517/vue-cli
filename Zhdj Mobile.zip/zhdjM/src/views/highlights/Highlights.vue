<template>
    <section class="high-lights">
        <div class="top">头条视频</div>
        <!-- 列表 -->
        <!-- video -->
        <div class="video-info" @click="playVideo(index)" v-for="(video , index) in videoList">
            <div class="video-area">
                <!-- 播放图标 -->
                <i v-show="index != showFlag"></i>
                <!-- 播放遮罩 -->
                <div class="video-mask" v-show="index != showFlag"></div>
                <video :id="'video_' + index" class="video" name="media" webkit-playsinline="true" playsinline="true"  x5-playsinline="true"
                       :poster="video.videoImg"
                       :src="video.url">
                </video>
            </div>

            <!-- 用户信息 -->
            <div class="user">
                <img class="user-head" src="../../assets/images/breakGame/he.jpg">
                <div class="user-info">
                    <span>{{video.userName}}</span>
                    <span class="time">{{video.createDate | dateFormat}}</span>
                    <div class="like">
                        <img src="../../assets/images/common/icon-like.png">
                        {{video.likeCount}}
                    </div>
                </div>
            </div>
        </div>

    </section>
</template>

<script>

    export default {
        components: {

        },
        data () {
            return {
                showFlag : -1,
                videoList:[
                    {vid:1,userName:'古月1',url:'https://media.vangv.com/OUT/media/0f2cfd410928b62de74c408427e06088.mp4.mp4',
                        videoImg:'https://img.vangv.com/OUT/screenshot/media/4d5f0abd515d3d4bb9a069c608962331.jpg',createDate:new Date(),likeCount:1},
                    {vid:2,userName:'古月2',url:'https://media.vangv.com/OUT/media/45317c5d9aab3a4840344f612b6d2e35.mp4.mp4',
                        videoImg:'https://img.vangv.com/OUT/screenshot/media/801f94903a14f3f52aea1b7ae35e3105.jpg',createDate:new Date(),likeCount:22},
                    {vid:3,userName:'古月3',url:'https://media.vangv.com/OUT/media/f6b95e3e7858b67e9eed236a522f7b0e.mp4.mp4',
                        videoImg:'https://img.vangv.com/OUT/coverPath/d99f6e898c25e5a5d16f1a75f9888413.png',createDate:new Date(),likeCount:333},
                ]
            }
        },
        methods: {
            playVideo:function (index) {
                if(index == this.showFlag){
                    this.showFlag = -1
                    $('#video_' + index).trigger('pause');
                } else {
                    this.showFlag = index
                    $('.video').trigger('pause');
                    $('#video_' + index).trigger('play');
                }
            }
        },
        mounted () {

        }
    }
</script>

<style lang="less">
    .high-lights{
        background-color: #ffffff;
        .video-info{
            position: relative;
            .video-area{
                position: relative;
                .video-mask{
                    position: absolute;
                    left: 0;
                    top:0;
                    width: 100%;
                    height: 100%;
                    background: rgba(0,0,0,0.5);
                    z-index: 111;
                }
                i{
                    display: inline-block;
                    position: absolute;
                    width: 64px;
                    height: 64px;
                    left: 50%;
                    margin-left: -32px;
                    top: 50%;
                    margin-top: -32px;
                    background: url("../../assets/images/survey/icon_video_p.png") no-repeat;
                    z-index: 112;
                }
                .video{
                    width: 100%;
                    height: 200px;
                    object-fit: fill;//poster全铺满video
                }
            }
            .user{
                position: relative;
                width: 100%;
                background: #fff;
                .user-head{
                    position: absolute;
                    width: 40px;
                    height: 40px;
                    border-radius: 50%;
                    top:-30px;
                    z-index: 112;
                }
                .user-info{
                    line-height: 40px;
                    padding: 0 10px 0 10px;
                    .time{
                        margin-left: 20px;
                    }
                    .like{
                        float: right;
                        right: 0;
                        img{
                            width:16px;
                            height:16px;
                            margin-right: 5px;
                        }
                    }
                }
            }
        }
        .top{
            line-height: 30px;
            background-color:#D0021B;
            color:#ffffff;
            padding-left: 10px;
        }
    }
</style>
