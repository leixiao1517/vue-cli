<template>
    <div id="app">
        <loading v-model="isLoading"></loading>
        <transition name="router-slid" mode="out-in">
            <router-view></router-view>
        </transition>

        <!--xiaohan for audio-->
        <keep-alive>
            <audio id="audioMedia" :src="imageRootPath + 'zhongyan/zhdj/breakgame/images/breakGame/sound/startSound.mp3'" preload loop></audio>
        </keep-alive>

        <keep-alive>
            <audio id="flagMusic" :src="imageRootPath + 'zhongyan/zhdj/breakgame/images/breakGame/sound/hostSound.mp3'" preload></audio>
        </keep-alive>

        <keep-alive>
            <audio id="getEquipmentFailMusic" :src="imageRootPath + 'zhongyan/zhdj/breakgame/images/breakGame/sound/getEquipmentFail.mp3'" preload></audio>
        </keep-alive>

        <keep-alive>
            <audio id="getEquipmentSuccMusic" :src="imageRootPath + 'zhongyan/zhdj/breakgame/images/breakGame/sound/getEquipmentSucc.mp3'" preload></audio>
        </keep-alive>
    </div>
</template>

<script>
    import {Loading} from 'vux'
    import {mapState} from 'vuex'
    import { roundInit,getWXJsApiSignData} from './api/api'
    import { wxShare} from './assets/js/common/wxjsapi.js'
    import { mobileServer,imageRootPath,mobileClient} from './config/config'

    export default {
        name: 'app',
        components: {
            Loading
        },
        computed: {
            ...mapState({
                isLoading: state => state.vux.isLoading
            })
        },
        data (){
          return {
              imageRootPath
          }
        },
        methods:{
            refreshUrl:function () {  //微信浏览器在分享链接后会在#前加入附加字符串from=xxx&isappinstall=xxx
                let urlTail = location.href.split('#')[1];   //hash-url地址
                let shareUrl = mobileClient + '#' + urlTail;
                window.location.href = shareUrl;
            },
//            WXShare:function () {
//                let _self = this;
//                /*接口请求*/
//                roundInit({}).then((response) => {
//                    console.log(response);
//                    if(response.success){
//                        sessionStorage.setItem('inner', response.data.inner);
//                        getWXJsApiSignData({}).then(function (rsp) {
//                            if(rsp.success){
//                                console.log(rsp);
//                                let link = mobileServer + "zhdjM/wy/login";
//                                console.log("mobileServer----",mobileServer)
//                                if (1 == response.data.inner){ //外部链接
//                                    link = mobileServer + "zhdjM/xh/login";
//                                }
//                                let param = {
//                                    title: "我是"+response.data.userName+"，第"+response.data.pc+"红旗手，我为党旗添光彩！", // 分享标题
//                                    desc:"“不忘初心 牢记使命”庆祝中国共产党建党97周年",// 分享描述
//                                    link: link ,
//                                    imgUrl: imageRootPath + 'zhongyan/zhdj/resource/image/large-logo.jpg'// 分享图标
//                                };
//                                wxShare(rsp.data,param);
//                            }
//                        })
//                    }else {
//                        _self.$vux.toast.text(response.message, 'middle');
//                        window.location.href = mobileServer + "zhdjM/wy/login";
//                    }
//                }).catch((error) => {
//                    console.log(error)
//                })
//            }
        },
        mounted(){
            //audio
            let _self = this;
            let audioMedia = document.getElementById("audioMedia");
            _self.GLOBAL.setAudioEle(audioMedia);
            let flagMusic = document.getElementById("flagMusic");
            _self.GLOBAL.setFlagMusic(flagMusic);

            let getEquipmentFailMusic = document.getElementById("getEquipmentFailMusic");
            _self.GLOBAL.setAudioElement("getEquipmentFailMusic", getEquipmentFailMusic);
            let getEquipmentSuccMusic = document.getElementById("getEquipmentSuccMusic");
            _self.GLOBAL.setAudioElement("getEquipmentSuccMusic", getEquipmentSuccMusic);

            document.addEventListener("WeixinJSBridgeReady", function () {
                let audio = _self.GLOBAL.getAudioEle();
                audio.currentTime = 0;
                audio.load();

                let flagMusic = _self.GLOBAL.getFlagMusic();
                flagMusic.currentTime = 0;
                flagMusic.load();

                let getEquipmentFailMusic = _self.GLOBAL.getAudioElement("getEquipmentFailMusic");
                getEquipmentFailMusic.currentTime = 0;
                getEquipmentFailMusic.load();

                let getEquipmentSuccMusic = _self.GLOBAL.getAudioElement("getEquipmentSuccMusic");
                getEquipmentSuccMusic.currentTime = 0;
                getEquipmentSuccMusic.load();

            }, false);

            //给img增加一个play和stop方法，用来给GIF图播放和停止
            if ('getContext' in document.createElement('canvas')) {
                HTMLImageElement.prototype.play = function() {
                    if (this.storeCanvas) {
                        // 移除存储的canvas
                        this.storeCanvas.parentElement.removeChild(this.storeCanvas);
                        this.storeCanvas = null;
                        // 透明度还原
                        this.style.opacity = '';
                    }
                    if (this.storeUrl) {
                        this.src = this.storeUrl;
                    }
                };
                HTMLImageElement.prototype.stop = function() {
                    var canvas = document.createElement('canvas');
                    // 尺寸
                    var width = this.width, height = this.height;
                    if (width && height) {
                        // 存储之前的地址
                        if (!this.storeUrl) {
                            this.storeUrl = this.src;
                        }
                        // canvas大小
                        canvas.width = width;
                        canvas.height = height;
                        // 绘制图片帧（第一帧）
                        canvas.getContext('2d').drawImage(this, 0, 0, width, height);
                        // 重置当前图片
                        try {
                            this.src = canvas.toDataURL("image/gif");
                        } catch(e) {
                            // 跨域
                            this.removeAttribute('src');
                            // 载入canvas元素
                            canvas.style.position = 'absolute';
                            // 前面插入图片
                            this.parentElement.insertBefore(canvas, this);
                            // 隐藏原图
                            this.style.opacity = '0';
                            // 存储canvas
                            this.storeCanvas = canvas;
                        }
                    }
                };
            }
        },
        created(){
            this.refreshUrl();
        }
    }
</script>

<style lang="less">
    @import '~vux/src/styles/reset.less';
    @import 'assets/css/common.css';
    @import '~swiper/dist/css/swiper.css';
    body {
        background-color: #f1f1f1;
    }

    .router-slid-enter-active, .router-slid-leave-active {
        transition: all .4s;
    }

    .router-slid-enter, .router-slid-leave-active {
        transform: translate3d(2rem, 0, 0);
        opacity: 0;
    }
</style>
