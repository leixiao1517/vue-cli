/**
 * 微信 JSAPI
 * Created by hlf on 2018-5-7.
 */

import Vue from 'vue';    //Vue.wechat=wx
import $ from 'jquery'
import { WechatPlugin } from 'vux'
import { mobileClient } from '../../../config/config.js'

Vue.use(WechatPlugin)

//该函数完成对所有jsapi接口的鉴权
//同时设置最新的分享链接，如果不需要设置，则用默认链接地址
export const wxShare = function (wxInfo, params){
    let wx = Vue.wechat;

    let shareLink = mobileClient + '#' + '/index';
    let defaultParm = {
        title: '智慧党建平台', // 分享标题
        desc: "智慧党建平台", // 分享描述
        link: shareLink,
        imgUrl: "https://imgt.zjyou.cn/test/camp/4.png" // 分享图标
    };

    // if(!params){
    //     params = defaultParm;
    // }
    params = $.extend({},defaultParm,params);

    var ua = window.navigator.userAgent.toLowerCase();
    if (ua.match(/MicroMessenger/i) == 'micromessenger') { //只有在微信浏览器中打开才会需要调用微信分享jsapi
        wx.config({
            debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
            appId: wxInfo.appId,
            nonceStr: wxInfo.nonceStr,
            timestamp: wxInfo.timestamp,
            signature: wxInfo.signature,
            jsApiList: [
                'checkJsApi',
                'chooseImage',
                'uploadImage',
                'previewImage',
                'scanQRCode',
                'onMenuShareQQ',
                'onMenuShareTimeline',
                'onMenuShareAppMessage',
                'onMenuShareQZone',
                'onMenuShareWeibo',
                'getLocalImgData'
            ]
        });
        wx.checkJsApi({
            jsApiList: [
                'chooseImage',
                'uploadImage',
                'previewImage',
                'scanQRCode',
                'onMenuShareQQ',
                'onMenuShareTimeline',
                'onMenuShareAppMessage',
                'onMenuShareQZone',
                'onMenuShareWeibo',
                'getLocalImgData'
            ],
            success: function (res) {
                //alert(JSON.stringify(res));
                console.log(JSON.stringify(res))
            }
        });

        wx.error(function (res) {
            console.error(res);
        });

        wx.ready(function () {
            // 获取“分享到朋友圈”按钮点击状态及自定义分享内容接口
            wx.onMenuShareTimeline({
                title: params.title.replace(/\s/g, ""), // 分享标题
                link: params.link,
                imgUrl: params.imgUrl // 分享图标
            });
            // 获取“分享给朋友”按钮点击状态及自定义分享内容接口
            wx.onMenuShareAppMessage({
                title: params.title.replace(/\s/g, ""), // 分享标题
                desc: params.desc.replace(/\s/g, ""), // 分享描述
                link: params.link,
                imgUrl: params.imgUrl, // 分享图标
                success: function () {
                    console.log("分享给朋友");
                },
                cancel: function () {
                    // 用户取消分享后执行的回调函数
                }
            });

            wx.onMenuShareQQ({
                title: params.title.replace(/\s/g, ""), // 分享标题
                desc: params.desc.replace(/\s/g, ""), // 分享描述
                link: params.link,
                imgUrl: params.imgUrl, // 分享图标
                success: function () {
                    // 用户确认分享后执行的回调函数
                },
                cancel: function () {
                    // 用户取消分享后执行的回调函数
                }
            });

            wx.onMenuShareQZone({
                title: params.title.replace(/\s/g, ""), // 分享标题
                desc: params.desc.replace(/\s/g, ""), // 分享描述
                link: params.link,
                imgUrl: params.imgUrl, // 分享图标
                success: function () {
                    // 用户确认分享后执行的回调函数
                },
                cancel: function () {
                    // 用户取消分享后执行的回调函数
                }
            });

            wx.onMenuShareWeibo({
                title: params.title.replace(/\s/g, ""), // 分享标题
                desc: params.desc.replace(/\s/g, ""), // 分享描述
                link: params.link,
                imgUrl: params.imgUrl, // 分享图标
                success: function () {
                    // 用户确认分享后执行的回调函数
                },
                cancel: function () {
                    // 用户取消分享后执行的回调函数
                }
            });
        });
    }

}

//扫一扫功能
export const wxScanQRCode = function (succCallback) {
    let wx = Vue.wechat;
    wx.scanQRCode({
        needResult: 1, // 默认为0，扫描结果由微信处理，1则直接返回扫描结果，
        scanType: ["qrCode","barCode"], // 可以指定扫二维码还是一维码，默认二者都有
        success: function (res) {
            // 当needResult 为 1 时，扫码返回的结果
            succCallback(res.resultStr);
        }

    });
}


//选取本地图片
export const wxChooseImage = function (succCallback) {
    let wx = Vue.wechat;

    wx.chooseImage({
        count: 1, // 默认9  (1~9)
        sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
        sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
        success: function (res) {
            // 返回选定照片的本地ID列表，localId可以作为img标签的src属性显示图片
            succCallback(res.localIds);
        }
    });
}

//上传本地图片
export const wxUploadImage = function (localIds, succCallback) {
    let wx = Vue.wechat;
    wx.uploadImage({
        localId: localIds.toString(), // 需要上传的图片的本地ID，由chooseImage接口获得
        isShowProgressTips: 1, // 默认为1，显示进度提示
        success: function (res) {
            // res.serverId返回图片的服务器端ID
            succCallback(res.serverId);
        }
    });
}



// ios预览图片兼容性代码
export const getLocalImgData = function (localIds,callback,errorcallback) {
    let wx = Vue.wechat;
    wx.getLocalImgData({  //循环调用  getLocalImgData
        localId:localIds[0], // 图片的localID
        success: function (res) {

            let localData = res.localData; // localData是图片的base64数据，可以用img标签显示
            localData = localData.replace('jpg', 'jpeg');//iOS 系统里面得到的数据，类型为 image/jgp,因此需要替换一下
            callback(localData);
        },
        fail:function(res){
            // alert(res);
            errorcallback(res);
        }
    });
}
