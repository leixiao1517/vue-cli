/**
 * Created by tanxijun on 2017/9/21.
 */
/**
 * 配置本地环境和线上环境之间的切换
 *
 * mobileServer: 后台域名地址
 * mobileClient: 前端域名地址
 * imgBaseUrl: 图片所在域名地址
 *
 */
import VConsole from 'vconsole'

let mobileServer = 'http://192.168.0.132:8088/be/mobile/';
let imageRootPath = 'https://img.zjyou.cn/';
let imageRootPath1 = 'http://192.168.0.132:8088/static/';
let mobileClient = 'http://192.168.0.132:8088/';

if (process.env.NODE_ENV === 'development') {
    let vconsole = new VConsole()
} else if (process.env.NODE_ENV === 'production') {
    // let vconsole = new VConsole()

    // $.ajax({
    //     url:'serverconfig.json',
    //     type:'GET', //GET
    //     async:false, //或false,是否异步
    //     data:{
    //     },
    //     timeout:1000, //超时时间
    //     dataType:'json', //返回的数据格式：
    //     beforeSend:function(xhr){
    //     },
    //     success:function(data,textStatus,jqXHR){
    //         mobileServer = data.mobileServer;
    //         mobileClient=data.mobileClient;
    //     },
    //     error:function(xhr,textStatus){
    //     },
    //     complete:function(){
    //     }
    // });
    imageRootPath = 'https://img.zjyou.cn/';
    imageRootPath1 = 'https://zhdj.zjyou.cn/zhdjM/static/'
    mobileServer = 'https://zhdjt.zjyou.cn/be/mobile/'
    mobileClient = 'https://zhdjt.zjyou.cn/fe/mobile/'
}

export {
    mobileServer,
    imageRootPath,
    imageRootPath1,
    mobileClient
}
