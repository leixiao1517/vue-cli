/**
 * Created by tanxijun on 2017/10/12.
 */
import * as api from './api';

export default api;
