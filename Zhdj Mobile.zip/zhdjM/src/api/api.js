/**
 * Created by tanxijun on 2017/10/12.
 */
import axios from '../config/http'
import {mobileServer as base} from '../config/config';

export const like = params => { return axios.post(`${base}like`, params).then( response => { return response.data })};
export const getRoleList = params => { return axios.post(`${base}user/getRoleList`, params).then( response => { return response.data })};
export const getAbilityByRole = params => { return axios.post(`${base}user/getAbilityByRole`, params).then( response => { return response.data })};
export const roundInit = params => { return axios.post(`${base}wy/roundInit`, params).then( response => { return response.data })};

// 发布会议
export const getHistoryAndRegularUsers = params => { return axios.post(`${base}meeting/getHistoryAndRegularUsers`, params).then( response => { return response.data })};
export const publishMeeting = params => { return axios.post(`${base}meeting/publishMeeting`, params).then( response => { return response.data })};
export const searchUser = params => { return axios.post(`${base}meeting/searchUser`, params).then( response => { return response.data })};
//会议详情
export const meetingDetail = params => { return axios.post(`${base}meeting/meetingDetail`, params).then( response => { return response.data })};
export const meetingUserList = params => { return axios.post(`${base}meeting/meetingUserList`, params).then( response => { return response.data })};
export const attendMeeting = params => { return axios.post(`${base}meeting/attendMeeting`, params).then( response => { return response.data })};

//会议列表数据模拟
export const getMeetingDataByUid = params => { return axios.post(`${base}meeting/getMeetingDataByUid`, params).then( response => { return response.data })};

//个人信息主页
export const getUserInfo = params => { return axios.post(`${base}user/getUserInfo`, params).then( response => { return response.data })};

//参加考试
export const getQuestionList = params => { return axios.post(`${base}exam/getQuestionList`, params).then( response => { return response.data })};
export const getQuestion = params => { return axios.post(`${base}exam/getQuestion`, params).then( response => { return response.data })};
export const saveAnswer = params => { return axios.post(`${base}exam/saveAnswer`, params).then( response => { return response.data })};
export const publishQuestion = params => { return axios.post(`${base}exam/publishQuestion`, params).then( response => { return response.data })};

//获取选择题
export const getAnswersGeneral = params => { return axios.post(`${base}exam/getAnswersGeneral`, params).then( response => { return response.data })};

//获取问答题
export const getSimpleQuestion = params => { return axios.post(`${base}exam/getSimpleQuestion`, params).then( response => { return response.data })};

//获取某题目
export const getQuestionByQid = params => { return axios.post(`${base}exam/getQuestionByQid`, params).then( response => { return response.data })};

//获取答题列表
export const getAnswerDetail = params => { return axios.post(`${base}exam/getAnswerDetail`, params).then( response => { return response.data })};

//发布考试
export const publishExam = params => { return axios.post(`${base}exam/publishExam`, params).then( response => { return response.data })};
//考试审核
export const questionReview = params => { return axios.post(`${base}exam/questionReview`, params).then( response => { return response.data })};

//答题详情
export const getAnswerByAsid = params => { return axios.post(`${base}exam/getAnswerByAsid`, params).then( response => { return response.data })};

export const reviewAnswer = params => { return axios.post(`${base}exam/reviewAnswer`, params).then( response => { return response.data })};

//个人信息改变角色
export const changeRole = params => { return axios.post(`${base}user/changeRole`, params).then( response => { return response.data })};


//请假
export const leaveDetail = params => { return axios.post(`${base}leave/leaveDetail`, params).then( response => { return response.data })};

//会议统计功能接口
export const getCreditsByUid = params => { return axios.post(`${base}credits/getCreditsByUid`, params).then( response => { return response.data })};
export const getPublishedByUid = params => { return axios.post(`${base}meeting/getPublishedByUid`, params).then( response => { return response.data })};
export const searchMeeting = params => { return axios.post(`${base}meeting/searchMeeting`, params).then( response => { return response.data })};


//申请请假
export const applyLeave = params => { return axios.post(`${base}leave/applyLeave`, params).then( response => { return response.data })};

//发布纪要
export const pubSummary = params => { return axios.post(`${base}summary/pubSummary`, params).then( response => { return response.data })};

//获取纪要
export const getSummary = params => { return axios.post(`${base}summary/getSummary`, params).then( response => { return response.data })};

//排行学分
export const getRankByUid = params => { return axios.post(`${base}credits/getRankByUid`, params).then( response => { return response.data })};
//会议消息
export const getMessageList = params => { return axios.post(`${base}meeting/getMessageList`, params).then( response => { return response.data })};
export const readMsg = params => { return axios.post(`${base}meeting/readMsg`, params).then( response => { return response.data })};

//参与者详情
export const getAtsMeetingStsByMid = params => { return axios.post(`${base}meeting/getAtsMeetingStsByMid`, params).then( response => { return response.data })};

//会议统计
export const getMeetingStatistics = params => { return axios.post(`${base}meeting/getMeetingStatistics`, params).then( response => { return response.data })};

//会议统计
export const leaveCheck = params => { return axios.post(`${base}leave/leaveCheck`, params).then( response => { return response.data })};

//获取会议
export const getMeetingByMid = params => { return axios.post(`${base}meeting/getMeetingByMid`, params).then( response => { return response.data })};

//生成座位接口
export const generateSeat = params => { return axios.post(`${base}meeting/generateSeat`, params).then( response => { return response.data })};

/**获取微信签名 start**/
export const getWXJsApiSignData = params => { return axios.post(`${base}getWXJsApiSignData`, params).then( response => { return response.data })};
/**获取微信签名 end**/

//增加补课学分
export const addLessonCredits = params => { return axios.post(`${base}summary/addLessonCredits`, params).then( response => { return response.data })};

//增加考试积分
export const addExamCredits = params => { return axios.post(`${base}exam/addExamCredits`, params).then( response => { return response.data })};

//支部排名
export const getPartyRank = params => { return axios.post(`${base}credits/getPartyRank`, params).then( response => { return response.data })};

//第1关答题游戏题目接口
export const gameQuestion = params => { return axios.post(`${base}UserEquipment/getQuestion`, params).then( response => { return response.data })};

//闯关游戏用户接口
export const getUserEquipmentByUid = params => { return axios.post(`${base}UserEquipment/getUserEquipmentByUid`, params).then( response => { return response.data })};

//升旗接口
export const hoistFlag = params => { return axios.post(`${base}UserEquipment/hoistFlag`, params).then( response => { return response.data })};

//答题结果提交
export const stageCommit = params => { return axios.post(`${base}UserEquipment/stageCommit`, params).then( response => { return response.data })};

//答题结果提交
export const finish = params => { return axios.post(`${base}UserEquipment/finish`, params).then( response => { return response.data })};

/**
 *
 * 答题闯关
 *
 */
//和+先锋榜
export const pioneer = params => { return axios.post(`${base}UserRank/pioneer`, params).then( response => { return response.data })};

//荣耀旗手榜
export const honor = params => { return axios.post(`${base}UserRank/honor`, params).then( response => { return response.data })};

//荣耀旗手榜
export const fort = params => { return axios.post(`${base}UserRank/fort`, params).then( response => { return response.data })};

//荣耀旗手榜
export const inner = params => { return axios.post(`${base}UserRank/inner`, params).then( response => { return response.data })};


//中奖人员信息
export const billboard=params=>{return axios.post(`${base}RankBillboard/billboard`,params).then(response=>{return response.data})};

//党员心声
export const publishVoice=params=>{return axios.post(`${base}publishVoice`,params).then(response=>{return response.data})};
export const deleteVoice=params=>{return axios.post(`${base}deleteVoice`,params).then(response=>{return response.data})};
//书记信箱
export const publishSecretary=params=>{return axios.post(`${base}publishVoice`,params).then(response=>{return response.data})};
export const deleteSecretary=params=>{return axios.post(`${base}deleteVoice`,params).then(response=>{return response.data})};
export const getVoicesList = params => { return axios.post(`${base}getVoicesList`,params).then(response=>{return response.data})};
export const getUserByToken = params => { return axios.post(`${base}getUserByToken`,params).then(response=>{return response.data})};
export const checkFeeUpgradeStatus = params => { return axios.post(`${base}checkFeeUpgradeStatus`,params).then(response=>{return response.data})};


//推荐读书列表

export const getBooksDetail = params => {
    return axios.post(`${base}recommendedBooksList`, params).then(response => {
        return response.data
    })
};
//获得本期推荐读书
export const getCurrentRecommend = params => {
    return axios.post(`${base}currentRecommend`, params).then(response => {
        return response.data;
    })
};

//推荐读书

export const recommendBookLink = params => {
    return axios.post(`${base}recommendBookLink`, params).then(response => {
        return response.data;
    })
};

//收藏到书单
export const collectMyFavorite = params => {
    return axios.post(`${base}collectMyFavorite`, params).then(response => {
        return response.data;
    })
};


//读者投稿列表
export const getContributionsDetail = params => {
    return axios.post(`${base}contributionsList`, params).then(response => {
        return response.data;
    })
};
//读者投稿详情

export const getContributionDetails = params => {
    return axios.post(`${base}contributionDetails`, params).then(response => {
        return response.data;
    })
};
//读者投稿

export const submitContributionLink = params => {
    return axios.post(`${base}submitContributionInfo`, params).then(response => {
        return response.data;
    })
};

//榜样力量列表
export const getRoleModelsDetail = params => {
    return axios.post(`${base}roleModelsDetail`, params).then(response => {
        return response.data
    })
};


export const fee = params => { return axios.post(`${base}fee`,params).then(response=>{return response.data})};

/***资源列表接口****/

export const getResourceList = params => {
    return axios.post(`${base}resource/getResourceList`, params).then(response => {
        return response.data
    })
};

/*****资源列表详情接口**/

export const getResourceDetail = params => {
    return axios.post(`${base}resource/getResourceDetail`, params).then(response => {
        return response.data
    })
};

/*****增加查看次数接口*****/

export const addResourceViews = params => {
    return axios.post(`${base}resource/addResourceViews`, params).then(response => {
        return response.data
    })
};

/*****获取三会一课列表*****/
export const getMeetingList = params => {
    return axios.post(`${base}meeting/getMeetingList`, params).then(response => {
        return response.data
    })
};



