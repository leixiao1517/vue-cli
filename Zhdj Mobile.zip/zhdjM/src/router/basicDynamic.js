/**
 * Created by Administrator on 2018/11/30.
 */

export default [
    {
        path: '/basicDynamic',
        name: 'basicDynamic',
        title: '基层动态',
        component: function (resolve) {
            require(['../views/basicDynamic/BasicDynamic.vue'], resolve)
        }
    },
]
