/**
 * Created by Administrator on 2018/11/1.
 */

/**
 * Created by Administrator on 2018/10/23.
 */
/***
 * 时政要闻路由
 ***/


export default [

    {
        path: '/PoliticsNews',
        name: 'PoliticsNews',
        title: '时政要闻',
        component: function (resolve) {
            require(['../views/politicsNews/PoliticsNews.vue'], resolve)
        },


        children: [
            {
                path: '',
                name: 'PoliticsTopic',
                component: function (resolve) {
                    require(['../views/politicsNews/PoliticsTopic.vue'], resolve)
                }
            },
            {
                path: '/PolicyElucidation',
                name: 'PolicyElucidation',
                component: function (resolve) {
                    require(['../views/politicsNews/PolicyElucidation.vue'], resolve)
                }
            },

            {
                path: '/ViewPolitics',
                name: 'ViewPolitics',
                component: function (resolve) {
                    require(['../views/politicsNews/ViewPolitics.vue'], resolve)
                }
            },

            {
                path: '/PoliticsTopic',
                name: 'PoliticsTopic',
                component: function (resolve) {
                    require(['../views/politicsNews/PoliticsTopic.vue'], resolve)
                }
            },
        ]


    },

]

