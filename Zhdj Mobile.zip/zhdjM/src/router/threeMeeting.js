/**
 * Created by Administrator on 2018/11/2.
 */


/***
 **三會一課路由
 */

export  default [
    {
        path: '/ThreeMeetingList',
        name: 'ThreeMeetingList',
        title: '三会一课',
        component: function (resolve) {
            require(['../views/ThreeMeeting/ThreeMeetingList.vue'], resolve)
        },
    },


]
