/**
 * Created by Administrator on 2018/9/7.
 *
 * 精彩来稿路由
 */
export  default [


    {
        path: '/contribution',
        name: 'contribution',
        title: '读者来稿',
        component: function (resolve) {
            require(['../views/contribution/Contribution.vue'], resolve)
        }
    },
    {
        path: '/contributionDetails',
        name: 'contributionDetails',
        title: '读者来稿',
        component: function (resolve) {
            require(['../views/contribution/ContributionDetails.vue'], resolve)
        }
    },
    {
        path: '/toContribution',
        name: 'toContribution',
        title: '读者来稿',
        component: function (resolve) {
            require(['../views/contribution/ToContribution.vue'], resolve)
        }
    },
]
