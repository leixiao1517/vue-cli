/**
 * 志愿者路由
 * Created by hlf on 18/4/11.
 */
export default [
    {
        path: '/Volunteer',
        name: 'Volunteer',
        title: '志愿者',
        component: function (resolve) {
            require(['../views/volunteer/Volunteer.vue'], resolve)
        }
    },
    {
        path: '/VolunteerActivityDetails',
        name: 'VolunteerActivityDetails',
        title: '志愿者详情',
        component: function (resolve) {
            require(['../views/volunteer/VolunteerActivityDetails.vue'], resolve)
        }
    },

]
