/**
 * 用户路由
 * Created by hlf on 18/4/11.
 */
export default [
    {
        path: '/confirm',
        name: 'confirm',
        title: '选择身份',
        component: function (resolve) {
            require(['../views/user/Confirm.vue'], resolve)
        }
    },
    {
        path: '/select',
        name: 'select',
        title: '选择身份',
        component: function (resolve) {
            require(['../views/user/Select.vue'], resolve)
        }
    },{
        path: '/indicateLeave/:meetId',
        name: 'indicateLeave',
        title: '请假',
        component: function (resolve) {
            require(['../views/user/IndicateLeave.vue'], resolve)
        }
    },
    {
        path: '/userInfo',
        name: 'userInfo',
        title: '个人信息',
        component: function (resolve) {
            require(['../views/user/UserInfo.vue'], resolve)
        }
    },
    {
        path: '/checkLeave',
        name: 'checkLeave',
        title: '请假审核',
        component: function (resolve) {
            require(['../views/user/CheckLeave.vue'], resolve)
        }
    },
    {
        path: '/myCredit',
        name: 'myCredit',
        title: '我的学分',
        component: function (resolve) {
            require(['../views/user/MyCredit.vue'], resolve)
        }
    },
    {
        path: '/myRank',
        name: 'myRank',
        title: '我的排行',
        component: function (resolve) {
            require(['../views/user/MyRank.vue'], resolve)
        }
    },
    {
        path: '/myMessage',
        name: 'myMessage',
        title: '我的消息',
        component: function (resolve) {
            require(['../views/user/MyMessage.vue'], resolve)
        }
    },
    {
        path: '/transfer',
        name: 'transfer',
        title: '页面跳转中...',
        component: function (resolve) {
            require(['../views/common/Transfer.vue'], resolve)
        }
    },
    {
        path: '/other',
        name: 'other',
        title: 'TA人主页',
        component: function (resolve) {
            require(['../views/user/OtherUser.vue'], resolve)
        }
    }
]



