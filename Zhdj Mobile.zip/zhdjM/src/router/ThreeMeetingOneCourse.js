/**
 * 三会一课
 * Created by hlf on 18/4/11.
 */
export default [
    {
        path: '/ThreeMeetingOneCourse',
        name: 'ThreeMeetingOneCourse',
        title: '三会一课',
        component: function (resolve) {
            require(['../views/ThreeMeetingOneCourse/ThreeMeetingOneCourse.vue'], resolve)
        }
    },
    {
        path: '/ThreeMeetingSubmitted',
        name: 'ThreeMeetingSubmitted',
        title: '党员心声',
        component: function (resolve) {
            require(['../views/ThreeMeetingOneCourse/ThreeMeetingSubmitted.vue'], resolve)
        }
    },
    {
        path: '/ThreeMeetingArticles',
        name: 'ThreeMeetingArticles',
        title: '会议纪要',
        component: function (resolve) {
            require(['../views/ThreeMeetingOneCourse/ThreeMeetingArticles.vue'], resolve)
        }
    },
    {
        path: '/ThreeMeetingDetails',
        name: 'ThreeMeetingDetails',
        title: '三会一课',
        component: function (resolve) {
            require(['../views/ThreeMeetingOneCourse/ThreeMeetingDetails.vue'], resolve)
        }
    },
    {
        path: '/ThreeMeetingEditable',
        name: 'ThreeMeetingEditable',
        title: '心得',
        component: function (resolve) {
            require(['../views/ThreeMeetingOneCourse/ThreeMeetingEditable.vue'], resolve)
        }
    },

]



