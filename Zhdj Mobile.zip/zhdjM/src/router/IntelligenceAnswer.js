/**
 * 智能问答路由
 * Created by hlf on 18/4/11.
 */
export default [
    {
        path: '/SearchAnswer',
        name: 'SearchAnswer',
        title: '智能问答',
        component: function (resolve) {
            require(['../views/intelligenceAnswer/SearchAnswer.vue'], resolve)
        }
    },
    {
        path: '/Result',
        name: 'Result',
        title: '智能问答',
        component: function (resolve) {
            require(['../views/intelligenceAnswer/Result.vue'], resolve)
        }
    },
    {
        path: '/QuestionDetails',
        name: 'QuestionDetails',
        title: '题目详情',
        component: function (resolve) {
            require(['../views/intelligenceAnswer/QuestionDetails.vue'], resolve)
        }
    },

]



