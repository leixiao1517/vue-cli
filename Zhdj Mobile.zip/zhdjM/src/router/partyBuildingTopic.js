/**
 * Created by Administrator on 2018/10/26.
 */

/***
 * 党建专题路由
 */

export  default [
    {
        path: '/PartyBuildingTopic',
        name: 'PartyBuildingTopic',
        title: '党建专题',
        component: function (resolve) {
            require(['../views/partyBuildingTopic/PartyBuildingTopic.vue'], resolve)
        },
    },
    {
        path: '/NineteenthTopic',
        name: 'NineteenthTopic',
        title: '十九大专题',
        component: function (resolve) {
            require(['../views/partyBuildingTopic/nineteenTopic/NineteenthTopic'], resolve)
        },
        children: [
            {
                path: '',
                name: 'FileSpiritList',
                component: function (resolve) {
                    require(['../views/partyBuildingTopic/nineteenTopic/FileSpiritList.vue'], resolve)
                },
            },
            {
                path: 'StudyDatumList',
                name: 'StudyDatumList',
                component: function (resolve) {
                    require(['../views/partyBuildingTopic/nineteenTopic/StudyDatumList.vue'], resolve)
                },
            },
            {
                path: 'StudyDynamicList',
                name: 'StudyDynamicList',
                component: function (resolve) {
                    require(['../views/partyBuildingTopic/nineteenTopic/StudyDynamicList.vue'], resolve)
                },
            },
            {
                path: 'StudyConditionList',
                name: 'StudyConditionList',
                component: function (resolve) {
                    require(['../views/partyBuildingTopic/nineteenTopic/StudyConditionList.vue'], resolve)
                },
            },

        ]
    },
    {
        path: '/StudyTopic',
        name: 'NineteenthTopic',
        title: '两学一做',
        component: function (resolve) {
            require(['../views/partyBuildingTopic/studyTopic/StudyTopic'], resolve)
        },
        children: [
            {
                path: '',
                name: 'CentralSpiritList',
                component: function (resolve) {
                    require(['../views/partyBuildingTopic/studyTopic/CentralSpiritList.vue'], resolve)
                },
            },
            {
                path: 'WorkTrendList',
                name: 'WorkTrendList',
                component: function (resolve) {
                    require(['../views/partyBuildingTopic/studyTopic/WorkTrendList.vue'], resolve)
                },
            },
            {
                path: 'PartyConstitutionList',
                name: 'PartyConstitutionList',
                component: function (resolve) {
                    require(['../views/partyBuildingTopic/studyTopic/PartyConstitutionList.vue'], resolve)
                },
            },
            {
                path: 'SeriesOfSpeechList',
                name: 'SeriesOfSpeechList',
                component: function (resolve) {
                    require(['../views/partyBuildingTopic/studyTopic/SeriesOfSpeechList.vue'], resolve)
                },
            },
            {
                path: 'LearnEducationSchemeList',
                name: 'LearnEducationSchemeList',
                component: function (resolve) {
                    require(['../views/partyBuildingTopic/studyTopic/LearnEducationSchemeList.vue'], resolve)
                },
            },
            {
                path: 'PioneerStoryList',
                name: 'PioneerStoryList',
                component: function (resolve) {
                    require(['../views/partyBuildingTopic/studyTopic/PioneerStoryList.vue'], resolve)
                },
            },
            {
                path: 'LearningServicesList',
                name: 'LearningServicesList',
                component: function (resolve) {
                    require(['../views/partyBuildingTopic/studyTopic/LearningServicesList.vue'], resolve)
                },
            },
        ]
    },
]

