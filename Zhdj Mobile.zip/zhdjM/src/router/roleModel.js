/**
 * Created by Administrator on 2018/9/10.
 */
/**
 * 榜样力量路由
 **/


export  default [

    {

        path: '/roleModel',
        name: 'roleModel',
        title: '榜样力量',
        component: function (resolve) {
            require(['../views/roleModel/RoleModel.vue'], resolve)
        }
    },

    {
        path: "/roleModelDetails",
        name: 'roleModelDetails',
        title: '榜样力量',
        component: function (resolve) {
            require(['../views/roleModel/RoleModelDetails.vue'], resolve)
        }

    }
]
