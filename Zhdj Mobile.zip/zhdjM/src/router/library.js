/**
 * Created by Administrator on 2018/10/23.
 */
/***
 * 图书馆路由
 ***/


export default [

    {
        path: '/library',
        name: 'library',
        title: '图书馆',
        component: function (resolve) {
            require(['../views/library/Library.vue'], resolve)
        },


        children: [
            {
                path: '',
                name: 'VideoLibrary',
                component: function (resolve) {
                    require(['../views/library/VideoLibrary.vue'], resolve)
                }
            },
            {
                path: '/PicLibrary',
                name: 'PicLibrary',
                component: function (resolve) {
                    require(['../views/library/PicLibrary.vue'], resolve)
                }
            },

            {
                path: '/BookLibrary',
                name: 'BookLibrary',
                component: function (resolve) {
                    require(['../views/library/BookLibrary.vue'], resolve)
                }
            },

            {
                path: '/VideoLibrary',
                name: 'VideoLibrary',
                component: function (resolve) {
                    require(['../views/library/VideoLibrary.vue'], resolve)
                }
            },
        ]


    },

]
