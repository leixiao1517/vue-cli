/**
 * 会议路由
 * Created by hlf on 18/4/11.
 */
export default [
    {
        path: '/meeting',
        name: 'meeting',
        title: '会议服务',
        component: function (resolve) {
            require(['../views/meeting/Meeting.vue'], resolve)
        }
    },
    {
        path: '/meetingDetail/:meetId',
        name: 'meetingDetail',
        title: '会议详情',
        component: function (resolve) {
            require(['../views/meeting/MeetingDetail.vue'], resolve)
        }
    },
    {
        path: '/meetingAttendance/:meetId',
        name: 'meetingAttendance',
        title: '参与者详情',
        component: function (resolve) {
            require(['../views/meeting/MeetingAttendance.vue'], resolve)
        }
    },
    {
        path: '/publishMeeting',
        name: 'publishMeeting',
        title: '发布会议',
        component: function (resolve) {
            require(['../views/meeting/PublishMeeting.vue'], resolve)
        },
        // meta: { requiresAuth: true}
    },
    {
        path: '/countMeeting/:meetId',
        name: 'countMeeting',
        title: '会议统计',
        component: function (resolve) {
            require(['../views/meeting/CountMeeting.vue'], resolve)
        }
    },
    {
        path: '/publishAbstract/:meetId',
        name: 'publishAbstract',
        title: '发布会议纪要',
        component: function (resolve) {
            require(['../views/meeting/PublishAbstract.vue'], resolve)
        }
    },
    {
        path: '/meetingAbstract/:meetId',
        name: 'meetingAbstract',
        title: '确认会议纪要',
        component: function (resolve) {
            require(['../views/meeting/MeetingAbstract.vue'], resolve)
        }
    },
    {
        path: '/partakeDetails/:meetId',
        name: 'partakeDetails',
        title: '参与详情',
        component: function (resolve) {
            require(['../views/meeting/PartakeDetails.vue'], resolve)
        }
    },
]
