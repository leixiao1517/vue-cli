/**
 * 必读热点路由
 * Created by hlf on 18/4/11.
 */
export default [
    {
        path: '/Articles',
        name: 'Articles',
        title: '必读热点',
        component: function (resolve) {
            require(['../views/mustRead/Articles.vue'], resolve)
        }
    },
    {
        path: '/MustRead',
        name: 'MustRead',
        title: '必读热点',
        component: function (resolve) {
            require(['../views/mustRead/MustRead.vue'], resolve)
        }
    },

]



