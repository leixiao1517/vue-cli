/**
 * 考试路由
 * Created by cg on 18/4/11.
 */
export default [
    {
        path: '/publishAsk/:mid',
        name: 'publishAsk',
        title: '发布问答题',
        component: function (resolve) {
            require(['../views/exam/PublishAsk.vue'], resolve)
        }
    },
    {
        path: '/publishQuestion/:meetId',
        name: 'publishQuestion',
        title: '发布补考',
        component: function (resolve) {
            require(['../views/exam/PublishQuestion.vue'], resolve)
        }
    },
    {
        path: '/modifyS/:qid',
        name: 'modifyS',
        title: '选择题详情',
        component: function (resolve) {
            require(['../views/exam/PublishSelect.vue'], resolve)
        }
    },
    {
        path: '/modifyQ/:qid',
        name: 'modifyQ',
        title: '问答题详情',
        component: function (resolve) {
            require(['../views/exam/PublishAsk.vue'], resolve)
        }
    },
    {
        path: '/publishSelect/:mid',
        name: 'publishSelect',
        title: '发布选择题',
        component: function (resolve) {
            require(['../views/exam/PublishSelect.vue'], resolve)
        }
    },
    {
        path: '/detailsExam/:meetId',
        name: 'detailsExam',
        title: '补考参与详情',
        component: function (resolve) {
            require(['../views/exam/DetailsExam.vue'], resolve)
        }
    },
    {
        path: '/replyDetails/:meetId',
        name: 'replyDetails',
        title: '答题情况',
        component: function (resolve) {
            require(['../views/exam/ReplyDetails.vue'], resolve)
        }
    },
    // {
    //     path: '/publishQuestion',
    //     name: 'publishQuestion',
    //     title: '发布考试',
    //     component: function (resolve) {
    //         require(['../views/exam/PublishQuestion.vue'], resolve)
    //     }
    // },
    {
        path: '/questionList/:meetId',
        name: 'questionList',
        title: '参加考试',
        component: function (resolve) {
            require(['../views/exam/QuestionList.vue'], resolve)
        }
    },
    {
        path: '/question/:qid',
        name: 'question',
        title: '参加考试',
        component: function (resolve) {
            require(['../views/exam/Question.vue'], resolve)
        }
    },
    {
        path: '/questionReviewList/:qid',
        name: 'questionReviewList',
        title: '人员列表',
        component: function (resolve) {
            require(['../views/exam/QuestionReviewList.vue'], resolve)
        }
    },
    {
        path: '/questionReview/:asid',
        name: 'questionReview',
        title: '考试查看',
        component: function (resolve) {
            require(['../views/exam/QuestionReview.vue'], resolve)
        }
    },


]



