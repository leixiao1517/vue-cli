/**
 * Created by Administrator on 2018/11/28.
 */


export default [
    {
        path: '/classRoom',
        name: 'classRoom',
        title: '云课堂',
        component: function (resolve) {
            require(['../views/classRoom/ClassRoom.vue'], resolve)
        }
    },
]
