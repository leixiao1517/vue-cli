/**
 * Created by Administrator on 2018/10/25.
 */


export default [

    {
        path: '/ResourceDetail',
        name: 'ResourceDetail',
        title: '资源详情',
        component: function (resolve) {
            require(['../views/resourceDetail/ResourceDetail.vue'], resolve)
        },
    },


]
