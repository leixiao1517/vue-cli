/**
 * 党员关怀路由
 * Created by hlf on 18/9/14.
 */
export default [
    {
        path: '/care',
        name: 'care',
        title: '党员关怀',
        component: function (resolve) {
            require(['../views/care/CareList.vue'], resolve)
        }
    },
    {
        path: '/care/:tid',
        name: 'talkDetail',
        title: '谈话详情',
        component: function (resolve) {
            require(['../views/care/TalkDetail.vue'], resolve)
        }
    },
]



