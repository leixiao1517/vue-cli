/**
 * Created by Administrator on 2018/11/1.
 */

/**
 * Created by Administrator on 2018/10/23.
 */
/***
 * 时政要闻路由
 ***/


export default [

    {
        path: '/LeaderSpeech',
        name: 'LeaderSpeech',
        title: '领导言论',
        component: function (resolve) {
            require(['../views/leadershipSpeech/LeaderSpeech.vue'], resolve)
        },


        children: [
            {
                path: '',
                name: 'CountrySpeech',
                component: function (resolve) {
                    require(['../views/leadershipSpeech/CountrySpeech.vue'], resolve)
                }
            },
            {
                path: '/ProvinceSpeech',
                name: 'ProvinceSpeech',
                component: function (resolve) {
                    require(['../views/leadershipSpeech/ProvinceSpeech.vue'], resolve)
                }
            },

            {
                path: '/CompanySpeech',
                name: 'CompanySpeech',
                component: function (resolve) {
                    require(['../views/leadershipSpeech/CompanySpeech.vue'], resolve)
                }
            },

            {
                path: '/CountrySpeech',
                name: 'CountrySpeech',
                component: function (resolve) {
                    require(['../views/leadershipSpeech/CountrySpeech.vue'], resolve)
                }
            },
        ]


    },

]

/**
 * Created by Administrator on 2018/11/1.
 */
