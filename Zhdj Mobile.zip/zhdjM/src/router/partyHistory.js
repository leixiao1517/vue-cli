/**
 * Created by Administrator on 2018/10/26.
 */


export  default [
    {
        path: '/PartyHistory',
        name: 'PartyHistory',
        title: '党史党章',
        component: function (resolve) {
            require(['../views/partyHistory/PartyHistory.vue'], resolve)
        },

        children: [
            {
                path: '',
                name: 'PartyHistoryList',
                component: function (resolve) {
                    require(['../views/partyHistory/PartyHistoryList.vue'], resolve)
                },
            },


            {
                path: '/PartyConstitutionList',
                name: 'PartyConstitutionList',

                component: function (resolve) {
                    require(['../views/partyHistory/PartyConstitutionList.vue'], resolve)
                },
            },

            {
                path: 'PartyHistoryList',
                name: 'PartyHistoryList',
                component: function (resolve) {
                    require(['../views/partyHistory/PartyHistoryList.vue'], resolve)
                },
            },

        ]
    },


]
