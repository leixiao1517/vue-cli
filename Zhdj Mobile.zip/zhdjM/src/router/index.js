import Vue from 'vue'
import Router from 'vue-router'
import InfiniteScroll from 'vue-infinite-scroll'
import meeting from './meeting'
import user from './user'
import exam from './exam'
import breakGame from "./breakGame";
import survey from "./survey";
import mustRead from "./MustRead";
import intelligenceAnswer from "./IntelligenceAnswer";
import volunteer from "./Volunteer";
// import book from "./book"
// import contribution from "./contribution"
// import roleModel from "./roleModel"
import TwoLearnOneDo from "./TwoLearnOneDo";
import care from "./care";
import ThreeMeetingOneCourse from "./ThreeMeetingOneCourse";
import Library from "./library";
import resourceDetail from "./resourceDetail";
import partyBuildingTopic from "./partyBuildingTopic"
import partyHistory from "./PartyHistory"
import PoliticsNews from "./PoliticsNews"
import leaderSpeech from "./leaderSpeech"
import threeMeeting from "./threeMeeting"
import classRoom from "./classRoom"
import partyRules from "./partyRules"
import basicDynamic from "./basicDynamic"



Vue.use(InfiniteScroll);

Vue.use(Router);

let rooterArray = [
    meeting,
    user,
    // index
    exam,
    breakGame,
    survey,
    mustRead,
    intelligenceAnswer,
    volunteer,
    // book,
    // contribution,
    // roleModel,
    TwoLearnOneDo,
    care,
    TwoLearnOneDo,
    ThreeMeetingOneCourse,
    Library,
    resourceDetail,
    partyBuildingTopic,
    partyHistory,
    PoliticsNews,
    leaderSpeech,
    threeMeeting,
    classRoom,
    partyRules,
    basicDynamic
];

const routes = [

    {
        path: '/',
        name: 'index',
        title: '智慧党建',
        component: function (resolve) {
            require(['../views/Index.vue'], resolve)
        }
    },
    {
        path: '/index',
        name: 'index',
        title: '智慧党建',
        component: function (resolve) {
            require(['../views/Index.vue'], resolve)
        }
    },
    {
        path: '/404',
        name: 'notFount',
        title: '404',
        component: function (resolve) {
            require(['../views/common/404.vue'], resolve)
        }
    },
    {
        path: '/noService',
        name: 'noService',
        title: '已经结束',
        component: function (resolve) {
            require(['../views/NoService.vue'], resolve)
        }
    },
    {
        path: '/noServiceOuter',
        name: 'noServiceOuter',
        title: '已经结束',
        component: function (resolve) {
            require(['../views/NoServiceOuter.vue'], resolve)
        }
    },
    {
        path: '/fee',
        name: 'fee',
        title: '党费缴纳',
        component: function (resolve) {
            require(['../views/icbc/IcbcPay.vue'], resolve)
        }
    },
    // {
    //     path: '/eCharts',
    //     name: 'eCharts',
    //     title: '图形',
    //     component: function (resolve) {
    //         require(['../views/eCharts.vue'], resolve)
    //     }
    // },
    {   path: '*',
        redirect: '/404'
    },

];

rooterArray.forEach(function(value, index, array) {
  value.forEach(function(route, index, array) {
    routes.push(route)
  })
});

const router = new Router({
  mode: 'hash',
  routes: routes
});

export default router
