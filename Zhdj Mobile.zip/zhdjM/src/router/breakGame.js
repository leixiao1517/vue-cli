/**
 * 答题游戏路由
 * Created by cg on 18/4/11.
 */
export default [
    {
        path: '/preLoad',
        name: 'preLoad',
        title: '加载中...',
        component: function (resolve) {
            require(['../views/breakGame/Preload.vue'], resolve)
        }
    },
    {
        path: '/gameStart',
        name: 'gameStart',
        title: '不忘初心 牢记使命',
        component: function (resolve) {
            require(['../views/breakGame/GameStart.vue'], resolve)
        }
    },
    {
        path: '/hostFlag',
        name: 'hostFlag',
        title: '升旗仪式',
        component: function (resolve) {
            require(['../views/breakGame/HostFlag.vue'], resolve)
        }
    },
    {
        path: '/gameRound',
        name: 'gameRound',
        title: '闯关环节',
        component: function (resolve) {
            require(['../views/breakGame/GameRound.vue'], resolve)
        }
    },
    {
        path: '/gameUserInfo',
        name: 'gameUserInfo',
        title: '个人中心',
        component: function (resolve) {
            require(['../views/breakGame/GameUserInfo.vue'], resolve)
        }
    },
    {
        path: '/luckRound',
        name: 'luckRound',
        title: '幸运环节',
        component: function (resolve) {
            require(['../views/breakGame/LuckRound.vue'], resolve)
        }
    },
    {
        path: '/rank',
        name: 'rank',
        title: '排行榜',
        component: function (resolve) {
            require(['../views/breakGame/Rank.vue'], resolve)
        }
    },
    {
        path: '/prizeInformation',
        name: 'prizeInformation',
        title: '中奖信息',
        component: function (resolve) {
            require(['../views/breakGame/PrizeInformation.vue'], resolve)
        }
    }

]



