/**
 * 两学一做
 * Created by hlf on 18/4/11.
 */
export default [
    {
        path: '/TwoLearnOneDo',
        name: 'TwoLearnOneDo',
        title: '两学一做',
        component: function (resolve) {
            require(['../views/TwoLearnOneDo/TwoLearnOneDo.vue'], resolve)
        }
    },
    {
        path: '/TwoLearnDetails',
        name: 'TwoLearnDetails',
        title: '两学一做',
        component: function (resolve) {
            require(['../views/TwoLearnOneDo/TwoLearnDetails.vue'], resolve)
        }
    },
    {
        path: '/TwoLearnArticles',
        name: 'TwoLearnArticles',
        title: '活动过程',
        component: function (resolve) {
            require(['../views/TwoLearnOneDo/TwoLearnArticles.vue'], resolve)
        }
    },
    {
        path: '/TwoLearnEditable',
        name: 'TwoLearnEditable',
        title: '心得',
        component: function (resolve) {
            require(['../views/TwoLearnOneDo/TwoLearnEditable.vue'], resolve)
        }
    },
    {
        path: '/TwoLearnSubmitted',
        name: 'TwoLearnSubmitted',
        title: '党员心声',
        component: function (resolve) {
            require(['../views/TwoLearnOneDo/TwoLearnSubmitted.vue'], resolve)
        }
    },

]



