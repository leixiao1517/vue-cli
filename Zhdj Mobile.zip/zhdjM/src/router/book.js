/**
 * 好书推荐路由
 **/

export default [

    {
        path: '/book',
        name: 'book',
        title: '好书推荐',
        component: function (resolve) {
            require(['../views/book/Recommended.vue'], resolve)
        }
    },

    {
        path: '/recommend/:bookId',
        name: 'recommendDetails',
        title: '书籍详情',
        component: function (resolve) {
            require(['../views/book/RecommendDetails.vue'], resolve)
        }
    },

    {
        path: '/mineBookList',
        name: 'mineBookList',
        title: '我的书单',
        component: function (resolve) {
            require(['../views/book/MineBookList.vue'], resolve)
        }
    },

    {
        path: '/recommendBooks',
        name: 'recommendBooks',
        title: '推荐好书',
        component: function (resolve) {
            require(['../views/book/RecommendBooks.vue'], resolve)
        }
    },


]
