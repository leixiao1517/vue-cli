/**
 * 问卷调查路由
 * Created by hlf on 18/9/5.
 */
export default [
    {
        path: '/survey',
        name: 'survey',
        title: '问卷调查',
        component: function (resolve) {
            require(['../views/survey/Survey.vue'], resolve)
        }
    },
    {
        path: '/voice',
        name: 'voice',
        title: '党员心声',
        component: function (resolve) {
            require(['../views/survey/Voice.vue'], resolve)
        },
    },
    {
        path: '/voice/:vid',
        name: 'voiceDetail',
        title: '心声详情',
        component: function (resolve) {
            require(['../views/survey/VoiceDetail.vue'], resolve)
        },
    },
    {
        path: '/partyVoice',
        name: 'partyVoice',
        title: '党员心声',
        component: function (resolve) {
            require(['../views/survey/PartyVoice.vue'], resolve)
        },
        children: [
            {
                path: '',
                name: 'edit',
                component: function (resolve) {
                    require(['../views/survey/EditVoice.vue'], resolve)
                },
            },
            {
                path: 'edit',
                name: 'edit',
                component: function (resolve) {
                    require(['../views/survey/EditVoice.vue'], resolve)
                },
            },
            {
                path: 'own',
                name: 'own',
                component: function (resolve) {
                    require(['../views/survey/OwnVoice.vue'], resolve)
                },
            },
        ]
    },
    {
        path: '/secretary',
        name: 'secretary',
        title: '书记信箱',
        component: function (resolve) {
            require(['../views/survey/Secretary.vue'], resolve)
        },
        children: [
            {
                path: '',
                name: 'edit',
                component: function (resolve) {
                    require(['../views/survey/EditSecretary.vue'], resolve)
                },
            },
            {
                path: 'edit',
                name: 'edit',
                component: function (resolve) {
                    require(['../views/survey/EditSecretary.vue'], resolve)
                },
            },
            {
                path: 'own',
                name: 'own',
                component: function (resolve) {
                    require(['../views/survey/OwnSecretary.vue'], resolve)
                },
            },
        ]
    },
    {
        path: '/secretary/:sid',
        name: 'secretaryDetail',
        title: '信箱详情',
        component: function (resolve) {
            require(['../views/survey/VoiceDetail.vue'], resolve)
        },
    },
    {
        path: '/highlights',
        name: 'highlights',
        title: '精彩回放',
        component: function (resolve) {
            require(['../views/highlights/Highlights.vue'], resolve)
        },
    },
    {
        path: '/research',
        name: 'research',
        title: '项目调研',
        component: function (resolve) {
            require(['../views/survey/Research.vue'], resolve)
        },
    },
    {
        path: '/vote',
        name: 'vote',
        title: '民意投票',
        component: function (resolve) {
            require(['../views/survey/Research.vue'], resolve)
        },
    },
    {
        path: '/vote/:rid',
        name: 'voteDetail',
        title: '民意投票',
        component: function (resolve) {
            require(['../views/survey/ResearchDetail.vue'], resolve)
        },
    }
]



