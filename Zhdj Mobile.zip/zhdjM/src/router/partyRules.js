/**
 * Created by Administrator on 2018/11/28.
 */


export default [
    {
        path: '/partyRules',
        name: 'partyRules',
        title: '党内法规',
        component: function (resolve) {
            require(['../views/partyRules/PartyRules.vue'], resolve)
        }
    },
]
