Vue-cli 项目包 （cmd方法）
	此项目包建立在环境依赖下NPM，注意是否有环境依赖，可通过npm -v 来检查是否有版本号
		1.npm install					安装项目文件中的必要依赖
		2.npm run dev					启动项目