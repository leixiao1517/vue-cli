<template>
    <div id="app">
        <loading v-model="isLoading"></loading>
        <router-view></router-view>
    </div>
</template>

<script>
    import $ from 'jquery'
    import Vue from 'vue'
    import {Loading} from 'vux'
    import {mapState} from 'vuex'

    export default {
        name: 'app',
        components: {
            Loading
        },
        computed: {
            ...mapState({
                isLoading: state => state.vux.isLoading
            })
        },
        mounted(){
        },

    }
</script>

<style lang="less">


</style>
