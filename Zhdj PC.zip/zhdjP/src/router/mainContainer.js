export default [
    {   path: '',
        redirect: 'manage'
    },
    {
        name: 'manage',
        path: '/manage',
        component: function (resolve) {
            require(['../views/manage/Manage.vue'], resolve)
        },
        children: [
            {
                path: '',
                name: 'defaultTab',
                component: function (resolve) {
                    require(['../views/manage/ClassSection.vue'], resolve)
                }
            },
            {
                path: 'party',
                name: 'party',
                component: function (resolve) {
                    require(['../views/manage/ClassSection.vue'], resolve)
                }
            },
            {
                path: 'meeting',
                name: 'meeting',
                component: function (resolve) {
                    require(['../views/manage/MeetingSection.vue'], resolve)
                }
            },
        ]
    },
    {
        name: 'meetingList',
        path: '/meetingList',
        component: function (resolve) {
            require(['../views/meeting/MeetingList.vue'], resolve)
        }
    }
]
