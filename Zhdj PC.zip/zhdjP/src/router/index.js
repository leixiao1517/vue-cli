import Vue from 'vue'
import Router from 'vue-router'
import mainContainerRouter from './mainContainer.js'


Vue.use(Router)

let routerArray = [
    mainContainerRouter,
]

const routes = [
    {
        path: '/404',
        name: '404',
        title: '404',
        component: function (resolve) {
            require(['../views/common/404.vue'], resolve)
        }
    },
    {   path: '*',
        redirect: '404'
    }]

routerArray.forEach(function (value, index, array) {
    value.forEach(function (route, index, array) {
        routes.push(route)
    })
})


// let RouteEx = [{
//     path: '/',
//     component: App,
//     children: routes,
// }];


const router = new Router({
    mode: 'hash',
    routes
    //RouteEx,
})

export default router
