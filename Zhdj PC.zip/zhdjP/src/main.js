// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import FastClick from 'fastclick'
import router from './router/index.js'
import App from './App.vue'
import { imageRootPath } from './config/config'
import Vuex from 'vuex'
import { dateFormat } from 'vux'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import utils from './plugins/utils'

FastClick.attach(document.body)
Vue.config.productionTip = false
Vue.use(Vuex)
Vue.use(ElementUI)
Vue.use(utils)

const store = new Vuex.Store({}) // 这里你可能已经有其他 module
store.registerModule('vux', { // 名字自己定义
    state: {
        isLoading: false
    },
    mutations: {
        updateLoadingStatus (state, payload) {
            state.isLoading = payload.isLoading
        }
    }
})

// router.beforeEach(function (to, from, next) {
//     store.commit('updateLoadingStatus', {isLoading: true});
//     if (to.matched.some(record => record.meta.requiresAuth)) {
//         // this route requires auth, check if logged in
//         // if not, redirect to login page.
//         let strObj = sessionStorage.getItem('userInfo');
//         console.log("strObj",strObj)
//         if (!strObj) {
//             next({
//                 path: '/login',
//                 query: {redirect: to.fullPath}//把要跳转的地址作为参数传到下一步
//             })
//         }else{
//             next();
//         }
//     }else{
//         next();
//     }
// })

router.afterEach(function (to) {
    store.commit('updateLoadingStatus', {isLoading: false})
})

Vue.filter('dateFormat', function (time,type) {
    let date = '';
    if(type == 'YMD'){
        date = dateFormat(time, 'YYYY-MM-DD');
    } else if (type == 'HMS'){
        date = dateFormat(time, 'HH:mm:ss');
    } else {
        date = dateFormat(time, 'YYYY-MM-DD HH:mm:ss');
    }
    return date;
})

/**
 * 图片路径过滤器
 * type 资源类型 以后台的typeName为准
 * id 营地id 商户id 营地管理员id
 *
 */
Vue.filter('imgPath', function(value,type,id) {
    // console.log("value:",value)
    if('' == value || undefined == value || value.length < 4 ){
        return;
    }
    // base64的格式和绝对路径不做处理 本地选取的图片
    if(value.substring(0,4)=="data"||
        value.substring(0,4)=="http"){
        return value;
    }

    let imgPath = ''
    if(type=="stay"||
        type=="food"||
        type=="play"||
        type=="special"||
        type=="businessman") {//住宿 美食 玩乐 特产 商户
        imgPath = imageRootPath + 'lyxxh/'  + '/businessman/' + id + value
    }else if(type=="scenicSpot"||
        type=="destination") {//景点 目的地
        imgPath = imageRootPath + 'lyxxh/'  + '/destination/' + id + value
    }else if(type=="destManager") {//目的地管理者
        imgPath = imageRootPath + 'lyxxh/'  + '/destManager/' + id + value
    }else if(type=="volunteer") {//志愿者
        imgPath = imageRootPath + 'lyxxh/'  + '/volunteer/' + id + value
    }

    return imgPath
})

//ES6.0 way
new Vue({
    store,
    router,
    render: h => h(App),
}).$mount('#app-box')

