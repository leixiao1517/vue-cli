import axios from 'axios';
import '../plugins/jquery.form.js'
import '../plugins/jqueryTool'
import {adminServer as basePath} from '../config/config';

export const pageMeeting = params => { return axios.post(`${basePath}pageMeeting`, params).then(res => res.data); };
export const getMeetingDetail = params => { return axios.post(`${basePath}meeting/getMeetingDetail`, params).then(res => res.data); };
export const getMeetingList = params => { return axios.post(`${basePath}meeting/getMeetingList`, params).then(res => res.data); };
export const publishMeeting = params => { return axios.post(`${basePath}meeting/publishMeeting`, params).then(res => res.data); };
export const searchMeeting = params => { return axios.post(`${basePath}meeting/searchMeeting`, params).then(res => res.data); };
export const PartyCommittee = params => { return axios.post(`${basePath}member/PartyCommittee`, params).then(res => res.data); };
export const PartyMemberList = params => { return axios.post(`${basePath}member/PartyMemberList`, params).then(res => res.data); };
export const editPartyMember = params => { return axios.post(`${basePath}member/editPartyMember`, params).then(res => res.data); };
export const searchPartyUser = params => { return axios.post(`${basePath}member/searchPartyUser`, params).then(res => res.data); };
export const getCommitteeInfo = params => { return axios.post(`${basePath}member/getCommitteeInfo`, params).then(res => res.data); };
export const getResourceList = params => { return axios.post(`${basePath}resource/getResourceList`, params).then(res => res.data); };
export const selectMeetingResource = params => { return axios.post(`${basePath}resource/selectMeetingResource `, params).then(res => res.data); };
export const getUser = params => { return axios.post(`${basePath}getUser`, params).then(res => res.data); };
export const readPartiesSet = params => { return axios.post(`${basePath}meeting/readPartiesSet`, params).then(res => res.data); };
export const generateUploadSign = params => { return axios.post(`${basePath}generateUploadSign`, params).then(res => res.data); };
export const saveMeeting = params => { return axios.post(`${basePath}saveMeeting`, params).then(res => res.data); };
export const uploadImg = params => { return axios.post(`${basePath}uploadImg`, params).then(res => res.data); };
