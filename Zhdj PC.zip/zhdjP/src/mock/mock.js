/**
 * Created by xiaohan on 2017/10/12.
 */
import destination from './data/destination.js'

const Mock = require('mockjs');
let basePath = '/api/v1/lyxxh';

Mock.mock(`${basePath}/destination/getDestination`, 'post', destination.getDestination);


