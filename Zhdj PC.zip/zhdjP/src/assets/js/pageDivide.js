
/**
 * Created by xiaohan on 2017-10-19.
 */
//查询数据 带分页
//pagePlugId 分页插件的容器div
//reqFun 向服务器请求数据的函数指针
//jsonData 请求参数
//succCallback 请求数据成功以后的回调函数


import './jquery.page'
import '../css/css.less'

import '../../plugins/bootoast/bootoast.css'
import '../../plugins/bootoast/bootoast.js'


class PageDivide{
    // 构造
    constructor(pagePlugId, reqFun, jsonData, succCallback){
        this.pagePlugId = pagePlugId;
        this.reqFun = reqFun;
        this.jsonData = jsonData;
        this.succCallback = succCallback;
    }

    getDataWithPages(){
        let _self = this;
        this.reqFun(_self.jsonData).then(function (rsp) {
            _self.onSucces(rsp);
            _self.succCallback(rsp);

        }).catch(function (err) {
            console.log(err);
            bootoast({
                message: '请检查网络是否畅通。',
                position:'top',
                timeout:2
            });

        })

        // this.reqFun(_self.jsonData).then((rsp) => {
        //     console.log(rsp)
        // })
    }

    onSucces(rsp){
        var _self = this;
        let pageDividID = '#pageDivideContainer';
        //清除分页（清除事件的影响）
        $(pageDividID).remove();

        //添加分页，从新添加事件。
        $(this.pagePlugId).append("<div id='" + pageDividID.substr(1) + "'></div>");

        //创建翻页插件
        $(pageDividID).createPage
        ({
            pageCount: rsp.data.pageCount,//总页数，数据从服务器获取
            current: rsp.data.pageNo,     //当前是第几页
            backFn: function (p) {
                _self.pageClick(p);
            }
        });

        //给分页插件加上css样式
        $(pageDividID).addClass('tcdPageCode');
    }

    pageClick = function (p) {
        this.jsonData.pageNo = p;
        this.getDataWithPages();
    }
}

// function GetDataObj(urlStr, jsonData, templateID, tableBodyID, pagePlugID) {
//     this.urlStr = urlStr;
//     this.jsonData = jsonData;
//     this.templateID = templateID;
//     this.tableBodyID = tableBodyID;
//     this.tempPageDivID = pagePlugID + templateID;
//     this.pagePlugID = pagePlugID;
//
//     this.succCallback = '';
// }
//
// GetDataObj.prototype.getDataWithPages = function (succCallback) {
//     //用self，为避免与其他函数内部的this冲突
//     var self = this;
//     self.succCallback = succCallback;
//     $.ajax({
//         type: "post",
//         url: self.urlStr,
//         data: self.jsonData,
//         dataType: "json",
//         success: function (result) {
//             if (result.success) {
//                 self.onSuccess(result);    //在$.ajax内部用self来表示类的this
//             }
//             else {
//                 bootbox.alert({
//                     size: 'small',
//                     message: result.message,
//                     callback: function () {
//
//                     }
//                 });
//             }
//         },
//         error: function (result) {
//
//         }
//     })
// }
//
// GetDataObj.prototype.onSuccess = function (result) {
//     var html = template(this.templateID, result);
//
//     if (this.tableBodyID) {
//         $(this.tableBodyID).html(html);
//     }
//
//     //清除分页（清除事件的影响）
//     $(this.tempPageDivID).remove();
//
//     //添加分页，从新添加事件。
//     $(this.pagePlugID).append("<div id='" + this.tempPageDivID.substr(1) + "'></div>");
//
//     var self = this;
//     //创建翻页插件
//     $(this.tempPageDivID).createPage
//     ({
//         pageCount: result.data.pageCount,//总页数，数据从服务器获取
//         current: result.data.pageNo,//当前是第几页
//         //backFn: this.pageClick,      //回调函数，调用pageClick，再次执行分页功能。
//         backFn: function (p) {
//             self.pageClick(self, p);
//         }
//     });
//
//     //给分页插件加上css样式
//     $(this.tempPageDivID).addClass('tcdPageCode');
// }
//
// GetDataObj.prototype.pageClick = function (self, p) {
//     self.jsonData.curPage = p;
//     self.getDataWithPages(self.succCallback);
// }

// export default GetDataObj;
export default PageDivide;
