<template>
    <div class="meeting-list">
        <!-- 列表区 -->
        <el-table :data="meetingList" style="min-width: 100%" @sort-change="changeDate()" v-loading="loading" element-loading-text="拼命加载中..."
                  element-loading-spinner="el-icon-loading" element-loading-background="rgba(0, 0, 0, 0.3)">
            <el-table-column fixed prop="startDate" label="日期" min-width="150" sortable :formatter="getTime" align="center"></el-table-column>
            <el-table-column prop="createUser" label="姓名" min-width="120" align="center"></el-table-column>
            <el-table-column prop="title" label="省份" min-width="300" align="center"></el-table-column>
            <el-table-column prop="address" label="地址" min-width="200" align="center"></el-table-column>
            <el-table-column prop="meetId" label="邮编" min-width="100" align="center"></el-table-column>
            <el-table-column label="操作" align="center">
                <template slot-scope="scope">
                    <el-button @click.native.prevent="uploadShow = true" type="text" size="small">编辑</el-button>
                    <el-button @click.native.prevent="deleteRow(scope.$index, meetingList)" type="text" size="small">移除</el-button>
                </template>
            </el-table-column>
        </el-table>

        <!-- 页码区 -->
        <el-pagination :current-page="currentPage" :page-sizes="[10, 20, 50, 100]" :page-size="pageSize"
               layout="total, sizes, prev, pager, next, jumper" :total="totalRow" @current-change="handleCurrentChange"
           @size-change="handleSizeChange">
        </el-pagination>

        <!-- 编辑弹框区 -->
        <el-dialog title="编辑" :visible.sync="dialogFormVisible">
            <el-form :model="form" label-position="right" :inline="true">
                <el-col :span="12">
                    <el-form-item label="名称" :label-width="formLabelWidth">
                        <el-input v-model="form.name" autocomplete="off"></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="12">
                    <el-form-item label="选择" :label-width="formLabelWidth">
                        <el-select v-model="form.region" placeholder="请选择活动区域">
                            <el-option label="选择一" value="shanghai"></el-option>
                            <el-option label="选择二" value="beijing"></el-option>
                        </el-select>
                    </el-form-item>
                </el-col>
                <el-col :span="12">
                    <el-form-item label="活动时间" :label-width="formLabelWidth">
                        <el-date-picker type="date" placeholder="选择日期" v-model="form.date1"></el-date-picker>
                    </el-form-item>
                </el-col>
                <el-col :span="12">
                    <el-form-item label="即时配送" :label-width="formLabelWidth">
                        <el-switch v-model="form.delivery"></el-switch>
                    </el-form-item>
                </el-col>
                <el-form-item label="活动性质" :label-width="formLabelWidth">
                    <el-checkbox-group v-model="form.type">
                        <el-checkbox label="美食/餐厅线上活动" name="type"></el-checkbox>
                        <el-checkbox label="地推活动" name="type"></el-checkbox>
                        <el-checkbox label="线下主题活动" name="type"></el-checkbox>
                        <el-checkbox label="单纯品牌曝光" name="type"></el-checkbox>
                    </el-checkbox-group>
                </el-form-item>
                <el-form-item label="特殊资源" :label-width="formLabelWidth">
                    <el-radio-group v-model="form.resource">
                        <el-radio label="线上品牌商赞助"></el-radio>
                        <el-radio label="线下场地免费"></el-radio>
                    </el-radio-group>
                </el-form-item>
                <el-col :span="24">
                    <el-form-item label="活动形式" :label-width="formLabelWidth">
                        <el-input type="textarea" v-model="form.desc"></el-input>
                    </el-form-item>
                </el-col>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取 消</el-button>
                <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
            </div>
        </el-dialog>

        <!-- 选择文件弹框区 -->
        <el-dialog title="选择文件" :visible.sync="uploadShow">
            <iframe name='upload' :src="'https://yun.vangv.com/index.php/resource/index?createtime='+ uploadParam.createtime +'&nostr=' + uploadParam.nostr
                    + '&owner=' + uploadParam.owner + '&user=' + uploadParam.user + '&sign=' + uploadParam.sign"
                            frameborder='0' height='600' scrolling='auto' width="100%"></iframe>
            <div slot="footer" class="dialog-footer">
                <el-button @click="uploadShow = false">取 消</el-button>
                <el-button type="primary" @click="uploadShow = false">确 定</el-button>
            </div>
        </el-dialog>

        <tinymce-editor v-model="msg" :disabled="disabled" @onClick="onClick" ref="editor"></tinymce-editor>
    </div>
</template>

<script>
    import {pageMeeting,generateUploadSign} from '../../api/api.js'
    import TinymceEditor from '../../components/TinyMce.vue'
    export default{
        name: 'MeetingList',
        components: {
            TinymceEditor
        },
        data(){
            return{
                currentPage:1,
                pageSize:10,
                totalRow:1,
                dateFlag:false,
                loading:true,
                dialogFormVisible:false,
                uploadShow:false,
                formLabelWidth: '120px',
                form: {
                    name: '',
                    region: '',
                    date1: '',
                    date2: '',
                    delivery: false,
                    type: [],
                    resource: '',
                    desc: ''
                },
                meetingList: [],
                uploadParam:{},
                msg: '请输入...',
                disabled: false
            }
        },
        methods:{
            //鼠标单击的事件
            onClick(e, editor) {
                console.log('Element clicked')
//                console.log(e)
//                console.log(editor)
            },
            getTime:function (row, column, cellValue, index) {
                //这里用了插件形式的时间格式化 而非过滤器
                return this.zjyDateFormat(cellValue)
            },
            deleteRow(index, rows) {
                this.$confirm('此操作将永久删除该项目, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {
                    rows.splice(index, 1);
                    this.$message({
                        type: 'success',
                        message: '删除成功!'
                    });
                }).catch(() => {
                    this.$message({
                        type: 'info',
                        message: '已取消删除'
                    });
                });
            },
            handleSizeChange: function (size) {
                this.pageSize = size;
                this.loadData()
            },
            handleCurrentChange:function (currentPage) {
                this.currentPage = currentPage
                this.loadData()
            },
            changeDate:function () {
                console.log(this.dateFlag)
                if(this.dateFlag){
                    this.dateFlag = false
                } else {
                    this.dateFlag = true
                }
                this.loadData()
            },
            loadData:function () {
                let _self = this
                _self.loading = true
                pageMeeting({curPage:_self.currentPage,pageSize:_self.pageSize}).then(function (rsp) {
                    console.log(rsp)
                    _self.loading = false
                    if (rsp.success) {
                        _self.totalRow = rsp.data.totalRow
                        _self.meetingList = rsp.data.list
                        _self.currentPage = rsp.data.pageNumber
                    } else {
                        _self.$message.error(rsp.message);
                    }
                });
            },
            getUploadParam:function () {
                let _self = this
                generateUploadSign({}).then(function (rsp) {
                    console.log(rsp)
                    if (rsp.success) {
                        _self.uploadParam = rsp.data
                    } else {
                        _self.$message.error(rsp.message);
                    }
                });
            }
        },
        mounted(){
            this.loadData()
            this.getUploadParam();
            window.onmessage = function(e){
                e = e || event;
                alert(e.data);
            }
        }
    }
</script>
<style lang="less" scoped>
    .meeting-list {
        .el-pagination{
            text-align: center;
        }
    }
</style>
