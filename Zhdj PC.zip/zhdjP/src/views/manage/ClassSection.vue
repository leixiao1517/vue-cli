<template>
    <section class="ClassSection">
            <el-container>
                <el-aside width="305">
                    <div class="tree-list">
                        <div class="input-box">
                            <el-input placeholder="请选择党委之后，输入关键字查询" v-model="filterText"></el-input>
                        </div>
                        <el-tree class="filter-tree" :data="trees" :props="defaultProps" ref="partyTree" :load="loadNode1" :filter-node-method="filterNode" lazy show-checkbox @node-click="handleNodeClick"></el-tree>
                    </div>
                </el-aside>
                <el-container>
                    <el-header style="height:160px">
                        <div class="tree-title">
                            <div>
                                <h3 v-if="tablePartyName != ''">{{tablePartyName}}</h3>
                                <h3 v-if="tablePartyName == ''">公司机关党委</h3>
                                <p>党(总)支部委员&nbsp;:&nbsp;
                                    <span style="color:#1890ff" v-for="item in tableHeadData.leader" v-if="item != 'null'">&nbsp;{{item}}&nbsp;</span>
                                </p>
                                <p>系统管理员&nbsp;:&nbsp;
                                    <span style="color:#1890ff" v-for="item in tableHeadData.admin">&nbsp;{{item}}&nbsp;</span>
                                </p>
                            </div>
                            <div>
                                <p>支部:{{dataTem.length}}个&nbsp;&nbsp;党员:{{countAll}}人</p>
                            </div>
                        </div>
                    </el-header>
                    <el-main>
                        <div class="tree-details">

                            <div class="search-member">
                                <div class="search-left"><span style="color:#1890ff">编辑</span>&nbsp;操作可修改组织关系、设置系统管理员</div>
                                <div class="search-right">
                                    <div>
                                        <el-input v-model="memberName" placeholder="用户姓名" ></el-input>
                                    </div>
                                    <div>
                                        <el-input v-model="phoneNumber" placeholder="手机号" ></el-input>
                                    </div>
                                    <el-button @click="findMember()" type="primary">查询</el-button>
                                    <el-button @click="resetmember()">重置</el-button>
                                </div>
                            </div>

                            <div class="member-list">
                                <template>
                                    <el-table :data="memberList" stripe style="width: 100%">
                                        <el-table-column prop="uid" label="工号" max-width="90" min-width="90" style="margin-left:2px"></el-table-column>
                                        <el-table-column prop="userName" label="用户姓名" max-width="90" min-width="90"></el-table-column>
                                        <el-table-column prop="mobile" label="手机号" max-width="120" min-width="120"></el-table-column>
                                        <el-table-column prop="committeeName" label="党委" max-width="210" min-width="120"></el-table-column>
                                        <el-table-column prop="partyName" label="支部" max-width="320" min-width="240"></el-table-column>
                                        <el-table-column prop="positions" label="党内职务" max-width="300" min-width="180"></el-table-column>
                                        <el-table-column label="操作" width="60">
                                            <template slot-scope="scope">
                                                <el-button type="text" size="small" @click="editMember(scope.$index)">编辑</el-button>
                                            </template>
                                        </el-table-column>
                                    </el-table>
                                </template>
                            </div>

                            <div class="list-page">
                                    <span v-if="this.countAll != ''">总共&nbsp;{{countAll}}&nbsp;条记录</span>
                                <div>
                                    <el-pagination :current-page="currentPage" :page-sizes="[10, 20, 50, 100]" :page-size="pageSize"
                                                   layout="sizes, prev, pager, next, jumper" :total="_self.totalRow" @current-change="handleCurrentChange"
                                                   @size-change="handleSizeChange">
                                    </el-pagination>
                                </div>
                            </div>
                        </div>
                    </el-main>
                </el-container>
            </el-container>
            <div class="edit-box" v-if="editable == '1'">
                <div class="edit-content">
                    <div class="edit-head">
                        <span><b>用户信息</b>&nbsp;&nbsp;只能修改党员组织关系以及设置系统管理员</span>
                        <i class="el-icon-close" @click="editable = '0'"></i>
                    </div>
                    <div class="edit-section">
                        <ul>
                            <li><span>用户姓名：</span><div><el-input  v-model="editMemberInfo.userName" :disabled="true"></el-input></div></li>
                            <li><span>手机号：</span><div><el-input    v-model="editMemberInfo.mobile" :disabled="true"></el-input></div></li>
                            <li><span>所属公司：</span><div><el-input  v-model="editMemberInfo.unitName" :disabled="true"></el-input></div></li>
                            <li><span>所属部门：</span><div><el-input  v-model="editMemberInfo.department" :disabled="true"></el-input></div></li>
                            <li><span>入党时间：</span><div><el-input  v-model="editMemberInfo.joinTime" :disabled="true"></el-input></div></li>
                            <li><span>转正时间：</span><div><el-input  v-model="editMemberInfo.positiveTime" :disabled="true"></el-input></div></li>
                            <li>
                                <span>
                                    所属党委：
                                </span>
                                <div>
                                    <template>
                                        <el-select v-model="selectClassEpistasis" filterable placeholder="请选择" @change="changeClassEpistasis()" :visible-change="false">
                                            <el-option v-for="item in classEpistasis" :key="item.value" :label="item.label" :value="item.value"></el-option>
                                        </el-select>
                                    </template>
                                </div>
                            </li>
                            <li>
                                <span>
                                    所属支部：
                                </span>
                                <div>
                                    <template>
                                        <el-select v-model="selectClassBasics" filterable placeholder="请选择">
                                            <el-option v-for="item in classBasics" :key="item.partyName" :label="item.label" :value="item.partyName"></el-option>
                                        </el-select>
                                    </template>
                                </div>
                            </li>
                            <li>
                                <span>
                                    党内职务：
                                </span>
                                <div>
                                    <template>
                                            <!--<el-input v-model="selectClassJob"></el-input>-->

                                        <el-select v-model="selectClassJob" placeholder="请选择" default-first-option filterable allow-create>
                                            <el-option v-for="item in positionList" :key="item.position" :label="item.label" :value="item.position" ></el-option>
                                        </el-select>
                                    </template>
                                </div>
                            </li>
                            <li>
                                <span>
                                    系统管理员：
                                </span>
                                <div>
                                    <el-radio-group v-model="editMemberInfo.admin">
                                        <el-radio :label="1">是</el-radio>
                                        <el-radio :label="0">否</el-radio>
                                    </el-radio-group>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div class="edit-footer">
                        <el-button type="primary" @click="pushMemberInfo()">确定</el-button>
                        <el-button @click="editable = '0'">取消</el-button>
                    </div>
                </div>
            </div>
    </section>
</template>

<script>
    import $ from 'jquery'
    import { PartyCommittee,PartyMemberList,editPartyMember,searchPartyUser,getCommitteeInfo,getUser } from '../../api/api.js'
    import eventbus from '../../plugins/EventBus.js'
    export default {
        watch: {
            filterText(val) {
                this.$refs.partyTree.filter(val);
            }
        },
        data() {
            return {
                trees:[],
                filterText: '',
                defaultProps: {
                    label: 'partyName',
                    children: 'children',
                    isLeaf: 'leaf',
                    level:'partyLevel',
                    pid:'pid'
                },
                treeSearch: '',
                memberName: '',
                phoneNumber: '',
                editable: '0',              //编辑党员信息弹窗
                editName: '',
                classData:'',
                list:[],
                memberList:[],
                countAll:'',
                tablePartyName:'',
                editMemberInfo:{},
                selectClassEpistasis: '',
                currentPage:1,
                pageSize:10,
                item:'',
                admin:'',
                classEpistasis:[
                    { label:'长沙卷烟厂党委',value: '长沙卷烟厂党委',pid:1},
                    { label:'郴州卷烟厂党委' ,value: '郴州卷烟厂党委',pid:2 },
                    { label:'金叶薄片党委',value: '金叶薄片党委',pid:3 },
                    { label:'四平卷烟厂党委',value: '四平卷烟厂党委',pid:4 },
                    { label:'吴忠卷烟厂党委',value: '吴忠卷烟厂党委',pid:5 },
                    { label:'零陵卷烟厂党委',value: '零陵卷烟厂党委',pid:6 },
                    { label:'常德卷烟厂党委',value: '常德卷烟厂党委',pid:7 },
                    { label:'公司机关党委',value: '公司机关党委',pid:8 }
                ],
                classBasics: [{
                    partyName:'',
                    pid:'',
                }],
                selectClassBasics: '',
                selectClassJob:'',
                positionList:[
                    { position:'党总支部书记',label:'党总支部书记' },
                    { position:'党总支部副书记',label:'党总支部副书记' },
                    { position:'党总支委员',label:'党总支委员' },
                    { position:'党支部书记',label:'党支部书记' },
                    { position:'党支部副书记',label:'党支部副书记' },
                    { position:'组织委员',label:'组织委员' },
                    { position:'宣传委员',label:'宣传委员' },
                    { position:'纪律检查委员',label:'纪律检查委员' },
                    { position:'青年委员',label:'青年委员' },
                    { position:'其他',label:'其他' }
                ],
                editClassJob: [],
                dataTem:[],
                memberPartyName:'',
                tableHeadData:'',
                checkData:[],
                pageNo:'',
                memberGetListType:'1',     //搜索党员时的判断，1.默认树形支部列表获取并且显示党委  2.从搜索条件中获取查询党委
                defaultMemberList:'1',       //默认页面初始化下获取接口 1=true 默认查询党员列表 ， 0=false 不是默认查询党员列表
                saveClickpid:'',
                saveClickPartyName:'',
                saveClickPartyLevel:'',
                treeInterval:{},
                retryTimes:1
            }
        },
        methods: {
            filterNode(value, data) {
                if (!value) return true;
                return data.partyName.indexOf(value) !== -1;
            },
            loadNode1(node, resolve) {
                let _self = this
                if (node.level === 0) {
                    resolve(this.trees);
                }
                if (node.level >= 1) {
                    console.log(node.data)
                    const dataTem = [];
                    PartyCommittee({partyName:node.data.partyName,partyLevel:node.level + 1}).then(function (rsp) {
                        console.log('1.PartyCommittee',rsp)
                        let parties = rsp.data
                        if (rsp.success) {
                            for(let i = 0 ; i < parties.length; i++){
                                let tem = {}
                                tem.pid = parties[i].pid
                                tem.partyName = parties[i].partyName
                                tem.partyLevel = parties[i].partyLevel
                                if(null != parties[i].leaf && parties[i].leaf === 1){
                                    tem.leaf = true
                                }
                                dataTem.push(tem)
                                _self.dataTem = dataTem;
                            }
                            console.log(dataTem);

                            resolve(dataTem);
                        } else {
                            _self.$message.error(rsp.message);
                        }
                    });
                }
            },
            handleNodeClick(data,node) {
                console.log('handleNodeClick',node.level);
                console.log('handleNodeClick',data);
                this.totalRow = 1;
                this.memberGetListType = '1';
                this.pageSize = 10;
                this.dataTem.length = 1;
                this.defaultMemberList = '0';
                this.saveClickpid = data.pid;
                this.saveClickPartyName = data.partyName;
                this.saveClickPartyLevel = node.level;
                let _self = this;
                _self.memberList = [];
                _self.tablePartyName = data.partyName;
                if(data.pid > 8){
                    let _self = this;
                    getCommitteeInfo({partyName:data.partyName}).then(function (rsp) {
                        if (rsp.success) {
                            console.log('getCommitteeInfo',rsp);
                            _self.tableHeadData = rsp.data
                            }
                         else {
                            _self.$message.error(rsp.message);
                        }
                    })
                }
                    this.checkData = data;
                    this.pageSize = 10;
                    PartyMemberList({pid:data.pid,partyLevel:node.level,curPage:1,pageSize:10,partyName:data.partyName}).then(function (rsp) {
                        console.log('2.PartyMemberList',rsp)
                        if (rsp.success) {
                            _self.memberList = rsp.data.list;
                            _self.countAll = rsp.data.total;
                            _self.memberPartyName = rsp.data.list[0].partyName;
                            _self.totalRow =  _self.countAll;
                            _self.currentPage = 1;

                        } else {
                            _self.$message.error(rsp.message);
                        }
                    })
            },
            resetmember:function(){
                this.memberName = '';
                this.phoneNumber = '';
                this.memberGetListType = '1';
            },
            findMember:function(){
                let _self = this;
                this.memberGetListType = '2';
                if( this.memberName != '' || this.phoneNumber != ''){
                console.log(this.memberName,this.phoneNumber);
                let saveFindMemberPage = '';
                if(this.memberGetListType == '1') {
                    _self.currentPage = 1;
                    _self.totalRow = 2;
                    saveFindMemberPage = 1
                }else if(this.memberGetListType == '2'){
                    saveFindMemberPage = this.currentPage;
                    }
                    searchPartyUser({
                        userName: this.memberName,
                        mobile: this.phoneNumber,
                        curPage: saveFindMemberPage,
                        pageSize: _self.pageSize,
                    }).then(function (rsp) {
                        _self.loading = false;
                        if (rsp.success) {
                            console.log('3.searchPartyUser', rsp, '!!!!!!!!!!!!!');
                            _self.memberList = rsp.data.list;
                            _self.totalRow = rsp.data.total;
                            _self.currentPage = rsp.data.pageNo;
                            _self.pageSize = rsp.data.pageSize;
                            _self.countAll = rsp.data.total;
                        } else {
                            _self.$message.error(rsp.message);
                        }
                    })
            }
            },
            editMember:function(index){
                let _self = this;
                this.editable = '1';
                this.editMemberInfo = this.memberList[index];

                this.classBasics = this.dataTem;
                this.selectClassBasics = this.editMemberInfo.partyName;
                this.selectClassJob =  this.editMemberInfo.positions;
                if(this.editMemberInfo.admin == null){
                    this.editMemberInfo.admin = 0;
                }

                this.selectClassEpistasis = this.editMemberInfo.committeeName;

                console.log('selectClassEpistasis',this.selectClassEpistasis);
                PartyCommittee({partyName:this.selectClassEpistasis }).then(function (rsp) {
                    if (rsp.success) {
                        console.log(rsp);
                        _self.classBasics = rsp.data;

                    } else {
                        _self.$message.error(rsp.message);
                    }
                })
            },
            pushMemberInfo:function(){
                let _self = this;
                _self.editable = '0';
                let editMemberInfo = this.editMemberInfo;
                let classBasics = this.selectClassBasics;
                console.log(editMemberInfo.userName,editMemberInfo.mobile,editMemberInfo.unitName,classBasics,editMemberInfo.admin,_self.selectClassJob);
                editPartyMember({
                    userName:editMemberInfo.userName,
                    uid:editMemberInfo.uid,
                    admin:editMemberInfo.admin,
                    partyName:_self.selectClassBasics,
                    positions:_self.selectClassJob,
                    }).then(function (rsp) {
                    if (rsp.success) {
                        console.log('5.editPartyMember',rsp);    //added by xiaohan
                        if (_self.memberGetListType == '1'){
                            _self.loadData(_self.saveClickpid,_self.saveClickPartyName,_self.saveClickPartyLevel);
                        }
                        if(_self.memberGetListType == '2') {
                            _self.findMember()
                        }
                        _self.$message.success('修改成功！');


                    } else {
                        _self.$message.error(rsp.message);
                    }
                })

            },
            changeClassEpistasis:function(){
                let _self = this;
                console.log('selectClassEpistasis',this.selectClassEpistasis);
                PartyCommittee({partyName:this.selectClassEpistasis}).then(function (rsp) {
                    if (rsp.success) {
                        console.log(rsp);
                        _self.selectClassBasics = '';
                        _self.classBasics = [];
                        _self.classBasics = rsp.data;
                        console.log('changeClassBasics',_self.classBasics);
                    } else {
                        _self.$message.error(rsp.message);
                    }
                })
            },
            handleSizeChange: function (size) {
                this.pageSize = size;
                if(this.memberGetListType == '1'){
                    this.loadData()
                }else if(this.memberGetListType == '2'){
                    this.findMember()
                }

            },
            handleCurrentChange:function (currentPage) {
                this.currentPage = currentPage
                if(this.memberGetListType == '1'){
                    this.loadData()
                }else if(this.memberGetListType == '2'){
                    this.findMember()
                }
            },
            changeDate:function () {
                console.log(this.dateFlag)
                if(this.dateFlag){
                    this.dateFlag = false
                } else {
                    this.dateFlag = true
                }
                this.loadData()
            },
            loadData:function (x,y,z) {
                let _self = this
                _self.loading = true
                this.memberList = [];
                let savePid = '';
                let savePartyName = '';
                let savePartyLevel = '';
                console.log('this.checkData',this.checkData);
                if (this.defaultMemberList == '0') {
                    if(x != undefined || y != undefined || z !=undefined){
                        savePid = x;
                        savePartyName = y;
                        savePartyLevel = z;
                        console.log('111111111111111111',x,y,z);
                    } else {
                        savePid = this.checkData.pid;
                        savePartyName = this.checkData.partyName;
                        savePartyLevel = this.checkData.partyLevel;
                        console.log('22222222222222222',x,y,z);
                    }
                } else if (this.defaultMemberList == '1') {
                    savePid = 8;
                    savePartyName = '公司机关党委';
                    savePartyLevel = 1;
                }
                PartyMemberList({
                    pid: savePid,
                    partyLevel: savePartyLevel,
                    curPage: _self.currentPage,
                    pageSize: _self.pageSize,
                    partyName: savePartyName,
                }).then(function (rsp) {
                    console.log('PartyMemberList=',rsp)
                    _self.loading = false
                    if (rsp.success) {
                        _self.totalRow = rsp.data.total;
                        _self.memberList = rsp.data.list;
                        _self.currentPage = rsp.data.pageNo;
                        _self.pageSize = rsp.data.pageSize;
                        _self.countAll = rsp.data.total;
                    } else {
                        _self.$message.error(rsp.message);
                        if("登录失效" == rsp.message){
                            sessionStorage.removeItem("zhdj")
                            setTimeout(function () {
                                let uid = _self.$route.query.uid;
                                getUser({uid:uid}).then(function (rsp) {
                                    console.log(rsp)
                                    if (rsp.success) {
                                        sessionStorage.setItem("zhdj",1)
                                        _self.$message.success("登录成功");
                                    }
                                });
                            },500)
                        }
                    }
                })
            },
            initTree:function () {
                let _self = this;
                PartyCommittee({partyLevel:1}).then(function (rsp) {
                    if (rsp.success) {
                        let saveDefaultTreeData = []
                        for(let x = 0;x < rsp.data.length;x ++){
                            let y = {};
                            y.pid = rsp.data[x].pid;
                            y.partyName = rsp.data[x].partyName;
                            saveDefaultTreeData.push(y);
                        }
                        _self.trees = saveDefaultTreeData;
                        sessionStorage.setItem("party-tree",JSON.stringify(_self.trees))
                        clearInterval(_self.treeInterval)
                        _self.loadData();
                    } else {
                        _self.$message.error(rsp.message);
                        if("登录失效" == rsp.message){
                            sessionStorage.removeItem("zhdj")
                            setTimeout(function () {
                                let uid = _self.$route.query.uid;
                                getUser({uid:uid}).then(function (rsp) {
                                    console.log(rsp)
                                    if (rsp.success) {
                                        sessionStorage.setItem("zhdj",1)
                                        _self.$message.success("登录成功");
                                    }
                                });
                            },500)
                        }
                    }
                })
            }
        },
        mounted() {
            let _self = this;
            let tree = sessionStorage.getItem("party-tree")
            if(tree){ //为了更快的刷出树结构
                _self.trees = JSON.parse(tree);
                _self.loadData();
            } else {
                _self.treeInterval = setInterval(function () {
                    let zhdj = sessionStorage.getItem("zhdj")
                    if(zhdj){
                        _self.initTree()
                    }
                    _self.retryTimes++
                    if(_self.retryTimes > 5){
                        clearInterval(_self.treeInterval)
                        return
                    }
                },500)
            }
        }
    }

</script>
<style lang="less" scoped>
    .ClassSection{
        .tree-list{
            background-color:#f2f2f2;
            width:305px;
            min-height:768px;
            display:inline-block;
            .input-box{
                width:80%;
                margin:5px auto;
                padding-top:3%;
            }
        }
        .el-tree{
            background-color:#f2f2f2;
        }
        .tree-title{
            height:160px;
            background-color:#f2f2f2;
            display:flex;
        }
        .tree-title>div{
            flex:1;
        }
        .tree-title>div:nth-child(1){
            flex: 0 0 60%;
            h3{
                padding-left:20px;
                margin:20px 0 0 0;
                line-height:27px;
                height:27px;
            }
            p{
                padding-left:20px;
                margin:20px 0 0 0;
                font-size:15px;
            }
        }
        .tree-title>div:nth-child(2){
            flex: 0 0 40%;
            p{
                float:right;
                padding-right:20px;
                margin:20px 0 0 0;
                font-size:15px;
                line-height:27px;
            }
        }
        .el-main{
            padding:10px 20px 0 20px;
        }
        .tree-details{
            min-height:598px;
            background-color:#f2f2f2;
        }

        .search-member{
            display:flex;
            height:56px;
            width:100%;
        }
        .search-member>.search-left{
            padding-left:10px;
            padding-top:10px;
            flex:0 0 35%;
            height:56px;
            line-height:56px;
        }
        .search-member>.search-right{
            padding-right:10px;
            padding-top:10px;
            flex:0 0 65%;
            height:56px;
            line-height:56px;
            text-align:right;
            div{
                display:inline-block;
                height:56px;
                width:150px;
            }
        }
        .el-button--primary{
            margin-left:1%;
        }
        .member-list{
            width:100%;
            padding:10px 10px;
        }
        .list-page{
            margin-left:10px;
            margin-right:10px;
            height:56px;
        }
        .list-page>span{
            float:left;
            margin-top:10px;
            line-height:32px;
        }
        .list-page>div{
            float:right;
            margin-top:10px;
        }
        .edit-box{
            position:fixed;
            background:rgba(0,0,0,0.6);
            top:0;
            left:0;
            height:100%;
            width:100%;
            z-index:20;
        }
        .edit-content{
            display:block;
            margin:8% auto;
            min-height:640px;
            max-height:800px;
            min-width:768px;
            max-width:1024px;
            background-color:#ffffff;
        }
        .edit-head{
            height:54px;
            border-bottom:1px solid #ebebeb;
        }
        .edit-head>span{
            font-size:15px;
            line-height:54px;
            margin-left:15px;
            color:#929292;
        }
        .edit-head>span>b{
            color:black;
        }
        .edit-head>i{
            float:right;
            font-size: 24px;
            line-height:54px;
            margin-right:20px;
            cursor:pointer;
        }
        .edit-section{
            min-height:505px;
            max-height:665px;
            border-bottom:1px solid #ebebeb;
        }
        .edit-section>ul{
            padding:0;
        }
        .edit-section>ul>li{
            display:inline-block;
            font-style:normal;
            width:42%;
            height:54px;
            margin-left:5%;
            margin-top:3%;
            div,span{
                display:inline-block;
                height:54px;
                line-height:54px;
            }
            div{
                width:75%;
                float:right;
                text-align:right;
            }
            span{
                width:25%;
                text-align:center;
            }
        }
        .edit-footer{
            float:right;
            height:81px;
            width:20%;
            line-height:81px;
            .el-button{
                margin-left:5%;
            }
        }



    }
</style>
