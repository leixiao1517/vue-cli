<template>
    <section class="meeting-section">
        <div class="meeting-box" v-if="moreDetails == '0'">
            <div class="epistasis-box">
                <template v-if="trees.length > 1">
                    <span>所属党委：</span>
                    <el-button :class="{active: tabType === '1'}" @click="classChange('公司机关党委',8),tabType = '1'">公司机关党委</el-button>
                    <el-button :class="{active: tabType === '2'}" @click="classChange('长沙卷烟厂党委',1),tabType = '2'">长沙烟厂党委</el-button>
                    <el-button :class="{active: tabType === '3'}" @click="classChange('常德卷烟厂党委',7),tabType = '3'">常德烟厂党委</el-button>
                    <el-button :class="{active: tabType === '4'}" @click="classChange('零陵卷烟厂党委',6),tabType = '4'">零陵烟厂党委</el-button>
                    <el-button :class="{active: tabType === '5'}" @click="classChange('郴州卷烟厂党委',2),tabType = '5'">郴州烟厂党委</el-button>
                    <el-button :class="{active: tabType === '6'}" @click="classChange('四平卷烟厂党委',4),tabType = '6'">四平烟厂党委</el-button>
                    <el-button :class="{active: tabType === '7'}" @click="classChange('吴忠卷烟厂党委',5),tabType = '7'">吴忠烟厂党委</el-button>
                    <el-button :class="{active: tabType === '8'}" @click="classChange('金叶薄片党委',3),tabType = '8'">金叶薄片党委</el-button>
                </template>
                <template v-if="trees.length == 1">
                    <el-button class="active">{{trees[0].partyName}}</el-button>
                </template>
            </div>
            <div class="basics-box">

                <div>
                    <span>
                        所属支部&nbsp;：
                            <template>
                                  <el-select v-model="selectClassBasics" filterable placeholder="请选择">
                                        <el-option v-for="item in classBasics" :key="item.partyName" :label="item.label" :value="item.partyName"></el-option>
                                  </el-select>
                            </template>
                    </span>
                </div>
                <div>
                    <span>
                        会议类型&nbsp;：
                            <template>
                                  <el-select v-model="selectMeetingType" filterable placeholder="请选择">
                                        <el-option v-for="item in meetingType" :key="item.value" :label="item.label" :value="item.value"></el-option>
                                  </el-select>
                            </template>
                    </span>
                </div>
                <div>
                    <span>
                        会议状态&nbsp;：
                            <template>
                                  <el-select v-model="meetStatus" filterable placeholder="请选择">
                                        <el-option v-for="item in selectMeetStatus" :key="item.value" :label="item.label" :value="item.value"></el-option>
                                  </el-select>
                            </template>
                    </span>
                </div>
            </div>
            <div class="select-search">
                <div>
                    <span>会议开始时间：</span>
                    <el-date-picker width="270" v-model="meetStartTime" type="date" placeholder="选择日期" format="yyyy 年 MM 月 dd 日" value-format="timestamp"></el-date-picker>
                </div>
                <div>
                    <el-button type="primary" @click="searchMeet(meetStartTime,meetStatus,selectMeetingType,selectClassBasics)">搜索</el-button>
                    <el-button @click="resetMeeting()">重置</el-button>
                </div>
            </div>
            <div class="meeting-list">
                <template>
                    <el-table :data="meetingData" stripe style="width: 100%" v-loading="tableLoading">
                        <el-table-column prop="startDate" align="center" sortable :formatter="getTime" label="会议日期" min-width="90" style="margin-left:2px"></el-table-column>
                        <el-table-column prop="meetingType" align="center" label="会议类型" min-width="90"></el-table-column>
                        <el-table-column prop="title" align="center" label="会议标题" min-width="150"></el-table-column>
                        <!--<el-table-column prop="committeeName" align="center" label="党委" min-width="90"></el-table-column>-->
                        <el-table-column prop="partyName" align="center" label="所属支部" min-width="120"></el-table-column>
                        <el-table-column prop="createUserName" align="center" label="主持人" min-width="75"></el-table-column>
                        <el-table-column prop="summaryUserName" align="center" label="纪要人" min-width="75"></el-table-column>
                        <!--<el-table-column prop="allNum" align="center" label="参与人数" min-width="45"></el-table-column>-->
                        <el-table-column align="center" label="状态" min-width="45">
                            <template slot-scope="scope">
                                <span v-if="scope.row.process == '1'">待开始</span>
                                <span v-if="scope.row.process == '2'">进行中</span>
                                <span v-if="scope.row.process == '3'">已结束</span>
                            </template>
                        </el-table-column>

                        <el-table-column label="操作" width="200" align="center">
                            <template slot-scope="scope" >
                                <el-button type="text" size="small" @click="publishMeet(scope.$index,1,1,scope.row.readParties)" v-if = "scope.row.readStatus != null && scope.row.readStatus == '0'">发布</el-button>
                                <el-button type="text" size="small" @click="publishMeet(scope.$index,0,0,scope.row.readParties)" v-if = "scope.row.readStatus == '1'">撤回</el-button>
                                <span>|</span>
                                <el-button type="text" size="small" @click="meetInformation(scope.$index)">详情</el-button>
                                <!--<span>|</span>-->
                                <!--<el-button type="text" size="small" @click="editMeeting(scope.row.meetId)">编辑</el-button>-->
                                <span>|</span>
                                <el-button type="text" size="small" @click="authorityMeet(scope.$index)">权限</el-button>
                            </template>
                        </el-table-column>
                    </el-table>
                </template>
            </div>
            <div class="list-page">
                <div>
                    <el-pagination :current-page="currentPage" :page-sizes="[10, 20, 50, 100]" :page-size="pageSize"
                        layout="total, sizes, prev, pager, next, jumper" :total="totalRow" @current-change="handleCurrentChange"
                        @size-change="handleSizeChange">
                    </el-pagination>
                </div>
            </div>
        </div>

        <div class="authority-box" v-if = "authority == '1'">
            <div class="authority-content">
                <div class="authority-header">
                    <span>阅读权限设置</span>
                    <i class="el-icon-close" @click="authority = '0';filterText = ''"></i>
                </div>
                <div class="tree-list">
                    <div class="input-box">
                        <el-input placeholder="请选择党委之后，输入关键字查询" v-model="filterText"></el-input>
                    </div>
                    <el-tree class="filter-tree" :props="defaultProps" ref="meetingSectionTree" :data="trees" :load="loadNode1" :filter-node-method="filterNode" lazy show-checkbox></el-tree>
                </div>
                <div class="authority-footer">
                    <el-button type="primary" @click="saveMeetingAuthority">确认</el-button>
                    <el-button @click="authority = '0'">取消</el-button>
                </div>
            </div>
        </div>

        <div class="details-box" v-if="moreDetails == '1'">
            <div class="details-header">
                <span>会议详情</span>
                <i class="el-icon-close" @click="cleanAllFile"></i>
            </div>
            <ul>
                <li>
                    <span>会议标题：{{meetDetails.title}}</span>
                    <span>会议地点：{{meetDetails.address}}</span>
                    <b class="topics-box" >会议议题：<span v-html="meetDetails.topics"></span></b>
                    <span :formatter="getTime">开始时间：{{meetDetails.startDate|dateFormat()}}</span>
                    <span :formatter="getTime">截止时间：{{meetDetails.endDate|dateFormat()}}</span>
                </li>
                <li>
                    <span v-if = "meetDetails.meetingType == '1'">会议类型：支部党员大会</span>
                    <span v-if = "meetDetails.meetingType == '2'">会议类型：党支部委员会</span>
                    <span v-if = "meetDetails.meetingType == '3'">会议类型：党小组会</span>
                    <span v-if = "meetDetails.meetingType == '4'">会议类型：支部主题党日</span>
                    <span v-if = "meetDetails.meetingType == '5'">会议类型：组织生活</span>
                    <span v-if = "meetDetails.meetingType == '6'">会议类型：民主评议</span>
                    <span v-if = "meetDetails.meetingType == '7'">会议类型：评选表彰</span>
                    <span v-if = "meetDetails.meetingType == '8'">会议类型：书记述职</span>
                    <span v-if = "meetDetails.meetingType == '9'">会议类型：其他</span>
                    <!--<span v-if="meetDetails.process == '1'">未开始</span>-->
                    <!--<span v-if="meetDetails.process == '2'">进行中</span>-->
                    <!--<span v-if="meetDetails.process == '3'">已结束</span>-->
                    <span>所属党委：{{meetDetails.committeeName}}</span>
                    <span>所属支部：{{meetDetails.partyName}}</span>
                </li>
                <li>
                    <span>主持人：{{meetDetails.createUserName}}</span>
                    <span>记录人：{{meetDetails.summaryUserName}}</span>
                    <span style="width:100%">参加人员：<i v-for = "item in attendUser">&nbsp;{{item.userName}}&nbsp;</i></span>
                </li>
                <li>
                    <div>
                        <span>会议纪要：</span>
                        <img src="../../assets/image/fileIcon/upload.png" class="upload-file" @click="meetingSummary('1')" v-show="meetDetails.readStatus == 0 || meetDetails.readStatus == null">
                            <b style="color:#919191;font-weight:normal;" v-show="!summaryFile">请点击左侧图标,可直接关联“我的云盘”中的会议纪要文件</b>
                            <b class="check-one-file-list" v-show="summaryFile">
                                <img src="../../assets/image/fileIcon/pdf.png" v-if = "summaryFile.docType == 1">
                                <img src="../../assets/image/fileIcon/mp4.png" v-if = "summaryFile.docType == 2">
                                <img src="../../assets/image/fileIcon/jpg.png" v-if = "summaryFile.docType == 3">
                                <p>{{summaryFile.title}}</p>
                            </b>
                    </div>
                    <div>
                        <span>会议现场：</span>
                        <img src="../../assets/image/fileIcon/upload.png" class="upload-file" @click="callBackFlag = true;meetingSummary('3');" v-show="meetDetails.readStatus == 0 || meetDetails.readStatus == null">
                        <b style="color:#919191;font-weight:normal;" v-if="sceneFile.cover == ''">请点击左侧图标,可直接关联“我的云盘”中的会议现场文件</b>
                        <b class="check-one-file-list" else>
                            <img :src="sceneFile.cover" style="height:90px;width:135px">
                        </b>
                        <img src="../../assets/image/fileIcon/upload.png" class="upload-file" @click="uploadLocalFile"
                             v-show="meetDetails.readStatus == 0 || meetDetails.readStatus == null">本地上传
                    </div>
                    <div>
                        <span style="float:left">会议资源：</span>
                        <img src="../../assets/image/fileIcon/upload.png" style="float:left;margin:29px 10px 0 15px ;" class="upload-file" @click="meetingSummary('2')" v-show="meetDetails.readStatus == 0 || meetDetails.readStatus == null">
                        <b style="color:#919191;font-weight:normal;float:left;line-height:90px;" v-show="transFileList == ''">&nbsp;请点击左侧图标,可直接关联“我的云盘”中的资源文件</b>
                        <div v-show="transFileList != ''" >
                            <div class="check-more-file-box">
                                <b class="check-more-file-list" v-for="item in transFileList">
                                    <img src="../../assets/image/fileIcon/pdf.png" v-if = "item.docType == 1">
                                    <img src="../../assets/image/fileIcon/mp4.png" v-if = "item.docType == 2">
                                    <img src="../../assets/image/fileIcon/jpg.png" v-if = "item.docType == 3">
                                    <span style="line-height:42px">{{item.title}}</span>
                                </b>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <span>考勤记录：<b style="cursor:pointer;" @click="checkAttendance = '1'">查看考勤记录</b></span>
                </li>
            </ul>
            <div class="alert-box" v-if="checkAttendance == '1' || isShowFileDialog == '1'">

                <div class="attendance-box" v-if="checkAttendance == '1'">
                    <div class="attendance-header">
                        <h3>考勤记录</h3>
                        <i class="el-icon-close" @click="checkAttendance = '0'"></i>
                    </div>
                    <div class="atendance-totail">
                        <b>应参加：{{attendMeetingTotal.allNum}}人</b>
                        <b>实际参加：{{attendMeetingTotal.realNum}}人</b>
                        <b>参与率：{{joinPercentage}}%</b>
                    </div>
                    <div class="atendance-totail atendance-details">
                        <b>签到：{{attendMeetingTotal.signIn}}人</b>
                        <b>抽查：{{attendMeetingTotal.checkNum}}人</b>
                        <b>签退：{{attendMeetingTotal.signOut}}人</b>
                        <b>请假：{{attendMeetingTotal.vacNum}}人</b>
                        <b>缺席：{{attendMeetingTotal.absNum}}人</b>
                        <b>补考：{{attendMeetingTotal.exam}}人</b>
                    </div>
                    <div class="atendance-list">
                        <div class="atendance-header" style="border-bottom:1px solid #ebebeb;">
                            <span>姓名</span>
                            <span>签到</span>
                            <span>抽查</span>
                            <span>签退</span>
                            <span>请假</span>
                            <span>缺席</span>
                        </div>
                        <div class="atendance-section-box">
                            <div class="atendance-section" style="height:45px;line-height:45px" v-for = "item in attendUser">
                                <span>{{item.userName}}</span>
                                <span ><img v-if="item.signIn == 1" src="../../assets/image/fileIcon/true.png"></span>
                                <span ><img v-if="item.checkStatus == 1" src="../../assets/image/fileIcon/true.png"></span>
                                <span ><img v-if="item.signOut == 1" src="../../assets/image/fileIcon/true.png"></span>
                                <span ><img v-if="item.leaveStatus == 1" src="../../assets/image/fileIcon/true.png"></span>
                                <span ><img v-if="item.absent == 0 && item.leaveStatus != 1 && item.signIn != 1 && item.checkStatus != 1 && item.signOut != 1" src="../../assets/image/fileIcon/true.png"></span>
                            </div>
                        </div>
                    </div>
                    <div class="atendance-footer">
                        <el-button type="primary" @click="checkAttendance = 0">确认</el-button>
                        <el-button @click="checkAttendance = 0">取消</el-button>
                    </div>
                </div>

                <div class="file-box" v-if="isShowFileDialog == '1'">
                    <div class="file-header">
                        <span id="change-file-doc" :class="{fileActive: fileType == '1'}" @click="changeFileType(1)" v-if="meetingSummaryType != '3'">文档</span>
                        <span id="change-file-image" :class="{fileActive: fileType == '3'}" @click="changeFileType(3)">图片</span>
                        <span id="change-file-mp4" :class="{fileActive: fileType == '2'}" @click="changeFileType(2)" v-if="meetingSummaryType != '3'">视频</span>
                        <i class="el-icon-close" @click="isShowFileDialog = '0'"></i>
                    </div>
                    <!--<div class="file-title">-->
                        <!--<span>我的云&nbsp;文件</span>-->
                    <!--</div>-->

                    <div class="file-list" v-show="fileType == '1'">
                        <el-table  ref="multipleTable1" :row-key="getRowKeys" :data="resourceDoc.list" tooltip-effect="dark" style="width: 100%" @selection-change="handleSelectionChange" >
                            <el-table-column type="selection" width="55" :reserve-selection="true" v-if="selectFileList == '2'" ></el-table-column>
                            <el-table-column property="vid" width="60" v-if="selectFileList == '2'"></el-table-column>
                            <el-table-column label="文件名" width="560" align="center">
                                <template slot-scope="scope">
                                    <div style="float:left">
                                        <template>
                                            <el-radio v-model="addArticle" :label='scope.row.vid' @change="checkFile(scope.$index)" v-if="selectFileList == '1'"></el-radio>
                                        </template>
                                    </div>
                                    <div class="icon-box">
                                        <img v-if="scope.row.zyType.indexOf('ppt') >= 0" src="../../assets/image/fileIcon/ppt.png">
                                        <img v-else-if="scope.row.zyType.indexOf('doc') >= 0" src="../../assets/image/fileIcon/word.png">
                                        <img v-else-if="scope.row.zyType.indexOf('pdf') >= 0" src="../../assets/image/fileIcon/pdf.png">
                                        <img v-else-if="scope.row.zyType.indexOf('xls') >= 0" src="../../assets/image/fileIcon/excel.png">
                                        <template v-else><img src="../../assets/image/fileIcon/pdf.png"></template>
                                        <span class="icon-title-box">{{scope.row.title}}</span>
                                    </div>
                                </template>
                            </el-table-column>
                            <el-table-column prop="modifyDate" label="日期" show-overflow-tooltip :formatter="getTime" align="center"></el-table-column>
                        </el-table>
                    </div>

                    <div class="file-list" v-show="fileType == '2'">
                        <el-table ref="multipleTable2" :row-key="getRowKeys" :data="resourceVideo.list" tooltip-effect="dark" style="width: 100%" @selection-change="handleSelectionChange">
                            <el-table-column type="selection" width="55" :reserve-selection="true" v-if="selectFileList == '2'"></el-table-column>
                            <el-table-column property="vid" width="60" v-if="selectFileList == '2'"></el-table-column>
                            <el-table-column label="文件名" width="560" align="center">
                                <template slot-scope="scope">
                                    <div style="float:left">
                                        <template>
                                            <el-radio v-model="addVideo" :label='scope.row.vid' @change="checkFile(scope.$index)" v-if="selectFileList == '1'"></el-radio>
                                        </template>
                                    </div>
                                    <div class="icon-box">
                                        <img src="../../assets/image/fileIcon/mp4.png">
                                        <!--<img src="../../assets/image/fileIcon/avi.png"  v-if = "resourceVideo.list[scope.$index].zyType == 'avi'">-->
                                        <span class="icon-title-box">{{scope.row.title}}</span>
                                    </div>
                                </template>
                            </el-table-column>
                            <el-table-column prop="modifyDate" label="日期" show-overflow-tooltip :formatter="getTime" align="center"></el-table-column>
                        </el-table>
                    </div>

                    <div class="file-list" v-show="fileType == '3'">
                        <el-table ref="multipleTable3" :row-key="getRowKeys" :data="resourceImage.list" tooltip-effect="dark" style="width: 100%" @selection-change="handleSelectionChange">
                            <el-table-column type="selection" :reserve-selection="true" width="55" v-if="selectFileList == '2'"></el-table-column>
                            <el-table-column property="vid" width="60" v-if="selectFileList == '2'"></el-table-column>
                            <el-table-column label="文件名" width="560" align="center">
                                <template slot-scope="scope">
                                    <div style="float:left">
                                        <template>
                                            <el-radio v-model="addImage" :label='scope.row.vid' @change="checkFile(scope.$index)" v-if="selectFileList == '1'"></el-radio>
                                        </template>
                                    </div>
                                    <div class="icon-box">
                                        <img src="../../assets/image/fileIcon/jpg.png">
                                        <!--<img src="../../assets/image/fileIcon/gif.png" v-if = "resourceImage.list[scope.$index].zyType == 'gif'">-->
                                        <span class="icon-title-box">{{scope.row.title}}</span>
                                    </div>
                                </template>
                            </el-table-column>
                            <el-table-column prop="modifyDate" label="日期" show-overflow-tooltip :formatter="getTime" align="center"></el-table-column>
                        </el-table>
                    </div>

                    <div class="file-page" v-show="fileType == '1'">
                        <span>总共&nbsp;{{resourceDoc.total}}&nbsp;条记录</span>
                        <div>
                            <el-pagination
                                background
                                layout="prev, pager, next"
                                :total="resourceDocTotalRow"
                                :current-page="resourceDocCurrentPage"
                                @current-change="resourceDocPageChange">
                            </el-pagination>
                        </div>
                    </div>

                    <div class="file-page" v-show="fileType == '2'">
                        <span>总共&nbsp;{{resourceVideo.total}}&nbsp;条记录</span>
                        <div>
                            <el-pagination
                                background
                                layout="prev, pager, next"
                                :total="resourceVideoTotalRow"
                                :current-page="resourceVideoCurrentPage"
                                @current-change="resourceVideoPageChange">
                            </el-pagination>
                        </div>
                    </div>

                    <div class="file-page" v-show="fileType == '3'">
                        <span>总共&nbsp;{{resourceImage.total}}&nbsp;条记录</span>
                        <div>
                            <el-pagination
                                background
                                layout="prev, pager, next"
                                :total="resourceImageTotalRow"
                                :current-page="resourceImageCurrentPage"
                                @current-change="resourceImagePageChange">
                            </el-pagination>
                        </div>
                    </div>

                    <div class="check-relation-file">
                        <b>选择的文件：</b>
                        <div class="check-file-box" v-if="selectFileList == '1' && meetingSummaryType != '3'">
                            <img src="../../assets/image/fileIcon/pdf.png" v-if = "oneCheckFile.docType == '1'">
                            <img src="../../assets/image/fileIcon/mp4.png" v-if = "oneCheckFile.docType == '2'">
                            <img src="../../assets/image/fileIcon/jpg.png" v-if = "oneCheckFile.docType == '3'">
                            <p>{{oneCheckFile.title}}</p>
                            <!--<i class="el-icon-circle-close-outline" v-if = "oneCheckFile.title != null" @click="cleanCheckFile(1)"></i>-->
                        </div>
                        <div class="check-file-box" v-if="selectFileList == '1' && meetingSummaryType == '3' && imgCheckFile.cover!=''">
                            <img :src="imgCheckFile.cover">
                            <!--<i class="el-icon-circle-close-outline" v-if = "imgCheckFile.cover != ''" @click="cleanCheckFile(3)"></i>-->
                        </div>
                        <div class="more-file-list-box" v-if="selectFileList == '2'">
                            <div class="more-file-box" v-for="(item,index) in moreTextFile">
                                <img src="../../assets/image/fileIcon/pdf.png" v-if = "item.docType == '1'">
                                <img src="../../assets/image/fileIcon/mp4.png" v-if = "item.docType == '2'">
                                <img src="../../assets/image/fileIcon/jpg.png" v-if = "item.docType == '3'">
                                <p>{{item.title}}</p>
                            </div>
                            <div class="more-file-box" v-for="(item,index) in moreVideoFile">
                                <img src="../../assets/image/fileIcon/mp4.png">
                                <p>{{item.title}}</p>
                            </div>
                            <div class="more-file-box" v-for="(item,index) in moreImageFile">
                                <img src="../../assets/image/fileIcon/jpg.png">
                                <p>{{item.title}}</p>
                            </div>
                        </div>
                        <i class="el-icon-circle-close-outline delete-more-file-icon" @click="cleanCheckFile(2)" v-if="selectFileList == '2' && (moreTextFile != '' || moreVideoFile != '' || moreImageFile != '')"></i>
                    </div>
                    <div class="atendance-footer">
                        <el-button type="primary" @click="saveCheckFile">确认</el-button>
                        <el-button @click="closeWindowFile">取消</el-button>
                    </div>
                </div>
            </div>
        </div>
        <!-- 选择文件弹框区 -->
        <el-dialog title="选择文件" :visible.sync="uploadShow" v-loading="loadingShow">
            <iframe name='upload' :src="'https://yun.vangv.com/index.php/resource/index?createtime='+ uploadParam.createtime +'&nostr=' + uploadParam.nostr
                    + '&owner=' + uploadParam.owner + '&user=' + uploadParam.user + '&sign=' + uploadParam.sign"
                    frameborder='0' height='300' scrolling='auto' width="100%"></iframe>
            <div slot="footer" class="dialog-footer">
                <el-button @click="cancelLocalSelect()">取 消</el-button>
                <el-button type="primary" @click="saveCover">确 定</el-button>
            </div>
        </el-dialog>

        <!-- 修改会议弹窗 -->
        <edit-meeting ref="editMeeting" @fetchData="getInitData"></edit-meeting>
    </section>
</template>

<script>
    import $ from 'jquery'
    import { readPartiesSet,getMeetingList,getMeetingDetail,publishMeeting,searchMeeting,getResourceList,
        PartyCommittee,generateUploadSign,selectMeetingResource,getUser } from '../../api/api.js'
    import { Radio, Group } from 'vux'
    import eventbus from '../../plugins/EventBus.js'
    import {isEmpty} from '../../plugins/utils.js'
    import EditMeeting from "./EditMeeting";
    export default {
        watch: {
            filterText(val) {
                this.$refs.meetingSectionTree.filter(val);
            }
        },
        components: {
            EditMeeting,
            Radio,
            Group,
        },
        data() {
            return {
                tableLoading:false,
                trees:[],
                filterText: '',
                defaultProps: {
                    label: 'partyName',
                    children: 'zones',
                    isLeaf: 'leaf',
                    level:'partyLevel',
                },
                resourceImageCurrentPage:1,
                resourceImageTotalRow:1,
                resourceDocCurrentPage:1,
                resourceDocTotalRow:1,
                resourceVideoCurrentPage:1,
                resourceVideoTotalRow:1,
                meetingData:[],
                tabType:'1',
                moreDetails: '0',
                checkAttendance: '0',
                selectFileList:'',
                isShowFileDialog: '0',
                fileType: '1',                 //关联会议文件类型 1 = 文档 , 2 = 视频 , 3 = 图片
                currentPage: 1,
                pageSize: 10,
                totalRow:2,
                dateFlag: false,
                loading: true,
                readStatus:'',
                meetDetails: {},
                meetState: {},
                meetStatus:'',
                index: '',
                attendUser: '',
                meetStartTime: '',
                meetTime: '',
                joinPercentage: '',
                selectClassBasics: '',
                oneCheckFile:{},
                authority:'0',
                classBasics: [{
                    partyName: '',
                    pid: '',
                }],
                addArticle:'',
                addImage:'',
                addVideo:'',
                meetingType: [{
                    value: '支部党员大会',
                    label: '支部党员大会'
                }, {
                    value: '党支部委员会',
                    label: '党支部委员会'
                }, {
                    value: '党小组会',
                    label: '党小组会'
                }, {
                    value: '支部主题党日',
                    label: '支部主题党日'
                }, {
                    value: '组织生活',
                    label: '组织生活'
                }, {
                    value: '民主评议',
                    label: '民主评议'
                }, {
                    value: '评选表彰',
                    label: '评选表彰'
                }, {
                    value: '书记述职',
                    label: '书记述职'
                }, {
                    value: '其他',
                    label: '其他'
                }],
                selectMeetingType: '',
                selectMeetStatus: [{
                    value: '1',
                    label: '待开始'
                }, {
                    value: '2',
                    label: '进行中'
                }, {
                    value: '3',
                    label: '已结束'
                }],
                resourceDoc:[],
                resourceImage:[],
                resourceVideo:[],
                checkFileList:[],
                multipleSelection: [],
                moreTextFile:[],
                moreVideoFile:[],
                moreImageFile:[],
                docType:1,                      //接口参数文档类型  1 = 文档 , 2 = 视频 , 3 = 图片
                meetingDataType:'',
                saveCheckList:[],
                authorityIndex:'',
                transFileList:'',
                onlyShowImgList:'0',
                meetingSummaryType:  '',     // 1:会议纪要   2:资源文件  3:会议现场
                imgCheckFile:{},
                uploadShow:false,//本地上传页面
                uploadParam:{},//本地上传签名等参数
                loadingShow:false,//本地上传loading
                callBackFlag:false, //本地上传回调标记
                clickSaveFlag:false, //本地上传点击了确定按钮
                summaryFile:{},//已经选择的会议纪要文件
                sceneFile:{},//已选择的会议现场文件
                localFile:{},//本地上传文件对象：必须点击确定 才能反写文件到详情页，所以要有个中间变量
                meetingInterval:{},//定时器捞数据
                retryTimes:1,
            }
        },
        methods: {
            editMeeting:function (meetId) {
                this.$refs.editMeeting.show(meetId);
            },
            getRowKeys(row) {
                return row.vid;
            },
            closeWindowFile(){
                this.isShowFileDialog = '0';

                this.imgCheckFile.cover = this.sceneFile.cover;
                this.imgCheckFile.coverId = this.sceneFile.coverId;
                this.imgCheckFile.videoImg = this.sceneFile.videoImg;
            },
            authorityMeet(index){
                this.authority = '1';
                this.authorityIndex = index
            },
            saveMeetingAuthority(){
                let _self = this
                _self.authority = '0'
                let parts = ''
                let partyArr = this.$refs.meetingSectionTree.getCheckedNodes()
                for(let i = 0 ; i < partyArr.length; i++){
                    if(partyArr[i].leaf == true) {
                        if(parts != ''){
                            parts += ','
                        }
                        parts += partyArr[i].partyName
                    }
                }
                let autIndex = _self.meetingData[_self.authorityIndex].meetId;
                readPartiesSet({
                    readParties: parts,
                    meetId:autIndex,
                }).then(function (rsp) {
                    console.log('readPartiesSet=', rsp);
                    _self.loading = false;
                    if (rsp.success) {
                        _self.meetingData[_self.authorityIndex].readParties = parts
                        _self.$message.success('权限设置修改成功');
                    } else {
                        _self.$message.error(rsp.message);
                    }
                });
            },
            filterNode(value, data) {
                if (!value) return true;
                return data.label.indexOf(value) !== -1;
            },
            loadNode1(node, resolve) {
                let _self = this
                if (node.level === 0) {
                    resolve(this.trees);
                }
                if (node.level >= 1) {
                    const dataTem = [];
                    PartyCommittee({partyName:node.data.partyName,partyLevel:node.level + 1}).then(function (rsp) {
                        console.log('1.PartyCommittee',rsp)
                        console.log('node',node);
                        let parties = rsp.data
                        if (rsp.success) {
                            for(let i = 0 ; i < parties.length; i++){
                                let tem = {}
                                tem.pid = parties[i].pid
                                tem.partyName = parties[i].partyName
                                tem.partyLevel = parties[i].partyLevel
                                if(null != parties[i].leaf && parties[i].leaf === 1){
                                    tem.leaf = true
                                }
                                dataTem.push(tem)
                                _self.dataTem = dataTem;
                            }
                            console.log(dataTem);

                            resolve(dataTem);
                        } else {
                            _self.$message.error(rsp.message);
                        }
                    });
                }
            },
            filterNode(value, data) {
                if (!value) return true;
                return data.partyName.indexOf(value) !== -1;
            },
            getTime: function (row, column, cellValue, index) {
                return this.zjyDateFormat(cellValue)
            },
            handleSizeChange: function (size) {
                this.pageSize = size;
                console.log('!!!!!!!!!!!!!!!',size)
                    this.loadData()
            },
            handleCurrentChange: function (currentPage) {
                this.currentPage = currentPage;
                console.log('~~~~~~~~~~~~~~~',currentPage);
                    this.loadData()
            },
            changeDate: function () {
                console.log(this.dateFlag)
                if (this.dateFlag) {
                    this.dateFlag = false
                } else {
                    this.dateFlag = true
                }
                this.loadData()
            },
            loadData: function (x) {
                let _self = this
                if(this.tabType == '1'){
                    this.meetingDataType = '公司机关党委';
                }if(this.tabType == '2'){
                    this.meetingDataType = '长沙烟厂党委';
                }if(this.tabType == '3'){
                    this.meetingDataType = '常德烟厂党委';
                }if(this.tabType == '4'){
                    this.meetingDataType = '零陵烟厂党委';
                }if(this.tabType == '5'){
                    this.meetingDataType = '郴州烟厂党委';
                }if(this.tabType == '6'){
                    this.meetingDataType = '四平烟厂党委';
                }if(this.tabType == '7'){
                    this.meetingDataType = '吴中烟厂党委';
                }if(this.tabType == '8'){
                    this.meetingDataType = '金叶薄片党委';
                }
                let changeMeetStartTime = this.meetStartTime.toString()
                if(x == '1'){
                    getMeetingList({
                        curPage: 1,
                        pageSize: _self.pageSize,
                        pageNo: _self.pageNo,
                        partyName:this.meetingDataType,
                        branchName:this.selectClassBasics,
                        meetingType: this.selectMeetingType,
                        process: this.meetStatus,
                        startDate: changeMeetStartTime,
                    }).then(function (rsp) {
                        console.log('1.getMeetingList', rsp)
                        _self.loading = false
                        if (rsp.success) {
                            _self.totalRow = rsp.data.total;
                            _self.meetingData = rsp.data.list;
                            _self.currentPage = 1;
                            _self.pageSize = rsp.data.pageSize;
                            clearInterval(_self.meetingInterval)
                        } else {
                            _self.$message.error(rsp.message);
                        }
                    });
                }else{
                    getMeetingList({
                        curPage: _self.currentPage,
                        pageSize: _self.pageSize,
                        pageNo: _self.pageNo,
                        partyName: this.meetingDataType,
                        branchName:this.selectClassBasics,
                        meetingType: this.selectMeetingType,
                        process: this.meetStatus,
                        startDate: changeMeetStartTime,
                    }).then(function (rsp) {
                        console.log('1.getMeetingList', rsp)
                        _self.loading = false
                        if (rsp.success) {
                            _self.totalRow = rsp.data.total;
                            _self.meetingData = rsp.data.list;
                            _self.currentPage = rsp.data.pageNo;
                            _self.pageSize = rsp.data.pageSize;
                            clearInterval(_self.meetingInterval)
                        } else {
                            _self.$message.error(rsp.message);
                        }
                    });
                }
            },
            meetInformation: function (index) {
                let _self = this;
                this.moreDetails = "1";
                let meetState = this.meetingData[index];
                getMeetingDetail({meetId: meetState.meetId}).then(function (rsp) {
                    _self.loading = false;
                    if (rsp.success) {
                        console.log('2.getMeetingDetail', rsp);
                        _self.meetDetails = rsp.data.meetingDetails;
                        _self.attendUser = rsp.data.allMeetingUser;
                        _self.attendMeetingTotal = rsp.data.attendMeeting;
                        _self.transFileList = rsp.data.attachmentTitle;
                        _self.moreTextFile = rsp.data.attachmentTitle;
                        if(rsp.data.summaryTitle.length > 0){
                            _self.summaryFile = rsp.data.summaryTitle[0];
                        }
                        _self.sceneFile.cover =  _self.meetDetails.cover;
                        _self.sceneFile.coverId =  _self.meetDetails.coverId;
                        _self.sceneFile.videoImg =  _self.meetDetails.videoImg;
                        if (_self.summaryFile){
                            _self.oneCheckFile = _self.summaryFile;
                        }
                        if (_self.sceneFile.cover != ''){
                            let imgCheckFile = {};
                            imgCheckFile.cover = _self.sceneFile.cover;
                            imgCheckFile.coverId = _self.sceneFile.coverId;
                            imgCheckFile.videoImg = _self.sceneFile.videoImg;
                            _self.imgCheckFile = imgCheckFile;
                        }
                        let joinPercentage = Math.round(_self.attendMeetingTotal.realNum / _self.attendMeetingTotal.allNum * 10000) / 100.00;
                        if(joinPercentage == NaN){
                            _self.joinPercentage = 0;
                        }else if (joinPercentage != NaN){
                            _self.joinPercentage = joinPercentage;
                        }
//                        console.log('~~~~~~~~~~~~~~~~~~!!!!!!!!!',typeof _self.attendUser[0].leaveStatus);
                    } else {
                        _self.$message.error(rsp.message);
                    }
                });
            },
            searchMeet: function () {
                console.log('selectClassBasics:',this.selectClassBasics,'branchName:',this.selectMeetingType,'process:',this.meetStatus,'startDate:',this.meetStartTime)
                let _self = this;
                _self.meetingData = [],
                this.loadData('1');
            },
            publishMeet: function (index,readStatus,pushStatus,readParties) {
                let _self = this;
                _self.tableLoading = true
                let meetState = _self.meetingData[index];
                console.log('partyName', meetState.partyName, 'meetId', meetState.meetId);
                setTimeout(function () {
                    _self.tableLoading = false
                },500)
                publishMeeting({
                    meetId: meetState.meetId,
                    readStatus:readStatus,
                    pushStatus:pushStatus,
                    readParties: readParties
                }).then(function (rsp) {
                    console.log('publishMeet=', rsp);
                    if(readStatus == 1){
                        _self.$message.success('发布成功');
                    }else if(readStatus == 0){
                        _self.$message.success('撤回成功');
                    }
                    _self.loading = false;
                    if (rsp.success) {
                        _self.meetingData[index].readStatus = readStatus;
                    } else {
                        _self.$message.error(rsp.message);
                    }
                });
            },
            meetingSummary: function (x) {
                this.meetingSummaryType = x;
                this.isShowFileDialog = '1';
                console.log('!!!!!!!!!!!!!',x);
                if (x != '3'){
                    this.selectFileList = x;
                    this.resourceDocPageList();
                    this.resourceVideoPageList();
                    this.resourceImagePageList();
                    this.fileType = '1';
                }else if(x == '3'){
                    console.log('1111111111111111');
                    this.resourceImagePageList();
                    this.selectFileList = '1';
                    this.onlyShowImgList = '1';
                    this.fileType = '3';
                    this.addImage = '';
                }
//                getResourceList({docType:1,curPage:1,pageSize:10}).then(function (rsp) {
//                    _self.loading = false;
//                    if (rsp.success) {
//                        _self.resourceDoc = rsp.data;
//                        console.log('resourceDoc',_self.resourceDoc)
//                    } else {
//                        _self.$message.error(rsp.message);
//                    }
//                });

//---------------------接口插入一条字段 整合为数组的方法
//                        let checkFileList = [];
//                        for(let x = 0;x < _self.ResourceDoc.list.length;x++){
//                            _self.ResourceDoc.list[x]["addedFile"] = false;
//                            checkFileList.push(_self.ResourceDoc.list[x]);
//                        }
//                        console.log(checkFileList);
//                        _self.checkFileList = checkFileList;
//                        console.log( _self.checkFileList);
//----------------------

            },
            changeFileType: function (x) {
                this.fileType = x;

            },
            classChange: function (partyName) {
                let _self = this;
                this.selectClassBasics = '';
                this.selectMeetingType = '';
                this.meetStatus = '';
                this.meetStartTime = '';

                if(this.trees.length > 1){
                    PartyCommittee({partyName:partyName}).then(function (rsp) {
                        if (rsp.success) {
                            console.log('partyCommittee',rsp);
                            _self.classBasics = rsp.data;
                        }
                        else {
                            _self.$message.error(rsp.message);
                        }
                    })
                }else if(this.trees.length == 1){
                    PartyCommittee({partyName:_self.trees[0].partyName}).then(function (rsp) {
                        if (rsp.success) {
                            console.log('partyCommittee',rsp);
                            _self.classBasics = rsp.data;
                        }
                        else {
                            _self.$message.error(rsp.message);
                        }
                    })
                }
                getMeetingList({partyName: partyName, curPage: 1, pageSize: 10, pageNo:1,startDate:''}).then(function (rsp) {
                    console.log('1.getMeetingList', rsp)
                    _self.loading = false
                    if (rsp.success) {
                        _self.totalRow = rsp.data.total;
                        _self.meetingData = rsp.data.list;
                        _self.currentPage = 1;
                        _self.pageSize = rsp.data.pageSize;
                    } else {
                        _self.$message.error(rsp.message);
                    }
                })
            },
            resetMeeting: function () {
                this.selectClassBasics = '';
                this.selectMeetingType = '';
                this.meetStatus = '';
                this.meetStartTime = '';
                this.loadData();
            },
            checkFile:function(x){
                console.log('change',this.imgCheckFile.cover,this.imgCheckFile.coverId)
                let _self = this;
                if(this.fileType == '1'){
                    let oneCheckFile = this.resourceDoc.list[x];
                    this.oneCheckFile = oneCheckFile;
                }
                if(this.fileType == '2'){

                    let oneCheckFile = this.resourceVideo.list[x];
                    this.oneCheckFile = oneCheckFile;

                }
                if(this.fileType == '3'){
                    if(_self.meetingSummaryType != '3'){
                        let oneCheckFile = this.resourceImage.list[x];
                        this.oneCheckFile = oneCheckFile;
                    }else if(_self.meetingSummaryType == '3'){
                        this.imgCheckFile.cover = this.resourceImage.list[x].url;
                        this.imgCheckFile.coverId = this.resourceImage.list[x].vid;
                        console.log('changed',this.imgCheckFile.cover,this.imgCheckFile.coverId)
                    }
                }
                if(this.selectFileList == '1' && this.fileType =='1') {
                    this.addImage = '';
                    this.addVideo = '';
                }else if(this.selectFileList == '1' && this.fileType =='2'){
                    this.addImage = '';
                    this.addArticle = '';
                }else if(this.selectFileList == '1' && this.fileType =='3'){
                    this.addVideo = '';
                    this.addArticle = '';
                }

            },
            resourceDocPageList:function(){
                let _self = this;
                getResourceList({privateTag:2,docType:1,curPage: _self.resourceDocCurrentPage,pageSize:10}).then(function (rsp) {

                    if (rsp.success) {
                        _self.resourceDoc = rsp.data;
                        _self.resourceDocTotalRow = rsp.data.total;
                        _self.resourceDocCurrentPage = rsp.data.pageNo;
                        console.log('resourceDoc',_self.resourceDoc)
                    } else {
                        _self.$message.error(rsp.message);
                    }
                });
            },
            resourceVideoPageList:function(){
                let _self = this;
                getResourceList({privateTag:2,docType:2,curPage: _self.resourceVideoCurrentPage,pageSize:10,readStatus:0}).then(function (rsp) {
                        if (rsp.success) {
                            _self.resourceVideo = rsp.data;
                            _self.resourceVideoTotalRow = rsp.data.total;
                            _self.resourceVideoCurrentPage = rsp.data.pageNo;
                            console.log('resourceVideo',_self.resourceVideo)
                        } else {
                            _self.$message.error(rsp.message);
                        }
                    });
            },
            resourceImagePageList:function(){
                let _self = this;
                getResourceList({privateTag:2,docType:3,curPage: _self.resourceImageCurrentPage,pageSize:10,readStatus:0}).then(function (rsp) {
                        if (rsp.success) {
                            _self.resourceImage = rsp.data;
                            _self.resourceImageTotalRow = rsp.data.total;
                            _self.resourceImageCurrentPage = rsp.data.pageNo;
                            console.log('resourceImage',_self.resourceImage)
                        } else {
                            _self.$message.error(rsp.message);
                        }
                    });
            },
            resourceImagePageChange:function(resourceImageCurrentPage){
                this.resourceImageCurrentPage = resourceImageCurrentPage;
                this.resourceImagePageList()
            },
            resourceVideoPageChange:function(resourceVideoCurrentPage){
                this.resourceVideoCurrentPage = resourceVideoCurrentPage;
                this.resourceVideoPageList()
            },
            resourceDocPageChange:function(resourceDocCurrentPage){
                this.resourceDocCurrentPage = resourceDocCurrentPage;
                this.resourceDocPageList()
            },
            cleanCheckFile:function(x){
                if(x == 1){//纪要
                    this.addImage = '';
                    this.addVideo = '';
                    this.addArticle = '';
                    this.oneCheckFile = '';
                }
                if(x == 2){//资源
                    this.moreTextFile = '';
                    this.moreVideoFile = '';
                    this.moreImageFile = '';
                }
                if(x == 3){//现场
                    this.imgCheckFile = '';
                }

            },
            handleSelectionChange(val) {
                console.log("handleSelectionChange val:",val);
                let len = this.moreTextFile.length + this.moreVideoFile.length + this.moreImageFile.length

                let docType = this.fileType
                console.log('doctype',docType)
                    if(len >= 11){
                        this.$notify({
                            title: '提示',
                            message: '最多一次关联10个文件',
                            type: 'warning'
                        });
                    }

                    if(true){
                        if(docType == 1){
                            this.moreTextFile = val
                        }else if(docType == 2){
                            this.moreVideoFile = val
                        }else if(docType == 3){
                            this.moreImageFile = val
                        }
                        this.multipleSelection = val;
                    }

                    len = this.moreTextFile.length + this.moreVideoFile.length + this.moreImageFile.length
                    if(len>10){
                        if(docType==1){
                            this.$refs.multipleTable1.toggleRowSelection(val[val.length-1]);
                        }else if(docType==2){
                            this.$refs.multipleTable2.toggleRowSelection(val[val.length-1]);
                        }else if(docType==3){
                            this.$refs.multipleTable3.toggleRowSelection(val[val.length-1]);
                        }
                    }
            },
            saveCheckFile(){
                let _self = this;
                this.isShowFileDialog = '0';
                let saveCheckList = [];
                saveCheckList = saveCheckList.concat(this.moreTextFile,this.moreVideoFile,this.moreImageFile);
                this.saveCheckList = saveCheckList;
                let saveVidList = [];
                console.log('++++++++=saveCheckList',this.saveCheckList);
                for(let x = 0; x < this.saveCheckList.length;x ++){
                    let y = {};
                    y.vid = saveCheckList[x].vid;
//                    y.url = saveCheckList[x].vid;
//                    y.vid = saveCheckList[x].vid;
//                    y.vid = saveCheckList[x].vid;
                    saveVidList.push(y);
                }
                let vidarr = saveCheckList.map(val=>{
                        console.log('++++++++=val',typeof val);
                        console.log('++++++++=val', val);
                        console.log('++++++++=val.length', val.length);
                        return val.vid
                })
                vidarr = vidarr.filter(val=>{
                    return val
                })
                console.log('++++++++=vidarr',vidarr);
                let vidstr = vidarr.join()
                console.log('++++++++++++++++++++++++vidstr',vidstr);
//                ----------
                if(this.selectFileList == '1' && _self.meetingSummaryType != '3'){
                    this.summaryFile = this.oneCheckFile;
                    let summaryId = 0;
                    if(this.oneCheckFile.vid != undefined){
                        summaryId = this.oneCheckFile.vid;
                    }
                    selectMeetingResource({meetId:_self.meetDetails.meetId,summaryId:summaryId}).then(function (rsp) {
                        if (rsp.success) {
                            _self.$message.success('会议纪要文件保存成功')
                        } else {
                            _self.$message.error(rsp.message);
                        }
                    })
                } else if(this.selectFileList == '1' && _self.meetingSummaryType == '3'){
                    _self.sceneFile = _self.imgCheckFile;
                    console.log('sceneFile=',_self.sceneFile);
                    _self.callBackFlag = false
                    selectMeetingResource({meetId:_self.meetDetails.meetId,coverId:_self.sceneFile.coverId,cover:_self.sceneFile.cover,thumb:_self.sceneFile.videoImg}).then(function (rsp) {
                        if (rsp.success) {
                            _self.$message.success('封面保存成功')
                        } else {
                            _self.$message.error(rsp.message);
                        }
                    })
                }else if(this.selectFileList == '2'){
                    selectMeetingResource({meetId:_self.meetDetails.meetId,attachment:vidstr}).then(function (rsp) {
                        if (rsp.success) {
                            _self.$message.success('会议资源文件保存成功')
                        } else {
                            _self.$message.error(rsp.message);
                        }
                    })
                }

                let transFileList = [];
                for(let i = 0;this.saveCheckList.length > i;i ++){
                    if(this.saveCheckList[i] != ''&& this.saveCheckList [i]!= undefined ){
                        let n = {};
                        console.log('this.saveCheckList[i].zyType',this.saveCheckList[i])
                        n.zyType = this.saveCheckList[i].zyType;
                        n.title = this.saveCheckList[i].title;
                        n.docType = this.saveCheckList[i].docType;
                        console.log('n.zyType',n.zyType)
                        console.log('n.title',n.title)
                        transFileList.push(n);
                    }
                }
                this.transFileList = transFileList
            },
            saveCover:function () {
                let _self = this
                if(!_self.callBackFlag){
                    _self.clickSaveFlag = true
                    _self.loadingShow = true
                } else {
                    //解决赋值一次后对象的地址引用问题（表现出数据绑定) 此方法会覆盖第一个对象的其他属性 原原本本与后面的对象相同
                    //另一种写法：Object.assign(_self.sceneFile, _self.localFile, ...); 此方法不会覆盖第一个对象的其他属性
                    _self.sceneFile = Object.assign({}, _self.localFile)
                    console.log("cover=",_self.sceneFile,","+_self.meetDetails.meetId)
                    selectMeetingResource({meetId:_self.meetDetails.meetId,coverId:_self.sceneFile.coverId,
                        cover:_self.sceneFile.cover,thumb:_self.sceneFile.videoImg}).then(function (rsp) {
                        if (rsp.success) {
                            _self.$message.success('封面保存成功')
                        } else {
                            _self.$message.error(rsp.message);
                        }
                        _self.uploadShow = false
                        _self.loadingShow = false
                        _self.callBackFlag = false
                        _self.clickSaveFlag = false
                    })
                }
            },
//            cleanCheckMoreFile(check-more-file-list,checkMoreFileVid,checkMoreFileTitle){
//                console.log(check-more-file-list,checkMoreFileVid,checkMoreFileTitle);
//            }
            cleanAllFile(){
                this.moreDetails = '0';
                this.oneCheckFile = '';
                this.moreVideoFile = '';
                this.moreImageFile = '';
                this.addImage = '';
                this.addVideo = '';
                this.addArticle = '';
                this.imgCheckFile = '';
                this.uploadShow = false
                this.loadingShow = false
                this.callBackFlag = false
                this.clickSaveFlag = false
            },
            uploadLocalFile:function () { //点击上传本地
                this.uploadShow = true
            },
            cancelLocalSelect:function () {
                this.uploadShow = false
            },
            getUploadParam:function () {
                let _self = this
                generateUploadSign({}).then(function (rsp) {
                    console.log(rsp)
                    if (rsp.success) {
                        _self.uploadParam = rsp.data
                    } else {
                        _self.$message.error(rsp.message);
                    }
                });
            },
            getInitData: function(){
                let _self = this;
                _self.loadData();
                _self.oneCheckFile = '';
                _self.imgCheckFile = '';
                PartyCommittee({partyLevel: 1}).then(function (rsp) {
                    if (rsp.success) {
                        let saveDefaultTreeData = []
                        for (let x = 0; x < rsp.data.length; x++) {
                            let y = {};
                            y.pid = rsp.data[x].pid;
                            y.partyName = rsp.data[x].partyName;
                            saveDefaultTreeData.push(y);
                        }
                        _self.trees = saveDefaultTreeData;
                        console.log('MeetingSection + trees==', saveDefaultTreeData);
                        _self.classChange('公司机关党委');
                        clearInterval(_self.meetingInterval)
                        _self.getUploadParam();
                    } else {
                        _self.$message.error(rsp.message);
                        if("登录失效" == rsp.message){
                            sessionStorage.removeItem("zhdj")
                            setTimeout(function () {
                                let uid = _self.$route.query.uid;
                                getUser({uid:uid}).then(function (rsp) {
                                    console.log(rsp)
                                    if (rsp.success) {
                                        sessionStorage.setItem("zhdj",1)
                                        _self.$message.success("登录成功");
                                    }
                                });
                            },500)
                        }
                    }
                })
            }
        },
        mounted() {
            let _self = this
            _self.meetingInterval = setInterval(function () {
                let zhdj = sessionStorage.getItem("zhdj")
                console.log('zhdj=',zhdj);
                if(zhdj){
                    _self.getInitData();
                }
                _self.retryTimes++
                if(_self.retryTimes > 5){
                    clearInterval(_self.meetingInterval)
                    return
                }
            },500)

            window.onmessage = function(e){
                _self.loadingShow = false
                _self.callBackFlag = true
                e = e || event;
                if (isEmpty(e.data)){
                    return;
                }
                console.log('e.data', e.data);
                var obj = JSON.parse(e.data);
                _self.localFile.coverId = obj.file_id
                _self.localFile.cover = obj.path
                _self.localFile.videoImg = obj.thumb
                _self.localFile.delFlag = obj.is_del
                if(_self.clickSaveFlag){ //点击确定 但是万英还没返回
                    console.log('clickSaveFlag-sceneFile：', _self.sceneFile);
                    _self.sceneFile = Object.assign({}, _self.localFile)
                    selectMeetingResource({meetId:_self.meetDetails.meetId,coverId:_self.sceneFile.coverId,cover:_self.sceneFile.cover,
                        thumb:_self.sceneFile.videoImg}).then(function (rsp) {
                        if (rsp.success) {
                            _self.$message.success('封面保存成功')
                        } else {
                            _self.$message.error(rsp.message);
                        }
                        _self.uploadShow = false
                        _self.loadingShow = false
                        _self.callBackFlag = false
                        _self.clickSaveFlag = false
                    })
                }
            }
        }
    }

</script>
<style lang="less" scoped>
    .meeting-section{
        .meeting-box{
            padding:0 2% 0 2%;
        }
        .epistasis-box{
            line-height:54px;
            span{
                margin-left:2%;
            }
            .el-button{
            border:none;
            }
            .active{
                background-color:#1890ff;
                color:#ffffff;
            }
        }
        .basics-box{
            border-top:2px dashed #ebebeb;
            border-bottom:2px dashed #ebebeb;
            line-height:81px;
            display:flex;
        }
        .basics-box>div{
            flex:1;
            text-align:center;
        }
        .select-search{
            height:54px;
            line-height:54px;
            margin-top:1%;
        }
        .select-search>div:nth-child(1){
             float:left;
             margin-left:2%;
             width:40%;
            .el-date-editor{
                width:422px;
            }
         }
        .select-search>div:nth-child(2){
            float:right;
            margin-right:2%;
            width:15%;
            text-align:right;
        }
        .list-page{
            margin-left:10px;
            margin-right:10px;
            height:56px;
        }
        .list-page>span{
            float:left;
            margin-top:10px;
            line-height:32px;
        }
        .list-page>div{
            float:right;
            margin-top:10px;
        }
        .details-box{
            width:96%;
            float:left;
        }
        .details-header{
            width:100%;
            border-bottom:1px solid #ebebeb;
            height:54px;
            span{
                margin-left:2%;
                line-height:54px;
            }
        }
        .el-icon-close{
            margin-right:2%;
            float:right;
            font-size: 24px;
            line-height:54px;
            cursor:pointer;
        }
        .details-box>ul>li{
            list-style:none;
        }
        .details-box>ul>li>span{
            line-height:54px;
            height:54px;
            width:48%;
            display:inline-block;
            margin-top:1%;
            b{
                font-weight:normal;
                color:#1890ff;
            }
            i{
                font-style:normal;
                display:inline-block;
                line-height:54px;
            }
        }
        .details-box>ul>li>div{
            width:100%;
            height:90px;
            margin:1% 0;
            span{
                line-height:90px;
                b{
                    font-weight:normal;
                    color: #858585;
                }
            }
        }
        .alert-box{
            height:100%;
            width:100%;
            background-color:rgba(0,0,0,0.6);
            position:fixed;
            top:0;
            left:0;
            z-index:2;
        }
        .attendance-box{
            height:704px;
            min-width:720px;
            max-width:80%;
            background-color:white;
            margin: 3% auto;
        }
        .attendance-header{
            height:54px;
            width:100%;
            border-bottom:1px solid #ebebeb;
            padding-left:3%;
            h3{
                margin:0;
                line-height:54px;
                display:inline-block;
            }
        }
        .atendance-totail{
            margin:0;
            height:39px;
            display:flex;
            width:100%;
            b{
                flex:1;
                line-height:39px;
                text-align:center;
                font-weight:normal;
            }
        }
        .atendance-details{
            border-bottom:1px solid #ebebeb;
        }
        .atendance-list {
            width: 100%;
            height: 500px;
            .atendance-header,.atendance-section {
                height: 39px;
                display: flex;
                span {
                    flex: 1;
                    display: inline-block;
                    line-height: 36px;
                    text-align: center;
                    img{
                        margin-left:9px;
                        height:27px;
                        width:27px;
                    }
                }
            }
        }
        .atendance-footer{
            margin-right:2%;
            margin-top:10px;
            height:54px;
            line-height:54px;
            float:right;
        }
        .atendance-section-box{
            border:none;
            height:464px;
            overflow-y:auto;
            border-bottom:1px solid #ebebeb;

            div:nth-child(2n){
                background-color:#f9f9f9;
            }
        }

        .file-box{
            height:804px;
            min-width:420px;
            max-width:80%;
            background-color:white;
            margin: 4% auto;
        }
        .file-header{
            height:54px;
            border-bottom:1px solid #ebebeb;
            max-width:100%;
            min-width:80%;
            span{
                height:53px;
                display:inline-block;
                line-height:53px;
                font-size:16px;
                min-width:108px;
                max-width:20%;
                background-color:white;
                text-align:center;
                margin-left:2%;
                cursor:pointer;
            }
            .fileActive{
                background-color:#cccccc;
            }
        }
        .file-title{
            height:36px;
            line-height:36px;
            border-bottom:1px solid #ebebeb;
            span{
                margin-left:2%;
            }
        }
        .file-list{
            height:568px;
            border-bottom:1px solid #ebebeb;
            background-color:white;
        }
        .file-page{
            margin-left:10px;
            margin-right:10px;
            height:56px;
            margin-top:10px;
        }
        .file-page>span{
            float:left;
            margin-top:10px;
            line-height:32px;
        }
        .file-page>div{
            float:right;
            margin-top:10px;
        }
        .el-date-editor{
            width:210px !important;
        }
        .icon-box{
            margin-left:5px;
            float:left;
            width:475px;
            height:25px;
            img{
                display:inline-block;
                margin-top:-13px;
                padding-left:-10px;
                height:23px;
                width:23px;
            }
            span{
                display:inline-block;
                width:435px;
                overflow: hidden;
                white-space: nowrap;
                text-overflow: ellipsis;
            }
        }
        .check-relation-file{
            display:inline-block;
            height:80px;
            margin-left:10px;
            font-size:16px;
            position:relative;
            b{
                font-weight:normal;
                color:#919191;
                line-height:81px;
                height:80px;
                float:left;
                width:100px;
                text-align:center;
            }
            .delete-more-file-icon{
                display:inline-block;
                position:absolute;
                right:0;
                top:0;
                font-size:16px;
                line-height:80px;
                color:#ff001e;
                cursor:pointer;
            }
        }
        .upload-file{
            height:24px;
            margin:0 10px 0 10px;
        }
        .check-file-box{
            display:inline-block;
            line-height:81px;
            position:relative;
            img{
                height:27px;
                width:27px;
                float:left;
                margin-top:27px;
            }
            p{
                display:inline-block;
                line-height:81px;
                font-size:14px;
                margin:0 0 0 3px;
                width:320px;
                overflow: hidden;
                white-space: nowrap;
                text-overflow: ellipsis;
            }
            .el-icon-circle-close-outline{
                margin-left:15px;
                font-size:14px;
                line-height:81px;
                color:#ff001e;
                cursor:pointer;
                display:inline-block;
                position:absolute;
                top:0;
                right:-10px
            }
        }
        .checkMoreFileBox{
            padding:0;
            margin:0;
            height:32px;
            width:210px;
            display:inline-block;
            background-color:skyblue;
        }
        .more-file-list-box{
            margin-left:5px;
            height:80px;
            width:600px;
            display:inline-block;
            .more-file-box{
                width:175px;
                height:35px;
                float:left;
                margin:5px 20px 0 0;
                position:relative;
                img{
                    margin-top:4px;
                    height:27px;
                    width:27px;
                    display:inline-block;
                    float:left;
                }
                p{
                    padding-left:5px;
                    line-height:35px;
                    font-size:14px;
                    margin:0;
                    width:145px;
                    white-space: nowrap;
                    overflow: hidden;
                    text-overflow: ellipsis;
                }
                .el-icon-circle-close-outline{
                    font-size:16px;
                    line-height:35px;
                    color:#ff001e;
                    cursor:pointer;
                    float:right;
                }
                i{
                    position:absolute;
                    right:0;
                    top:0;
                }
            }
        }
        .authority-box{
            position:fixed;
            top:0;
            left:0;
            width:100%;
            height:100%;
            background:rgba(0,0,0,0.6);
            z-index:10;
                .authority-content{
                    height:760px;
                    width:560px;
                    background-color:white;
                    margin:3% auto;
                    .authority-header{
                        height:54px;
                        width:100%;
                        border-bottom:1px solid #f1f1f1;
                        span{
                            line-height:54px;
                            font-size:16px;
                            margin-left:12px;
                        }
                    }
                }


        }
        .tree-list{
            width:100%;
            height:651px;
            display:inline-block;
            overflow:auto;
            border-bottom:1px solid #f0f0f0;
            .input-box{
                width:80%;
                margin:0 auto 10px auto;
                padding-top:3%;
            }
        }
        .authority-footer{
            height:50px;
            float:right;
            margin-right:10px;
            margin-top:4px;
        }
        .check-one-file-list{
            height:90px;
            font-weight:normal;
            img{
                height:24px;
            }
            p{
                display:inline-block;
                /*width:60%;*/
                line-height:23px;
            }
        }
        .check-more-file-list{
            float:left;
            max-width:270px;
            min-width:210px;
            height:42px;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
            img{
                float:left;
                height:24px;
                width:24px;
                margin-top:9px;
                margin-left:4px;
            }
            span{
                margin-left:5px;
                display:inline;
                line-height:42px;
                max-width:240px;
                min-width:120px;
                font-weight:normal;
            }
        }
        .check-more-file-box{
            margin-left:5px;
            display:inline-block;
            width:80%;
            height:90px;
            float:left;
        }
        .topics-box{
            display:block;
            line-height:54px;
            margin-top:1%;
            font-weight:normal;
        }


}
</style>
