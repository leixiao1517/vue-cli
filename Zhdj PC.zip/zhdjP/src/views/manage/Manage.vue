<template>
    <section class="manage" style="padding:0;margin:0;">
        <el-tabs v-model="tabType" @tab-click="changeTab()">
            <el-tab-pane label="党员管理" name="1"></el-tab-pane>
            <el-tab-pane label="会议服务" name="2"></el-tab-pane>
        </el-tabs>
        <div class="content-box">
            <router-view></router-view>
        </div>
    </section>
</template>

<script>
    import $ from 'jquery'
    import {getUser} from '../../api/api.js'

    export default {
        components: {
        },
        data() {
            return {
                uid:'',
                tabType:'1',
            }
        },
        methods: {
            changeTab:function () {
                let _self = this
                console.log(_self.tabType)
                if (_self.tabType === '1'){
                    this.$router.replace('/manage/party?uid=' + _self.uid);
                } else if (_self.tabType === '2'){
                    this.$router.replace('/manage/meeting?uid=' + _self.uid);
                }
            },
            getUser:function (uid) {
                sessionStorage.removeItem("zhdj")
                let _self = this

                let curPathName = this.$route.name;
                if(curPathName === 'meeting'){
                    this.tabType = '2';
                } else {
                    this.tabType = '1';
                }

                getUser({uid:uid}).then(function (rsp) {
                    console.log(rsp)
                    if (rsp.success) {
                    	sessionStorage.setItem("zhdj",1)
                        _self.$message.success(rsp.message);
                    } else {
                        _self.$message.error(rsp.message);
                    }
                });
            }
        },
        mounted(){
            this.uid = this.$route.query.uid;
            this.getUser(this.uid)
        }
    };
</script>
<style lang="less" scoped>
    .manage{
        .el-tabs{
            padding-left: 10px;
        }
        .tab-box{
            height:56px;
            ul{
                float:left;
                width:100%;
                height:56px;
                margin:0;
                padding:0;
            }
            ul>li{
                display:inline-block;
                font-style:normal;
                text-align:center;
                font-size:100%;
                line-height:56px;
                width:96px;
                margin-right:1%;
                background-color:#f2f2f2;
                border-bottom:1px solid #efeff4;
                cursor:pointer;

            }
            .active{
                background-color:#ffffff;
                color:#b81c24;
            }
        }
        .content-box{
            background-color:#ffffff;
        }
    }
</style>
