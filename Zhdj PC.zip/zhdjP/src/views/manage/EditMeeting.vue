<template>
    <div class="edit-meeting">
        <!-- 编辑弹框区 -->
        <el-dialog title="编辑" :visible.sync="meetingFlag">
            <el-form :model="meeting" label-position="right">
                <el-col :span="24">
                    <el-form-item label="会议标题" :label-width="formLabelWidth">
                        <el-input v-model="meeting.title" autocomplete="off" clearable></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="24">
                    <el-form-item label="开始时间" :label-width="formLabelWidth">
                        <el-date-picker type="datetime" placeholder="选择日期" v-model="meeting.startDate" :value-format="dateFormatStr" :format="dateFormatStr"></el-date-picker>
                    </el-form-item>
                    <el-form-item label="结束时间" :label-width="formLabelWidth">
                        <el-date-picker type="datetime" placeholder="选择日期" v-model="meeting.endDate" :value-format="dateFormatStr" :format="dateFormatStr"></el-date-picker>
                    </el-form-item>
                </el-col>
                <el-col :span="24">
                    <el-form-item label="会议类型" :label-width="formLabelWidth">
                        <el-checkbox-group v-model="meetingType">
                            <el-checkbox label="支部党员大会" name="支部党员大会"></el-checkbox>
                            <el-checkbox label="党支部委员会" name="党支部委员会"></el-checkbox>
                            <el-checkbox label="支部主题党日" name="支部主题党日"></el-checkbox>
                            <el-checkbox label="党小组会" name="党小组会"></el-checkbox>
                            <el-checkbox label="组织生活会" name="组织生活会"></el-checkbox>
                            <el-checkbox label="民主评议" name="民主评议"></el-checkbox>
                            <el-checkbox label="评选表彰" name="评选表彰"></el-checkbox>
                            <el-checkbox label="书记述职" name="书记述职"></el-checkbox>
                            <el-checkbox label="党课" name="党课"></el-checkbox>
                            <el-checkbox label="其他" name="其他"></el-checkbox>
                        </el-checkbox-group>
                    </el-form-item>
                </el-col>
                <el-col :span="24">
                    <el-form-item label="活动内容" :label-width="formLabelWidth">
                            <tinymce-editor v-model="meeting.content" ref="editor"></tinymce-editor>
                    </el-form-item>
                </el-col>
            </el-form>
            <div slot="footer" class="dialog-footer">
                <el-button @click="meetingFlag = false">取 消</el-button>
                <el-button type="primary" @click="saveMeeting()">确 定</el-button>
            </div>
        </el-dialog>
    </div>
</template>

<script>
    import TinymceEditor from '../../components/TinyMce.vue'
    import {getMeetingDetail,saveMeeting} from '../../api/api.js'

    export default{
        name: 'EditMeeting',
        components: {
            TinymceEditor
        },
        data(){
            return{
                formLabelWidth:'100px',
                dateFormatStr:'yyyy-MM-dd HH:mm:ss',
                meetId:Number,
                meetingFlag:false,
                meeting:{},
                meetingType:[],
            }
        },
        methods:{
            show(meetId){
                this.meetId = meetId;
                this.meetingFlag = true;
                this.meetingDialog()
            },
            meetingDialog(){
                let _self = this;
                getMeetingDetail({meetId:this.meetId}).then(function (rsp) {
                    console.log(rsp)
                    if(rsp.success){
                        _self.meeting = rsp.data.meetingDetails;
                        _self.meeting.startDate = new Date(_self.meeting.startDate)
                        _self.meeting.endDate = new Date(_self.meeting.endDate)
                        _self.meetingType = _self.meeting.meetingType.split(",")
                    } else {
                        console.log(rsp.message);
                    }
                })
            },
            saveMeeting:function () {
                let _self = this;
                saveMeeting(_self.meeting).then(function (rsp) {
                    console.log(rsp)
                    if(rsp.success){
                        _self.$message({
                            type: 'success',
                            message: '保存成功'
                        });
                        _self.meetingFlag = false;
                    } else {
                        console.log(rsp.message);
                    }
                })
            }
        },
        mounted(){

        }
    }
</script>
<style lang="less" scoped>
    .edit-meeting {

    }
</style>
