/**
 * Created by hlf on 2017/9/21.
 */
/**
 * 配置编译环境和线上环境之间的切换
 *
 * baseUrl: 域名地址
 * routerMode: 路由模式
 * imgBaseUrl: 图片所在域名地址
 *
 */

let adminServer = 'http://192.168.1.218:8088/be/admin/'
let adminClient = 'http://192.168.1.218:8088/'
let imageRootPath = 'http://192.168.1.218:8081/zhongyan/zhdj/resource/'
let imgFilter = /^(?:image\/bmp|image\/cis\-cod|image\/gif|image\/ief|image\/jpeg|image\/jpeg|image\/jpeg|image\/pipeg|image\/png|image\/svg\+xml|image\/tiff|image\/x\-cmu\-raster|image\/x\-cmx|image\/x\-icon|image\/x\-portable\-anymap|image\/x\-portable\-bitmap|image\/x\-portable\-graymap|image\/x\-portable\-pixmap|image\/x\-rgb|image\/x\-xbitmap|image\/x\-xpixmap|image\/x\-xwindowdump)$/i;


if (process.env.NODE_ENV === 'development') {

} else if (process.env.NODE_ENV === 'production') {
    imageRootPath = 'https://img.zjyou.cn/';
    adminServer = 'https://zhdjt.zjyou.cn/be/admin/'
    adminClient = 'https://zhdjt.zjyou.cn/fe/admin/'
}

export {
    adminServer,
    adminClient,
    imageRootPath,
    imgFilter,
}
