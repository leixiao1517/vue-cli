/**
 * Created by showhand on 2018/12/2.
 */
import Vue from 'vue'
export default new Vue
