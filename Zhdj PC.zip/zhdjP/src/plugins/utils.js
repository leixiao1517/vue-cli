import { dateFormat } from 'vux'
export default{
    install: function (Vue, options) {
        // 格式化时间
        Vue.prototype.zjyDateFormat = function (time,type) {
            let date = '';
            if(type == 'YMD'){
                date = dateFormat(time, 'YYYY-MM-DD');
            } else if (type == 'HMS'){
                date = dateFormat(time, 'HH:mm:ss');
            } else {
                date = dateFormat(time, 'YYYY-MM-DD HH:mm:ss');
            }
            return date;
        }

    },
}

//判断对象是否为null，undefined，或者字符串为空
export const isEmpty = function (obj){
    if (obj === null) return true;
    if (typeof obj === 'undefined') {
        return true;
    }
    if (typeof obj === 'string') {
        if (obj === "") {
            return true;
        }
        // var reg = new RegExp("^([ ]+)|([　]+)$");   判断是否为空格
        // return reg.test(obj);
    }
    return false;
}
